import React from 'react';
import { Box, Typography } from '@mui/material';
import { useTranslation } from 'react-i18next';

const COLORS = {
  healthy: { glow: '#39FF88', text: '#0B3D24', bg: 'rgba(57,255,136,0.15)' },
  unhealthy: { glow: '#FF3B5C', text: '#4A0A16', bg: 'rgba(255,59,92,0.15)' },
  checking: { glow: '#FFC93B', text: '#4A3A0A', bg: 'rgba(255,201,59,0.15)' },
};

// Neon-style glowing pill for the login page's health status, placed directly
// under the login button. healthy = green, unhealthy = red, checking = amber/pulsing.
export default function NeonStatusPill({ status = 'checking' }) {
  const { t } = useTranslation();
  const c = COLORS[status] || COLORS.checking;
  const label = status === 'healthy' ? t('common.healthy') : status === 'unhealthy' ? t('common.unhealthy') : t('common.checkingHealth');

  return (
    <Box
      sx={{
        display: 'inline-flex', alignItems: 'center', gap: 1,
        px: 2, py: 0.6, borderRadius: 999,
        bgcolor: c.bg,
        border: `1px solid ${c.glow}`,
        boxShadow: `0 0 8px ${c.glow}, 0 0 16px ${c.glow}55`,
        animation: status === 'checking' ? 'neon-pulse 1.4s ease-in-out infinite' : 'none',
        '@keyframes neon-pulse': {
          '0%, 100%': { opacity: 1 },
          '50%': { opacity: 0.5 },
        },
      }}
    >
      <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: c.glow, boxShadow: `0 0 6px ${c.glow}` }} />
      <Typography sx={{ fontSize: '0.75rem', fontWeight: 700, letterSpacing: '0.03em', color: c.glow }}>
        {label}
      </Typography>
    </Box>
  );
}
