import { useMediaQuery, useTheme } from '@mui/material';

// Shared breakpoint check for "should this listing render as cards instead
// of a table?" — mobile only (below `sm`), never on tablet/desktop.
// See tempmem.md section 5. Every list table in the app must use this same
// check rather than inventing its own breakpoint.
export function useIsMobileListView() {
  const theme = useTheme();
  return useMediaQuery(theme.breakpoints.down('sm'));
}
