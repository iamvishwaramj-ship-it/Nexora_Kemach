import React from 'react';
import { Card, CardContent, Stack, Box, Typography, IconButton, Divider } from '@mui/material';
import EditIcon from '@mui/icons-material/EditOutlined';
import DeleteIcon from '@mui/icons-material/DeleteOutline';
import VisibilityIcon from '@mui/icons-material/VisibilityOutlined';
import { usePermissions } from '../../lib/permissions';

/**
 * MobileRecordCard — the mobile ("xs"/below `sm`) stand-in for a table row.
 * Every listing table in the app collapses into a stack of these below the
 * `sm` breakpoint instead of a horizontally-scrolled table — see tempmem.md
 * section 5.
 *
 * title: primary field shown as the card heading (usually the row's name/code)
 * fields: [{ label, value }] rendered as stacked label/value pairs
 * statusChip: optional node (e.g. a MUI <Chip />) shown next to the title
 * onEdit/onDelete/onView: optional row action handlers, receive the row
 */
export default function MobileRecordCard({ title, fields = [], statusChip, onEdit, onDelete, onView }) {
  // Row actions follow the signed-in user's menu permissions for whichever page
  // this card is rendered on. Gating here covers every mobile list at once; the
  // desktop tables gate their own icon buttons the same way.
  const { canEdit, canDelete } = usePermissions();
  const showEdit = onEdit && canEdit;
  const showDelete = onDelete && canDelete;
  const hasActions = showEdit || showDelete || onView;

  return (
    <Card variant="outlined" sx={{ mb: 1.5 }}>
      <CardContent sx={{ p: 2, '&:last-child': { pb: 2 } }}>
        <Stack direction="row" alignItems="flex-start" justifyContent="space-between" spacing={1}>
          <Typography variant="subtitle2" fontWeight={700} sx={{ wordBreak: 'break-word' }}>
            {title}
          </Typography>
          {statusChip}
        </Stack>

        <Stack spacing={0.75} sx={{ mt: 1.5 }}>
          {fields.map((f) => (
            <Stack key={f.label} direction="row" justifyContent="space-between" spacing={2}>
              <Typography variant="caption" color="text.secondary" sx={{ flexShrink: 0 }}>{f.label}</Typography>
              <Typography variant="body2" sx={{ textAlign: 'right', wordBreak: 'break-word' }}>{f.value ?? '—'}</Typography>
            </Stack>
          ))}
        </Stack>

        {hasActions && (
          <>
            <Divider sx={{ my: 1.5 }} />
            <Stack direction="row" spacing={0.5} justifyContent="flex-end">
              {onView && (
                <IconButton size="small" onClick={onView} aria-label="view">
                  <VisibilityIcon fontSize="small" />
                </IconButton>
              )}
              {showEdit && (
                <IconButton size="small" color="primary" onClick={onEdit} aria-label="edit">
                  <EditIcon fontSize="small" />
                </IconButton>
              )}
              {showDelete && (
                <IconButton size="small" color="error" onClick={onDelete} aria-label="delete">
                  <DeleteIcon fontSize="small" />
                </IconButton>
              )}
            </Stack>
          </>
        )}
      </CardContent>
    </Card>
  );
}

// Shared hook so every page checks the same breakpoint the same way.
export { useIsMobileListView } from './useIsMobileListView';
