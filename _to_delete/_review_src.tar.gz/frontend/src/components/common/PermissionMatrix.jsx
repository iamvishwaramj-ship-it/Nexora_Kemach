import React, { useMemo, useState } from 'react';
import {
  Box, TextField, InputAdornment, IconButton, Table, TableBody, TableCell, TableHead, TableRow,
  Checkbox, Typography,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import ClearIcon from '@mui/icons-material/Close';
import { Controller, useFormContext } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import ScrollableTableContainer from '../data-display/ScrollableTableContainer';
import { flatNav } from '../../router/navConfig';
import { useFormReadOnly } from '../form/AppForm';

// Section rows that are pure navigation (a card-grid landing page — Company,
// Reports > Sales, ...) or a page with genuinely no add/edit/delete concept
// of its own (Dashboard, every individual report under Reports, Settings)
// only ever carry View — matches the reference design's Dashboard/
// Organization rows, which show "—" instead of a checkbox for the three
// columns that don't apply there.
function isViewOnly(node) {
  if (node.isParent) return true;
  if (node.key === 'dashboard' || node.key === 'settings') return true;
  // Every leaf under Reports (Enquiry Register, Stock Valuation, ...) is a
  // read-only register/analysis with no add/edit/delete of its own.
  if (node.trail.some((n) => n.key === 'reports')) return true;
  return false;
}

function navLabel(node, t) {
  return node.labelKey?.startsWith('nav.') ? t(node.labelKey) : node.labelKey;
}

/**
 * Seeds a `permissions` form field with one row per navConfig entry — every
 * top-level section AND every submenu beneath it, at full depth (Reports'
 * individual report pages included) — carrying over an existing user's
 * saved flags where a menuKey matches, and defaulting a menu item the user
 * has never been granted anything on to all-false.
 *
 * The row order always follows flatNav, and PermissionMatrix addresses each
 * row by that same flatNav index — the two must never seed from different
 * orderings or a row's checkboxes would end up controlling a different
 * menu item than the label next to them claims.
 */
export function buildPermissionRows(existingPermissions = []) {
  const byKey = new Map((existingPermissions || []).map((p) => [p.menuKey, p]));
  return flatNav.map((node) => {
    const existing = byKey.get(node.key);
    return {
      menuKey: node.key,
      canView: existing ? !!existing.canView : false,
      canAdd: existing ? !!existing.canAdd : false,
      canEdit: existing ? !!existing.canEdit : false,
      canDelete: existing ? !!existing.canDelete : false,
    };
  });
}

function ActionCheckbox({ name, disabled }) {
  const readOnly = useFormReadOnly();
  const { control } = useFormContext();
  if (disabled) {
    return (
      <Typography variant="body2" color="text.disabled" align="center" component="span">
        —
      </Typography>
    );
  }
  return (
    <Controller
      name={name}
      control={control}
      render={({ field }) => (
        <Checkbox
          size="small"
          checked={!!field.value}
          disabled={readOnly}
          onChange={(e) => field.onChange(e.target.checked)}
        />
      )}
    />
  );
}

// "All" isn't its own stored flag — it's a convenience toggle over the row's
// real columns, so it reads/writes them directly instead of being a field of
// its own. For a view-only row (see isViewOnly above) the only real column IS
// View, so All and View end up mirroring each other there, same as the
// reference design's Dashboard/Organization rows showing both as live,
// independently-clickable checkboxes.
function AllCheckbox({ baseName, viewOnly }) {
  const readOnly = useFormReadOnly();
  const { watch, setValue } = useFormContext();
  const row = watch(baseName) || {};
  const checked = viewOnly
    ? !!row.canView
    : !!(row.canView && row.canAdd && row.canEdit && row.canDelete);

  const handleChange = (e) => {
    const next = e.target.checked;
    setValue(`${baseName}.canView`, next, { shouldDirty: true, shouldValidate: true });
    if (!viewOnly) {
      setValue(`${baseName}.canAdd`, next, { shouldDirty: true, shouldValidate: true });
      setValue(`${baseName}.canEdit`, next, { shouldDirty: true, shouldValidate: true });
      setValue(`${baseName}.canDelete`, next, { shouldDirty: true, shouldValidate: true });
    }
  };

  return <Checkbox size="small" checked={checked} disabled={readOnly} onChange={handleChange} />;
}

/**
 * Menu-based permission grid — one row per section AND submenu (navConfig,
 * full depth), View/Add/Edit/Delete + a convenience All column per row, and a
 * search box to find a section in a ~95-row list. Bind it to a form field
 * (default name "permissions") seeded via buildPermissionRows() above.
 */
export default function PermissionMatrix({ name = 'permissions' }) {
  const { t } = useTranslation();
  const { formState: { errors } } = useFormContext();
  const [search, setSearch] = useState('');

  // zodResolver puts an array-level .refine() error either directly on the
  // field (`errors.permissions.message`) or nested under `.root`, depending
  // on resolver version — check both rather than assume one shape.
  const fieldError = errors?.[name];
  const errorMessage = fieldError?.message || fieldError?.root?.message;

  const q = search.trim().toLowerCase();
  const visibleIndices = useMemo(() => {
    const indices = flatNav.map((_, i) => i);
    if (!q) return indices;
    return indices.filter((i) => navLabel(flatNav[i], t).toLowerCase().includes(q));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q]);

  return (
    <Box>
      {errorMessage && (
        <Typography variant="body2" color="error.main" fontWeight={500} sx={{ mb: 1 }}>
          {errorMessage}
        </Typography>
      )}
      <TextField
        size="small"
        fullWidth
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        placeholder="Search sections..."
        sx={{ mb: 1.5 }}
        InputProps={{
          startAdornment: (
            <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment>
          ),
          endAdornment: search ? (
            <InputAdornment position="end">
              <IconButton size="small" onClick={() => setSearch('')} aria-label="clear search">
                <ClearIcon fontSize="small" />
              </IconButton>
            </InputAdornment>
          ) : null,
        }}
      />
      <ScrollableTableContainer
        maxHeight="clamp(280px, 46vh, 460px)"
        sx={{ border: '1px solid', borderColor: 'divider', borderRadius: 1 }}
      >
        <Table size="small" stickyHeader>
          <TableHead>
            <TableRow>
              <TableCell>Section</TableCell>
              <TableCell align="center">View</TableCell>
              <TableCell align="center">Add</TableCell>
              <TableCell align="center">Edit</TableCell>
              <TableCell align="center">Delete</TableCell>
              <TableCell align="center">All</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {visibleIndices.map((i) => {
              const node = flatNav[i];
              const label = navLabel(node, t);
              const depth = node.trail.length - 1;
              const viewOnly = isViewOnly(node);
              const baseName = `${name}.${i}`;
              return (
                <TableRow key={node.key} hover>
                  <TableCell sx={{ pl: 2 + depth * 2.5 }}>
                    <Typography variant="body2" fontWeight={node.isParent ? 700 : 400}>
                      {label}
                    </Typography>
                  </TableCell>
                  <TableCell align="center"><ActionCheckbox name={`${baseName}.canView`} /></TableCell>
                  <TableCell align="center"><ActionCheckbox name={`${baseName}.canAdd`} disabled={viewOnly} /></TableCell>
                  <TableCell align="center"><ActionCheckbox name={`${baseName}.canEdit`} disabled={viewOnly} /></TableCell>
                  <TableCell align="center"><ActionCheckbox name={`${baseName}.canDelete`} disabled={viewOnly} /></TableCell>
                  <TableCell align="center"><AllCheckbox baseName={baseName} viewOnly={viewOnly} /></TableCell>
                </TableRow>
              );
            })}
            {visibleIndices.length === 0 && (
              <TableRow>
                <TableCell colSpan={6}>
                  <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 2 }}>
                    No sections match your search
                  </Typography>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </ScrollableTableContainer>
    </Box>
  );
}
