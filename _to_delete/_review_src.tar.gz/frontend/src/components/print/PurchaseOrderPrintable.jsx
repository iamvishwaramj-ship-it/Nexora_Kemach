import React from 'react';
import dayjs from 'dayjs';
import BadgeOutlinedIcon from '@mui/icons-material/BadgeOutlined';
import PhoneOutlinedIcon from '@mui/icons-material/PhoneOutlined';
import EmailOutlinedIcon from '@mui/icons-material/EmailOutlined';
import LanguageOutlinedIcon from '@mui/icons-material/LanguageOutlined';
import Inventory2OutlinedIcon from '@mui/icons-material/Inventory2Outlined';
import LocationOnOutlinedIcon from '@mui/icons-material/LocationOnOutlined';
import DescriptionOutlinedIcon from '@mui/icons-material/DescriptionOutlined';
import AccountBalanceOutlinedIcon from '@mui/icons-material/AccountBalanceOutlined';
import CurrencyRupeeOutlinedIcon from '@mui/icons-material/CurrencyRupeeOutlined';
import GavelOutlinedIcon from '@mui/icons-material/GavelOutlined';
import { amountToWords } from '../../lib/numberToWords';
import { buildDocument, round2, isInterState, taxComponentRows } from '../../lib/documentTotals';

// Fixed letterhead brand colors — matching the reference Purchase Order
// document exactly (navy + orange). These stay constant regardless of the
// app's active UI theme, the same way a real company's letterhead doesn't
// change color when someone switches their screen to dark mode.
const NAVY = '#0B1E3D';
const ORANGE = '#F15A24';

// Header row column sizing — three independently tunable columns sitting
// side by side: the logo, the company/address block, and the PURCHASE
// ORDER box. Adjust these to rebalance the header without touching any
// other layout rule.
const HEADER_LOGO_WIDTH = 150;   // px — fixed width of the logo column
const HEADER_LOGO_HEIGHT = 'auto';    // px (number) or 'auto' — fixed/min height of the logo column
const HEADER_COMPANY_FLEX = 2;   // flex-grow — company name/address column width
const HEADER_COMPANY_HEIGHT = 'auto'; // px (number) or 'auto' — fixed/min height of the company column
const HEADER_ORDER_FLEX = 5;   // flex-grow — PURCHASE ORDER box column width
const HEADER_ORDER_HEIGHT = 'auto';   // px (number) or 'auto' — fixed/min height of the order box column

// Logo image size — set independently from HEADER_LOGO_WIDTH above (that one
// sizes the column itself; these two size the actual <img>).
const LOGO_IMAGE_WIDTH = 'auto';  // px (number) or 'auto' — logo image width
const LOGO_IMAGE_HEIGHT = 50;     // px — logo image height

// Helper: turns a HEADER_*_HEIGHT value ('auto' or a number of px) into a
// CSS min-height declaration (or nothing, when left as 'auto').
const colMinHeight = (h) => (h === 'auto' || h == null ? '' : `min-height: ${h}px;`);
const pxOrAuto = (v) => (v === 'auto' || v == null ? 'auto' : `${v}px`);

const fmtDate = (d) => (d ? dayjs(d).format('DD/MM/YYYY') : '—');
const fmtMoney = (n) => `₹ ${(Number(n) || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

// Totals come from the shared engine in lib/documentTotals.js — the same
// module the form uses and a behavioural mirror of the server's own.
//
// Each template used to carry a private re-implementation of this arithmetic
// "so the printed totals always match what's shown/saved on the form". They
// stopped matching. The copies here never rounded per line, so a printed
// total could sit a few paise off the stored header, and none of them could
// represent IGST — an inter-state document printed a CGST/SGST split that its
// own database row does not have.
function computeTotals(items, discountPercent, interState = false) {
  const { totals } = buildDocument(items, discountPercent, { interState, roundOff: true });
  return {
    ...totals,
    discount: round2(totals.subtotal - totals.taxableAmount),
    grandTotal: totals.amount,
  };
}

/**
 * A formal, letterhead-style printable Purchase Order document. Only ever
 * rendered inside a `.po-print-area` wrapper that's invisible on screen and
 * shown exclusively via the `@media print` rules below — the interactive
 * form itself never gets printed directly.
 */
export default function PurchaseOrderPrintable({ order, company, supplierRecord, branchRecord, buyingBranchRecord, houseBankRecord }) {
  const navy = NAVY;
  const accent = ORANGE;

  if (!order) return null;

  const items = order.items || [];
  const interState = isInterState(order.placeOfSupply, company?.state);
  const totals = computeTotals(items, order.discountPercent, interState);
  const roundOff = totals.roundOff;
  const finalTotal = totals.grandTotal;
  const discPct = Number(order.discountPercent) || 0;

  const taxRows = taxComponentRows(totals, interState);

  const companyAddrLine2 = [company?.city, company?.state, company?.pincode].filter(Boolean).join(', ');
  const companyName = (company?.companyName || 'Nexora KEMACH').toUpperCase();

  const deliveryName = order.shipTo || company?.companyName || '—';
  const deliveryAddr = branchRecord?.address || company?.address || '';
  const deliveryLine2 = branchRecord
    ? [branchRecord.city, branchRecord.state, branchRecord.zipCode].filter(Boolean).join(', ')
    : companyAddrLine2;
  const deliveryPhone = branchRecord?.phone || company?.phone;
  const deliveryEmail = branchRecord?.email || company?.email;

  const supplierAddrLine2 = [supplierRecord?.city, supplierRecord?.state].filter(Boolean).join(', ');

  const buyingBranchLabel = buyingBranchRecord?.branchName || order.buyingBranch || '—';

  // Bank details for the NEFT/RTGS box — prefer the resolved HouseBank
  // record; fall back to splitting the denormalized "Bank - AccountNo"
  // string stored on the order if the record can't be resolved (e.g. the
  // house bank was deleted after being selected).
  const [fallbackBankName, fallbackAccountNo] = String(order.bankAccount || '').split(' - ');
  const bankName = houseBankRecord?.bankName || fallbackBankName || '—';
  const accountNumber = houseBankRecord?.accountNumber || fallbackAccountNo || '—';
  const accountName = houseBankRecord?.accountName || company?.companyName || '—';
  const ifscCode = houseBankRecord?.ifscCode || '—';
  const bankBranch = houseBankRecord?.branchName || '—';
  const hasBankDetails = Boolean(order.bankAccount || houseBankRecord);

  return (
    <div className="po-print-area">
      <style>{`
        .po-print-area { display: none; }
        @media print {
          body * { visibility: hidden; }
          .po-print-area, .po-print-area * { visibility: visible; }
          .po-print-area {
            display: block; position: absolute; top: 0; left: 0; width: 100%;
            padding: 8mm; box-sizing: border-box;
          }
          @page { size: A4; margin: 8mm; }
        }
        .po-sheet { font-family: Arial, Helvetica, sans-serif; color: #1a1a1a; font-size: 11px; }
        .po-topbar { height: 5px; background: linear-gradient(90deg, ${navy} 0%, ${accent} 100%); border-radius: 2px; margin-bottom: 8px; }
        .po-header-row { display: flex; align-items: stretch; border: 1px solid ${accent}; border-radius: 4px; overflow: hidden; margin-bottom: 10px; }
        .po-logo-col {
          flex-shrink: 0; width: ${HEADER_LOGO_WIDTH}px; ${colMinHeight(HEADER_LOGO_HEIGHT)} display: flex; flex-direction: column;
          align-items: center; justify-content: center; gap: 8px; padding: 14px 12px; text-align: center;
        }
        .po-logo-mark { width: ${pxOrAuto(LOGO_IMAGE_WIDTH)}; height: ${pxOrAuto(LOGO_IMAGE_HEIGHT)}; object-fit: contain; }
        .po-header-divider { width: 1px; background: #e2e2e2; margin: 18px 0; flex-shrink: 0; }
        .po-company-col { flex: ${HEADER_COMPANY_FLEX}; ${colMinHeight(HEADER_COMPANY_HEIGHT)} padding: 14px 16px; }
        .po-brand-name { font-size: 14px; font-weight: 800; letter-spacing: 0.3px; color: ${navy}; margin-bottom: 4px; }
        .po-tagline { font-size: 9px; color: #999; font-style: italic; margin-bottom: 8px; white-space: nowrap; }
        .po-company-lines > div.addr { line-height: 1.5; color: #333; font-weight: 600; }
        .po-company-icons { margin-top: 8px; display: flex; flex-direction: column; gap: 5px; }
        .po-company-icons .item {
          display: grid; grid-template-columns: 18px 78px 10px 1fr; align-items: center; column-gap: 8px; color: #333;
        }
        .po-company-icons .item .colon { color: #333; }
        .po-icon-dot {
          width: 18px; height: 18px; border-radius: 50%; background: ${accent}; color: #fff;
          display: flex; align-items: center; justify-content: center; flex-shrink: 0;
        }
        .po-icon-dot svg { font-size: 12px; width: 12px; height: 12px; }
        .po-header-right { flex: ${HEADER_ORDER_FLEX}; ${colMinHeight(HEADER_ORDER_HEIGHT)} background: #fafafa; border-left: 1px solid ${accent}; display: flex; flex-direction: column; }
        .po-banner {
          background: ${navy}; color: #fff; font-weight: 800; font-size: 15px; letter-spacing: 1px;
          text-align: center; padding: 9px 0; position: relative; overflow: hidden;
        }
        .po-banner::after {
          content: ''; position: absolute; top: 0; right: 0; width: 0; height: 0;
          border-style: solid; border-width: 0 34px 34px 0; border-color: transparent ${accent} transparent transparent;
        }
        .po-meta-table { width: 100%; border-collapse: collapse; table-layout: fixed; }
        .po-meta-table td { padding: 4px 6px; font-size: 9.5px; vertical-align: top; word-break: break-word; overflow-wrap: break-word; }
        .po-meta-table td.label { color: #666; width: 27%; }
        .po-meta-table td.value { font-weight: 700; width: 23%; padding-right: 4px; }
        .po-boxes-row { display: flex; gap: 10px; margin-bottom: 10px; }
        .po-box { flex: 1; border: 1px solid #ddd; border-radius: 4px; overflow: hidden; }
        .po-box-title {
          background: ${navy}; color: #fff; font-weight: 700; font-size: 10.5px; letter-spacing: 0.5px;
          padding: 6px 10px; display: flex; align-items: center; gap: 6px;
        }
        .po-box-title.accent { background: ${accent}; }
        .po-box-title svg { font-size: 13px; width: 13px; height: 13px; }
        .po-box-body { padding: 8px 10px; }
        .po-box-body .name { font-weight: 700; margin-bottom: 3px; }
        .po-box-body div { line-height: 1.5; color: #333; }
        .po-box-body .field { margin-top: 4px; }
        .po-box-body .field .l { color: #666; display: inline-block; min-width: 90px; }
        .po-box-body .divider { border-top: 1px solid #ddd; margin: 8px 0 4px; }
        table.po-items { width: 100%; border-collapse: collapse; margin-bottom: 10px; }
        table.po-items th { background: ${navy}; color: #fff; font-size: 9.5px; padding: 6px 5px; text-align: left; white-space: nowrap; }
        table.po-items td { border-bottom: 1px solid #eee; padding: 5px; font-size: 10px; }
        table.po-items td.num, table.po-items th.num { text-align: right; }
        .po-summary-row { display: flex; gap: 10px; margin-bottom: 10px; }
        .po-words-box { flex: 1.4; border: 1px solid #ddd; border-radius: 4px; padding: 10px 12px; }
        .po-words-box .title { font-weight: 700; color: ${accent}; font-size: 10.5px; margin-bottom: 4px; display: flex; align-items: center; gap: 5px; }
        .po-words-box .title svg { font-size: 13px; width: 13px; height: 13px; }
        .po-words-box .terms-title { font-weight: 700; color: ${accent}; font-size: 10.5px; margin: 10px 0 4px; display: flex; align-items: center; gap: 5px; }
        .po-words-box .terms-title svg { font-size: 13px; width: 13px; height: 13px; }
        .po-words-box .terms { white-space: pre-line; color: #333; line-height: 1.5; font-size: 10px; }
        .po-totals-box { flex: 1; border: 1px solid #ddd; border-radius: 4px; height: fit-content; }
        .po-totals-box .row { display: flex; justify-content: space-between; padding: 7px 12px; border-bottom: 1px solid #eee; font-size: 10.5px; }
        .po-totals-box .row.grand { background: ${accent}; color: #fff; font-weight: 800; font-size: 12px; border-bottom: none; }
        .po-bottom-row { display: flex; gap: 10px; margin-top: 4px; align-items: stretch; }
        .po-bank-box { flex: 1.2; border: 1px solid #ddd; border-radius: 4px; overflow: hidden; }
        .po-bank-box .po-box-body { display: flex; flex-direction: column; gap: 2px; }
        .po-sign-cols { flex: 2; display: flex; border-top: 1px solid #ddd; padding-top: 10px; }
        .po-sign-box {
          flex: 1; padding: 0 10px; border-left: 1px solid #ddd;
          text-align: center; font-size: 9.5px; color: #333;
          display: flex; flex-direction: column; justify-content: space-between; min-height: 100px;
        }
        .po-sign-box:first-child { border-left: none; padding-left: 0; }
        .po-sign-heading { font-weight: 700; color: #1a1a1a; }
        .po-sign-typed { color: #333; margin-bottom: 4px; }
        .po-sign-role { font-weight: 700; }
        .po-footer {
          margin-top: 14px; padding-top: 8px; border-top: 1px solid #ddd;
          display: grid; grid-template-columns: 1fr auto 1fr; align-items: center;
          font-size: 10px; color: #777;
        }
        .po-footer .po-footer-left { display: flex; align-items: center; gap: 4px; justify-self: start; white-space: nowrap; }
        .po-footer .po-footer-logo { height: 16px; width: auto; object-fit: contain; flex-shrink: 0; }
        .po-footer .po-footer-note { justify-self: center; white-space: nowrap; }
        .po-footer .po-footer-page { justify-self: end; white-space: nowrap; }
      `}</style>

      <div className="po-sheet">
        <div className="po-topbar" />

        <div className="po-header-row">
          <div className="po-logo-col">
            <img className="po-logo-mark" src="https://i.ibb.co/zH84Rn7w/Logo-tradeone.png" alt={company?.companyName || 'Nexora KEMACH'} />
            <div className="po-tagline">Trade Smarter. Grow Together.</div>
          </div>
          <div className="po-header-divider" />
          <div className="po-company-col">
            <div className="po-brand-name">{companyName}</div>
            <div className="po-company-lines">
              {company?.address && <div className="addr">{company.address}</div>}
              {companyAddrLine2 && <div className="addr">{companyAddrLine2}</div>}
            </div>
            <div className="po-company-icons">
              {company?.gstin && (
                <div className="item"><span className="po-icon-dot"><BadgeOutlinedIcon /></span><span>GSTIN</span><span className="colon">:</span><span>{company.gstin}</span></div>
              )}
              {company?.phone && (
                <div className="item"><span className="po-icon-dot"><PhoneOutlinedIcon /></span><span>Phone</span><span className="colon">:</span><span>{company.phone}</span></div>
              )}
              {company?.email && (
                <div className="item"><span className="po-icon-dot"><EmailOutlinedIcon /></span><span>Email</span><span className="colon">:</span><span>{company.email}</span></div>
              )}
              {company?.website && (
                <div className="item"><span className="po-icon-dot"><LanguageOutlinedIcon /></span><span>Website</span><span className="colon">:</span><span>{company.website}</span></div>
              )}
            </div>
          </div>
          <div className="po-header-right">
            <div className="po-banner">PURCHASE ORDER</div>
            <table className="po-meta-table">
              <tbody>
                <tr>
                  <td className="label">PO Number</td><td className="value">{order.poNo || '—'}</td>
                  <td className="label">Buying Branch</td><td className="value">{buyingBranchLabel}</td>
                </tr>
                <tr>
                  <td className="label">PO Date</td><td className="value">{fmtDate(order.poDate)}</td>
                  <td className="label">Department</td><td className="value">{order.department || '—'}</td>
                </tr>
                <tr>
                  <td className="label">Supplier Ref. No.</td><td className="value">{order.referenceNo || '—'}</td>
                  <td className="label">Place of Supply</td><td className="value">{order.placeOfSupply || '—'}</td>
                </tr>
                <tr>
                  <td className="label">Delivery Date</td><td className="value">{fmtDate(order.deliveryDate)}</td>
                  <td className="label">Transport Mode</td><td className="value">{order.transportMode || '—'}</td>
                </tr>
                <tr>
                  <td className="label">Payment Terms</td><td className="value">{order.paymentTerms || '—'}</td>
                  <td className="label">E-Way Bill No.</td><td className="value">{order.eWayBillNo || '—'}</td>
                </tr>
                <tr>
                  <td className="label">Currency</td><td className="value">{order.currency || 'INR'}</td>
                  <td className="label">E-Way Bill Date</td><td className="value">{fmtDate(order.eWayBillDate)}</td>
                </tr>
                <tr>
                  <td className="label">Status</td><td className="value">{order.status || '—'}</td>
                  <td className="label">Valid Till</td><td className="value">{fmtDate(order.validUpto)}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div className="po-boxes-row">
          <div className="po-box">
            <div className="po-box-title accent"><Inventory2OutlinedIcon /> SUPPLIER DETAILS</div>
            <div className="po-box-body">
              <div className="name">{order.supplier || '—'}</div>
              {supplierRecord?.billingAddress && <div>{supplierRecord.billingAddress}</div>}
              {supplierAddrLine2 && <div>{supplierAddrLine2}</div>}
              {supplierRecord?.gstin && <div className="field"><span className="l">GSTIN</span>: {supplierRecord.gstin}</div>}
              <div className="divider" />
              <div className="field"><span className="l">Phone</span>: {order.phone || supplierRecord?.phone || '—'}</div>
              <div className="field"><span className="l">Email</span>: {order.email || supplierRecord?.email || '—'}</div>
              <div className="field"><span className="l">Contact Person</span>: {order.contactPerson || '—'}</div>
            </div>
          </div>

          <div className="po-box">
            <div className="po-box-title"><LocationOnOutlinedIcon /> DELIVERY TO</div>
            <div className="po-box-body">
              <div className="name">{deliveryName}</div>
              {deliveryAddr && <div>{deliveryAddr}</div>}
              {deliveryLine2 && <div>{deliveryLine2}</div>}
              <div className="divider" />
              {deliveryPhone && <div className="field"><span className="l">Phone</span>: {deliveryPhone}</div>}
              {deliveryEmail && <div className="field"><span className="l">Email</span>: {deliveryEmail}</div>}
            </div>
          </div>

          <div className="po-box">
            <div className="po-box-title accent"><DescriptionOutlinedIcon /> OTHER DETAILS</div>
            <div className="po-box-body">
              <div className="field"><span className="l">Packing &amp; Forwarding</span>: {order.packingForwarding || '—'}</div>
              <div className="field"><span className="l">Loading / Unloading</span>: {order.loadingUnloading || '—'}</div>
              <div className="field"><span className="l">Inspection</span>: {order.inspection || '—'}</div>
              <div className="field"><span className="l">Warranty</span>: {order.warranty || '—'}</div>
              <div className="field"><span className="l">Remarks</span>: {order.remarks || '—'}</div>
            </div>
          </div>
        </div>

        <table className="po-items">
          <thead>
            <tr>
              <th>#</th>
              <th>Item Code</th>
              <th>Item Description</th>
              <th>HSN/SAC</th>
              <th>UOM</th>
              <th className="num">Qty</th>
              <th className="num">Unit Price (₹)</th>
              <th className="num">Discount (%)</th>
              <th className="num">Taxable Value (₹)</th>
              <th className="num">GST %</th>
              <th className="num">GST Amount (₹)</th>
              <th className="num">Total Amount (₹)</th>
            </tr>
          </thead>
          <tbody>
            {items.map((it, idx) => {
              const amount = (Number(it.quantity) || 0) * (Number(it.unitPrice) || 0);
              const taxable = amount * (1 - discPct / 100);
              const taxPct = Number(it.taxPercent) || 0;
              const gstAmt = taxable * (taxPct / 100);
              const total = taxable + gstAmt;
              return (
                <tr key={idx}>
                  <td>{idx + 1}</td>
                  <td>{it.productCode || '—'}</td>
                  <td>{it.description || it.productName || '—'}</td>
                  <td>{it.hsnCode || '—'}</td>
                  <td>{it.uom || '—'}</td>
                  <td className="num">{Number(it.quantity) || 0}</td>
                  <td className="num">{(Number(it.unitPrice) || 0).toFixed(2)}</td>
                  <td className="num">{discPct.toFixed(2)}</td>
                  <td className="num">{taxable.toFixed(2)}</td>
                  <td className="num">{taxPct}%</td>
                  <td className="num">{gstAmt.toFixed(2)}</td>
                  <td className="num">{total.toFixed(2)}</td>
                </tr>
              );
            })}
          </tbody>
        </table>

        <div className="po-summary-row">
          <div className="po-words-box">
            <div className="title"><CurrencyRupeeOutlinedIcon /> AMOUNT IN WORDS</div>
            <div>{amountToWords(finalTotal) || '—'}</div>
            {order.termsConditions && (
              <>
                <div className="terms-title"><GavelOutlinedIcon /> TERMS &amp; CONDITIONS</div>
                <div className="terms">{order.termsConditions}</div>
              </>
            )}
          </div>
          <div className="po-totals-box">
            <div className="row"><span>Total Taxable Value</span><span>{fmtMoney(totals.taxableAmount)}</span></div>
            {taxRows.map((t) => (
              <div className="row" key={t.label}><span>{t.label}</span><span>{fmtMoney(t.amount)}</span></div>
            ))}
            <div className="row"><span>Round Off</span><span>{fmtMoney(roundOff)}</span></div>
            <div className="row grand"><span>GRAND TOTAL</span><span>{fmtMoney(finalTotal)}</span></div>
          </div>
        </div>

        <div className="po-bottom-row">
          <div className="po-bank-box">
            <div className="po-box-title"><AccountBalanceOutlinedIcon /> BANK DETAILS (FOR NEFT/RTGS)</div>
            <div className="po-box-body">
              <div className="field"><span className="l">Bank Name</span>: {hasBankDetails ? bankName : '—'}</div>
              <div className="field"><span className="l">A/c No.</span>: {hasBankDetails ? accountNumber : '—'}</div>
              <div className="field"><span className="l">A/c Name</span>: {hasBankDetails ? accountName : '—'}</div>
              <div className="field"><span className="l">IFSC Code</span>: {hasBankDetails ? ifscCode : '—'}</div>
              <div className="field"><span className="l">Branch</span>: {hasBankDetails ? bankBranch : '—'}</div>
            </div>
          </div>

          <div className="po-sign-cols">
            <div className="po-sign-box">
              <div className="po-sign-heading">Prepared By</div>
              <div className="po-sign-bottom">
                <div className="po-sign-typed">{order.preparedBy || '—'}</div>
                <div className="po-sign-role">Purchase Executive</div>
              </div>
            </div>
            <div className="po-sign-box">
              <div className="po-sign-heading">Checked By</div>
              <div className="po-sign-bottom">
                <div className="po-sign-typed">{order.checkedBy || '—'}</div>
                <div className="po-sign-role">Purchase Manager</div>
              </div>
            </div>
            <div className="po-sign-box">
              <div className="po-sign-heading">Approved By</div>
              <div className="po-sign-bottom">
                <div className="po-sign-typed">{order.approvedBy || '—'}</div>
                <div className="po-sign-role">Finance Manager</div>
              </div>
            </div>
            <div className="po-sign-box">
              <div className="po-sign-heading">For {companyName}</div>
              <div className="po-sign-bottom">
                <div className="po-sign-role">Authorised Signatory</div>
              </div>
            </div>
          </div>
        </div>

        <div className="po-footer">
          <span className="po-footer-left">
            <img className="po-footer-logo" src="https://i.ibb.co/v6qwV2tf/img-logo.png" alt="" />
            Thank you for your business!
          </span>
          <span className="po-footer-note">This is a computer generated document. No signature is required.</span>
          <span className="po-footer-page">Page 1 of 1</span>
        </div>
      </div>
    </div>
  );
}
