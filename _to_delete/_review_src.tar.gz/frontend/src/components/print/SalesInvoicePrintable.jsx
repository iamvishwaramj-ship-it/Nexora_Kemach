import React from 'react';
import dayjs from 'dayjs';
import { amountToWords } from '../../lib/numberToWords';
import { buildDocument, round2, isInterState } from '../../lib/documentTotals';
import {
  LetterheadHeader, LetterheadWatermark, LetterheadFooter, letterheadStyles,
  LETTERHEAD_TOP_MM, LETTERHEAD_BOTTOM_MM,
} from './Letterhead';

// Statutory GST tax invoice: company and e-invoice block, billing/shipping
// addresses side by side, document details, the line-item grid, an HSN/SAC tax
// summary, amounts in words, bank details, and the jurisdiction notes. The
// invoice itself stays plain — black text on ruled boxes — because it is
// produced for assessment and follows the standard arrangement.
//
// The BRANDING around it is the letterhead (see ./Letterhead.jsx), drawn into
// the top and bottom bands. Those bands used to be left blank on the
// assumption that pre-printed stationery would be in the tray. That only holds
// when someone remembers to load it: email the PDF, or print on plain A4, and
// the invoice goes out with two unexplained empty strips. Drawing it means one
// artefact is right everywhere.
//
// Printed three times, as ORIGINAL / DUPLICATE / TRIPLICATE — the customer,
// transporter and supplier copies. Each is the same page with a different
// heading and page number, and each carries its own letterhead: they are
// separate sheets, so a header rendered once would only reach the first.
const COPY_LABELS = ['ORIGINAL', 'DUPLICATE', 'TRIPLICATE'];

// One weight for every rule on the sheet — the outer box, the block
// separators and the lines inside the item grid alike. Change this single
// number to make the whole grid heavier or lighter; nothing else specifies a
// border width, so they cannot drift apart again.
const GRID_BORDER_PX = 1;

// A4, and the @page margin applied on each edge below. The usable content
// height is the sheet less those margins less the letterhead reserves.
const PAGE_HEIGHT_MM = 297;
const PAGE_MARGIN_MM = 8;

// --- Brand rule spacing, for THIS document ---------------------------------
// Clear space above and below the red rule, in millimetres. The header's rule
// and the footer's rule are tuned independently — four separate numbers — so
// tightening the gap under the masthead cannot quietly shift the registered
// office line at the foot, and vice versa.
//
// Only the keys set here override the shared letterhead defaults
// (RULE_SPACING_MM in ./Letterhead.jsx); all four are restated so every gap on
// the sheet is visible in one place while the layout is being tuned.
//
// These change how the bands LOOK, not how tall they are: the bands stay
// LETTERHEAD_TOP_MM / LETTERHEAD_BOTTOM_MM and the body's reserve is
// untouched, so nudging them cannot push the invoice onto another page. Keep
// the sums inside the bands though — the masthead plus headerAbove plus
// headerBelow has to stay under LETTERHEAD_TOP_MM, or the rule rides out of
// the reserved strip and over the body.
const RULE_SPACING = {
  headerAbove: 1.5,
  headerBelow: 0,
  footerAbove: 2,
  footerBelow: 1.5,
};

const fmtDate = (d) => (d ? dayjs(d).format('DD-MMM-YYYY') : '');
// Plain grouped numbers, no currency symbol: the column headings already say
// the amounts are in the document's currency, and a symbol in every cell makes
// the grid harder to scan.
const fmtNum = (n) => (Number(n) || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const fmtQty = (n) => {
  const v = Number(n) || 0;
  return Number.isInteger(v) ? String(v) : v.toFixed(2);
};

// Totals come from the shared engine in lib/documentTotals.js — the same
// module the form uses and a behavioural mirror of the server's own, so the
// printed figures always match what was saved.
function computeTotals(items, discountPercent, interState = false) {
  const { totals } = buildDocument(items, discountPercent, { interState, roundOff: true });
  return {
    ...totals,
    discount: round2(totals.subtotal - totals.taxableAmount),
    grandTotal: totals.amount,
  };
}

/**
 * Per-line figures, derived the same way the item grid and the tax summary
 * both need them — computed once here so the two can never disagree.
 */
function lineFigures(it, headerDiscPct) {
  const qty = Number(it.quantity) || 0;
  const price = Number(it.unitPrice) || 0;
  const itemDiscPct = Number(it.discountPercent) || 0;
  const gross = qty * price;
  const afterItemDisc = gross - gross * (itemDiscPct / 100);
  const taxable = afterItemDisc * (1 - headerDiscPct / 100);
  const taxPct = Number(it.taxPercent) || 0;
  const taxAmount = taxable * (taxPct / 100);
  return { qty, price, itemDiscPct, taxable, taxPct, taxAmount, total: taxable + taxAmount };
}

/**
 * The HSN/SAC summary table beneath the totals: one row per HSN code with its
 * taxable value and tax split. Required on a GST invoice, and it has to
 * aggregate rather than repeat the line grid, since several lines can share an
 * HSN code.
 */
function hsnSummary(items, headerDiscPct, interState) {
  const byHsn = new Map();
  for (const it of items) {
    const key = it.hsnCode || '—';
    const { taxable, taxPct, taxAmount } = lineFigures(it, headerDiscPct);
    const prev = byHsn.get(key) || { hsn: key, taxable: 0, taxPct, taxAmount: 0 };
    prev.taxable += taxable;
    prev.taxAmount += taxAmount;
    prev.taxPct = taxPct;
    byHsn.set(key, prev);
  }
  return [...byHsn.values()].map((r) => ({
    ...r,
    // Intra-state splits the rate evenly across CGST and SGST; inter-state is
    // wholly IGST. Same rule the totals engine applies.
    halfPct: interState ? r.taxPct : r.taxPct / 2,
    halfAmount: interState ? r.taxAmount : r.taxAmount / 2,
  }));
}

export default function SalesInvoicePrintable({
  order, company, customerRecord, salesEmployeeRecord, houseBank,
}) {
  if (!order) return null;

  const items = order.items || [];
  const interState = isInterState(order.placeOfSupply, company?.state);
  const discPct = Number(order.discountPercent) || 0;
  const totals = computeTotals(items, discPct, interState);
  const hsnRows = hsnSummary(items, discPct, interState);

  const companyName = (company?.companyName || 'Nexora KEMACH').toUpperCase();
  const companyAddrLine = [company?.city, company?.state, company?.pincode].filter(Boolean).join(', ');
  const totalQty = items.reduce((s, i) => s + (Number(i.quantity) || 0), 0);
  const taxTotal = round2(totals.cgstAmount + totals.sgstAmount + totals.igstAmount);

  const billingAddr = order.billingAddress || customerRecord?.billingAddress || '';
  const shippingAddr = order.shippingAddress || customerRecord?.shippingAddress || '';

  // Fields the sample invoice carries that this application has no column for
  // yet (e-invoicing IRN, despatch details, freight). They print as labelled
  // blanks so the layout is the final one and filling them in later is purely
  // additive — see order.* below, each falling back to ''.
  const renderCopy = (copyLabel, pageNo) => (
    <div className="sinv-page" key={copyLabel}>
      <LetterheadHeader company={company} />
      <LetterheadWatermark />

      <div className="sinv-copy-title">
        <span className="sinv-copy-label">{copyLabel}</span>
        <span className="sinv-doc-title">TAX INVOICE</span>
      </div>

      {/* Company + e-invoice block */}
      <table className="sinv-grid sinv-head">
        <tbody>
          <tr>
            <td className="sinv-head-company">
              <div className="sinv-company-name">{companyName}</div>
              {company?.address && <div>{company.address}</div>}
              {companyAddrLine && <div>{companyAddrLine}</div>}
              {company?.gstin && <div>GSTN No:{company.gstin}</div>}
              <div>GSTN Type:{company?.gstnType || 'Regular/TDS/ISD'}</div>
            </td>
            <td className="sinv-head-irn">
              <div className="sinv-kv"><span className="k">IRN Ack. No</span><span className="v">{order.irnAckNo || ''}</span></div>
              <div className="sinv-kv"><span className="k">IRN No</span><span className="v sinv-break">{order.irnNo || ''}</span></div>
            </td>
          </tr>
        </tbody>
      </table>

      {/* Billing / shipping addresses */}
      <table className="sinv-grid">
        <tbody>
          <tr>
            <td className="sinv-half">
              <div className="sinv-addr-title">Billing Address To :</div>
              <div className="sinv-party">{order.customer || ''}</div>
              {billingAddr && <div className="sinv-pre">{billingAddr}</div>}
              <div>GST Registration Number : {customerRecord?.gstin || ''}</div>
              <div>GST Registration Type : {customerRecord?.gstRegistrationType || 'Regular/TDS/ISD'}</div>
            </td>
            <td className="sinv-half">
              <div className="sinv-addr-title">Shipping Address To :</div>
              <div className="sinv-party">{order.customer || ''}</div>
              {shippingAddr && <div className="sinv-pre">{shippingAddr}</div>}
              <div>GST Registration Number : {customerRecord?.gstin || ''}</div>
              <div>GST Registration Type : {customerRecord?.gstRegistrationType || 'Regular/TDS/ISD'}</div>
            </td>
          </tr>
        </tbody>
      </table>

      {/* Document details */}
      <table className="sinv-grid">
        <tbody>
          <tr>
            <td className="sinv-half">
              <div className="sinv-kv"><span className="k">Invoice No</span><span className="c">:</span><span className="v">{order.invoiceNo || ''}</span></div>
              <div className="sinv-kv"><span className="k">Invoice Date</span><span className="c">:</span><span className="v">{fmtDate(order.invoiceDate)}</span></div>
              <div className="sinv-kv"><span className="k">Delivery Note</span><span className="c">:</span><span className="v">{order.deliveryChallanNo || ''}</span></div>
              <div className="sinv-kv"><span className="k">Buyer&apos;s Order No</span><span className="c">:</span><span className="v">{order.orderNo || ''}</span></div>
              <div className="sinv-kv"><span className="k">Sales Employee</span><span className="c">:</span><span className="v">{order.salesPerson || ''}</span></div>
            </td>
            <td className="sinv-half">
              <div className="sinv-kv"><span className="k">Place of Supply</span><span className="c">:</span><span className="v">{order.placeOfSupply || ''}</span></div>
              <div className="sinv-kv"><span className="k">Ship Via</span><span className="c">:</span><span className="v">{order.shipVia || ''}</span></div>
              <div className="sinv-kv"><span className="k">Carrier Name</span><span className="c">:</span><span className="v">{order.carrierName || ''}</span></div>
              <div className="sinv-kv"><span className="k">Payment Terms</span><span className="c">:</span><span className="v">{order.paymentTerms || ''}</span></div>
            </td>
          </tr>
          <tr>
            <td className="sinv-half" colSpan={2}>
              <div className="sinv-kv"><span className="k">Remarks</span><span className="c">:</span><span className="v">{order.remarks || ''}</span></div>
            </td>
          </tr>
        </tbody>
      </table>

      {/* Line items */}
      <table className="sinv-grid sinv-items">
        <thead>
          <tr>
            <th className="w-sn">S.<br />No</th>
            <th className="w-code">Item Code</th>
            <th className="w-desc">Description</th>
            <th className="w-hsn">HSN/<br />SAC</th>
            <th className="w-um">UM</th>
            <th className="num w-qty">Qty</th>
            <th className="num w-price">Unit<br />Price</th>
            <th className="num w-disc">Disc<br />%</th>
            <th className="num w-ass">Ass.<br />Value</th>
            <th className="w-tax">Tax<br />%</th>
            <th className="num w-taxamt">Tax<br />Amount</th>
            <th className="num w-amt">Amount</th>
          </tr>
        </thead>
        <tbody>
          {items.map((it, idx) => {
            const f = lineFigures(it, discPct);
            // Intra-state shows CGST and SGST as two stacked sub-rows against
            // one line, exactly as the sample does; inter-state is a single
            // IGST row.
            const components = interState
              ? [{ label: 'IGST', pct: f.taxPct, amt: f.taxAmount }]
              : [
                  { label: 'CGST', pct: f.taxPct / 2, amt: f.taxAmount / 2 },
                  { label: 'SGST', pct: f.taxPct / 2, amt: f.taxAmount / 2 },
                ];
            return (
              <React.Fragment key={idx}>
                <tr>
                  <td rowSpan={components.length}>{idx + 1}</td>
                  <td rowSpan={components.length}>{it.productCode || ''}</td>
                  <td rowSpan={components.length}>{it.description || it.productName || ''}</td>
                  <td rowSpan={components.length}>{it.hsnCode || ''}</td>
                  <td rowSpan={components.length}>{it.uom || ''}</td>
                  <td className="num" rowSpan={components.length}>{fmtQty(f.qty)}</td>
                  <td className="num" rowSpan={components.length}>{fmtNum(f.price)}</td>
                  <td className="num" rowSpan={components.length}>{f.itemDiscPct.toFixed(2)}</td>
                  <td className="num" rowSpan={components.length}>{fmtNum(f.taxable)}</td>
                  <td className="sinv-taxcell">{components[0].label} {components[0].pct.toFixed(2)}%</td>
                  <td className="num">{fmtNum(components[0].amt)}</td>
                  <td className="num" rowSpan={components.length}>{fmtNum(f.total)}</td>
                </tr>
                {components.slice(1).map((c) => (
                  <tr key={c.label}>
                    <td className="sinv-taxcell">{c.label} {c.pct.toFixed(2)}%</td>
                    <td className="num">{fmtNum(c.amt)}</td>
                  </tr>
                ))}
              </React.Fragment>
            );
          })}
        </tbody>
      </table>

      {/* Absorbs whatever vertical space is left so the blocks below sit at the
          foot of the sheet rather than bunching under a short item list.
          It's a continuation of the item grid — same class, so `table-layout:
          fixed` gives it identical column widths and the vertical rules carry
          straight down through the blank area to the totals block. */}
      <table className="sinv-grid sinv-items sinv-fill">
        <tbody>
          <tr>
            <td className="w-sn" />
            <td className="w-code" />
            <td className="w-desc" />
            <td className="w-hsn" />
            <td className="w-um" />
            <td className="w-qty" />
            <td className="w-price" />
            <td className="w-disc" />
            <td className="w-ass" />
            <td className="w-tax" />
            <td className="w-taxamt" />
            <td className="w-amt" />
          </tr>
        </tbody>
      </table>

      {/* Totals */}
      <table className="sinv-grid">
        <tbody>
          <tr>
            <td className="sinv-qty-cell">Total Qty <b>{fmtQty(totalQty)}</b></td>
            <td className="sinv-total-label">Total</td>
            <td className="sinv-total-value">{fmtNum(totals.taxableAmount + taxTotal)}</td>
          </tr>
          <tr>
            <td rowSpan={3} className="sinv-words-cell">
              <div>Amount in Words. ({order.currency || 'INR'})</div>
              <div className="sinv-words">{amountToWords(totals.grandTotal) || ''}</div>
            </td>
            <td className="sinv-total-label">Freight charges</td>
            <td className="sinv-total-value">{fmtNum(order.freightCharges || 0)}</td>
          </tr>
          <tr>
            <td className="sinv-total-label">Round off</td>
            <td className="sinv-total-value">{fmtNum(totals.roundOff)}</td>
          </tr>
          <tr>
            <td className="sinv-total-label"><b>Grand Total</b></td>
            <td className="sinv-total-value"><b>{fmtNum(totals.grandTotal)}</b></td>
          </tr>
        </tbody>
      </table>

      {/* HSN/SAC tax summary */}
      <table className="sinv-grid sinv-hsn">
        <thead>
          <tr>
            <th>HSN/SAC</th>
            <th className="num">TAXABLE VALUE</th>
            <th className="num">{interState ? 'INTEGRATED TAX %' : 'CENTRAL TAX %'}</th>
            <th className="num">{interState ? 'INTEGRATED TAX AMT' : 'CENTRAL TAX AMT'}</th>
            {!interState && <th className="num">STATE TAX %</th>}
            {!interState && <th className="num">STATE TAX AMT</th>}
          </tr>
        </thead>
        <tbody>
          {hsnRows.map((r) => (
            <tr key={r.hsn}>
              <td>{r.hsn}</td>
              <td className="num">{fmtNum(r.taxable)}</td>
              <td className="num">{r.halfPct.toFixed(2)}</td>
              <td className="num">{fmtNum(r.halfAmount)}</td>
              {!interState && <td className="num">{r.halfPct.toFixed(2)}</td>}
              {!interState && <td className="num">{fmtNum(r.halfAmount)}</td>}
            </tr>
          ))}
        </tbody>
      </table>

      <table className="sinv-grid">
        <tbody>
          <tr>
            <td>Tax Amount in Words. ({order.currency || 'INR'}) {amountToWords(taxTotal) || ''}</td>
          </tr>
        </tbody>
      </table>

      {/* Bank details — from the House Bank master */}
      <table className="sinv-grid">
        <tbody>
          <tr>
            <td colSpan={2} className="sinv-bank-title">Company&apos;s Bank Details :</td>
          </tr>
          <tr>
            <td className="sinv-half">
              <div className="sinv-kv"><span className="k">Beneficiary Name</span><span className="c">:</span><span className="v">{houseBank?.accountName || company?.companyName || ''}</span></div>
              <div className="sinv-kv"><span className="k">Bank Name</span><span className="c">:</span><span className="v">{houseBank?.bankName || ''}</span></div>
              <div className="sinv-kv"><span className="k">Branch</span><span className="c">:</span><span className="v">{houseBank?.branchName || ''}</span></div>
            </td>
            <td className="sinv-half">
              <div className="sinv-kv"><span className="k">A/c No.</span><span className="c">:</span><span className="v">{houseBank?.accountNumber || ''}</span></div>
              <div className="sinv-kv"><span className="k">RTGS/IFSC Code</span><span className="c">:</span><span className="v">{houseBank?.ifscCode || ''}</span></div>
              <div className="sinv-kv"><span className="k">Type</span><span className="c">:</span><span className="v">{houseBank?.accountType || ''}</span></div>
            </td>
          </tr>
        </tbody>
      </table>

      {/* Declarations + signature */}
      <table className="sinv-grid sinv-foot">
        <tbody>
          <tr>
            <td className="sinv-foot-left">Interest at 24% p.a. will be charged on all overdue payments</td>
            <td className="sinv-foot-right">For {companyName}</td>
          </tr>
          <tr>
            <td className="sinv-foot-left">
              {order.termsConditions
                ? <div className="sinv-pre">{order.termsConditions}</div>
                : (
                  <>
                    <div>All agreements contingent upon strikes, accidents and other conditions beyond our control.</div>
                    <div>All contracts are subject to approval by an office of the Company.</div>
                  </>
                )}
            </td>
            <td className="sinv-foot-right sinv-sign">Authorized Signatory</td>
          </tr>
        </tbody>
      </table>

      <div className="sinv-pagefoot">
        <span>{company?.phone ? `Ph No : ${company.phone}` : ''}</span>
        <span>{company?.email ? `Email Id : ${company.email}` : ''}</span>
        <span>Page {pageNo} of {COPY_LABELS.length}</span>
      </div>

      <LetterheadFooter company={company} />
    </div>
  );

  return (
    <div className="sinv-print-area">
      <style>{`
        ${letterheadStyles('.sinv-page', RULE_SPACING)}
        .sinv-print-area { display: none; }
        @media print {
          body * { visibility: hidden; }
          .sinv-print-area, .sinv-print-area * { visibility: visible; }
          .sinv-print-area {
            display: block; position: absolute; top: 0; left: 0; width: 100%;
            box-sizing: border-box;
          }
          @page { size: A4; margin: ${PAGE_MARGIN_MM}mm; }
          /* Each copy is its own sheet; the last must not emit a trailing blank page. */
          .sinv-page { page-break-after: always; }
          .sinv-page:last-child { page-break-after: auto; }
        }
        /* Each copy fills the sheet: A4 height less the @page margins top and
           bottom. As a column flexbox with a growing spacer in the middle, a
           short invoice pushes its totals/bank/declaration blocks down to the
           foot of the page instead of leaving the bottom half empty, while a
           long one simply overflows onto the next page as normal.

           The letterhead reserves are padding rather than margin: with
           box-sizing: border-box they come out of the fixed page height, so the
           sheet still ends where it should. A margin would add to that height
           and push each copy's footer onto an extra page. */
        .sinv-page {
          display: flex; flex-direction: column;
          min-height: calc(${PAGE_HEIGHT_MM}mm - ${PAGE_MARGIN_MM * 2}mm);
          box-sizing: border-box;
          padding-top: ${LETTERHEAD_TOP_MM}mm;
          padding-bottom: ${LETTERHEAD_BOTTOM_MM}mm;
        }
        /* The one element allowed to grow — every other block keeps its natural
           height (flex-shrink: 0 below), so all the slack lands here. Overrides
           that shared flex-shrink because this table is meant to flex. */
        table.sinv-fill { flex: 1 1 auto; }
        /* Its single row inherits the table's stretched height, carrying the
           column rules down through the blank space. */
        table.sinv-fill td { height: 100%; }
        .sinv-print-area { font-family: Arial, Helvetica, sans-serif; color: #000; font-size: 8.5px; }
        /* Copy word pinned left, "TAX INVOICE" centred on the sheet. A 1fr/auto/1fr
           grid (rather than floating the label) keeps the title on the page's true
           centre line regardless of how wide the copy word is, so ORIGINAL,
           DUPLICATE and TRIPLICATE all print with the title in the same place. */
        .sinv-copy-title {
          display: grid; grid-template-columns: 1fr auto 1fr; align-items: baseline;
          font-weight: 700; font-size: 11px; margin-bottom: 3px;
        }
        .sinv-copy-label { justify-self: start; }
        .sinv-doc-title { justify-self: center; }

        /* One ruled grid for the whole document — every block is a table so the
           vertical rules line up down the page. */
        /* flex-shrink: 0 — as flex items inside .sinv-page these would otherwise
           be compressed to fit the fixed page height, squashing the rows. */
        table.sinv-grid { width: 100%; border-collapse: collapse; table-layout: fixed; flex-shrink: 0; }
        table.sinv-grid td, table.sinv-grid th {
          border: ${GRID_BORDER_PX}px solid #000; padding: 3px 4px; vertical-align: top;
        }
        /* Every rule on the sheet is one weight, including the ones between
           blocks.
           border-collapse merges adjacent borders WITHIN a table, but the
           document is a stack of separate tables, and collapsing does not
           reach across two of them. So where one block ended and the next
           began, the bottom rule of the first and the top rule of the second
           printed one under the other and came out at double weight — the band
           separators looked heavier than the lines inside the item grid.
           Pulling each table up by exactly one border width lands the two rules
           on the same pixel row, which is what collapsing would have done had
           they been in the same table.
           (The old rule here removed border-top from the TABLE element. That
           element carries no border of its own — the cells do — so it never had
           any effect.) */
        table.sinv-grid + table.sinv-grid { margin-top: -${GRID_BORDER_PX}px; }
        .sinv-half { width: 50%; }
        .num { text-align: right; }

        .sinv-company-name { font-weight: 700; font-size: 10px; margin-bottom: 1px; }
        .sinv-head-company { width: 62%; }
        .sinv-head-irn { width: 38%; }
        .sinv-break { word-break: break-all; }

        .sinv-kv { display: flex; gap: 4px; line-height: 1.45; }
        .sinv-kv .k { flex: 0 0 42%; }
        .sinv-kv .c { flex: 0 0 4px; }
        .sinv-kv .v { flex: 1; font-weight: 600; }

        .sinv-addr-title { font-weight: 700; margin-bottom: 2px; }
        .sinv-party { font-weight: 700; }
        .sinv-pre { white-space: pre-line; line-height: 1.45; }

        table.sinv-items th { font-weight: 700; text-align: center; font-size: 8px; }
        table.sinv-items td { font-size: 8.5px; }
        table.sinv-items .w-sn { width: 3.5%; }
        table.sinv-items .w-code { width: 9%; }
        table.sinv-items .w-desc { width: 20%; }
        table.sinv-items .w-hsn { width: 9%; }
        table.sinv-items .w-um { width: 5%; }
        table.sinv-items .w-qty { width: 5%; }
        table.sinv-items .w-price { width: 8.5%; }
        table.sinv-items .w-disc { width: 5.5%; }
        table.sinv-items .w-ass { width: 9%; }
        table.sinv-items .w-tax { width: 9.5%; }
        table.sinv-items .w-taxamt { width: 8%; }
        table.sinv-items .w-amt { width: 8%; }
        .sinv-taxcell { white-space: nowrap; }

        .sinv-qty-cell { width: 62%; }
        .sinv-total-label { width: 22%; }
        .sinv-total-value { width: 16%; text-align: right; }
        .sinv-words-cell { vertical-align: top; }
        .sinv-words { font-weight: 600; text-transform: uppercase; }

        table.sinv-hsn th { font-weight: 700; font-size: 8px; }

        .sinv-bank-title { font-weight: 700; }

        table.sinv-foot .sinv-foot-left { width: 62%; line-height: 1.45; }
        table.sinv-foot .sinv-foot-right { width: 38%; text-align: right; }
        table.sinv-foot .sinv-sign { height: 46px; vertical-align: bottom; }

        .sinv-pagefoot { display: flex; justify-content: space-between; padding: 3px 2px 0; font-size: 8px; }
      `}</style>

      {COPY_LABELS.map((label, i) => renderCopy(label, i + 1))}
    </div>
  );
}
