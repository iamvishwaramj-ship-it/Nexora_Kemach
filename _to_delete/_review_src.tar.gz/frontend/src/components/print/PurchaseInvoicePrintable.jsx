import React from 'react';
import dayjs from 'dayjs';
import BadgeOutlinedIcon from '@mui/icons-material/BadgeOutlined';
import PhoneOutlinedIcon from '@mui/icons-material/PhoneOutlined';
import EmailOutlinedIcon from '@mui/icons-material/EmailOutlined';
import LanguageOutlinedIcon from '@mui/icons-material/LanguageOutlined';
import HomeOutlinedIcon from '@mui/icons-material/HomeOutlined';
import LocationOnOutlinedIcon from '@mui/icons-material/LocationOnOutlined';
import DescriptionOutlinedIcon from '@mui/icons-material/DescriptionOutlined';
import AccountBalanceOutlinedIcon from '@mui/icons-material/AccountBalanceOutlined';
import CurrencyRupeeOutlinedIcon from '@mui/icons-material/CurrencyRupeeOutlined';
import GavelOutlinedIcon from '@mui/icons-material/GavelOutlined';
import { amountToWords } from '../../lib/numberToWords';
import { buildDocument, round2, isInterState, taxComponentRows } from '../../lib/documentTotals';

// Same fixed letterhead brand colors as the Purchase Order print template —
// navy + orange, independent of the app's active UI theme.
const NAVY = '#0B1E3D';
const ORANGE = '#F15A24';

// Header row column sizing — three independently tunable columns sitting
// side by side: the logo, the company/address block, and the PURCHASE
// INVOICE box. Adjust these to rebalance the header without touching any
// other layout rule.
const HEADER_LOGO_WIDTH = 150;   // px — fixed width of the logo column
const HEADER_LOGO_HEIGHT = 'auto';    // px (number) or 'auto' — fixed/min height of the logo column
const HEADER_COMPANY_FLEX = 2;   // flex-grow — company name/address column width
const HEADER_COMPANY_HEIGHT = 'auto'; // px (number) or 'auto' — fixed/min height of the company column
const HEADER_INVOICE_FLEX = 5; // flex-grow — PURCHASE INVOICE box column width
const HEADER_INVOICE_HEIGHT = 'auto'; // px (number) or 'auto' — fixed/min height of the invoice box column

// Helper: turns a HEADER_*_HEIGHT value ('auto' or a number of px) into a
// CSS min-height declaration (or nothing, when left as 'auto').
const colMinHeight = (h) => (h === 'auto' || h == null ? '' : `min-height: ${h}px;`);

// Logo image size — set independently from HEADER_LOGO_WIDTH above (that one
// sizes the column itself; these two size the actual <img>).
const LOGO_IMAGE_WIDTH = "auto";   // px — logo image width
const LOGO_IMAGE_HEIGHT = 50;  // px — logo image height

const fmtDate = (d) => (d ? dayjs(d).format('DD/MM/YYYY') : '—');
const fmtMoney = (n) => `₹ ${(Number(n) || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

// Totals come from the shared engine in lib/documentTotals.js — the same
// module the form uses and a behavioural mirror of the server's own.
//
// Each template used to carry a private re-implementation of this arithmetic
// "so the printed totals always match what's shown/saved on the form". They
// stopped matching. The copies here never rounded per line, so a printed
// total could sit a few paise off the stored header, and none of them could
// represent IGST — an inter-state document printed a CGST/SGST split that its
// own database row does not have.
function computeTotals(items, discountPercent, interState = false) {
  const { totals } = buildDocument(items, discountPercent, { interState, roundOff: true });
  return {
    ...totals,
    discount: round2(totals.subtotal - totals.taxableAmount),
    grandTotal: totals.amount,
  };
}

// billFrom / shipTo are stored as newline-joined "Name\nAddress, City, State"
// strings on the invoice itself (see PurchaseInvoice.jsx's formatAddress) —
// split them back into a name line + address line(s) for display.
function splitBlock(text) {
  const lines = String(text || '').split('\n').map((l) => l.trim()).filter(Boolean);
  return { name: lines[0] || '', rest: lines.slice(1) };
}

/**
 * A formal, letterhead-style printable Purchase Invoice document — visual
 * twin of PurchaseOrderPrintable, adapted for invoice-specific fields
 * (GRN/PO cross-references, due date, payment status). Only ever rendered
 * inside a `.pinv-print-area` wrapper that's invisible on screen and shown
 * exclusively via the `@media print` rules below.
 */
export default function PurchaseInvoicePrintable({ order, company, supplierRecord, grnRecord, poRecord }) {
  const navy = NAVY;
  const accent = ORANGE;

  if (!order) return null;

  const items = order.items || [];
  const interState = isInterState(order.placeOfSupply, company?.state);
  const totals = computeTotals(items, order.discountPercent, interState);
  const discPct = Number(order.discountPercent) || 0;

  const taxRows = taxComponentRows(totals, interState);

  const companyAddrLine2 = [company?.city, company?.state, company?.pincode].filter(Boolean).join(', ');
  const companyName = (company?.companyName || 'Nexora KEMACH').toUpperCase();

  const supplierBlock = splitBlock(order.billFrom);
  const deliveryBlock = splitBlock(order.shipTo);

  const poDate = poRecord?.poDate || grnRecord?.poDate;
  const grnDate = grnRecord?.receivedDate;

  return (
    <div className="pinv-print-area">
      <style>{`
        .pinv-print-area { display: none; }
        @media print {
          body * { visibility: hidden; }
          .pinv-print-area, .pinv-print-area * { visibility: visible; }
          .pinv-print-area {
            display: block; position: absolute; top: 0; left: 0; width: 100%;
            padding: 8mm; box-sizing: border-box;
          }
          @page { size: A4; margin: 8mm; }
        }
        .pinv-sheet { font-family: Arial, Helvetica, sans-serif; color: #1a1a1a; font-size: 11px; }
        .pinv-topbar { height: 5px; background: linear-gradient(90deg, ${navy} 0%, ${accent} 100%); border-radius: 2px; margin-bottom: 8px; }
        .pinv-header-row { display: flex; align-items: stretch; border: 1px solid ${accent}; border-radius: 4px; overflow: hidden; margin-bottom: 10px; }
        .pinv-logo-col {
          flex-shrink: 0; width: ${HEADER_LOGO_WIDTH}px; ${colMinHeight(HEADER_LOGO_HEIGHT)} display: flex; flex-direction: column;
          align-items: center; justify-content: center; gap: 8px; padding: 14px 12px; text-align: center;
        }
        .pinv-logo-mark { width: ${LOGO_IMAGE_WIDTH}px; height: ${LOGO_IMAGE_HEIGHT}px; object-fit: contain; }
        .pinv-header-divider { width: 1px; background: #e2e2e2; margin: 18px 0; flex-shrink: 0; }
        .pinv-company-col { flex: ${HEADER_COMPANY_FLEX}; ${colMinHeight(HEADER_COMPANY_HEIGHT)} padding: 14px 16px; }
        .pinv-brand-name { font-size: 14px; font-weight: 800; letter-spacing: 0.3px; color: ${navy}; margin-bottom: 4px; }
        .pinv-tagline { font-size: 9px; color: #999; font-style: italic; margin-bottom: 8px; white-space: nowrap; }
        .pinv-company-lines .addr { line-height: 1.5; color: #333; font-weight: 600; }
        .pinv-company-icons { margin-top: 8px; display: grid; grid-template-columns: 1fr; row-gap: 5px; column-gap: 10px; }
        .pinv-company-icons .item { display: grid; grid-template-columns: 18px 58px 8px 1fr; align-items: center; column-gap: 6px; color: #333; }
        .pinv-icon-dot {
          width: 18px; height: 18px; border-radius: 50%; background: ${accent}; color: #fff;
          display: flex; align-items: center; justify-content: center; flex-shrink: 0;
        }
        .pinv-icon-dot svg { font-size: 12px; width: 12px; height: 12px; }
        .pinv-header-right { flex: ${HEADER_INVOICE_FLEX}; ${colMinHeight(HEADER_INVOICE_HEIGHT)} background: #fafafa; border-left: 1px solid ${accent}; display: flex; flex-direction: column; }
        .pinv-banner {
          background: ${navy}; color: #fff; font-weight: 800; font-size: 15px; letter-spacing: 1px;
          text-align: center; padding: 9px 0; position: relative; overflow: hidden;
        }
        .pinv-banner::after {
          content: ''; position: absolute; top: 0; right: 0; width: 0; height: 0;
          border-style: solid; border-width: 0 34px 34px 0; border-color: transparent ${accent} transparent transparent;
        }
        .pinv-meta-table { width: 100%; border-collapse: collapse; table-layout: fixed; }
        .pinv-meta-table td { padding: 4px 6px; font-size: 9.5px; vertical-align: top; word-break: break-word; overflow-wrap: break-word; }
        .pinv-meta-table td.label { color: #666; width: 27%; }
        .pinv-meta-table td.value { font-weight: 700; width: 23%; padding-right: 4px; }
        .pinv-boxes-row { display: flex; gap: 10px; margin-bottom: 10px; }
        .pinv-box { flex: 1; border: 1px solid #ddd; border-radius: 4px; overflow: hidden; }
        .pinv-box-title {
          background: ${navy}; color: #fff; font-weight: 700; font-size: 10.5px; letter-spacing: 0.5px;
          padding: 6px 10px; display: flex; align-items: center; gap: 6px;
        }
        .pinv-box-title.accent { background: ${accent}; }
        .pinv-box-title svg { font-size: 13px; width: 13px; height: 13px; }
        .pinv-box-body { padding: 8px 10px; }
        .pinv-box-body .name { font-weight: 700; margin-bottom: 3px; }
        .pinv-box-body div { line-height: 1.5; color: #333; }
        .pinv-box-body .field { margin-top: 4px; }
        .pinv-box-body .field .l { color: #666; display: inline-block; min-width: 90px; }
        .pinv-box-body .divider { border-top: 1px solid #ddd; margin: 8px 0 4px; }
        table.pinv-items { width: 100%; border-collapse: collapse; margin-bottom: 10px; }
        table.pinv-items th { background: ${navy}; color: #fff; font-size: 9.5px; padding: 6px 5px; text-align: left; white-space: nowrap; }
        table.pinv-items td { border-bottom: 1px solid #eee; padding: 5px; font-size: 10px; }
        table.pinv-items td.num, table.pinv-items th.num { text-align: right; }
        .pinv-summary-row { display: flex; gap: 10px; margin-bottom: 10px; }
        .pinv-words-box { flex: 1.4; border: 1px solid #ddd; border-radius: 4px; padding: 10px 12px; background: #fdf1ea; }
        .pinv-words-box .title { font-weight: 700; color: ${accent}; font-size: 10.5px; margin-bottom: 4px; display: flex; align-items: center; gap: 5px; }
        .pinv-words-box .title svg { font-size: 13px; width: 13px; height: 13px; }
        .pinv-terms-box { flex: 1.4; border: 1px solid #ddd; border-radius: 4px; padding: 10px 12px; margin-top: 8px; }
        .pinv-terms-box .title { font-weight: 700; color: ${accent}; font-size: 10.5px; margin-bottom: 4px; display: flex; align-items: center; gap: 5px; }
        .pinv-terms-box .title svg { font-size: 13px; width: 13px; height: 13px; }
        .pinv-terms { white-space: pre-line; color: #333; line-height: 1.5; font-size: 10px; }
        .pinv-totals-box { flex: 1; border: 1px solid #ddd; border-radius: 4px; height: fit-content; }
        .pinv-totals-box .row { display: flex; justify-content: space-between; padding: 7px 12px; border-bottom: 1px solid #eee; font-size: 10.5px; }
        .pinv-totals-box .row.grand { background: ${accent}; color: #fff; font-weight: 800; font-size: 12px; border-bottom: none; }
        .pinv-bottom-row { display: flex; gap: 10px; margin-top: 4px; align-items: stretch; }
        .pinv-bank-box { flex: 1.2; border: 1px solid #ddd; border-radius: 4px; overflow: hidden; }
        .pinv-bank-box .pinv-box-body { display: flex; flex-direction: column; gap: 2px; }
        .pinv-sign-cols { flex: 2; display: flex; border-top: 1px solid #ddd; padding-top: 10px; }
        .pinv-sign-box {
          flex: 1; padding: 0 10px; border-left: 1px solid #ddd;
          text-align: center; font-size: 9.5px; color: #333;
          display: flex; flex-direction: column; justify-content: space-between; min-height: 100px;
        }
        .pinv-sign-box:first-child { border-left: none; padding-left: 0; }
        .pinv-sign-heading { font-weight: 700; color: #1a1a1a; }
        .pinv-sign-typed { color: #333; margin-bottom: 4px; }
        .pinv-sign-role { font-weight: 700; }
        .pinv-footer {
          margin-top: 14px; padding-top: 8px; border-top: 1px solid #ddd;
          display: grid; grid-template-columns: 1fr auto 1fr; align-items: center;
          font-size: 10px; color: #777;
        }
        .pinv-footer .pinv-footer-left { display: flex; align-items: center; gap: 4px; justify-self: start; white-space: nowrap; }
        .pinv-footer .pinv-footer-logo { height: 16px; width: auto; object-fit: contain; flex-shrink: 0; }
        .pinv-footer .pinv-footer-note { justify-self: center; white-space: nowrap; }
        .pinv-footer .pinv-footer-page { justify-self: end; white-space: nowrap; }
      `}</style>

      <div className="pinv-sheet">
        <div className="pinv-topbar" />

        <div className="pinv-header-row">
          <div className="pinv-logo-col">
            <img className="pinv-logo-mark" src="https://i.ibb.co/zH84Rn7w/Logo-tradeone.png" alt={company?.companyName || 'Nexora KEMACH'} />
            <div className="pinv-tagline">Trade Smarter. Grow Together.</div>
          </div>
          <div className="pinv-header-divider" />
          <div className="pinv-company-col">
            <div className="pinv-brand-name">{companyName}</div>
            <div className="pinv-company-lines">
              {company?.address && <div className="addr">{company.address}</div>}
              {companyAddrLine2 && <div className="addr">{companyAddrLine2}</div>}
            </div>
            <div className="pinv-company-icons">
              {company?.gstin && (
                <div className="item"><span className="pinv-icon-dot"><BadgeOutlinedIcon /></span><span>GSTIN</span><span>:</span><span>{company.gstin}</span></div>
              )}
              {company?.email && (
                <div className="item"><span className="pinv-icon-dot"><EmailOutlinedIcon /></span><span>Email</span><span>:</span><span>{company.email}</span></div>
              )}
              {company?.phone && (
                <div className="item"><span className="pinv-icon-dot"><PhoneOutlinedIcon /></span><span>Phone</span><span>:</span><span>{company.phone}</span></div>
              )}
              {company?.website && (
                <div className="item"><span className="pinv-icon-dot"><LanguageOutlinedIcon /></span><span>Website</span><span>:</span><span>{company.website}</span></div>
              )}
            </div>
          </div>
          <div className="pinv-header-right">
            <div className="pinv-banner">PURCHASE INVOICE</div>
            <table className="pinv-meta-table">
              <tbody>
                <tr>
                  <td className="label">Invoice No.</td><td className="value">{order.invoiceNo || '—'}</td>
                  <td className="label">Supplier Invoice Date</td><td className="value">{fmtDate(order.supplierInvoiceDate)}</td>
                </tr>
                <tr>
                  <td className="label">Invoice Date</td><td className="value">{fmtDate(order.invoiceDate)}</td>
                  <td className="label">GRN / Receipt No.</td><td className="value">{order.grnNo || '—'}</td>
                </tr>
                <tr>
                  <td className="label">Purchase Order No.</td><td className="value">{order.poNo || '—'}</td>
                  <td className="label">GRN / Receipt Date</td><td className="value">{fmtDate(grnDate)}</td>
                </tr>
                <tr>
                  <td className="label">PO Date</td><td className="value">{fmtDate(poDate)}</td>
                  <td className="label">Payment Terms</td><td className="value">{order.paymentTerms || '—'}</td>
                </tr>
                <tr>
                  <td className="label">Supplier Ref. No.</td><td className="value">{order.referenceNo || '—'}</td>
                  <td className="label">Due Date</td><td className="value">{fmtDate(order.dueDate)}</td>
                </tr>
                <tr>
                  <td className="label">Status</td><td className="value">{order.status || '—'}</td>
                  <td className="label">Currency</td><td className="value">{order.currency || 'INR'}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div className="pinv-boxes-row">
          <div className="pinv-box">
            <div className="pinv-box-title accent"><HomeOutlinedIcon /> SUPPLIER DETAILS</div>
            <div className="pinv-box-body">
              <div className="name">{supplierBlock.name || order.supplier || '—'}</div>
              {supplierBlock.rest.map((line, i) => <div key={i}>{line}</div>)}
              {supplierRecord?.gstin && <div className="field"><span className="l">GSTIN</span>: {supplierRecord.gstin}</div>}
              <div className="divider" />
              <div className="field"><span className="l">Phone</span>: {supplierRecord?.phone || '—'}</div>
              <div className="field"><span className="l">Email</span>: {supplierRecord?.email || '—'}</div>
            </div>
          </div>

          <div className="pinv-box">
            <div className="pinv-box-title"><LocationOnOutlinedIcon /> DELIVERY TO</div>
            <div className="pinv-box-body">
              <div className="name">{deliveryBlock.name || company?.companyName || '—'}</div>
              {deliveryBlock.rest.map((line, i) => <div key={i}>{line}</div>)}
              <div className="divider" />
              <div className="field"><span className="l">Phone</span>: {company?.phone || '—'}</div>
            </div>
          </div>

          <div className="pinv-box">
            <div className="pinv-box-title accent"><DescriptionOutlinedIcon /> OTHER DETAILS</div>
            <div className="pinv-box-body">
              <div className="field"><span className="l">Buying Branch</span>: {order.buyingBranch || '—'}</div>
              <div className="field"><span className="l">Department</span>: {order.department || '—'}</div>
              <div className="field"><span className="l">Place of Supply</span>: {order.placeOfSupply || '—'}</div>
              <div className="field"><span className="l">Transport Mode</span>: {order.transportMode || '—'}</div>
              <div className="field"><span className="l">E-Way Bill No.</span>: {order.eWayBillNo || '—'}</div>
              <div className="field"><span className="l">E-Way Bill Date</span>: {fmtDate(order.eWayBillDate)}</div>
            </div>
          </div>
        </div>

        <table className="pinv-items">
          <thead>
            <tr>
              <th>#</th>
              <th>Item Code</th>
              <th>Item Description</th>
              <th>HSN/SAC</th>
              <th>UOM</th>
              <th className="num">Qty</th>
              <th className="num">Unit Price (₹)</th>
              <th className="num">Discount (%)</th>
              <th className="num">Taxable Value (₹)</th>
              <th className="num">GST %</th>
              <th className="num">GST Amount (₹)</th>
              <th className="num">Total Amount (₹)</th>
            </tr>
          </thead>
          <tbody>
            {items.map((it, idx) => {
              const qty = Number(it.quantity) || 0;
              const price = Number(it.unitPrice) || 0;
              const itemDiscPct = Number(it.discountPercent) || 0;
              const gross = qty * price;
              const netAmount = gross - gross * (itemDiscPct / 100);
              const taxable = netAmount * (1 - discPct / 100);
              const taxPct = Number(it.taxPercent) || 0;
              const gstAmt = taxable * (taxPct / 100);
              const total = taxable + gstAmt;
              return (
                <tr key={idx}>
                  <td>{idx + 1}</td>
                  <td>{it.productCode || '—'}</td>
                  <td>{it.description || it.productName || '—'}</td>
                  <td>{it.hsnCode || '—'}</td>
                  <td>{it.uom || '—'}</td>
                  <td className="num">{qty}</td>
                  <td className="num">{price.toFixed(2)}</td>
                  <td className="num">{itemDiscPct.toFixed(2)}</td>
                  <td className="num">{taxable.toFixed(2)}</td>
                  <td className="num">{taxPct}%</td>
                  <td className="num">{gstAmt.toFixed(2)}</td>
                  <td className="num">{total.toFixed(2)}</td>
                </tr>
              );
            })}
          </tbody>
        </table>

        <div className="pinv-summary-row">
          <div style={{ flex: 1.4 }}>
            <div className="pinv-words-box">
              <div className="title"><CurrencyRupeeOutlinedIcon /> Amount in Words</div>
              <div>{amountToWords(totals.grandTotal) || '—'}</div>
            </div>
            {order.termsConditions && (
              <div className="pinv-terms-box">
                <div className="title"><GavelOutlinedIcon /> Terms &amp; Conditions</div>
                <div className="pinv-terms">{order.termsConditions}</div>
              </div>
            )}
          </div>
          <div className="pinv-totals-box">
            <div className="row"><span>Total Taxable Value</span><span>{fmtMoney(totals.taxableAmount)}</span></div>
            {taxRows.map((t) => (
              <div className="row" key={t.label}><span>{t.label}</span><span>{fmtMoney(t.amount)}</span></div>
            ))}
            <div className="row"><span>Round Off</span><span>{fmtMoney(totals.roundOff)}</span></div>
            <div className="row grand"><span>Grand Total</span><span>{fmtMoney(totals.grandTotal)}</span></div>
          </div>
        </div>

        <div className="pinv-bottom-row">
          <div className="pinv-bank-box">
            <div className="pinv-box-title"><AccountBalanceOutlinedIcon /> Bank Details (For NEFT / RTGS)</div>
            <div className="pinv-box-body">
              <div className="field"><span className="l">Bank Name</span>: {order.bankName || '—'}</div>
              <div className="field"><span className="l">A/c No.</span>: {order.bankAccountNo || '—'}</div>
              <div className="field"><span className="l">A/c Name</span>: {order.bankAccountName || company?.companyName || '—'}</div>
              <div className="field"><span className="l">IFSC Code</span>: {order.bankIfsc || '—'}</div>
              <div className="field"><span className="l">Branch</span>: {order.bankBranch || '—'}</div>
            </div>
          </div>

          <div className="pinv-sign-cols">
            <div className="pinv-sign-box">
              <div className="pinv-sign-heading">Verified By</div>
              <div>
                <div className="pinv-sign-typed">{order.verifiedBy || '—'}</div>
                <div className="pinv-sign-role">Purchase Manager</div>
              </div>
            </div>
            <div className="pinv-sign-box">
              <div className="pinv-sign-heading">Checked By</div>
              <div>
                <div className="pinv-sign-typed">{order.checkedBy || '—'}</div>
                <div className="pinv-sign-role">Purchase Executive</div>
              </div>
            </div>
            <div className="pinv-sign-box">
              <div className="pinv-sign-heading">Approved By</div>
              <div>
                <div className="pinv-sign-typed">{order.approvedBy || '—'}</div>
                <div className="pinv-sign-role">Finance Manager</div>
              </div>
            </div>
            <div className="pinv-sign-box">
              <div className="pinv-sign-heading">Authorised Signatory</div>
              <div>
                <div className="pinv-sign-typed">{order.authorisedSignatory || '—'}</div>
                <div className="pinv-sign-role">Director</div>
              </div>
            </div>
          </div>
        </div>

        <div className="pinv-footer">
          <span className="pinv-footer-left">
            <img className="pinv-footer-logo" src="https://i.ibb.co/v6qwV2tf/img-logo.png" alt="" />
            Thank you for your business!
          </span>
          <span className="pinv-footer-note">This is a computer generated document. No signature is required.</span>
          <span className="pinv-footer-page">Page 1 of 1</span>
        </div>
      </div>
    </div>
  );
}
