import React from 'react';
import dayjs from 'dayjs';
import BadgeOutlinedIcon from '@mui/icons-material/BadgeOutlined';
import PhoneOutlinedIcon from '@mui/icons-material/PhoneOutlined';
import EmailOutlinedIcon from '@mui/icons-material/EmailOutlined';
import LanguageOutlinedIcon from '@mui/icons-material/LanguageOutlined';
import HomeOutlinedIcon from '@mui/icons-material/HomeOutlined';
import LocationOnOutlinedIcon from '@mui/icons-material/LocationOnOutlined';
import DescriptionOutlinedIcon from '@mui/icons-material/DescriptionOutlined';
import AccountBalanceOutlinedIcon from '@mui/icons-material/AccountBalanceOutlined';
import CurrencyRupeeOutlinedIcon from '@mui/icons-material/CurrencyRupeeOutlined';
import GavelOutlinedIcon from '@mui/icons-material/GavelOutlined';
import { amountToWords } from '../../lib/numberToWords';
import { buildDocument, round2, isInterState, taxComponentRows } from '../../lib/documentTotals';

// Same fixed letterhead brand colors as the other print templates — navy +
// orange, independent of the app's active UI theme.
const NAVY = '#0B1E3D';
const ORANGE = '#F15A24';

// Header row column sizing — three independently tunable columns sitting
// side by side: the logo, the company/address block, and the DELIVERY
// CHALLAN box. Adjust these to rebalance the header without touching any
// other layout rule.
const HEADER_LOGO_WIDTH = 150;   // px — fixed width of the logo column
const HEADER_LOGO_HEIGHT = 'auto';    // px (number) or 'auto' — fixed/min height of the logo column
const HEADER_COMPANY_FLEX = 2;   // flex-grow — company name/address column width
const HEADER_COMPANY_HEIGHT = 'auto'; // px (number) or 'auto' — fixed/min height of the company column
const HEADER_CHALLAN_FLEX = 5;   // flex-grow — DELIVERY CHALLAN box column width
const HEADER_CHALLAN_HEIGHT = 'auto';   // px (number) or 'auto' — fixed/min height of the challan box column

// Logo image size — set independently from HEADER_LOGO_WIDTH above (that one
// sizes the column itself; these two size the actual <img>).
const LOGO_IMAGE_WIDTH = 'auto';  // px (number) or 'auto' — logo image width
const LOGO_IMAGE_HEIGHT = 50;     // px — logo image height

// Helper: turns a HEADER_*_HEIGHT value ('auto' or a number of px) into a
// CSS min-height declaration (or nothing, when left as 'auto').
const colMinHeight = (h) => (h === 'auto' || h == null ? '' : `min-height: ${h}px;`);
const pxOrAuto = (v) => (v === 'auto' || v == null ? 'auto' : `${v}px`);

const fmtDate = (d) => (d ? dayjs(d).format('DD/MM/YYYY') : '—');
const fmtMoney = (n) => `₹ ${(Number(n) || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

// Totals come from the shared engine in lib/documentTotals.js — the same
// module the form uses and a behavioural mirror of the server's own.
//
// This template was the furthest adrift of the six. It charged a flat 9%
// CGST + 9% SGST on the raw subtotal, ignoring each line's own tax rate and
// its discount entirely, on the stated grounds that it "mirrors
// DeliveryChallan.jsx's computeTotals exactly" — which stopped being true
// when that page moved to the shared engine. A challan of 5% goods printed
// 18% tax; a discounted line printed tax on the undiscounted amount.
function computeTotals(items, discountPercent, interState = false) {
  const { totals } = buildDocument(items, discountPercent, { interState, roundOff: true });
  return {
    ...totals,
    discount: round2(totals.subtotal - totals.taxableAmount),
    grandTotal: totals.amount,
  };
}

/**
 * A formal, letterhead-style printable Delivery Challan document — visual
 * twin of the Purchase Order / Purchase Invoice / Sales Quotation / Sales
 * Order templates. Only ever rendered inside a `.dc-print-area` wrapper
 * that's invisible on screen and shown exclusively via the `@media print`
 * rules below.
 */
export default function DeliveryChallanPrintable({ order, company, customerRecord, salesOrderRecord }) {
  const navy = NAVY;
  const accent = ORANGE;

  if (!order) return null;

  const items = order.items || [];
  // A Delivery Challan carries no header discount — the line discounts are
  // already inside each line's amount.
  const interState = isInterState(order.placeOfSupply, company?.state);
  const totals = computeTotals(items, 0, interState);
  const taxRows = taxComponentRows(totals, interState);

  const companyAddrLine2 = [company?.city, company?.state, company?.pincode].filter(Boolean).join(', ');
  const companyName = (company?.companyName || 'Nexora KEMACH').toUpperCase();

  const customerAddrLine = order.billingAddress || customerRecord?.billingAddress || '';
  const shippingAddrLine = order.shippingAddress || customerRecord?.shippingAddress || '';

  return (
    <div className="dc-print-area">
      <style>{`
        .dc-print-area { display: none; }
        @media print {
          body * { visibility: hidden; }
          .dc-print-area, .dc-print-area * { visibility: visible; }
          .dc-print-area {
            display: block; position: absolute; top: 0; left: 0; width: 100%;
            padding: 8mm; box-sizing: border-box;
          }
          @page { size: A4; margin: 8mm; }
        }
        .dc-sheet { font-family: Arial, Helvetica, sans-serif; color: #1a1a1a; font-size: 11px; }
        .dc-topbar { height: 5px; background: linear-gradient(90deg, ${navy} 0%, ${accent} 100%); border-radius: 2px; margin-bottom: 8px; }
        .dc-header-row { display: flex; align-items: stretch; border: 1px solid ${accent}; border-radius: 4px; overflow: hidden; margin-bottom: 10px; }
        .dc-logo-col {
          flex-shrink: 0; width: ${HEADER_LOGO_WIDTH}px; ${colMinHeight(HEADER_LOGO_HEIGHT)} display: flex; flex-direction: column;
          align-items: center; justify-content: center; gap: 8px; padding: 14px 12px; text-align: center;
        }
        .dc-logo-mark { width: ${pxOrAuto(LOGO_IMAGE_WIDTH)}; height: ${pxOrAuto(LOGO_IMAGE_HEIGHT)}; object-fit: contain; }
        .dc-tagline { font-size: 9px; color: #999; font-style: italic; white-space: nowrap; }
        .dc-header-divider { width: 1px; background: #e2e2e2; margin: 18px 0; flex-shrink: 0; }
        .dc-company-col { flex: ${HEADER_COMPANY_FLEX}; ${colMinHeight(HEADER_COMPANY_HEIGHT)} padding: 14px 16px; }
        .dc-brand-name { font-size: 14px; font-weight: 800; letter-spacing: 0.3px; color: ${navy}; margin-bottom: 4px; }
        .dc-company-lines .addr { line-height: 1.5; color: #333; font-weight: 600; }
        .dc-company-icons { margin-top: 8px; display: flex; flex-direction: column; gap: 5px; }
        .dc-company-icons .item { display: grid; grid-template-columns: 18px 78px 8px 1fr; align-items: center; column-gap: 8px; color: #333; }
        .dc-icon-dot {
          width: 18px; height: 18px; border-radius: 50%; background: ${accent}; color: #fff;
          display: flex; align-items: center; justify-content: center; flex-shrink: 0;
        }
        .dc-icon-dot svg { font-size: 12px; width: 12px; height: 12px; }
        .dc-header-right { flex: ${HEADER_CHALLAN_FLEX}; ${colMinHeight(HEADER_CHALLAN_HEIGHT)} background: #fafafa; border-left: 1px solid ${accent}; display: flex; flex-direction: column; }
        .dc-banner {
          background: ${navy}; color: #fff; font-weight: 800; font-size: 15px; letter-spacing: 1px;
          text-align: center; padding: 9px 0; position: relative; overflow: hidden;
        }
        .dc-banner::after {
          content: ''; position: absolute; top: 0; right: 0; width: 0; height: 0;
          border-style: solid; border-width: 0 34px 34px 0; border-color: transparent ${accent} transparent transparent;
        }
        .dc-meta-table { width: 100%; border-collapse: collapse; table-layout: fixed; }
        .dc-meta-table td { padding: 4px 6px; font-size: 9.5px; vertical-align: top; word-break: break-word; overflow-wrap: break-word; }
        .dc-meta-table td.label { color: #666; width: 27%; }
        .dc-meta-table td.value { font-weight: 700; width: 23%; padding-right: 4px; }
        .dc-boxes-row { display: flex; gap: 10px; margin-bottom: 10px; }
        .dc-box { flex: 1; border: 1px solid #ddd; border-radius: 4px; overflow: hidden; }
        .dc-box-title {
          background: ${navy}; color: #fff; font-weight: 700; font-size: 10.5px; letter-spacing: 0.5px;
          padding: 6px 10px; display: flex; align-items: center; gap: 6px;
        }
        .dc-box-title.accent { background: ${accent}; }
        .dc-box-title svg { font-size: 13px; width: 13px; height: 13px; }
        .dc-box-body { padding: 8px 10px; }
        .dc-box-body .name { font-weight: 700; margin-bottom: 3px; }
        .dc-box-body div { line-height: 1.5; color: #333; }
        .dc-box-body .field { margin-top: 4px; }
        .dc-box-body .field .l { color: #666; display: inline-block; min-width: 90px; }
        .dc-box-body .divider { border-top: 1px solid #ddd; margin: 8px 0 4px; }
        table.dc-items { width: 100%; border-collapse: collapse; margin-bottom: 10px; }
        table.dc-items th { background: ${navy}; color: #fff; font-size: 9.5px; padding: 6px 5px; text-align: left; white-space: nowrap; }
        table.dc-items td { border-bottom: 1px solid #eee; padding: 5px; font-size: 10px; }
        table.dc-items td.num, table.dc-items th.num { text-align: right; }
        .dc-summary-row { display: flex; gap: 10px; margin-bottom: 10px; }
        .dc-words-box { flex: 1.4; border: 1px solid #ddd; border-radius: 4px; padding: 10px 12px; background: #fdf1ea; }
        .dc-words-box .title { font-weight: 700; color: ${accent}; font-size: 10.5px; margin-bottom: 4px; display: flex; align-items: center; gap: 5px; }
        .dc-words-box .title svg { font-size: 13px; width: 13px; height: 13px; }
        .dc-terms-box { flex: 1.4; border: 1px solid #ddd; border-radius: 4px; padding: 10px 12px; margin-top: 8px; }
        .dc-terms-box .title { font-weight: 700; color: ${accent}; font-size: 10.5px; margin-bottom: 4px; display: flex; align-items: center; gap: 5px; }
        .dc-terms-box .title svg { font-size: 13px; width: 13px; height: 13px; }
        .dc-terms { white-space: pre-line; color: #333; line-height: 1.5; font-size: 10px; }
        .dc-totals-box { flex: 1; border: 1px solid #ddd; border-radius: 4px; height: fit-content; }
        .dc-totals-box .row { display: flex; justify-content: space-between; padding: 7px 12px; border-bottom: 1px solid #eee; font-size: 10.5px; }
        .dc-totals-box .row.grand { background: ${accent}; color: #fff; font-weight: 800; font-size: 12px; border-bottom: none; }
        .dc-bottom-row { display: flex; gap: 10px; margin-top: 4px; align-items: stretch; }
        .dc-bank-box { flex: 1.2; border: 1px solid #ddd; border-radius: 4px; overflow: hidden; }
        .dc-bank-box .dc-box-body { display: flex; flex-direction: column; gap: 2px; }
        .dc-sign-cols { flex: 2; display: flex; border-top: 1px solid #ddd; padding-top: 10px; }
        .dc-sign-box {
          flex: 1; padding: 0 10px; border-left: 1px solid #ddd;
          text-align: center; font-size: 9.5px; color: #333;
          display: flex; flex-direction: column; justify-content: space-between; min-height: 100px;
        }
        .dc-sign-box:first-child { border-left: none; padding-left: 0; }
        .dc-sign-heading { font-weight: 700; color: #1a1a1a; }
        .dc-sign-typed { color: #333; margin-bottom: 4px; }
        .dc-sign-role { font-weight: 700; }
        .dc-footer {
          margin-top: 14px; padding-top: 8px; border-top: 1px solid #ddd;
          display: grid; grid-template-columns: 1fr auto 1fr; align-items: center;
          font-size: 10px; color: #777;
        }
        .dc-footer .dc-footer-left { display: flex; align-items: center; gap: 4px; justify-self: start; white-space: nowrap; }
        .dc-footer .dc-footer-logo { height: 16px; width: auto; object-fit: contain; flex-shrink: 0; }
        .dc-footer .dc-footer-note { justify-self: center; white-space: nowrap; }
        .dc-footer .dc-footer-page { justify-self: end; white-space: nowrap; }
      `}</style>

      <div className="dc-sheet">
        <div className="dc-topbar" />

        <div className="dc-header-row">
          <div className="dc-logo-col">
            <img className="dc-logo-mark" src="https://i.ibb.co/zH84Rn7w/Logo-tradeone.png" alt={company?.companyName || 'Nexora KEMACH'} />
            <div className="dc-tagline">Trade Smarter. Grow Together.</div>
          </div>
          <div className="dc-header-divider" />
          <div className="dc-company-col">
            <div className="dc-brand-name">{companyName}</div>
            <div className="dc-company-lines">
              {company?.address && <div className="addr">{company.address}</div>}
              {companyAddrLine2 && <div className="addr">{companyAddrLine2}</div>}
            </div>
            <div className="dc-company-icons">
              {company?.gstin && (
                <div className="item"><span className="dc-icon-dot"><BadgeOutlinedIcon /></span><span>GSTIN</span><span>:</span><span>{company.gstin}</span></div>
              )}
              {company?.phone && (
                <div className="item"><span className="dc-icon-dot"><PhoneOutlinedIcon /></span><span>Phone</span><span>:</span><span>{company.phone}</span></div>
              )}
              {company?.email && (
                <div className="item"><span className="dc-icon-dot"><EmailOutlinedIcon /></span><span>Email</span><span>:</span><span>{company.email}</span></div>
              )}
              {company?.website && (
                <div className="item"><span className="dc-icon-dot"><LanguageOutlinedIcon /></span><span>Website</span><span>:</span><span>{company.website}</span></div>
              )}
            </div>
          </div>
          <div className="dc-header-right">
            <div className="dc-banner">DELIVERY CHALLAN</div>
            <table className="dc-meta-table">
              <tbody>
                <tr>
                  <td className="label">Challan No.</td><td className="value">{order.challanNo || '—'}</td>
                  <td className="label">Delivery Date</td><td className="value">{fmtDate(order.deliveryDate)}</td>
                </tr>
                <tr>
                  <td className="label">Challan Date</td><td className="value">{fmtDate(order.challanDate)}</td>
                  <td className="label">E-Way Bill No.</td><td className="value">{order.eWayBillNo || '—'}</td>
                </tr>
                <tr>
                  <td className="label">Sales Order No.</td><td className="value">{order.orderNo || '—'}</td>
                  <td className="label">E-Way Bill Date</td><td className="value">{fmtDate(order.eWayBillDate)}</td>
                </tr>
                <tr>
                  <td className="label">Sales Order Date</td><td className="value">{fmtDate(salesOrderRecord?.orderDate)}</td>
                  <td className="label">Place of Supply</td><td className="value">{order.placeOfSupply || '—'}</td>
                </tr>
                <tr>
                  <td className="label">Customer Ref. No.</td><td className="value">{salesOrderRecord?.referenceNo || '—'}</td>
                  <td className="label">No. of Packages</td><td className="value">{order.noOfPackages || '—'}</td>
                </tr>
                <tr>
                  <td className="label">Contact No.</td><td className="value">{order.phone || customerRecord?.phone || '—'}</td>
                  <td className="label">Total Weight (KG)</td><td className="value">{order.totalWeight || '—'}</td>
                </tr>
                <tr>
                  <td className="label">Transport Mode</td><td className="value">{order.transportMode || '—'}</td>
                  <td className="label">Prepared By</td><td className="value">{order.salesPerson || '—'}</td>
                </tr>
                <tr>
                  <td className="label">Vehicle No.</td><td className="value">{order.vehicleNo || '—'}</td>
                  <td className="label"></td><td className="value"></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div className="dc-boxes-row">
          <div className="dc-box">
            <div className="dc-box-title accent"><HomeOutlinedIcon /> BILL TO (CUSTOMER DETAILS)</div>
            <div className="dc-box-body">
              <div className="name">{order.customer || '—'}</div>
              {customerAddrLine && <div>{customerAddrLine}</div>}
              {customerRecord?.gstin && <div className="field"><span className="l">GSTIN</span>: {customerRecord.gstin}</div>}
              <div className="divider" />
              <div className="field"><span className="l">Phone</span>: {order.phone || customerRecord?.phone || '—'}</div>
              <div className="field"><span className="l">Email</span>: {order.email || customerRecord?.email || '—'}</div>
              <div className="field"><span className="l">Contact Person</span>: {order.contactPerson || '—'}</div>
            </div>
          </div>

          <div className="dc-box">
            <div className="dc-box-title"><LocationOnOutlinedIcon /> SHIP TO (DELIVERY ADDRESS)</div>
            <div className="dc-box-body">
              <div className="name">{order.customer || '—'}</div>
              {shippingAddrLine && <div>{shippingAddrLine}</div>}
              <div className="divider" />
              <div className="field"><span className="l">Phone</span>: {order.phone || customerRecord?.phone || '—'}</div>
              <div className="field"><span className="l">Contact Person</span>: {order.contactPerson || '—'}</div>
            </div>
          </div>

          <div className="dc-box">
            <div className="dc-box-title accent"><DescriptionOutlinedIcon /> OTHER DETAILS</div>
            <div className="dc-box-body">
              <div className="field"><span className="l">Packing &amp; Forwarding</span>: {order.packingForwarding || '—'}</div>
              <div className="field"><span className="l">Loading / Unloading</span>: {order.loadingUnloading || '—'}</div>
              <div className="field"><span className="l">Inspection</span>: {order.inspection || '—'}</div>
              <div className="field"><span className="l">Remarks</span>: {order.remarks || '—'}</div>
            </div>
          </div>
        </div>

        <table className="dc-items">
          <thead>
            <tr>
              <th>#</th>
              <th>Item Code</th>
              <th>Item Description</th>
              <th>HSN/SAC</th>
              <th>UOM</th>
              <th className="num">Qty</th>
              <th className="num">No. of Packages</th>
              <th className="num">Unit Price (₹)</th>
              <th className="num">Total Amount (₹)</th>
            </tr>
          </thead>
          <tbody>
            {items.map((it, idx) => {
              const qty = Number(it.quantity) || 0;
              const price = Number(it.unitPrice) || 0;
              const total = qty * price;
              return (
                <tr key={idx}>
                  <td>{idx + 1}</td>
                  <td>{it.productCode || '—'}</td>
                  <td>{it.description || it.productName || '—'}</td>
                  <td>{it.hsnCode || '—'}</td>
                  <td>{it.uom || '—'}</td>
                  <td className="num">{qty}</td>
                  <td className="num">{it.noOfPackages || 1}</td>
                  <td className="num">{price.toFixed(2)}</td>
                  <td className="num">{total.toFixed(2)}</td>
                </tr>
              );
            })}
          </tbody>
        </table>

        <div className="dc-summary-row">
          <div style={{ flex: 1.4 }}>
            <div className="dc-words-box">
              <div className="title"><CurrencyRupeeOutlinedIcon /> Amount in Words</div>
              <div>{amountToWords(totals.grandTotal) || '—'}</div>
            </div>
            {order.termsConditions && (
              <div className="dc-terms-box">
                <div className="title"><GavelOutlinedIcon /> Terms &amp; Conditions</div>
                <div className="dc-terms">{order.termsConditions}</div>
              </div>
            )}
          </div>
          <div className="dc-totals-box">
            <div className="row"><span>Total Taxable Value</span><span>{fmtMoney(totals.taxableAmount)}</span></div>
            {taxRows.map((t) => (
              <div className="row" key={t.label}><span>{t.label}</span><span>{fmtMoney(t.amount)}</span></div>
            ))}
            <div className="row"><span>Round Off</span><span>{fmtMoney(totals.roundOff)}</span></div>
            <div className="row grand"><span>Grand Total</span><span>{fmtMoney(totals.grandTotal)}</span></div>
          </div>
        </div>

        <div className="dc-bottom-row">
          <div className="dc-bank-box">
            <div className="dc-box-title"><AccountBalanceOutlinedIcon /> Bank Details (For NEFT / RTGS)</div>
            <div className="dc-box-body">
              <div className="field"><span className="l">Bank Name</span>: {order.bankName || '—'}</div>
              <div className="field"><span className="l">A/c No.</span>: {order.bankAccountNo || '—'}</div>
              <div className="field"><span className="l">A/c Name</span>: {order.bankAccountName || company?.companyName || '—'}</div>
              <div className="field"><span className="l">IFSC Code</span>: {order.bankIfsc || '—'}</div>
              <div className="field"><span className="l">Branch</span>: {order.bankBranch || '—'}</div>
            </div>
          </div>

          <div className="dc-sign-cols">
            <div className="dc-sign-box">
              <div className="dc-sign-heading">Prepared By</div>
              <div>
                <div className="dc-sign-typed">{order.salesPerson || '—'}</div>
                <div className="dc-sign-role">Sales Executive</div>
              </div>
            </div>
            <div className="dc-sign-box">
              <div className="dc-sign-heading">Checked By</div>
              <div>
                <div className="dc-sign-typed">{order.checkedBy || '—'}</div>
                <div className="dc-sign-role">Sales Manager</div>
              </div>
            </div>
            <div className="dc-sign-box">
              <div className="dc-sign-heading">Authorized By</div>
              <div>
                <div className="dc-sign-typed">{order.authorizedBy || '—'}</div>
                <div className="dc-sign-role">Finance Manager</div>
              </div>
            </div>
            <div className="dc-sign-box">
              <div className="dc-sign-heading">For {companyName}</div>
              <div>
                <div className="dc-sign-typed">{order.authorisedSignatory || '—'}</div>
                <div className="dc-sign-role">Director</div>
              </div>
            </div>
          </div>
        </div>

        <div className="dc-footer">
          <span className="dc-footer-left">
            <img className="dc-footer-logo" src="https://i.ibb.co/v6qwV2tf/img-logo.png" alt="" />
            Thank you for your business!
          </span>
          <span className="dc-footer-note">This is a computer generated document. No signature is required.</span>
          <span className="dc-footer-page">Page 1 of 1</span>
        </div>
      </div>
    </div>
  );
}
