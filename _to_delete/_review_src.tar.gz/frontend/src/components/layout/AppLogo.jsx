import React from 'react';
import { Box, Typography } from '@mui/material';

// Brand mark icon (flame/flag glyph). Hosted, not bundled, per the supplied
// asset -- if this ever needs to move local, drop it in /public and swap
// this for an import so it's still a single point of change.
const LOGO_ICON_URL = 'https://i.ibb.co/v6qwV2tf/img-logo.png';

// The wordmark's accent letter is fixed brand orange -- it deliberately does
// NOT follow theme.palette.primary. The user-selectable colour schemes
// (blue, green, purple...) recolour the app chrome, but the logo has to keep
// matching the icon glyph beside it, which is a static orange image. Letting
// it track the theme made the "O" clash with its own icon on every non-orange
// scheme. Same value as colorSchemes.orange.primary.
const BRAND_ACCENT = '#FF6B35';

// Single source for the org brand mark (icon + wordmark) so every surface
// that shows it -- header, sidebar, auth screens -- renders identical
// branding. `iconOnly` drops the wordmark for tight spaces (collapsed
// sidebar rail, mobile). `titleFontSize`/`subtitleFontSize` default to the
// header/sidebar sizing but are overridable per-surface -- the login page
// wants a bigger wordmark than a 36px sidebar rail can fit, without bumping
// the size everywhere else that renders this same component.
export default function AppLogo({
  iconOnly = false, iconSize = 36,
  titleFontSize = '1.05rem', subtitleFontSize = '0.6rem',
}) {
  return (
    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, minWidth: 0 }}>
      <Box
        component="img"
        src={LOGO_ICON_URL}
        alt="Nexora"
        sx={{ height: iconSize, width: 'auto', flexShrink: 0, objectFit: 'contain' }}
      />
      {!iconOnly && (
        <Box sx={{ minWidth: 0, lineHeight: 1 }}>
          <Typography
            noWrap
            sx={{
              fontWeight: 800, fontSize: titleFontSize, letterSpacing: '0.01em',
              color: 'text.primary', lineHeight: 1.15,
            }}
          >
            NEX
            <Box component="span" sx={{ color: BRAND_ACCENT }}>O</Box>
            RA
          </Typography>
          <Typography
            noWrap
            sx={{
              fontSize: subtitleFontSize, fontWeight: 600, letterSpacing: '0.22em',
              color: 'text.secondary', lineHeight: 1.4,
            }}
          >
            KEMACH
          </Typography>
        </Box>
      )}
    </Box>
  );
}
