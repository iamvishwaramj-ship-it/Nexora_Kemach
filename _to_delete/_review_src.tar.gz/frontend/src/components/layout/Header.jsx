import React, { useState } from 'react';
import {
  AppBar, Toolbar, IconButton, Typography, Box,
  Avatar, Menu, MenuItem, Divider, Tooltip, ListItemIcon, useMediaQuery,
} from '@mui/material';
import { useTheme } from '@mui/material/styles';
import MenuIcon from '@mui/icons-material/Menu';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import SearchIcon from '@mui/icons-material/Search';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import PersonIcon from '@mui/icons-material/Person';
import SettingsIcon from '@mui/icons-material/Settings';
import LogoutIcon from '@mui/icons-material/Logout';
import LanguageIcon from '@mui/icons-material/Language';
import PaletteIcon from '@mui/icons-material/Palette';
import LightModeIcon from '@mui/icons-material/LightMode';
import DarkModeIcon from '@mui/icons-material/DarkMode';
import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { toggleSidebar, toggleMobileSidebar } from '../../store/uiSlice';
import { setColorScheme, toggleMode } from '../../store/themeSlice';
import { colorSchemeList } from '../../theme/colorSchemes';
import { selectCurrentUser } from '../../store/authSlice';
import { useLogoutMutation } from '../../features/auth/authApi';
import GlobalSearch from '../navigation/GlobalSearch';
import AppLogo from './AppLogo';
import { SIDEBAR_WIDTH, SIDEBAR_WIDTH_COLLAPSED } from './Sidebar';

const LANGUAGES = [
  { code: 'en', label: 'English' },
  { code: 'ta', label: 'தமிழ்' },
  { code: 'hi', label: 'हिन्दी' },
];

const Header = React.memo(() => {
  const { t, i18n } = useTranslation();
  const theme = useTheme();
  // Same breakpoint Sidebar.jsx uses to decide permanent vs temporary drawer
  // — the hamburger button must toggle whichever state that drawer is
  // actually reading, or it silently does nothing (or toggles the wrong,
  // persisted desktop-collapse state instead of the transient mobile one).
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  // Separate, narrower breakpoint than `isMobile`: tablets (600-900px) still
  // have room for the wordmark and an always-visible search field, phones do
  // not. Below 600px the navbar switches to icon-only + reveal-on-tap search.
  const isCompact = useMediaQuery(theme.breakpoints.down('sm'));
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const user = useSelector(selectCurrentUser);
  const mode = useSelector((s) => s.theme.mode);
  const colorScheme = useSelector((s) => s.theme.colorScheme);
  const collapsed = useSelector((s) => s.ui.sidebarCollapsed);
  // Matches Sidebar's own width exactly, so the search bar (and everything
  // after it) starts right where the sidebar ends instead of wherever the
  // hamburger+logo cluster happens to measure.
  const brandWidth = isMobile ? 'auto' : (collapsed ? SIDEBAR_WIDTH_COLLAPSED : SIDEBAR_WIDTH);
  const [logout] = useLogoutMutation();
  const [userMenuAnchor, setUserMenuAnchor] = useState(null);
  const [langMenuAnchor, setLangMenuAnchor] = useState(null);
  const [themeMenuAnchor, setThemeMenuAnchor] = useState(null);
  const [searchOpen, setSearchOpen] = useState(false);

  const handleLanguageChange = (code) => {
    i18n.changeLanguage(code);
    localStorage.setItem('nexora_language', code);
    setLangMenuAnchor(null);
  };

  const handleLogout = async () => {
    setUserMenuAnchor(null);
    const refreshToken = localStorage.getItem('nexora_refresh_token');
    try { await logout(refreshToken).unwrap(); } catch { /* ignore */ }
    navigate('/login');
  };

  return (
    <AppBar
      position="fixed"
      elevation={0}
      sx={{ zIndex: (theme) => theme.zIndex.drawer + 1, bgcolor: 'background.paper', borderBottom: '1px solid', borderColor: 'divider', color: 'text.primary' }}
    >
      <Toolbar disableGutters sx={{ gap: { xs: 0.25, sm: 1.5 }, minHeight: '64px !important', pr: { xs: 0.5, sm: 2 } }}>
        {isCompact && searchOpen ? (
          /* Phone-width search: there's no room for a permanent field next to
             six controls, so the search icon takes over the whole toolbar
             until the user backs out or picks a result. */
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, width: '100%', pl: 0.5, pr: 1 }}>
            <IconButton onClick={() => setSearchOpen(false)} aria-label={t('common.close')}>
              <ArrowBackIcon />
            </IconButton>
            <Box sx={{ flex: 1, minWidth: 0 }}>
              <GlobalSearch fullWidth autoFocus onNavigate={() => setSearchOpen(false)} />
            </Box>
          </Box>
        ) : (
        <>
        <Box
          sx={{
            display: 'flex', alignItems: 'center', gap: 1,
            // On phones the wordmark is the one thing that *may* give ground:
            // let it ellipsis rather than shove the action icons off-screen on
            // a 320px device. Everything else in the bar is flexShrink: 0.
            flexShrink: isCompact ? 1 : 0, minWidth: 0,
            width: brandWidth,
            // Both states line the leading control up with the vertical axis
            // of the sidebar nav icons directly beneath it:
            //   expanded  -> List px:1 (8px) + ListItemButton pl (16px) + half
            //                of the 20px icon = 34px centre. A small
            //                IconButton is 34px wide, so pl:17px centres it
            //                on 34px too.
            //   collapsed -> the 72px rail centres its icons on 36px, and this
            //                box is exactly 72px wide with a single centred
            //                child, so it lands on 36px as well.
            // On phones the sidebar is a temporary drawer, so there are no
            // rail icons to line up with -- reclaim the inset for content.
            pl: !isMobile && collapsed ? 0 : (isCompact ? 0.5 : '17px'),
            justifyContent: !isMobile && collapsed ? 'center' : 'flex-start',
            transition: 'width 0.2s',
          }}
        >
          {!isMobile && collapsed ? (
            /* Collapsed rail is only 72px wide -- a hamburger *and* a logo
               can't both sit there without one of them falling off the icon
               axis. So the rail shows the brand mark alone, and the brand
               mark itself becomes the expand affordance: hovering swaps it
               for a chevron so it's obvious it's clickable. */
            <Tooltip title={t('common.expandSidebar')} placement="right">
              <IconButton
                onClick={() => dispatch(toggleSidebar())}
                aria-label={t('common.expandSidebar')}
                sx={{
                  p: 0.75,
                  '&:hover .brand-mark': { opacity: 0 },
                  '&:hover .expand-mark': { opacity: 1 },
                }}
              >
                <Box sx={{ position: 'relative', width: 24, height: 24, display: 'grid', placeItems: 'center' }}>
                  <Box
                    className="brand-mark"
                    sx={{ position: 'absolute', inset: 0, display: 'grid', placeItems: 'center', transition: 'opacity 0.15s' }}
                  >
                    <AppLogo iconOnly iconSize={24} />
                  </Box>
                  <ChevronRightIcon
                    className="expand-mark"
                    sx={{ position: 'absolute', fontSize: 22, opacity: 0, transition: 'opacity 0.15s' }}
                  />
                </Box>
              </IconButton>
            </Tooltip>
          ) : (
            <>
              <IconButton
                onClick={() => dispatch(isMobile ? toggleMobileSidebar() : toggleSidebar())}
                size="small"
                aria-label={t('common.collapseSidebar')}
              >
                <MenuIcon />
              </IconButton>
              {/* Full wordmark in every state, just a size down on phones.
                  The room for it comes from moving the language switcher
                  into the profile menu below sm. */}
              <AppLogo iconSize={isCompact ? 28 : 32} />
            </>
          )}
        </Box>

        {!isCompact && <GlobalSearch />}

        <Box sx={{ flex: 1 }} />

        {isCompact && (
          <IconButton size="small" onClick={() => setSearchOpen(true)} aria-label={t('common.search')} sx={{ flexShrink: 0 }}>
            <SearchIcon fontSize="small" />
          </IconButton>
        )}

        {/* Language switcher -- desktop/tablet only. Below sm it lives inside
            the profile menu instead, which is what buys the wordmark its
            space back in the phone navbar. */}
        {!isCompact && (
          <>
            <Tooltip title={t('common.language')}>
              <IconButton size="small" onClick={(e) => setLangMenuAnchor(e.currentTarget)} sx={{ flexShrink: 0 }}>
                <LanguageIcon fontSize="small" />
              </IconButton>
            </Tooltip>
            <Menu anchorEl={langMenuAnchor} open={Boolean(langMenuAnchor)} onClose={() => setLangMenuAnchor(null)}>
              {LANGUAGES.map((l) => (
                <MenuItem key={l.code} selected={i18n.language === l.code} onClick={() => handleLanguageChange(l.code)}>
                  {l.label}
                </MenuItem>
              ))}
            </Menu>
          </>
        )}

        {/* Theme color switcher */}
        <Tooltip title={t('common.theme')}>
          <IconButton size="small" onClick={(e) => setThemeMenuAnchor(e.currentTarget)} sx={{ flexShrink: 0 }}>
            <PaletteIcon fontSize="small" />
          </IconButton>
        </Tooltip>
        <Menu anchorEl={themeMenuAnchor} open={Boolean(themeMenuAnchor)} onClose={() => setThemeMenuAnchor(null)}>
          {colorSchemeList.map((s) => (
            <MenuItem key={s.key} selected={colorScheme === s.key} onClick={() => { dispatch(setColorScheme(s.key)); setThemeMenuAnchor(null); }}>
              <ListItemIcon>
                <Box sx={{ width: 16, height: 16, borderRadius: '50%', background: `linear-gradient(135deg, ${s.primary}, ${s.accent})` }} />
              </ListItemIcon>
              {s.label}
            </MenuItem>
          ))}
        </Menu>

        {/* Light/dark mode */}
        <Tooltip title={mode === 'light' ? t('common.darkMode') : t('common.lightMode')}>
          <IconButton size="small" onClick={() => dispatch(toggleMode())} sx={{ flexShrink: 0 }}>
            {mode === 'light' ? <DarkModeIcon fontSize="small" /> : <LightModeIcon fontSize="small" />}
          </IconButton>
        </Tooltip>

        {/* Profile */}
        <Box
          onClick={(e) => setUserMenuAnchor(e.currentTarget)}
          sx={{
            display: 'flex', alignItems: 'center', gap: 1, cursor: 'pointer', flexShrink: 0,
            px: { xs: 0.5, sm: 1 }, py: 0.5, borderRadius: 2, '&:hover': { bgcolor: 'action.hover' },
          }}
        >
          <Avatar src={user?.profilePhotoUrl} sx={{ width: 32, height: 32, bgcolor: 'primary.main', fontSize: '0.875rem', fontWeight: 600 }}>
            {user?.name?.charAt(0) || 'U'}
          </Avatar>
          <Box sx={{ display: { xs: 'none', md: 'block' } }}>
            <Typography sx={{ fontSize: '0.8125rem', fontWeight: 600, lineHeight: 1.2 }}>{user?.name || 'User'}</Typography>
            <Typography sx={{ fontSize: '0.7rem', color: 'text.secondary', lineHeight: 1.2 }}>{user?.role || 'Admin'}</Typography>
          </Box>
          {/* The caret only labels the (hidden) name block -- on a phone it's
              a bare arrow next to an avatar, which reads as clutter. */}
          <KeyboardArrowDownIcon sx={{ fontSize: 16, display: { xs: 'none', md: 'block' } }} />
        </Box>
        </>
        )}

        <Menu anchorEl={userMenuAnchor} open={Boolean(userMenuAnchor)} onClose={() => setUserMenuAnchor(null)} PaperProps={{ sx: { mt: 1, minWidth: 200 } }}>
          <Box sx={{ px: 2, py: 1.5 }}>
            <Typography variant="subtitle2">{user?.name}</Typography>
            <Typography variant="caption" color="text.secondary">{user?.email}</Typography>
          </Box>
          <Divider />
          <MenuItem onClick={() => { navigate('/settings/profile'); setUserMenuAnchor(null); }} sx={{ gap: 1.5, fontSize: '0.875rem' }}>
            <PersonIcon fontSize="small" /> {t('common.profile')}
          </MenuItem>
          <MenuItem onClick={() => { navigate('/settings'); setUserMenuAnchor(null); }} sx={{ gap: 1.5, fontSize: '0.875rem' }}>
            <SettingsIcon fontSize="small" /> {t('common.settings')}
          </MenuItem>

          {/* Phone-only: the language options are listed inline rather than
              behind a nested menu. A submenu would have to anchor on a
              MenuItem that unmounts the moment this menu closes, which is
              exactly the kind of dangling-anchor bug worth avoiding. */}
          {isCompact && <Divider key="lang-divider" />}
          {isCompact && (
            <Box key="lang-heading" sx={{ px: 2, pt: 1, pb: 0.5, display: 'flex', alignItems: 'center', gap: 1.5 }}>
              <LanguageIcon fontSize="small" sx={{ color: 'text.secondary' }} />
              <Typography variant="caption" color="text.secondary">{t('common.language')}</Typography>
            </Box>
          )}
          {isCompact && LANGUAGES.map((l) => (
            <MenuItem
              key={`lang-${l.code}`}
              selected={i18n.language === l.code}
              onClick={() => { handleLanguageChange(l.code); setUserMenuAnchor(null); }}
              sx={{ pl: 5.5, fontSize: '0.875rem' }}
            >
              {l.label}
            </MenuItem>
          ))}

          <Divider />
          <MenuItem onClick={handleLogout} sx={{ gap: 1.5, fontSize: '0.875rem', color: 'error.main' }}>
            <LogoutIcon fontSize="small" /> {t('common.logout')}
          </MenuItem>
        </Menu>
      </Toolbar>
    </AppBar>
  );
});

export default Header;
