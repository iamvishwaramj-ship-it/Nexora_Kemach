import React from 'react';
import { Box, Divider, Stack, Typography } from '@mui/material';
import FormTextField from './FormTextField';
import { taxComponentRows } from '../../lib/documentTotals';

/**
 * The totals panel shared by all eight sales/purchase document pages.
 *
 * Each page used to inline its own copy of this markup, and every copy
 * hard-coded the tax lines as "CGST (9%)" and "SGST (9%)" regardless of what
 * the goods actually attract — a document of 5% items still announced 9% —
 * and none of them could render IGST at all. That last part mattered: the
 * server decides CGST/SGST vs IGST by comparing the document's Place of
 * Supply against the company's registered state (resolveTaxTreatment in
 * backend/src/routes/resources.js), so on an inter-state supply the panel was
 * showing a split that the saved record does not have.
 *
 * Rendering it once, here, driven by the same `interState` flag the server
 * uses, means the screen and the ledger can't disagree again.
 */

function Row({ label, value, bold = false }) {
  return (
    <Stack direction="row" justifyContent="space-between">
      <Typography variant="body2" color="text.secondary">{label}</Typography>
      <Typography variant="body2" fontWeight={bold ? 700 : 600}>₹{value}</Typography>
    </Stack>
  );
}

/**
 * @param {object}  totals        result of the page's computeTotals()
 * @param {boolean} interState    true when the supply is taxed wholly as IGST
 * @param {string}  subtotalLabel some pages say "Sub Total", others "Subtotal"
 * @param {string}  discountField name of the header Discount % field, or null
 *                                on documents that have no header discount
 * @param {boolean} showRoundOff  Purchase Order has no round-off line
 */
export default function DocumentTotalsPanel({
  totals,
  interState = false,
  subtotalLabel = 'Sub Total',
  discountField = 'discountPercent',
  showRoundOff = true,
}) {
  const taxRows = taxComponentRows(totals, interState);

  return (
    <Stack spacing={1.25}>
      <Row label={subtotalLabel} value={totals.subtotal.toFixed(2)} />

      {discountField ? (
        <Stack direction="row" justifyContent="space-between" alignItems="center">
          <Typography variant="body2" color="text.secondary">Discount %</Typography>
          <Box sx={{ width: 90 }}>
            <FormTextField name={discountField} label="" type="number" placeholder="0" />
          </Box>
        </Stack>
      ) : (
        <Row label="Discount" value={(Number(totals.discount) || 0).toFixed(2)} />
      )}

      <Row label="Taxable Amount" value={totals.taxableAmount.toFixed(2)} />

      {taxRows.map((r) => (
        <Row key={r.label} label={r.label} value={r.amount.toFixed(2)} />
      ))}

      {showRoundOff && <Row label="Round Off" value={totals.roundOff.toFixed(2)} />}

      <Divider />
      <Stack direction="row" justifyContent="space-between">
        <Typography variant="subtitle1" fontWeight={700}>Grand Total</Typography>
        <Typography variant="subtitle1" fontWeight={700}>₹{totals.grandTotal.toFixed(2)}</Typography>
      </Stack>
    </Stack>
  );
}
