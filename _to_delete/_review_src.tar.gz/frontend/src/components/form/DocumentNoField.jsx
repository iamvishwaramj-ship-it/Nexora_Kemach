import React, { useEffect, useRef, useState } from 'react';
import { InputAdornment, CircularProgress } from '@mui/material';
import { useFormContext } from 'react-hook-form';
import FormTextField from './FormTextField';
import { usePeekDocumentNumberMutation } from '../../features/company/companyDetailsApi';
import { useNotify } from '../feedback/NotificationProvider';

// Shared "No." field for every create form backed by the numbering-series
// engine (PO, GRN, PI, ENQ, PQ, SQ, SO, DC, SI, SRC, SIG, ADJ, RV, PV, DEP,
// CHQ). On create it peeks the active series for `documentCode` purely to
// find out which mode it's in, then behaves like one of two entirely
// different fields depending on that series' Auto Generate / Manual Entry
// switches (documentNumberingSeries — Company Setup > Document Numbering):
//   - Auto Generate on (Manual Entry off, the normal/default case): the
//     series' next number is fetched and filled in automatically, and the
//     field is locked -- disabled on the MUI TextField only (never on the
//     Controller/RHF field), so the value still submits, same pattern
//     already used for the other auto-filled/disabled fields on these forms
//     (e.g. Contact Person on PurchaseOrder.jsx). Nothing is left for the
//     user to type.
//   - Manual Entry on (Auto Generate off): nothing is auto-generated at
//     all -- the field is left blank and fully editable so the user types
//     the number themselves, validated against the series pattern/range
//     server-side on save.
//   - peek fails (e.g. no series defined for this FY): the error is
//     surfaced via the shared notify() toast and the field is left enabled
//     and blank as a fallback so the user isn't blocked -- typing a number
//     when Manual Entry is actually off is rejected server-side on save
//     with a clear message, which is the correct fallback.
// On edit/view (isCreate=false) this never peeks and behaves like a plain
// FormTextField, so an existing document's saved number is never touched.
export default function DocumentNoField({ documentCode, name, label, isCreate, placeholder, ...rest }) {
  const { setValue } = useFormContext();
  const notify = useNotify();
  const [peekDocumentNumber] = usePeekDocumentNumberMutation();
  const [state, setState] = useState({ loading: false, manualEntry: true });
  const requested = useRef(false);

  useEffect(() => {
    if (!isCreate || requested.current) return;
    requested.current = true;
    setState({ loading: true, manualEntry: true });
    peekDocumentNumber({ documentCode })
      .unwrap()
      .then((res) => {
        const manualEntry = !!res?.series?.manualEntry;
        // Only Auto Generate series get a value put in the field -- Manual
        // Entry means the system generates nothing and the user types the
        // whole number themselves.
        if (!manualEntry) setValue(name, res?.documentNumber || '', { shouldValidate: true });
        setState({ loading: false, manualEntry });
      })
      .catch((err) => {
        notify.error(err?.data?.message || 'Could not generate document number');
        setState({ loading: false, manualEntry: true });
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isCreate, documentCode]);

  const locked = isCreate && (state.loading || !state.manualEntry);

  return (
    <FormTextField
      name={name}
      label={label}
      placeholder={state.loading ? 'Generating…' : (state.manualEntry ? 'Enter document number' : placeholder)}
      disabled={locked}
      InputProps={state.loading ? {
        endAdornment: (
          <InputAdornment position="end">
            <CircularProgress size={16} />
          </InputAdornment>
        ),
      } : undefined}
      {...rest}
    />
  );
}

// Peeks the next number for `documentCode` outside of a mounted form --
// used by "Duplicate"/"Clone as new draft" shortcuts that build a payload
// and submit it directly without ever opening the create form UI. Falls
// back to '' (letting the server auto-allocate on save) if the peek fails,
// and surfaces the failure via notify() rather than blocking the duplicate.
export async function peekNextDocumentNumber(peekDocumentNumber, documentCode, notify) {
  try {
    const res = await peekDocumentNumber({ documentCode }).unwrap();
    return res?.documentNumber || '';
  } catch (err) {
    notify.error(err?.data?.message || 'Could not generate document number');
    return '';
  }
}
