import React from 'react';
import { Controller, useFormContext } from 'react-hook-form';
import { FormControlLabel, Checkbox, Switch } from '@mui/material';
import { useFormReadOnly } from './AppForm';

// `disabled` is OR'd with the form's read-only state rather than replacing it:
// a caller disabling one box (because the value is pinned by something outside
// the form — see ProductUsageFlags) must not be able to re-enable it inside a
// read-only form by passing false.
export function FormCheckbox({ name, label, disabled = false }) {
  const readOnly = useFormReadOnly();
  const { control } = useFormContext();
  return (
    <Controller
      name={name}
      control={control}
      render={({ field }) => (
        <FormControlLabel
          control={<Checkbox {...field} checked={!!field.value} disabled={readOnly || disabled} />}
          label={label}
        />
      )}
    />
  );
}

export function FormSwitch({ name, label }) {
  const readOnly = useFormReadOnly();
  const { control } = useFormContext();
  return (
    <Controller
      name={name}
      control={control}
      render={({ field }) => (
        <FormControlLabel control={<Switch {...field} checked={!!field.value} disabled={readOnly} />} label={label} />
      )}
    />
  );
}
