import React from 'react';
import { Controller, useFormContext } from 'react-hook-form';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { TextField } from '@mui/material';
import dayjs from 'dayjs';
import { useFormReadOnly } from './AppForm';

export default function FormDatePicker({ name, label, fullWidth = true, size = 'small', helperText, ...rest }) {
  const readOnly = useFormReadOnly();
  const { control } = useFormContext();
  return (
    <Controller
      name={name}
      control={control}
      render={({ field, fieldState: { error } }) => (
        <DatePicker
          label={label}
          value={field.value ? dayjs(field.value) : null}
          onChange={(newValue) => {
            if (!newValue || !newValue.isValid()) {
              field.onChange(null);
              return;
            }
            // Store the selected calendar day as a UTC-midnight Date instead of
            // newValue.toDate() (which bakes in the local wall-clock time as the
            // UTC instant). Without this, selecting a date in any timezone ahead
            // of UTC (e.g. IST, +5:30) produces an instant that falls on the
            // *previous* UTC day, so once serialized to JSON/ISO and stored as a
            // date-only value on the backend, the record ends up one day earlier
            // than what was picked.
            field.onChange(new Date(Date.UTC(newValue.year(), newValue.month(), newValue.date())));
          }}
          slotProps={{
            textField: {
              fullWidth,
              size,
              error: !!error,
              helperText: error?.message || helperText || ' ',
              FormHelperTextProps: { sx: { mx: 0, mt: 0.25, minHeight: '1.1em', lineHeight: 1.3 } },
              onBlur: field.onBlur,
            },
          }}
          {...rest}
          // A read-only form disables its fields; an explicit
          // disabled still applies while editing.
          disabled={readOnly || rest.disabled}
        />
      )}
    />
  );
}
