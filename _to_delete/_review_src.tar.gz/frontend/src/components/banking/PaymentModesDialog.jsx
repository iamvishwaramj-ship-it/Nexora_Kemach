import React, { useEffect, useMemo, useState } from 'react';
import {
  Box, Dialog, DialogContent, DialogActions, Button, IconButton, Typography, Stack,
  Tabs, Tab, TextField, Autocomplete, Table, TableHead, TableBody, TableRow, TableCell,
  Select, MenuItem,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import RemoveIcon from '@mui/icons-material/Remove';
import OpenInFullIcon from '@mui/icons-material/OpenInFull';
import AddIcon from '@mui/icons-material/Add';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import { chartOfAccountApi } from '../../features/resources';
import { CURRENCY_OPTIONS } from '../../lib/validation/partnerSchemas';
import { countries } from '../../lib/constants/locations';
import ScrollableTableContainer from '../data-display/ScrollableTableContainer';

const round2 = (n) => Math.round((Number(n) || 0) * 100) / 100;

const emptyChequeRow = () => ({
  dueDate: '', amount: '', bankName: '', branch: '', account: '', glAccount: '',
  country: '', chequeNo: '', chequeDate: '', type: '', endors: '', issuedBy: '',
});

// G/L Account picker as a plain dropdown select, sourced from the same
// chartOfAccountApi list every other G/L Account field in the app uses
// (see AccountCodeDropdownPaper in WarehouseMaster.jsx/ProductGroup.jsx).
function GLAccountField({ label, value, onChange, options, required }) {
  return (
    <Box>
      {label && (
        <Typography variant="body2" fontWeight={600} sx={{ mb: 0.5 }}>
          {label}{required && <Box component="span" sx={{ color: 'error.main' }}> *</Box>}
        </Typography>
      )}
      <Select
        size="small"
        fullWidth
        displayEmpty
        value={value || ''}
        onChange={(e) => onChange(e.target.value)}
      >
        <MenuItem value="">
          <em>Select...</em>
        </MenuItem>
        {options.map((o) => (
          <MenuItem key={o.value} value={o.value}>{o.label}</MenuItem>
        ))}
      </Select>
    </Box>
  );
}

function LabeledField({ label, required, children }) {
  return (
    <Box>
      {label && (
        <Typography variant="body2" fontWeight={600} sx={{ mb: 0.5 }}>
          {label}{required && <Box component="span" sx={{ color: 'error.main' }}> *</Box>}
        </Typography>
      )}
      {children}
    </Box>
  );
}

/**
 * "Payment Modes" popup — reached from the eye icon next to Applied Amount
 * on Payment Receipt and Payment Voucher. Currency + Cash / Cheque / Bank
 * Transfer sub-tabs, each with its own G/L Account and amount, plus a
 * shared Bank Charges / Overall Amount / Discount / Balance Due / Paid
 * Amount section underneath every tab.
 *
 * Self-contained local state rather than wired into the host page's
 * react-hook-form instance — it's a satellite breakdown of how the payment
 * splits across modes, not itself a field the parent schema validates.
 * `onApply` (optional) hands the finished breakdown back to the caller.
 */
export default function PaymentModesDialog({ open, onClose, appliedAmount = 0, defaultCurrency = 'INR', onApply }) {
  const { data: accounts } = chartOfAccountApi.useList();
  const accountOptions = useMemo(() => (accounts || [])
    .filter((a) => a.accountNature === 'A' && a.status === 'A')
    .map((a) => ({ label: `${a.accountCode} — ${a.accountName}`, value: a.accountCode })),
  [accounts]);

  const [currency, setCurrency] = useState(defaultCurrency);
  const [tab, setTab] = useState(0);
  const [cash, setCash] = useState({ glAccount: '', primaryFormItem: '', total: '' });
  const [cheque, setCheque] = useState({ glAccount: '', rows: [] });
  const [bankTransfer, setBankTransfer] = useState({ glAccount: '', transferDate: '', reference: '', total: '' });
  const [bankChargesAccount, setBankChargesAccount] = useState('');
  const [bankChargesAmount, setBankChargesAmount] = useState('');
  const [discountPercent, setDiscountPercent] = useState('');
  const [paidAmount, setPaidAmount] = useState('');

  // Re-seed every field whenever the dialog is (re)opened, so a value typed
  // and then cancelled doesn't linger the next time it's reopened, and the
  // Overall Amount always reflects whatever the host form's Applied Amount
  // currently is.
  useEffect(() => {
    if (!open) return;
    setCurrency(defaultCurrency);
    setTab(0);
    setCash({ glAccount: '', primaryFormItem: '', total: '' });
    setCheque({ glAccount: '', rows: [] });
    setBankTransfer({ glAccount: '', transferDate: '', reference: '', total: '' });
    setBankChargesAccount('');
    setBankChargesAmount('');
    setDiscountPercent('');
    setPaidAmount(appliedAmount ? String(round2(appliedAmount)) : '');
  }, [open, defaultCurrency, appliedAmount]);

  const overallAmount = round2(appliedAmount);
  const balanceDue = round2(overallAmount - (Number(paidAmount) || 0));
  const chequeTotal = round2(cheque.rows.reduce((sum, r) => sum + (Number(r.amount) || 0), 0));

  const updateChequeRow = (index, patch) => {
    setCheque((prev) => ({
      ...prev,
      rows: prev.rows.map((r, i) => (i === index ? { ...r, ...patch } : r)),
    }));
  };
  const addChequeRow = () => setCheque((prev) => ({ ...prev, rows: [...prev.rows, emptyChequeRow()] }));
  const removeChequeRow = (index) => setCheque((prev) => ({ ...prev, rows: prev.rows.filter((_, i) => i !== index) }));

  const handleOk = () => {
    onApply?.({
      currency, mode: ['Cash', 'Cheque', 'Bank Transfer'][tab],
      cash, cheque: { ...cheque, total: chequeTotal }, bankTransfer,
      bankChargesAccount, bankChargesAmount: Number(bankChargesAmount) || 0,
      overallAmount, discountPercent: Number(discountPercent) || 0,
      balanceDue, paidAmount: Number(paidAmount) || 0,
    });
    onClose();
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="lg" fullWidth>
      {/* Title bar styled after the reference screen — a solid primary strip
          with a thin accent line beneath it, rather than the app's usual
          plain DialogTitle, since this popup is meant to read as a
          self-contained "mode" screen. */}
      <Box sx={{ bgcolor: 'primary.main', color: 'primary.contrastText', px: 3, py: 1.75, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <Typography variant="subtitle1" fontWeight={700}>Payment Modes</Typography>
        <Stack direction="row" spacing={0.5}>
          <IconButton size="small" sx={{ color: 'inherit', bgcolor: 'rgba(255,255,255,0.15)' }} disabled>
            <RemoveIcon fontSize="small" />
          </IconButton>
          <IconButton size="small" sx={{ color: 'inherit', bgcolor: 'rgba(255,255,255,0.15)' }} disabled>
            <OpenInFullIcon fontSize="small" sx={{ fontSize: 16 }} />
          </IconButton>
          <IconButton size="small" onClick={onClose} sx={{ color: '#fff', bgcolor: 'error.main', '&:hover': { bgcolor: 'error.dark' } }}>
            <CloseIcon fontSize="small" />
          </IconButton>
        </Stack>
      </Box>
      <Box sx={{ height: 4, bgcolor: 'success.main' }} />

      <DialogContent sx={{ p: 3 }}>
        <Box sx={{ maxWidth: 360, mb: 3 }}>
          <LabeledField label="Currency">
            <Autocomplete
              size="small"
              options={CURRENCY_OPTIONS}
              value={CURRENCY_OPTIONS.find((o) => o.value === currency) || null}
              isOptionEqualToValue={(o, v) => o.value === v.value}
              getOptionLabel={(o) => o.label || ''}
              onChange={(_e, v) => setCurrency(v?.value ?? '')}
              renderInput={(params) => <TextField {...params} />}
            />
          </LabeledField>
        </Box>

        <Tabs value={tab} onChange={(_e, v) => setTab(v)} sx={{ mb: 3, borderBottom: 1, borderColor: 'divider' }}>
          <Tab label="Cash" />
          <Tab label="Cheque" />
          <Tab label="Bank Transfer" />
        </Tabs>

        {tab === 0 && (
          <Stack direction={{ xs: 'column', md: 'row' }} spacing={4} sx={{ mb: 3 }}>
            <Stack spacing={2} sx={{ flex: 1 }}>
              <GLAccountField
                label="G/L Account" required
                value={cash.glAccount}
                onChange={(v) => setCash((p) => ({ ...p, glAccount: v }))}
                options={accountOptions}
              />
              <LabeledField label="Total">
                <TextField size="small" type="number" placeholder="Total" fullWidth
                  value={cash.total} onChange={(e) => setCash((p) => ({ ...p, total: e.target.value }))} />
              </LabeledField>
            </Stack>
            <Stack spacing={2} sx={{ flex: 1 }}>
              <LabeledField label="Primary Form Item">
                <Autocomplete
                  size="small"
                  options={[]}
                  value={cash.primaryFormItem || null}
                  onChange={(_e, v) => setCash((p) => ({ ...p, primaryFormItem: v || '' }))}
                  renderInput={(params) => <TextField {...params} />}
                />
              </LabeledField>
            </Stack>
          </Stack>
        )}

        {tab === 1 && (
          <Box sx={{ mb: 3 }}>
            <Box sx={{ maxWidth: 420, mb: 2 }}>
              <GLAccountField
                label="G/L Account" required
                value={cheque.glAccount}
                onChange={(v) => setCheque((p) => ({ ...p, glAccount: v }))}
                options={accountOptions}
              />
            </Box>

            <ScrollableTableContainer maxHeight={280}>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell width={40}>#</TableCell>
                    <TableCell>Due Date</TableCell>
                    <TableCell>Amount</TableCell>
                    <TableCell>Bank Name</TableCell>
                    <TableCell>Branch</TableCell>
                    <TableCell>Account</TableCell>
                    <TableCell>G/L Account</TableCell>
                    <TableCell>Country</TableCell>
                    <TableCell>Cheque No. *</TableCell>
                    <TableCell>Cheque Date *</TableCell>
                    <TableCell>Type</TableCell>
                    <TableCell>Endors</TableCell>
                    <TableCell>Originally Issued By</TableCell>
                    <TableCell width={40} />
                  </TableRow>
                </TableHead>
                <TableBody>
                  {cheque.rows.length === 0 && (
                    <TableRow>
                      <TableCell />
                      <TableCell colSpan={12}>
                        <Typography variant="caption" color="text.secondary">Total</Typography>
                      </TableCell>
                      <TableCell align="right">
                        <Typography variant="body2">{chequeTotal.toFixed(3)}</Typography>
                      </TableCell>
                    </TableRow>
                  )}
                  {cheque.rows.map((row, i) => (
                    <TableRow key={i}>
                      <TableCell>{i + 1}</TableCell>
                      <TableCell sx={{ minWidth: 130 }}>
                        <TextField size="small" type="date" fullWidth value={row.dueDate} onChange={(e) => updateChequeRow(i, { dueDate: e.target.value })} />
                      </TableCell>
                      <TableCell sx={{ minWidth: 90 }}>
                        <TextField size="small" type="number" fullWidth value={row.amount} onChange={(e) => updateChequeRow(i, { amount: e.target.value })} />
                      </TableCell>
                      <TableCell sx={{ minWidth: 130 }}>
                        <TextField size="small" fullWidth value={row.bankName} onChange={(e) => updateChequeRow(i, { bankName: e.target.value })} />
                      </TableCell>
                      <TableCell sx={{ minWidth: 110 }}>
                        <TextField size="small" fullWidth value={row.branch} onChange={(e) => updateChequeRow(i, { branch: e.target.value })} />
                      </TableCell>
                      <TableCell sx={{ minWidth: 110 }}>
                        <TextField size="small" fullWidth value={row.account} onChange={(e) => updateChequeRow(i, { account: e.target.value })} />
                      </TableCell>
                      <TableCell sx={{ minWidth: 160 }}>
                        <Autocomplete
                          size="small"
                          options={accountOptions}
                          value={accountOptions.find((o) => o.value === row.glAccount) || null}
                          isOptionEqualToValue={(o, v) => o.value === v.value}
                          getOptionLabel={(o) => o.label || ''}
                          onChange={(_e, v) => updateChequeRow(i, { glAccount: v?.value ?? '' })}
                          renderInput={(params) => <TextField {...params} placeholder="Search..." />}
                        />
                      </TableCell>
                      <TableCell sx={{ minWidth: 130 }}>
                        <Autocomplete
                          size="small"
                          options={countries}
                          value={countries.find((c) => c.value === row.country) || null}
                          isOptionEqualToValue={(o, v) => o.value === v.value}
                          getOptionLabel={(o) => o.label || ''}
                          onChange={(_e, v) => updateChequeRow(i, { country: v?.value ?? '' })}
                          renderInput={(params) => <TextField {...params} />}
                        />
                      </TableCell>
                      <TableCell sx={{ minWidth: 120 }}>
                        <TextField size="small" fullWidth value={row.chequeNo} onChange={(e) => updateChequeRow(i, { chequeNo: e.target.value })} />
                      </TableCell>
                      <TableCell sx={{ minWidth: 130 }}>
                        <TextField size="small" type="date" fullWidth value={row.chequeDate} onChange={(e) => updateChequeRow(i, { chequeDate: e.target.value })} />
                      </TableCell>
                      <TableCell sx={{ minWidth: 100 }}>
                        <TextField size="small" fullWidth value={row.type} onChange={(e) => updateChequeRow(i, { type: e.target.value })} />
                      </TableCell>
                      <TableCell sx={{ minWidth: 100 }}>
                        <TextField size="small" fullWidth value={row.endors} onChange={(e) => updateChequeRow(i, { endors: e.target.value })} />
                      </TableCell>
                      <TableCell sx={{ minWidth: 160 }}>
                        <TextField size="small" fullWidth value={row.issuedBy} onChange={(e) => updateChequeRow(i, { issuedBy: e.target.value })} />
                      </TableCell>
                      <TableCell>
                        <IconButton size="small" color="error" onClick={() => removeChequeRow(i)} aria-label="remove cheque row">
                          <DeleteOutlineIcon fontSize="small" />
                        </IconButton>
                      </TableCell>
                    </TableRow>
                  ))}
                  {cheque.rows.length > 0 && (
                    <TableRow>
                      <TableCell />
                      <TableCell colSpan={2}>
                        <Typography variant="caption" color="text.secondary">Total: {chequeTotal.toFixed(3)}</Typography>
                      </TableCell>
                      <TableCell colSpan={10} />
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </ScrollableTableContainer>
            <Button size="small" startIcon={<AddIcon />} onClick={addChequeRow} sx={{ mt: 1 }}>
              Add Cheque
            </Button>
          </Box>
        )}

        {tab === 2 && (
          <Stack direction={{ xs: 'column', md: 'row' }} spacing={4} sx={{ mb: 3 }}>
            <Stack spacing={2} sx={{ flex: 1 }}>
              <GLAccountField
                label="G/L Account" required
                value={bankTransfer.glAccount}
                onChange={(v) => setBankTransfer((p) => ({ ...p, glAccount: v }))}
                options={accountOptions}
              />
              <LabeledField label="Reference">
                <TextField size="small" placeholder="Reference" fullWidth
                  value={bankTransfer.reference} onChange={(e) => setBankTransfer((p) => ({ ...p, reference: e.target.value }))} />
              </LabeledField>
            </Stack>
            <Stack spacing={2} sx={{ flex: 1 }}>
              <LabeledField label="Transfer Date">
                <TextField size="small" type="date" fullWidth
                  value={bankTransfer.transferDate} onChange={(e) => setBankTransfer((p) => ({ ...p, transferDate: e.target.value }))} />
              </LabeledField>
              <LabeledField label="Total">
                <TextField size="small" type="number" fullWidth
                  value={bankTransfer.total} onChange={(e) => setBankTransfer((p) => ({ ...p, total: e.target.value }))} />
              </LabeledField>
            </Stack>
          </Stack>
        )}

        {/* Shared across every payment mode. */}
        <Box sx={{ borderTop: 1, borderColor: 'divider', pt: 3 }}>
          <Stack direction={{ xs: 'column', md: 'row' }} spacing={4}>
            <Stack spacing={2} sx={{ flex: 1 }}>
              <GLAccountField
                label="Bank Charges G/L Account"
                value={bankChargesAccount}
                onChange={setBankChargesAccount}
                options={accountOptions}
              />
              <LabeledField label="Overall Amount" required>
                <TextField size="small" fullWidth disabled value={overallAmount.toFixed(3)} />
              </LabeledField>
              <LabeledField label="Balance Due">
                <TextField size="small" fullWidth disabled value={balanceDue.toFixed(3)} />
              </LabeledField>
            </Stack>
            <Stack spacing={2} sx={{ flex: 1 }}>
              <LabeledField label="Bank Charges Amount">
                <TextField size="small" type="number" placeholder="Charges Amount" fullWidth
                  value={bankChargesAmount} onChange={(e) => setBankChargesAmount(e.target.value)} />
              </LabeledField>
              <LabeledField label="Discount %">
                <TextField size="small" type="number" placeholder="Discount Amount" fullWidth
                  value={discountPercent} onChange={(e) => setDiscountPercent(e.target.value)} />
              </LabeledField>
              <LabeledField label="Paid Amount" required>
                <TextField size="small" type="number" fullWidth
                  value={paidAmount} onChange={(e) => setPaidAmount(e.target.value)} />
              </LabeledField>
            </Stack>
          </Stack>
        </Box>
      </DialogContent>

      <DialogActions sx={{ px: 3, py: 2 }}>
        <Button variant="contained" onClick={handleOk}>Ok</Button>
        <Button variant="contained" color="error" onClick={onClose}>Cancel</Button>
      </DialogActions>
    </Dialog>
  );
}
