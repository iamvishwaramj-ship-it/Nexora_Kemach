import React, { useEffect, useMemo, useState } from 'react';
import { useFormContext } from 'react-hook-form';
import { useNavigate, useParams } from 'react-router-dom';
import {
  Box, Typography, Card, CardContent, Stack, Tabs, Tab, Table, TableHead, TableBody,
  TableRow, TableCell, TableContainer, Paper, Autocomplete, TextField, Button,
} from '@mui/material';
import RuleOutlinedIcon from '@mui/icons-material/RuleOutlined';
import AppForm, { FormSubmitButton } from '../../components/form/AppForm';
import FormSelect from '../../components/form/FormSelect';
import { FormCheckbox } from '../../components/form/FormCheckbox';
import EntityHeaderCard from '../../components/common/EntityHeaderCard';
import CompanyBadge from '../../components/common/CompanyBadge';
import { useNotify } from '../../components/feedback/NotificationProvider';
import { applyServerErrors } from '../../lib/formErrors';
import {
  financialYearApi, chartOfAccountApi, customerApi, glAccountDeterminationApi,
} from '../../features/resources';

const LIST_PATH = '/accounting/gl-account-determination';

// Sales > General account rows, in the order SAP's own "Add GL Account
// Determination" screen lists them. `field` is the form/DB field storing the
// chosen ChartOfAccount id.
const SALES_GENERAL_ROWS = [
  { field: 'domesticAccountsReceivableId', label: 'Domestic Accounts Receivable' },
  { field: 'foreignAccountsReceivableId', label: 'Foreign Accounts Receivable' },
  { field: 'checksReceivedId', label: 'Checks Received' },
  { field: 'cashOnHandId', label: 'Cash on Hand' },
  { field: 'overpaymentARId', label: 'Overpayment A/R Account' },
  { field: 'underpaymentARId', label: 'Underpayment A/R Account' },
  { field: 'downPaymentClearingId', label: 'Down Payment Clearing Account' },
  { field: 'realizedExchangeDiffGainId', label: 'Realized Exchange Diff. Gain' },
  { field: 'realizedExchangeDiffLossId', label: 'Realized Exchange Diff. Loss' },
  { field: 'realizedConversionDiffGainId', label: 'Realized Conversion Diff. Gain' },
  { field: 'realizedConversionDiffLossId', label: 'Realized Conversion Diff. Loss' },
  // Feeds Product Group's Accounting tab (see PRODUCT_GROUP_ACCOUNT_MAP in
  // ProductGroup.jsx) — not part of the original reference screen.
  { field: 'revenueAccountId', label: 'Revenue Account' },
  { field: 'salesCreditAccountId', label: 'Sales Credit Account' },
];

const PURCHASING_ROWS = [
  { field: 'domesticAccountsPayableId', label: 'Domestic Accounts Payable' },
  { field: 'foreignAccountsPayableId', label: 'Foreign Accounts Payable' },
  { field: 'purchRealizedExchangeDiffGainId', label: 'Realized Exchange Diff. Gain' },
  { field: 'purchRealizedExchangeDiffLossId', label: 'Realized Exchange Diff. Loss' },
  { field: 'purchRealizedConversionDiffGainId', label: 'Realized Conversion Diff. Gain' },
  { field: 'purchRealizedConversionDiffLossId', label: 'Realized Conversion Diff. Loss' },
  { field: 'bankTransferId', label: 'Bank Transfer' },
  { field: 'cashDiscountId', label: 'Cash Discount' },
  { field: 'cashDiscountClearingId', label: 'Cash Discount Clearing' },
  { field: 'expenseAccountId', label: 'Expense Account' },
  { field: 'purchaseCreditAccountId', label: 'Purchase Credit Account' },
  { field: 'overpaymentAPId', label: 'Overpayment A/P Account' },
  // Feeds Product Group's Accounting tab (see PRODUCT_GROUP_ACCOUNT_MAP in
  // ProductGroup.jsx) — not part of the original reference screen.
  { field: 'purchaseAccountId', label: 'Purchase Account' },
  { field: 'purchaseReturnAccountId', label: 'Purchase Return Account' },
  { field: 'costOfGoodsPurchasedAccountId', label: 'Cost of Goods Purchased Account' },
  { field: 'purchaseBalanceAccountId', label: 'Purchase Balance Account' },
];

const GENERAL_ROWS = [
  { field: 'creditCardDepositFeeId', label: 'Credit Card Deposit Fee' },
  { field: 'roundingAccountId', label: 'Rounding Account' },
  { field: 'automaticReconciliationDiffId', label: 'Automatic Reconciliation Diff' },
  { field: 'periodEndClosingAccountId', label: 'Period-End Closing Account' },
  { field: 'genRealizedExchangeDiffGainId', label: 'Realized Exchange Diff. Gain' },
  { field: 'genRealizedExchangeDiffLossId', label: 'Realized Exchange Diff. Loss' },
  { field: 'genRealizedConversionDiffGainId', label: 'Realized Conversion Diff. Gain' },
  { field: 'genRealizedConversionDiffLossId', label: 'Realized Conversion Diff. Loss' },
  { field: 'openingBalanceAccountId', label: 'Opening Balance Account' },
  { field: 'bankChargesAccountId', label: 'Bank Charges Account' },
  { field: 'incomingCenvatClearingActId', label: 'Incoming CENVAT Clearing Act' },
  { field: 'outgoingCenvatClearingActId', label: 'Outgoing CENVAT Clearing Act' },
  { field: 'plaId', label: 'PLA' },
  { field: 'tdsInterestActId', label: 'TDS Interest Act' },
  { field: 'tdsOtherChargesActId', label: 'TDS Other Charges Act' },
  { field: 'tdsFeeActId', label: 'TDS Fee Act' },
  { field: 'gstInterestAccountId', label: 'GST Interest Account' },
  // GST control accounts — where the CGST/SGST/IGST split computed on every
  // invoice lands in the ledger when its journal entry is generated
  // (backend/src/utils/glPosting.js). Output = tax collected on a sale, a
  // liability; Input = tax paid on a purchase, recoverable against it.
  //
  // Three per side rather than one lumped tax account because GSTR-1/GSTR-3B
  // report the three separately — collapse them and the returns can no longer
  // be derived from the ledger. An unconfigured one parks that document's
  // journal entry with a message naming it; it never blocks the document.
  { field: 'outputCgstPayableId', label: 'Output CGST Payable' },
  { field: 'outputSgstPayableId', label: 'Output SGST Payable' },
  { field: 'outputIgstPayableId', label: 'Output IGST Payable' },
  { field: 'inputCgstReceivableId', label: 'Input CGST Receivable' },
  { field: 'inputSgstReceivableId', label: 'Input SGST Receivable' },
  { field: 'inputIgstReceivableId', label: 'Input IGST Receivable' },
  // Feeds Product Group's Accounting tab (see PRODUCT_GROUP_ACCOUNT_MAP in
  // ProductGroup.jsx) — not part of the original reference screen.
  { field: 'expenseClearingAccountId', label: 'Expense Clearing Account' },
];

const INVENTORY_ROWS = [
  { field: 'inventoryAccountId', label: 'Inventory Account' },
  { field: 'costOfGoodsSoldAccountId', label: 'Cost of Goods Sold Account' },
  { field: 'allocationAccountId', label: 'Allocation Account' },
  { field: 'varianceAccountId', label: 'Variance Account' },
  { field: 'priceDifferenceAccountId', label: 'Price Difference Account' },
  { field: 'negativeInventoryAdjAcctId', label: 'Negative Inventory Adj. Acct' },
  { field: 'inventoryOffsetDecrAcctId', label: 'Inventory Offset - Decr. Acct' },
  { field: 'inventoryOffsetIncrAcctId', label: 'Inventory Offset - Incr. Acct' },
  { field: 'salesReturnsAccountId', label: 'Sales Returns Account' },
  { field: 'exchangeRateDifferencesAccountId', label: 'Exchange Rate Differences Account' },
  { field: 'goodsClearingAccountId', label: 'Goods Clearing Account' },
  { field: 'glDecreaseAccountId', label: 'G/L Decrease Account' },
  { field: 'glIncreaseAccountId', label: 'G/L Increase Account' },
  { field: 'wipInventoryAccountId', label: 'WIP Inventory Account' },
  { field: 'wipInventoryVarianceAccountId', label: 'WIP Inventory Variance Account' },
  { field: 'wipOffsetPLAccountId', label: 'WIP Offset P&L Account' },
  // Feeds Product Group's Accounting tab (see PRODUCT_GROUP_ACCOUNT_MAP in
  // ProductGroup.jsx) — not part of the original reference screen.
  { field: 'inventoryOffsetPnlAccountId', label: 'Inventory Offset P&L Account' },
  { field: 'shippedGoodsAccountId', label: 'Shipped Goods Account' },
];

const ALL_ROW_GROUPS = [SALES_GENERAL_ROWS, PURCHASING_ROWS, GENERAL_ROWS, INVENTORY_ROWS];

const emptyValues = {
  accountsReceivableId: null,
  permitChangeOfControlAccounts: false,
  defaultCustomerId: null,
  ...Object.fromEntries(ALL_ROW_GROUPS.flat().map((r) => [r.field, null])),
};

// Reached at /accounting/gl-account-determination/new (create) or
// /accounting/gl-account-determination/:id/edit (edit an existing row — one
// per Financial Year). The list page (GLAccountDetermination.jsx) is what
// links here; this component only ever handles one record at a time.
export default function GLAccountDeterminationForm() {
  const navigate = useNavigate();
  const { id } = useParams();
  const isEdit = Boolean(id);
  const notify = useNotify();
  const { data: years } = financialYearApi.useList();
  const { data: accounts } = chartOfAccountApi.useList();
  const { data: customers } = customerApi.useList();
  const { data: determinations } = glAccountDeterminationApi.useList();
  const [create, { isLoading: creating }] = glAccountDeterminationApi.useCreate();
  const [update, { isLoading: updating }] = glAccountDeterminationApi.useUpdate();

  const yearOptions = useMemo(
    () => (years || []).map((y) => ({ label: y.financialYearName, value: y.id })),
    [years]
  );
  const accountOptions = useMemo(
    () => (accounts || []).map((a) => ({ label: a.accountCode, value: a.id })),
    [accounts]
  );
  const accountById = useMemo(() => new Map((accounts || []).map((a) => [a.id, a])), [accounts]);
  const customerOptions = useMemo(
    () => (customers || []).map((c) => ({ label: `${c.customerCode} — ${c.customerName}`, value: c.id })),
    [customers]
  );

  // The row being edited (edit mode), found by route id — vs. `periodId`
  // below, which drives create mode and is otherwise derived from it once
  // it loads.
  const editingRow = useMemo(
    () => (isEdit ? (determinations || []).find((d) => String(d.id) === String(id)) || null : null),
    [isEdit, determinations, id]
  );

  // Which Financial Year the screen is editing. In edit mode this is fixed
  // to the record's own year (see effect below); in create mode it's a live
  // choice that decides whether Save creates or — if a row for that year
  // somehow already exists — updates it instead of colliding with the
  // table's one-row-per-year constraint.
  const [periodId, setPeriodId] = useState(null);
  useEffect(() => {
    if (editingRow) setPeriodId(editingRow.financialYearId);
  }, [editingRow]);

  const existing = isEdit
    ? editingRow
    : (determinations || []).find((d) => d.financialYearId === periodId) || null;

  // Top-level Sales / Purchasing / General / Inventory tabs. Resources and
  // WIP Mapping — present on the reference screen — are intentionally left
  // out; nothing in this build maps to them yet.
  const [mainTab, setMainTab] = useState(0);
  // Sales' own General / Tax sub-tabs.
  const [salesTab, setSalesTab] = useState(0);

  const handleSubmit = async (values, formMethods) => {
    if (!periodId) {
      notify.error('Select a Period first.');
      return;
    }
    const payload = { ...values, financialYearId: periodId };
    try {
      if (existing) {
        await update({ id: existing.id, ...payload }).unwrap();
        notify.success('GL Account Determination updated');
      } else {
        await create(payload).unwrap();
        notify.success('GL Account Determination saved');
      }
      navigate(LIST_PATH);
    } catch (err) {
      notify.error(applyServerErrors(err, formMethods.setError));
    }
  };

  // In edit mode, wait for the record to actually load before rendering the
  // form — otherwise it would briefly mount with emptyValues and a formKey
  // that then has to change again once editingRow arrives.
  if (isEdit && !editingRow && determinations === undefined) {
    return null;
  }

  return (
    <Box>
      <EntityHeaderCard
        icon={<RuleOutlinedIcon />}
        title={isEdit ? 'Edit GL Account Determination' : 'Add GL Account Determination'}
        subtitle="Map default G/L accounts used when posting sales, purchasing, and inventory documents."
        rightContent={<CompanyBadge compact />}
      />

      <Card variant="outlined">
        <CardContent sx={{ p: 3 }}>
          <Box sx={{ maxWidth: 320, mb: 2 }}>
            <FormSelectStandalone
              label="Period Selection *"
              options={yearOptions}
              value={periodId}
              onChange={setPeriodId}
              disabled={isEdit}
            />
          </Box>

          <AppForm
            key={existing?.id ?? periodId ?? 'none'}
            defaultValues={existing ? { ...emptyValues, ...existing } : emptyValues}
            onSubmit={handleSubmit}
          >
            <Tabs
              value={mainTab}
              onChange={(_e, v) => setMainTab(v)}
              variant="scrollable"
              allowScrollButtonsMobile
              sx={{ mb: 1, borderBottom: 1, borderColor: 'divider' }}
            >
              <Tab label="Sales" />
              <Tab label="Purchasing" />
              <Tab label="General" />
              <Tab label="Inventory" />
            </Tabs>

            {mainTab === 0 && (
              <Box sx={{ pt: 1 }}>
                <Tabs
                  value={salesTab}
                  onChange={(_e, v) => setSalesTab(v)}
                  sx={{ mb: 2, minHeight: 36, '& .MuiTab-root': { minHeight: 36, py: 0.5 } }}
                >
                  <Tab label="General" />
                  <Tab label="Tax" />
                </Tabs>

                {salesTab === 0 && (
                  <SalesGeneralTab
                    accountOptions={accountOptions}
                    accountById={accountById}
                    customerOptions={customerOptions}
                  />
                )}
                {salesTab === 1 && (
                  <Typography variant="body2" color="text.secondary" sx={{ py: 3 }}>
                    Tax account mapping for Sales is not configured yet.
                  </Typography>
                )}
              </Box>
            )}

            {mainTab === 1 && (
              <Box sx={{ pt: 1 }}>
                <AccountRowsTable rows={PURCHASING_ROWS} accountOptions={accountOptions} accountById={accountById} />
              </Box>
            )}
            {mainTab === 2 && (
              <Box sx={{ pt: 1 }}>
                <AccountRowsTable rows={GENERAL_ROWS} accountOptions={accountOptions} accountById={accountById} />
              </Box>
            )}
            {mainTab === 3 && (
              <Box sx={{ pt: 1 }}>
                <AccountRowsTable rows={INVENTORY_ROWS} accountOptions={accountOptions} accountById={accountById} />
              </Box>
            )}

            <Stack direction="row" spacing={1.5} justifyContent="flex-end" sx={{ mt: 3 }}>
              <Button variant="outlined" color="error" disabled={creating || updating} onClick={() => navigate(LIST_PATH)}>
                Cancel
              </Button>
              <FormSubmitButton disabled={creating || updating}>
                Save
              </FormSubmitButton>
            </Stack>
          </AppForm>
        </CardContent>
      </Card>
    </Box>
  );
}

// Sales > General — Accounts Receivable / Permit Change of Control Accounts /
// Default Customer, then the Type of Account table. Split out of the main
// component only so its fields sit inside AppForm's FormProvider tree, same
// as ChartOfAccounts' AccountFormFields.
function SalesGeneralTab({ accountOptions, accountById, customerOptions }) {
  return (
    <Box>
      <Stack
        direction={{ xs: 'column', md: 'row' }}
        spacing={3}
        alignItems={{ md: 'flex-start' }}
        sx={{ mb: 3 }}
      >
        <Box sx={{ width: { xs: '100%', md: 320 } }}>
          <FormSelect name="accountsReceivableId" label="Accounts Receivable" options={accountOptions} />
        </Box>
        <Box sx={{ pt: { md: 1 } }}>
          <FormCheckbox name="permitChangeOfControlAccounts" label="Permit Change of Control Accounts" />
        </Box>
      </Stack>

      <Box sx={{ width: { xs: '100%', md: 420 }, mb: 3 }}>
        <FormSelect
          name="defaultCustomerId"
          label="Default Customer for A/R Invoice and Payment"
          options={customerOptions}
        />
      </Box>

      <AccountRowsTable rows={SALES_GENERAL_ROWS} accountOptions={accountOptions} accountById={accountById} />
    </Box>
  );
}

// The "# / Type of Account / Account Code / Account Name" table shared by
// every tab (Sales > General, Purchasing, General, Inventory) — only the row
// list differs per tab.
function AccountRowsTable({ rows, accountOptions, accountById }) {
  return (
    <TableContainer component={Paper} variant="outlined">
      <Table size="small">
        <TableHead>
          <TableRow>
            <TableCell width={48}>#</TableCell>
            <TableCell>Type of Account</TableCell>
            <TableCell width={220}>Account Code</TableCell>
            <TableCell>Account Name</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row, idx) => (
            <DeterminationRow
              key={row.field}
              index={idx + 1}
              row={row}
              accountOptions={accountOptions}
              accountById={accountById}
            />
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}

// One table row: the account picker plus a read-only Account Name cell that
// follows whatever was picked — mirrors the reference screen, where Account
// Name is filled in by the system once a code is chosen, not typed.
function DeterminationRow({ index, row, accountOptions, accountById }) {
  const { watch } = useFormContext();
  const selectedId = watch(row.field);
  const account = selectedId ? accountById.get(selectedId) : null;
  return (
    <TableRow>
      <TableCell>{index}</TableCell>
      <TableCell>{row.label}</TableCell>
      <TableCell sx={{ py: 0.75 }}>
        <FormSelect name={row.field} label="" options={accountOptions} size="small" />
      </TableCell>
      <TableCell>{account?.accountName || ''}</TableCell>
    </TableRow>
  );
}

// A plain (non-RHF) Autocomplete-style select for Period Selection, which
// lives outside the form — it decides WHICH saved record the form loads
// rather than being a value the form itself submits. Locked in edit mode:
// a saved row's year isn't something Save is allowed to move.
function FormSelectStandalone({ label, options, value, onChange, disabled }) {
  const selected = options.find((o) => o.value === value) || null;
  return (
    <Autocomplete
      options={options}
      value={selected}
      size="small"
      disabled={disabled}
      isOptionEqualToValue={(o, v) => o.value === v.value}
      getOptionLabel={(o) => o.label || ''}
      onChange={(_e, newValue) => onChange(newValue?.value ?? null)}
      renderInput={(params) => <TextField {...params} label={label} required />}
    />
  );
}
