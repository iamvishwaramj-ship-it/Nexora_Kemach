import React from 'react';
import { Box, Typography, Card, CardContent, Grid, ToggleButtonGroup, ToggleButton, Slider, MenuItem, Select, FormControl, InputLabel, Avatar, Stack } from '@mui/material';
import FormatBoldIcon from '@mui/icons-material/FormatBold';
import FormatItalicIcon from '@mui/icons-material/FormatItalic';
import FormatUnderlinedIcon from '@mui/icons-material/FormatUnderlined';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  setColorScheme, setMode, setSidebarFont, setBodyFont,
  setSidebarBold, setSidebarItalic, setSidebarUnderline,
  setBodyBold, setBodyItalic, setBodyUnderline,
} from '../../store/themeSlice';
import { setMaxTabs, closeAllTabs } from '../../store/tabsSlice';
import { colorSchemeList } from '../../theme/colorSchemes';
import { fontList } from '../../theme/fonts';
import { selectCurrentUser } from '../../store/authSlice';
import { useNotify } from '../../components/feedback/NotificationProvider';
import { useConfirm } from '../../components/feedback/ConfirmationDialog';
import AppButton from '../../components/ui/AppButton';

const LANGUAGES = [
  { code: 'en', label: 'English' },
  { code: 'ta', label: 'தமிழ் (Tamil)' },
  { code: 'hi', label: 'हिन्दी (Hindi)' },
];

// Every settings card shares this footprint so cards in the same row match
// height (via Grid's default row stretch) without ballooning past what their
// content actually needs.
const CARD_SX = { height: '100%', minHeight: 260, display: 'flex', flexDirection: 'column' };
const CARD_CONTENT_SX = { flex: 1, display: 'flex', flexDirection: 'column', overflow: 'auto', p: 2.5, '&:last-child': { pb: 2.5 } };

export default function Settings() {
  const { t, i18n } = useTranslation();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const notify = useNotify();
  const confirmDialog = useConfirm();
  const user = useSelector(selectCurrentUser);
  const colorScheme = useSelector((s) => s.theme.colorScheme);
  const mode = useSelector((s) => s.theme.mode);
  const sidebarFont = useSelector((s) => s.theme.sidebarFont);
  const bodyFont = useSelector((s) => s.theme.bodyFont);
  const sidebarBold = useSelector((s) => s.theme.sidebarBold);
  const sidebarItalic = useSelector((s) => s.theme.sidebarItalic);
  const sidebarUnderline = useSelector((s) => s.theme.sidebarUnderline);
  const bodyBold = useSelector((s) => s.theme.bodyBold);
  const bodyItalic = useSelector((s) => s.theme.bodyItalic);
  const bodyUnderline = useSelector((s) => s.theme.bodyUnderline);
  const maxTabs = useSelector((s) => s.tabs.maxTabs);

  const sidebarStyleValues = [
    sidebarBold && 'bold',
    sidebarItalic && 'italic',
    sidebarUnderline && 'underline',
  ].filter(Boolean);
  const bodyStyleValues = [
    bodyBold && 'bold',
    bodyItalic && 'italic',
    bodyUnderline && 'underline',
  ].filter(Boolean);

  const handleSidebarStyleChange = (_e, values) => {
    dispatch(setSidebarBold(values.includes('bold')));
    dispatch(setSidebarItalic(values.includes('italic')));
    dispatch(setSidebarUnderline(values.includes('underline')));
  };
  const handleBodyStyleChange = (_e, values) => {
    dispatch(setBodyBold(values.includes('bold')));
    dispatch(setBodyItalic(values.includes('italic')));
    dispatch(setBodyUnderline(values.includes('underline')));
  };

  const handleLanguageChange = (e) => {
    i18n.changeLanguage(e.target.value);
    localStorage.setItem('nexora_language', e.target.value);
  };

  const handleCloseAllTabs = async () => {
    const ok = await confirmDialog({ title: 'Close all tabs', message: 'This will close every open tab. Continue?' });
    if (ok) {
      dispatch(closeAllTabs());
      notify.success('All tabs closed');
    }
  };

  return (
    <Box>
      <Typography variant="h5" fontWeight={700} sx={{ mb: 3 }}>{t('common.settings')}</Typography>

      <Grid container spacing={3} alignItems="stretch">
        <Grid item xs={12} sm={6} md={4}>
          <Card variant="outlined" sx={CARD_SX}>
            <CardContent sx={CARD_CONTENT_SX}>
              <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 2 }}>{t('common.profile')}</Typography>
              <Stack direction="row" spacing={2} alignItems="center" sx={{ mb: 3 }}>
                <Avatar
                  src={user?.profilePhotoUrl}
                  sx={{ width: 64, height: 64, bgcolor: 'primary.main', fontSize: '1.5rem' }}
                >
                  {user?.name?.charAt(0)}
                </Avatar>
                <Box sx={{ minWidth: 0 }}>
                  <Typography variant="subtitle1" fontWeight={600} noWrap>{user?.name || '—'}</Typography>
                  <Typography variant="body2" color="text.secondary" noWrap>{user?.email || '—'}</Typography>
                  {user?.role && (
                    <Typography variant="caption" color="text.secondary">{user.role}</Typography>
                  )}
                </Box>
              </Stack>
              <Box sx={{ mt: 'auto', display: 'flex', justifyContent: 'flex-end' }}>
                <AppButton variant="outlined" onClick={() => navigate('/settings/profile')}>
                  Manage Profile
                </AppButton>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={4}>
          <Card variant="outlined" sx={CARD_SX}>
            <CardContent sx={CARD_CONTENT_SX}>
              <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 2 }}>{t('common.theme')}</Typography>

              <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>Color</Typography>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 3 }}>
                {colorSchemeList.map((s) => (
                  <Box
                    key={s.key}
                    onClick={() => dispatch(setColorScheme(s.key))}
                    title={s.label}
                    sx={{
                      width: 32, height: 32, borderRadius: '50%', cursor: 'pointer',
                      background: `linear-gradient(135deg, ${s.primary}, ${s.accent})`,
                      border: colorScheme === s.key ? '3px solid' : '1px solid',
                      borderColor: colorScheme === s.key ? 'text.primary' : 'divider',
                    }}
                  />
                ))}
              </Box>

              <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>Mode</Typography>
              <ToggleButtonGroup exclusive value={mode} onChange={(_e, v) => v && dispatch(setMode(v))} size="small">
                <ToggleButton value="light">{t('common.lightMode')}</ToggleButton>
                <ToggleButton value="dark">{t('common.darkMode')}</ToggleButton>
              </ToggleButtonGroup>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={4}>
          <Card variant="outlined" sx={CARD_SX}>
            <CardContent sx={CARD_CONTENT_SX}>
              <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 2 }}>Fonts</Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                Sidebar font
              </Typography>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2, alignItems: 'flex-end', mb: 3 }}>
                <FormControl size="small" sx={{ minWidth: 220 }}>
                  <InputLabel>Sidebar font</InputLabel>
                  <Select
                    value={sidebarFont}
                    label="Sidebar font"
                    onChange={(e) => dispatch(setSidebarFont(e.target.value))}
                  >
                    {fontList.map((f) => (
                      <MenuItem key={f.key} value={f.key} sx={{ fontFamily: f.stack }}>
                        {f.label}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
                <ToggleButtonGroup size="small" value={sidebarStyleValues} onChange={handleSidebarStyleChange}>
                  <ToggleButton value="bold" aria-label="Sidebar bold"><FormatBoldIcon fontSize="small" /></ToggleButton>
                  <ToggleButton value="italic" aria-label="Sidebar italic"><FormatItalicIcon fontSize="small" /></ToggleButton>
                  <ToggleButton value="underline" aria-label="Sidebar underline"><FormatUnderlinedIcon fontSize="small" /></ToggleButton>
                </ToggleButtonGroup>
              </Box>

              <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                Body font (dashboard &amp; all pages)
              </Typography>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2, alignItems: 'flex-end' }}>
                <FormControl size="small" sx={{ minWidth: 220 }}>
                  <InputLabel>Body font</InputLabel>
                  <Select
                    value={bodyFont}
                    label="Body font"
                    onChange={(e) => dispatch(setBodyFont(e.target.value))}
                  >
                    {fontList.map((f) => (
                      <MenuItem key={f.key} value={f.key} sx={{ fontFamily: f.stack }}>
                        {f.label}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
                <ToggleButtonGroup size="small" value={bodyStyleValues} onChange={handleBodyStyleChange}>
                  <ToggleButton value="bold" aria-label="Body bold"><FormatBoldIcon fontSize="small" /></ToggleButton>
                  <ToggleButton value="italic" aria-label="Body italic"><FormatItalicIcon fontSize="small" /></ToggleButton>
                  <ToggleButton value="underline" aria-label="Body underline"><FormatUnderlinedIcon fontSize="small" /></ToggleButton>
                </ToggleButtonGroup>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={4}>
          <Card variant="outlined" sx={CARD_SX}>
            <CardContent sx={CARD_CONTENT_SX}>
              <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 2 }}>{t('common.language')}</Typography>
              <FormControl size="small" sx={{ minWidth: 220 }}>
                <InputLabel>{t('common.language')}</InputLabel>
                <Select value={i18n.language?.split('-')[0] || 'en'} label={t('common.language')} onChange={handleLanguageChange}>
                  {LANGUAGES.map((l) => (
                    <MenuItem key={l.code} value={l.code}>{l.label}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={4}>
          <Card variant="outlined" sx={CARD_SX}>
            <CardContent sx={CARD_CONTENT_SX}>
              <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 2 }}>Tabs</Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                Max open tabs: {maxTabs}
              </Typography>
              <Slider
                value={maxTabs}
                min={1}
                max={10}
                step={1}
                marks
                valueLabelDisplay="auto"
                onChange={(_e, v) => dispatch(setMaxTabs(v))}
                sx={{ maxWidth: 320, mb: 2 }}
              />
              <Box sx={{ mt: 'auto', display: 'flex', justifyContent: 'flex-end' }}>
                <AppButton variant="outlined" color="error" onClick={handleCloseAllTabs}>
                  {t('common.closeAll')}
                </AppButton>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}
