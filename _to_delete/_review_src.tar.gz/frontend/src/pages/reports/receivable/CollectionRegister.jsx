import React, { useEffect, useMemo, useState } from 'react';
import { useForm, FormProvider } from 'react-hook-form';
import {
  Box, Typography, Button, Card, CardContent, Stack, Grid, Table, TableBody, TableCell,
  TableHead, TableRow,
} from '@mui/material';
import { useTheme } from '@mui/material/styles';
import {
  ResponsiveContainer, PieChart, Pie, Cell, Tooltip as RechartsTooltip,
  BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, LabelList,
} from 'recharts';
import PaymentsOutlinedIcon from '@mui/icons-material/PaymentsOutlined';
import SearchIcon from '@mui/icons-material/Search';
import FileDownloadOutlinedIcon from '@mui/icons-material/FileDownloadOutlined';
import PrintOutlinedIcon from '@mui/icons-material/PrintOutlined';
import EventNoteOutlinedIcon from '@mui/icons-material/EventNoteOutlined';
import PeopleAltOutlinedIcon from '@mui/icons-material/PeopleAltOutlined';
import SavingsOutlinedIcon from '@mui/icons-material/SavingsOutlined';
import AccountBalanceOutlinedIcon from '@mui/icons-material/AccountBalanceOutlined';
import PhoneAndroidOutlinedIcon from '@mui/icons-material/PhoneAndroidOutlined';
import dayjs from 'dayjs';
import FormSelect from '../../../components/form/FormSelect';
import FormDatePicker from '../../../components/form/FormDatePicker';
import EntityHeaderCard from '../../../components/common/EntityHeaderCard';
import CompanyBadge from '../../../components/common/CompanyBadge';
import EntityListPagination from '../../../components/data-display/EntityListPagination';
import MobileRecordCard from '../../../components/data-display/MobileRecordCard';
import { useIsMobileListView } from '../../../components/data-display/useIsMobileListView';
import StatCard from '../../../components/data-display/StatCard';
import { branchApi, customerApi, salesEmployeeApi } from '../../../features/resources';
import { useGetCollectionRegisterReportQuery } from '../../../features/receivables/collectionRegisterReportApi';
import useTableFeatures from '../../../components/data-display/useTableFeatures';
import TableToolbar from '../../../components/data-display/TableToolbar';
import SortableHeaderCell from '../../../components/data-display/SortableHeaderCell';
import ScrollableTableContainer from '../../../components/data-display/ScrollableTableContainer';
import TableFilterPanel from '../../../components/data-display/TableFilterPanel';

const PAGE_SIZE = 10;

const PERIOD_RANGE_OPTIONS = ['MTD (Month To Date)', 'WTD (Week To Date)', 'QTD (Quarter To Date)', 'YTD (Year To Date)', 'Custom Range'];
const PAYMENT_MODE_OPTIONS = ['Cash', 'Cheque', 'Bank Transfer', 'UPI', 'NEFT', 'RTGS'];
const INCLUDE_OPTIONS = ['All Collections', 'Posted Only', 'Draft Only'];
const SHOW_INACTIVE_OPTIONS = [{ label: 'No', value: 'No' }, { label: 'Yes', value: 'Yes' }];
const CURRENCY_OPTIONS = ['INR - Indian Rupee'];

const currency = (v) => `₹ ${Number(v || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const currencyLakh = (v) => `${(Number(v || 0) / 100000).toFixed(2)}L`;
const formatDate = (d) => (d ? dayjs(d).format('DD/MM/YYYY') : '—');

// Resolves a Period Range preset into concrete {from, to} dates. "Custom
// Range" is handled by the caller (it leaves the user's manual From/To
// Date picks alone rather than overwriting them).
function resolvePeriodRange(preset) {
  const today = dayjs();
  if (preset === 'WTD (Week To Date)') {
    const day = today.day(); // 0 = Sunday
    const diffToMonday = day === 0 ? 6 : day - 1;
    return { from: today.subtract(diffToMonday, 'day').startOf('day'), to: today };
  }
  if (preset === 'QTD (Quarter To Date)') {
    const quarterStartMonth = Math.floor(today.month() / 3) * 3;
    return { from: today.month(quarterStartMonth).startOf('month'), to: today };
  }
  if (preset === 'YTD (Year To Date)') {
    return { from: today.startOf('year'), to: today };
  }
  // Default: MTD (Month To Date)
  return { from: today.startOf('month'), to: today };
}

const DEFAULT_FILTERS = {
  branch: '', customerGroup: '', customer: '', salesPerson: '', paymentMode: '',
  include: 'All Collections', showInactiveCustomers: 'No', currency: 'INR - Indian Rupee',
  fromDate: resolvePeriodRange('MTD (Month To Date)').from.format('YYYY-MM-DD'),
  toDate: resolvePeriodRange('MTD (Month To Date)').to.format('YYYY-MM-DD'),
};

export default function CollectionRegister() {
  const theme = useTheme();
  const isMobile = useIsMobileListView();

  const { data: branches } = branchApi.useList();
  const { data: customers } = customerApi.useList();
  const { data: salesEmployees } = salesEmployeeApi.useList();

  const branchOptions = useMemo(() => ([
    { label: 'All Branches', value: '' },
    ...(branches || []).map((b) => ({ label: b.branchName, value: b.branchName })),
  ]), [branches]);

  const customerGroupOptions = useMemo(() => {
    const distinct = Array.from(new Set((customers || []).map((c) => c.customerType).filter(Boolean)));
    return [{ label: 'All Groups', value: '' }, ...distinct.map((g) => ({ label: g, value: g }))];
  }, [customers]);

  const customerOptions = useMemo(() => ([
    { label: 'All Customers', value: '' },
    ...(customers || []).map((c) => ({ label: c.customerName, value: c.customerName })),
  ]), [customers]);

  const salesPersonOptions = useMemo(() => ([
    { label: 'All Sales Persons', value: '' },
    ...(salesEmployees || []).map((e) => ({ label: e.employeeName, value: e.employeeName })),
  ]), [salesEmployees]);

  const periodRangeOptions = useMemo(() => (
    PERIOD_RANGE_OPTIONS.map((s) => ({ label: s, value: s }))
  ), []);
  const paymentModeOptions = useMemo(() => ([
    { label: 'All', value: '' },
    ...PAYMENT_MODE_OPTIONS.map((s) => ({ label: s, value: s })),
  ]), []);
  const includeOptions = useMemo(() => (
    INCLUDE_OPTIONS.map((s) => ({ label: s, value: s }))
  ), []);
  const currencyOptions = useMemo(() => (
    CURRENCY_OPTIONS.map((s) => ({ label: s, value: s }))
  ), []);

  // Filter bar is a report toolbar, not a create/edit form — no Zod
  // validation or persisted mutation, same as other report pages.
  const methods = useForm({
    defaultValues: {
      periodRange: 'MTD (Month To Date)',
      fromDate: resolvePeriodRange('MTD (Month To Date)').from,
      toDate: resolvePeriodRange('MTD (Month To Date)').to,
      branch: '', customerGroup: '', customer: '', salesPerson: '', paymentMode: '',
      include: 'All Collections', showInactiveCustomers: 'No', currency: 'INR - Indian Rupee',
    },
  });
  const { handleSubmit, reset, watch, setValue } = methods;
  const periodRange = watch('periodRange');

  // Selecting a preset (anything but Custom Range) recomputes From/To Date
  // automatically; Custom Range leaves whatever the user last set alone.
  useEffect(() => {
    if (periodRange && periodRange !== 'Custom Range') {
      const { from, to } = resolvePeriodRange(periodRange);
      setValue('fromDate', from);
      setValue('toDate', to);
    }
  }, [periodRange, setValue]);

  const [appliedFilters, setAppliedFilters] = useState(DEFAULT_FILTERS);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(PAGE_SIZE);

  const { data, isLoading, isFetching } = useGetCollectionRegisterReportQuery(appliedFilters);
  const baseTableRows = data?.rows || [];

  // Column definitions drive the global search, the sort icons and the filter
  // popover — see components/data-display/useTableFeatures.js.
  const tableColumns = useMemo(() => ([
    { field: 'receiptNo', headerName: 'Receipt No.', filter: 'text' },
    { field: 'receiptDate', headerName: 'Receipt Date', filter: 'dateRange', sortValue: (row) => (row.receiptDate ? new Date(row.receiptDate).getTime() : null), searchValue: (row) => formatDate(row.receiptDate) },
    { field: 'customerCode', headerName: 'Customer Code', filter: 'text' },
    { field: 'customerName', headerName: 'Customer Name', filter: 'text' },
    { field: 'paymentMode', headerName: 'Payment Mode', filter: 'text' },
    { field: 'referenceNo', headerName: 'Reference No.', filter: 'text' },
    { field: 'bankName', headerName: 'Bank Name / UTR No.', filter: 'text' },
    { field: 'invoiceAmount', headerName: 'Invoice Amount (₹)', filter: 'numberRange', sortValue: (row) => (row.invoiceAmount == null || row.invoiceAmount === '' ? null : Number(row.invoiceAmount)) },
    { field: 'paidAmount', headerName: 'Paid Amount (₹)', filter: 'numberRange', sortValue: (row) => (row.paidAmount == null || row.paidAmount === '' ? null : Number(row.paidAmount)) },
    { field: 'outstanding', headerName: 'Outstanding (₹)', filter: 'numberRange', sortValue: (row) => (row.outstanding == null || row.outstanding === '' ? null : Number(row.outstanding)) },
    { field: 'collectedBy', headerName: 'Collected By', filter: 'text' },
  ]), []);
  const table = useTableFeatures(baseTableRows, tableColumns, { onChange: setPage });
  const rows = table.rows;
  const totals = data?.totals || {};
  const stats = data?.stats || {};
  const collectionByPaymentMode = data?.collectionByPaymentMode || [];
  const collectionTrend = data?.collectionTrend || [];
  const top5CustomersByCollection = data?.top5CustomersByCollection || [];
  const pagedRows = useMemo(() => rows.slice(page * pageSize, page * pageSize + pageSize), [rows, page, pageSize]);

  const onView = handleSubmit((values) => {
    setAppliedFilters({
      branch: values.branch || '',
      customerGroup: values.customerGroup || '',
      customer: values.customer || '',
      salesPerson: values.salesPerson || '',
      paymentMode: values.paymentMode || '',
      include: values.include || 'All Collections',
      showInactiveCustomers: values.showInactiveCustomers || 'No',
      currency: values.currency || 'INR - Indian Rupee',
      fromDate: values.fromDate ? dayjs(values.fromDate).format('YYYY-MM-DD') : '',
      toDate: values.toDate ? dayjs(values.toDate).format('YYYY-MM-DD') : '',
    });
    setPage(0);
  });

  const onReset = () => {
    const { from, to } = resolvePeriodRange('MTD (Month To Date)');
    reset({
      periodRange: 'MTD (Month To Date)', fromDate: from, toDate: to,
      branch: '', customerGroup: '', customer: '', salesPerson: '', paymentMode: '',
      include: 'All Collections', showInactiveCustomers: 'No', currency: 'INR - Indian Rupee',
    });
    setAppliedFilters(DEFAULT_FILTERS);
    setPage(0);
  };

  const periodLabel = useMemo(() => {
    const label = (methods.getValues('periodRange') || 'MTD (Month To Date)').split(' ')[0];
    return label;
  }, [appliedFilters]); // eslint-disable-line react-hooks/exhaustive-deps

  const totalForPct = stats.totalCollections || 1;
  const pct = (v) => Math.round((Number(v || 0) / totalForPct) * 1000) / 10;

  const statCards = [
    { icon: <PaymentsOutlinedIcon fontSize="small" />, label: 'Total Collections', value: currency(stats.totalCollections), color: 'primary' },
    { icon: <EventNoteOutlinedIcon fontSize="small" />, label: `Total Receipts (${periodLabel})`, value: stats.totalReceipts ?? 0, color: 'success' },
    { icon: <PeopleAltOutlinedIcon fontSize="small" />, label: `Total Customers (${periodLabel})`, value: stats.totalCustomers ?? 0, color: 'warning' },
    { icon: <SavingsOutlinedIcon fontSize="small" />, label: `Cash Amount (${pct(stats.cashAmount)}%)`, value: currency(stats.cashAmount), color: 'secondary' },
    { icon: <AccountBalanceOutlinedIcon fontSize="small" />, label: `Bank Amount (${pct(stats.bankAmount)}%)`, value: currency(stats.bankAmount), color: 'primary' },
    { icon: <PhoneAndroidOutlinedIcon fontSize="small" />, label: `Other Mode Amount (${pct(stats.otherModeAmount)}%)`, value: currency(stats.otherModeAmount), color: 'secondary' },
  ];

  const donutColors = [
    theme.palette.primary.main, theme.palette.success.main, theme.palette.warning.main,
    theme.palette.secondary.main, theme.palette.error.main, theme.palette.grey[400],
  ];
  const chartTooltipStyle = { backgroundColor: theme.palette.background.paper, border: `1px solid ${theme.palette.divider}`, borderRadius: 8 };

  // Export: current filtered rows to CSV — same client-side pattern used
  // elsewhere.
  const EXPORT_COLUMNS = [
    ['receiptNo', 'Receipt No.'], ['receiptDate', 'Receipt Date'], ['customerCode', 'Customer Code'], ['customerName', 'Customer Name'],
    ['paymentMode', 'Payment Mode'], ['referenceNo', 'Reference No.'], ['bankName', 'Bank Name / UTR No.'],
    ['invoiceAmount', 'Invoice Amount'], ['paidAmount', 'Paid Amount'], ['outstanding', 'Outstanding'], ['collectedBy', 'Collected By'],
  ];
  const handleExport = () => {
    const header = EXPORT_COLUMNS.map(([, label]) => label).join(',');
    const lines = rows.map((r) => EXPORT_COLUMNS.map(([key]) => {
      let v = r[key];
      if (key === 'receiptDate') v = formatDate(v);
      return `"${String(v ?? '').replace(/"/g, '""')}"`;
    }).join(','));
    const csv = [header, ...lines].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'collection-register.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <Box>
      <EntityHeaderCard
        icon={<PaymentsOutlinedIcon />}
        title="Collection Register"
        subtitle="All collections received in the selected period."
        rightContent={<CompanyBadge />}
      />

      <Card variant="outlined" sx={{ mb: 2 }}>
        <CardContent>
          <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 2 }}>Filters</Typography>
          <FormProvider {...methods}>
            <Grid container spacing={2} alignItems="flex-start">
              <Grid item xs={12} sm={6} md={2}>
                <FormSelect name="periodRange" label="Period Range" options={periodRangeOptions} />
              </Grid>
              <Grid item xs={12} sm={6} md={2}>
                <FormDatePicker name="fromDate" label="From Date" disabled={periodRange !== 'Custom Range'} />
              </Grid>
              <Grid item xs={12} sm={6} md={2}>
                <FormDatePicker name="toDate" label="To Date" disabled={periodRange !== 'Custom Range'} />
              </Grid>
              <Grid item xs={12} sm={6} md={2}>
                <FormSelect name="branch" label="Branch" options={branchOptions} emptyValue="" />
              </Grid>
              <Grid item xs={12} sm={6} md={2}>
                <FormSelect name="customerGroup" label="Customer Group" options={customerGroupOptions} />
              </Grid>
              <Grid item xs={12} sm={6} md={2}>
                <FormSelect name="customer" label="Customer" options={customerOptions} emptyValue="" />
              </Grid>
              <Grid item xs={12} sm={6} md={2}>
                <FormSelect name="paymentMode" label="Payment Mode" options={paymentModeOptions} />
              </Grid>
              <Grid item xs={12} sm={6} md={2}>
                <FormSelect name="include" label="Include" options={includeOptions} />
              </Grid>
              <Grid item xs={12} sm={6} md={2}>
                <FormSelect name="currency" label="Currency" options={currencyOptions} />
              </Grid>
              <Grid item xs={12} sm={6} md={3}>
                <FormSelect name="showInactiveCustomers" label="Show Inactive Customers" options={SHOW_INACTIVE_OPTIONS} />
              </Grid>
              <Grid item xs={12} sm={6} md={3}>
                <FormSelect name="salesPerson" label="Sales Person" options={salesPersonOptions} emptyValue="" />
              </Grid>
              <Grid item xs={12}>
                <Stack direction="row" spacing={1.5} justifyContent="flex-end" flexWrap="wrap" useFlexGap>
                  <Button
                    variant="contained"
                    color="primary"
                    startIcon={<SearchIcon />}
                    onClick={onView}
                    disabled={isFetching}
                    sx={{ height: 40, minWidth: 130, whiteSpace: 'nowrap' }}
                  >
                    View Report
                  </Button>
                  <Button variant="outlined" color="inherit" onClick={onReset} sx={{ height: 40, minWidth: 100 }}>
                    Reset
                  </Button>
                </Stack>
              </Grid>
            </Grid>
          </FormProvider>
        </CardContent>
      </Card>

      <Grid container spacing={2} sx={{ mb: 2 }}>
        {statCards.map((c) => (
          <Grid item xs={12} sm={6} md={2} key={c.label}>
            <StatCard {...c} />
          </Grid>
        ))}
      </Grid>

      <Card variant="outlined" sx={{ mb: 2 }}>
        <CardContent sx={{ p: 0 }}>
          <TableToolbar
            title="Collection Register List"
            searchPlaceholder="Search..."
            table={table}
            resultCount={table.rows.length}
            totalCount={table.totalCount}
            rightContent={(
              <Stack direction="row" spacing={1.5} flexWrap="wrap" useFlexGap>
                <Button variant="outlined" color="inherit" size="small" startIcon={<FileDownloadOutlinedIcon />} onClick={handleExport}>
                  Export
                </Button>
                <Button variant="outlined" color="inherit" size="small" startIcon={<PrintOutlinedIcon />} onClick={() => window.print()}>
                  Print
                </Button>
              </Stack>
            )}
          />
          <TableFilterPanel table={table} />
          {isMobile ? (
            <Box sx={{ px: 2, pb: 1 }}>
              {!isLoading && pagedRows.map((row, idx) => (
                <MobileRecordCard
                  key={row.id}
                  title={row.customerName}
                  fields={[
                    { label: '#', value: page * pageSize + idx + 1 },
                    { label: 'Receipt No.', value: row.receiptNo },
                    { label: 'Receipt Date', value: formatDate(row.receiptDate) },
                    { label: 'Customer Code', value: row.customerCode },
                    { label: 'Payment Mode', value: row.paymentMode },
                    { label: 'Reference No.', value: row.referenceNo },
                    { label: 'Bank Name / UTR No.', value: row.bankName },
                    { label: 'Invoice Amount', value: currency(row.invoiceAmount) },
                    { label: 'Paid Amount', value: currency(row.paidAmount) },
                    { label: 'Outstanding', value: currency(row.outstanding) },
                    { label: 'Collected By', value: row.collectedBy },
                  ]}
                />
              ))}
              {!isLoading && rows.length === 0 && (
                <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>
                  {isFetching ? 'Loading…' : 'No collections found for the selected criteria'}
                </Typography>
              )}
              {!isLoading && rows.length > 0 && (
                <Card variant="outlined" sx={{ mb: 1.5, bgcolor: 'action.hover' }}>
                  <CardContent sx={{ p: 2, '&:last-child': { pb: 2 } }}>
                    <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1 }}>Total</Typography>
                    <Stack spacing={0.75}>
                      {[
                        ['Invoice Amount', currency(totals.invoiceAmount)], ['Paid Amount', currency(totals.paidAmount)],
                        ['Outstanding', currency(totals.outstanding)],
                      ].map(([label, value]) => (
                        <Stack key={label} direction="row" justifyContent="space-between">
                          <Typography variant="caption" color="text.secondary">{label}</Typography>
                          <Typography variant="body2" fontWeight={700}>{value}</Typography>
                        </Stack>
                      ))}
                    </Stack>
                  </CardContent>
                </Card>
              )}
            </Box>
          ) : (
            <ScrollableTableContainer>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell>#</TableCell>
                    <SortableHeaderCell field="receiptNo" sort={table.sort} onSort={table.toggleSort}>Receipt No.</SortableHeaderCell>
                    <SortableHeaderCell field="receiptDate" sort={table.sort} onSort={table.toggleSort}>Receipt Date</SortableHeaderCell>
                    <SortableHeaderCell field="customerCode" sort={table.sort} onSort={table.toggleSort}>Customer Code</SortableHeaderCell>
                    <SortableHeaderCell field="customerName" sort={table.sort} onSort={table.toggleSort}>Customer Name</SortableHeaderCell>
                    <SortableHeaderCell field="paymentMode" sort={table.sort} onSort={table.toggleSort}>Payment Mode</SortableHeaderCell>
                    <SortableHeaderCell field="referenceNo" sort={table.sort} onSort={table.toggleSort}>Reference No.</SortableHeaderCell>
                    <SortableHeaderCell field="bankName" sort={table.sort} onSort={table.toggleSort}>Bank Name / UTR No.</SortableHeaderCell>
                    <SortableHeaderCell field="invoiceAmount" sort={table.sort} onSort={table.toggleSort} align="right">Invoice Amount (₹)</SortableHeaderCell>
                    <SortableHeaderCell field="paidAmount" sort={table.sort} onSort={table.toggleSort} align="right">Paid Amount (₹)</SortableHeaderCell>
                    <SortableHeaderCell field="outstanding" sort={table.sort} onSort={table.toggleSort} align="right">Outstanding (₹)</SortableHeaderCell>
                    <SortableHeaderCell field="collectedBy" sort={table.sort} onSort={table.toggleSort}>Collected By</SortableHeaderCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {!isLoading && pagedRows.map((row, i) => (
                    <TableRow key={row.id} hover>
                      <TableCell>{page * pageSize + i + 1}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>
                        <Typography variant="body2" fontWeight={700} color="primary.main">{row.receiptNo}</Typography>
                      </TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{formatDate(row.receiptDate)}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.customerCode}</TableCell>
                      <TableCell sx={{ minWidth: 150 }}>{row.customerName}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.paymentMode}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.referenceNo}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.bankName}</TableCell>
                      <TableCell align="right" sx={{ whiteSpace: 'nowrap' }}>{currency(row.invoiceAmount)}</TableCell>
                      <TableCell align="right" sx={{ whiteSpace: 'nowrap' }}>{currency(row.paidAmount)}</TableCell>
                      <TableCell align="right" sx={{ whiteSpace: 'nowrap' }}>{currency(row.outstanding)}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.collectedBy}</TableCell>
                    </TableRow>
                  ))}
                  {!isLoading && rows.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={12}>
                        <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>
                          {isFetching ? 'Loading…' : 'No collections found for the selected criteria'}
                        </Typography>
                      </TableCell>
                    </TableRow>
                  )}
                  {!isLoading && rows.length > 0 && (
                    <TableRow>
                      <TableCell colSpan={8}><Typography fontWeight={700}>Total</Typography></TableCell>
                      <TableCell align="right"><Typography fontWeight={700}>{currency(totals.invoiceAmount)}</Typography></TableCell>
                      <TableCell align="right"><Typography fontWeight={700}>{currency(totals.paidAmount)}</Typography></TableCell>
                      <TableCell align="right"><Typography fontWeight={700}>{currency(totals.outstanding)}</Typography></TableCell>
                      <TableCell>—</TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </ScrollableTableContainer>
          )}

          <EntityListPagination total={rows.length} page={page} onChange={setPage} pageSize={pageSize} onPageSizeChange={(v) => { setPageSize(v); setPage(0); }} />
        </CardContent>
      </Card>

      <Grid container spacing={2}>
        <Grid item xs={12} md={4}>
          <Card variant="outlined" sx={{ height: '100%' }}>
            <CardContent>
              <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 1 }}>Collection by Payment Mode ({periodLabel})</Typography>
              <Box sx={{ width: '100%', height: 180, position: 'relative' }}>
                <ResponsiveContainer>
                  <PieChart>
                    <Pie data={collectionByPaymentMode} dataKey="value" nameKey="name" innerRadius={50} outerRadius={80} paddingAngle={2} strokeWidth={0}>
                      {collectionByPaymentMode.map((entry, i) => <Cell key={entry.name} fill={donutColors[i % donutColors.length]} />)}
                    </Pie>
                    <RechartsTooltip contentStyle={chartTooltipStyle} formatter={(v) => currency(v)} />
                  </PieChart>
                </ResponsiveContainer>
                <Box sx={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', textAlign: 'center', pointerEvents: 'none' }}>
                  <Typography variant="caption" color="text.secondary" display="block">Total</Typography>
                  <Typography variant="subtitle2" fontWeight={700}>{currency(stats.totalCollections)}</Typography>
                </Box>
              </Box>
              <Stack spacing={0.75} sx={{ mt: 1 }}>
                {collectionByPaymentMode.map((d, i) => (
                  <Stack key={d.name} direction="row" alignItems="center" justifyContent="space-between">
                    <Stack direction="row" alignItems="center" spacing={1} sx={{ minWidth: 0 }}>
                      <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: donutColors[i % donutColors.length], flexShrink: 0 }} />
                      <Typography variant="caption" color="text.secondary" noWrap>{d.name}</Typography>
                    </Stack>
                    <Typography variant="caption" color="text.secondary">{currency(d.value)} ({d.percent}%)</Typography>
                  </Stack>
                ))}
              </Stack>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={4}>
          <Card variant="outlined" sx={{ height: '100%' }}>
            <CardContent>
              <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 1 }}>Collection Trend (Last 7 Days)</Typography>
              <Box sx={{ width: '100%', height: 300, mt: 1 }}>
                <ResponsiveContainer>
                  <LineChart data={collectionTrend} margin={{ top: 10, right: 16, left: -8, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke={theme.palette.divider} vertical={false} />
                    <XAxis dataKey="name" tick={{ fontSize: 10, fill: theme.palette.text.secondary }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fontSize: 10, fill: theme.palette.text.secondary }} axisLine={false} tickLine={false} tickFormatter={(v) => currencyLakh(v)} />
                    <RechartsTooltip contentStyle={chartTooltipStyle} formatter={(v) => currency(v)} />
                    <Line type="monotone" dataKey="value" stroke={theme.palette.primary.main} strokeWidth={2} dot={{ r: 4 }} />
                  </LineChart>
                </ResponsiveContainer>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={4}>
          <Card variant="outlined" sx={{ height: '100%' }}>
            <CardContent>
              <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 1 }}>Top 5 Customers by Collection ({periodLabel})</Typography>
              <Box sx={{ width: '100%', height: 260, mt: 1 }}>
                <ResponsiveContainer>
                  <BarChart data={top5CustomersByCollection} layout="vertical" margin={{ top: 5, right: 50, left: 10, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke={theme.palette.divider} horizontal={false} />
                    <XAxis type="number" tick={{ fontSize: 10, fill: theme.palette.text.secondary }} axisLine={false} tickLine={false} />
                    <YAxis type="category" dataKey="name" width={100} tick={{ fontSize: 9, fill: theme.palette.text.secondary }} axisLine={false} tickLine={false} />
                    <RechartsTooltip contentStyle={chartTooltipStyle} formatter={(v) => currency(v)} />
                    <Bar dataKey="value" fill={theme.palette.primary.main} radius={[0, 4, 4, 0]} maxBarSize={18}>
                      <LabelList dataKey="value" position="right" formatter={(v) => currency(v)} style={{ fontSize: 9, fill: theme.palette.text.secondary }} />
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}
