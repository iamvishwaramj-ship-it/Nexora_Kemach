import React, { useMemo, useState } from 'react';
import { useForm, FormProvider } from 'react-hook-form';
import {
  Box, Typography, Button, Card, CardContent, Stack, Grid, Table, TableBody,
  TableCell, TableHead, TableRow,
} from '@mui/material';
import { useTheme } from '@mui/material/styles';
import {
  ResponsiveContainer, PieChart, Pie, Cell, Tooltip as RechartsTooltip,
  BarChart, Bar, XAxis, YAxis, CartesianGrid, LabelList,
} from 'recharts';
import SpeedOutlinedIcon from '@mui/icons-material/SpeedOutlined';
import SearchIcon from '@mui/icons-material/Search';
import FileDownloadOutlinedIcon from '@mui/icons-material/FileDownloadOutlined';
import PrintOutlinedIcon from '@mui/icons-material/PrintOutlined';
import HourglassEmptyOutlinedIcon from '@mui/icons-material/HourglassEmptyOutlined';
import Inventory2OutlinedIcon from '@mui/icons-material/Inventory2Outlined';
import HomeOutlinedIcon from '@mui/icons-material/HomeOutlined';
import CurrencyRupeeOutlinedIcon from '@mui/icons-material/CurrencyRupeeOutlined';
import ShowChartOutlinedIcon from '@mui/icons-material/ShowChartOutlined';
import AccessTimeOutlinedIcon from '@mui/icons-material/AccessTimeOutlined';
import dayjs from 'dayjs';
import FormSelect from '../../../components/form/FormSelect';
import FormDatePicker from '../../../components/form/FormDatePicker';
import EntityHeaderCard from '../../../components/common/EntityHeaderCard';
import CompanyBadge from '../../../components/common/CompanyBadge';
import EntityListPagination from '../../../components/data-display/EntityListPagination';
import MobileRecordCard from '../../../components/data-display/MobileRecordCard';
import { useIsMobileListView } from '../../../components/data-display/useIsMobileListView';
import StatCard from '../../../components/data-display/StatCard';
import { branchApi, productGroupApi, productApi } from '../../../features/resources';
import { useWarehouseOptions } from '../../../lib/useWarehouseOptions';
import { useGetSlowMovingStockReportQuery } from '../../../features/inventory/slowMovingStockReportApi';
import useTableFeatures from '../../../components/data-display/useTableFeatures';
import TableToolbar from '../../../components/data-display/TableToolbar';
import SortableHeaderCell from '../../../components/data-display/SortableHeaderCell';
import ScrollableTableContainer from '../../../components/data-display/ScrollableTableContainer';
import FormTextField, { noSpinnersSx } from '../../../components/form/FormTextField';
import TableFilterPanel from '../../../components/data-display/TableFilterPanel';

const PAGE_SIZE = 10;

const PRODUCT_TYPE_OPTIONS = ['Raw Material', 'Semi-Finished Goods', 'Finished Goods', 'Trading Goods', 'Service', 'Consumable', 'Other'];

// Stock Type has no dedicated column anywhere in the data model — this
// list is filter-bar-only and currently a no-op on the backend, see the
// route comment in resources.js.
const STOCK_TYPE_OPTIONS = ['Raw Material', 'Finished Goods', 'Consumable', 'Trading'];

const SLOW_MOVING_BASED_ON_OPTIONS = ['Last Sale Date', 'Last Purchase Date'];
const DAYS_COMPARATOR_OPTIONS = ['Greater than'];

const currency = (v) => `₹ ${Number(v || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const number3 = (v) => Number(v || 0).toLocaleString('en-IN', { minimumFractionDigits: 3, maximumFractionDigits: 3 });
const formatDate = (d) => (d ? dayjs(d).format('DD/MM/YYYY') : '—');

const DEFAULT_FILTERS = {
  branch: '', warehouse: '', productGroup: '', itemCategory: '', stockType: '',
  slowMovingBasedOn: 'Last Sale Date', daysThreshold: 90, asOnDate: dayjs().format('YYYY-MM-DD'),
};

export default function SlowMovingStock() {
  const theme = useTheme();
  const isMobile = useIsMobileListView();

  const { data: branches } = branchApi.useList();
  const { data: productGroups } = productGroupApi.useList();
  const { data: products } = productApi.useList();

  const branchOptions = useMemo(() => ([
    { label: 'All Branches', value: '' },
    ...(branches || []).map((b) => ({ label: b.branchName, value: b.branchName })),
  ]), [branches]);

  // Warehouse is Product.defaultLocation — a real per-product field — so
  // the option list is just the distinct values already in use.
  // Warehouses come from the Warehouse Master — see lib/useWarehouseOptions.js.
  // This filter used to list the distinct free-text values of
  // Product.defaultLocation, so it offered whatever anyone had happened to type
  // on a product record, and could never offer a warehouse holding no product.
  const { options: warehouseOptions } = useWarehouseOptions({ allLabel: 'All Warehouses' });

  const productGroupOptions = useMemo(() => ([
    { label: 'All Groups', value: '' },
    ...(productGroups || []).map((g) => ({ label: g.groupName, value: g.groupName })),
  ]), [productGroups]);

  const itemCategoryOptions = useMemo(() => ([
    { label: 'All Categories', value: '' },
    ...PRODUCT_TYPE_OPTIONS.map((s) => ({ label: s, value: s })),
  ]), []);

  const stockTypeOptions = useMemo(() => ([
    { label: 'All', value: '' },
    ...STOCK_TYPE_OPTIONS.map((s) => ({ label: s, value: s })),
  ]), []);

  const slowMovingBasedOnOptions = useMemo(() => (
    SLOW_MOVING_BASED_ON_OPTIONS.map((s) => ({ label: s, value: s }))
  ), []);

  const daysComparatorOptions = useMemo(() => (
    DAYS_COMPARATOR_OPTIONS.map((s) => ({ label: s, value: s }))
  ), []);

  // Filter bar is a report toolbar, not a create/edit form — no Zod
  // validation or persisted mutation, same as other report pages.
  const methods = useForm({
    defaultValues: {
      branch: '', warehouse: '', productGroup: '', itemCategory: '', stockType: '',
      slowMovingBasedOn: 'Last Sale Date', daysComparator: 'Greater than', daysThreshold: 90, asOnDate: dayjs(),
    },
  });
  const { handleSubmit, reset } = methods;

  const [appliedFilters, setAppliedFilters] = useState(DEFAULT_FILTERS);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(PAGE_SIZE);

  const { data, isLoading, isFetching } = useGetSlowMovingStockReportQuery(appliedFilters);
  const baseTableRows = data?.rows || [];

  // Column definitions drive the global search, the sort icons and the filter
  // popover — see components/data-display/useTableFeatures.js.
  const tableColumns = useMemo(() => ([
    { field: 'productCode', headerName: 'Product Code', filter: 'text' },
    { field: 'productName', headerName: 'Product Name', filter: 'text' },
    { field: 'productGroup', headerName: 'Product Group', filter: 'text' },
    { field: 'warehouse', headerName: 'Warehouse', filter: 'text' },
    { field: 'uom', headerName: 'UOM', filter: 'text' },
    { field: 'onHandQty', headerName: 'On-Hand Qty', filter: 'numberRange', sortValue: (row) => (row.onHandQty == null || row.onHandQty === '' ? null : Number(row.onHandQty)) },
    { field: 'lastSaleDate', headerName: 'Last Sale Date', filter: 'dateRange', sortValue: (row) => (row.lastSaleDate ? new Date(row.lastSaleDate).getTime() : null), searchValue: (row) => formatDate(row.lastSaleDate) },
    { field: 'daysInStock', headerName: 'Days in Stock', filter: 'numberRange', sortValue: (row) => (row.daysInStock == null || row.daysInStock === '' ? null : Number(row.daysInStock)) },
    { field: 'unitCost', headerName: 'Unit Cost (₹)', filter: 'numberRange', sortValue: (row) => (row.unitCost == null || row.unitCost === '' ? null : Number(row.unitCost)) },
    { field: 'stockValue', headerName: 'Stock Value (₹)', filter: 'numberRange', sortValue: (row) => (row.stockValue == null || row.stockValue === '' ? null : Number(row.stockValue)) },
    { field: 'lastPurchaseDate', headerName: 'Last Purchase Date', filter: 'dateRange', sortValue: (row) => (row.lastPurchaseDate ? new Date(row.lastPurchaseDate).getTime() : null), searchValue: (row) => formatDate(row.lastPurchaseDate) },
  ]), []);
  const table = useTableFeatures(baseTableRows, tableColumns, { onChange: setPage });
  const rows = table.rows;
  const totals = data?.totals || {};
  const stats = data?.stats || {};
  const slowMovingByDaysInStock = data?.slowMovingByDaysInStock || [];
  const topSlowMovingItems = data?.topSlowMovingItems || [];
  const slowMovingByWarehouse = data?.slowMovingByWarehouse || [];
  const slowMovingByGroup = data?.slowMovingByGroup || [];
  const pagedRows = useMemo(() => rows.slice(page * pageSize, page * pageSize + pageSize), [rows, page, pageSize]);

  const onView = handleSubmit((values) => {
    setAppliedFilters({
      branch: values.branch || '',
      warehouse: values.warehouse || '',
      productGroup: values.productGroup || '',
      itemCategory: values.itemCategory || '',
      stockType: values.stockType || '',
      slowMovingBasedOn: values.slowMovingBasedOn || 'Last Sale Date',
      daysThreshold: Number(values.daysThreshold) > 0 ? Number(values.daysThreshold) : 90,
      asOnDate: values.asOnDate ? dayjs(values.asOnDate).format('YYYY-MM-DD') : '',
    });
    setPage(0);
  });

  const onReset = () => {
    reset({
      branch: '', warehouse: '', productGroup: '', itemCategory: '', stockType: '',
      slowMovingBasedOn: 'Last Sale Date', daysComparator: 'Greater than', daysThreshold: 90, asOnDate: dayjs(),
    });
    setAppliedFilters(DEFAULT_FILTERS);
    setPage(0);
  };

  const statCards = [
    { icon: <HourglassEmptyOutlinedIcon fontSize="small" />, label: 'Slow Moving Items', value: stats.slowMovingItems ?? 0, color: 'secondary' },
    { icon: <Inventory2OutlinedIcon fontSize="small" />, label: 'Total Products', value: stats.totalProducts ?? 0, color: 'warning' },
    { icon: <HomeOutlinedIcon fontSize="small" />, label: 'Total Warehouses', value: stats.totalWarehouses ?? 0, color: 'primary' },
    { icon: <CurrencyRupeeOutlinedIcon fontSize="small" />, label: 'Total Stock Value (₹)', value: currency(stats.totalStockValue), color: 'secondary' },
    { icon: <ShowChartOutlinedIcon fontSize="small" />, label: 'Avg. Days in Stock', value: `${stats.avgDaysInStock ?? 0} Days`, color: 'warning' },
    { icon: <AccessTimeOutlinedIcon fontSize="small" />, label: 'Last Sale Before', value: `> ${stats.thresholdDays ?? 90} Days`, color: 'success' },
  ];

  const donutColors = [
    theme.palette.primary.main, theme.palette.success.main, theme.palette.warning.main,
    theme.palette.secondary.main, theme.palette.error.main, theme.palette.grey[400],
  ];
  const chartTooltipStyle = { backgroundColor: theme.palette.background.paper, border: `1px solid ${theme.palette.divider}`, borderRadius: 8 };

  // Export: current filtered rows to CSV — same client-side pattern used
  // elsewhere (LowStockReport.jsx).
  const EXPORT_COLUMNS = [
    ['productCode', 'Product Code'], ['productName', 'Product Name'], ['productGroup', 'Product Group'], ['warehouse', 'Warehouse'],
    ['uom', 'UOM'], ['onHandQty', 'On-Hand Qty'], ['lastSaleDate', 'Last Sale Date'], ['daysInStock', 'Days in Stock'],
    ['unitCost', 'Unit Cost'], ['stockValue', 'Stock Value'], ['lastPurchaseDate', 'Last Purchase Date'],
  ];
  const handleExport = () => {
    const header = EXPORT_COLUMNS.map(([, label]) => label).join(',');
    const lines = rows.map((r) => EXPORT_COLUMNS.map(([key]) => {
      let v = r[key];
      if (key === 'lastSaleDate' || key === 'lastPurchaseDate') v = formatDate(v);
      else if (key === 'daysInStock') v = v ?? 'Never';
      return `"${String(v ?? '').replace(/"/g, '""')}"`;
    }).join(','));
    const csv = [header, ...lines].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'slow-moving-stock.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <Box>
      <EntityHeaderCard
        icon={<SpeedOutlinedIcon />}
        title="Slow Moving Stock"
        subtitle="Products with low movement over the selected period."
        rightContent={<CompanyBadge />}
      />

      <Card variant="outlined" sx={{ mb: 2 }}>
        <CardContent>
          <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 2 }}>Filters</Typography>
          <FormProvider {...methods}>
            <Grid container spacing={2} alignItems="flex-start">
              <Grid item xs={12} sm={6} md={2}>
                <FormSelect name="branch" label="Branch" options={branchOptions} emptyValue="" />
              </Grid>
              <Grid item xs={12} sm={6} md={2}>
                <FormSelect name="warehouse" label="Warehouse" options={warehouseOptions} />
              </Grid>
              <Grid item xs={12} sm={6} md={2}>
                <FormSelect name="productGroup" label="Product Group" options={productGroupOptions} emptyValue="" />
              </Grid>
              <Grid item xs={12} sm={6} md={2}>
                <FormSelect name="itemCategory" label="Item Category" options={itemCategoryOptions} emptyValue="" />
              </Grid>
              <Grid item xs={12} sm={6} md={2}>
                <FormSelect name="slowMovingBasedOn" label="Slow Moving Based On" options={slowMovingBasedOnOptions} />
              </Grid>
              {/* Fills out the row exactly: the five fields above this one
                  already take 10 of 12 columns, so this md=2 slot lands
                  right at the edge instead of being squeezed into whatever
                  fractional width was left over — which is what used to
                  push No. of Days/the day-count box onto their own
                  misaligned line. */}
              <Grid item xs={12} sm={6} md={2}>
                <FormSelect name="stockType" label="Stock Type" options={stockTypeOptions} />
              </Grid>
              <Grid item xs={12} sm={6} md={2.5}>
                <FormSelect name="daysComparator" label="No. of Days" options={daysComparatorOptions} />
              </Grid>
              {/* Was a bare Controller+TextField with a hand-tuned `mt`
                  nudge to line its box up with the labelled fields either
                  side of it — a fix that only held for the exact spot it
                  was tuned in and broke again the moment this field moved.
                  FormTextField renders the identical label/input structure
                  FormSelect and FormDatePicker do, so it sits at the same
                  baseline as its neighbours with no manual offset needed. */}
              <Grid item xs={12} sm={6} md={1}>
                <FormTextField name="daysThreshold" label="" type="number" inputProps={{ min: 1 }} />
              </Grid>
              <Grid item xs={12} sm={6} md={2}>
                <FormDatePicker name="asOnDate" label="As On Date" />
              </Grid>
              <Grid item xs={12}>
                <Stack direction="row" spacing={1.5} justifyContent="flex-end" flexWrap="wrap" useFlexGap>
                  <Button
                    variant="contained"
                    color="primary"
                    startIcon={<SearchIcon />}
                    onClick={onView}
                    disabled={isFetching}
                    sx={{ height: 40, minWidth: 130, whiteSpace: 'nowrap' }}
                  >
                    View Report
                  </Button>
                  <Button variant="outlined" color="inherit" onClick={onReset} sx={{ height: 40, minWidth: 100 }}>
                    Reset
                  </Button>
                </Stack>
              </Grid>
            </Grid>
          </FormProvider>
        </CardContent>
      </Card>

      <Grid container spacing={2} sx={{ mb: 2 }}>
        {statCards.map((c) => (
          <Grid item xs={12} sm={6} md={2} key={c.label}>
            <StatCard {...c} />
          </Grid>
        ))}
      </Grid>

      <Card variant="outlined" sx={{ mb: 2 }}>
        <CardContent sx={{ p: 0 }}>
          <TableToolbar
            title="Slow Moving Stock List"
            searchPlaceholder="Search..."
            table={table}
            resultCount={table.rows.length}
            totalCount={table.totalCount}
            rightContent={(
              <Stack direction="row" spacing={1.5} flexWrap="wrap" useFlexGap>
                <Button variant="outlined" color="inherit" size="small" startIcon={<FileDownloadOutlinedIcon />} onClick={handleExport}>
                  Export
                </Button>
                <Button variant="outlined" color="inherit" size="small" startIcon={<PrintOutlinedIcon />} onClick={() => window.print()}>
                  Print
                </Button>
              </Stack>
            )}
          />
          <TableFilterPanel table={table} />
          {isMobile ? (
            <Box sx={{ px: 2, pb: 1 }}>
              {!isLoading && pagedRows.map((row, idx) => (
                <MobileRecordCard
                  key={row.productCode}
                  title={row.productName}
                  fields={[
                    { label: '#', value: page * pageSize + idx + 1 },
                    { label: 'Product Code', value: row.productCode },
                    { label: 'Warehouse', value: row.warehouse },
                    { label: 'On-Hand Qty', value: number3(row.onHandQty) },
                    { label: 'Last Sale Date', value: formatDate(row.lastSaleDate) },
                    { label: 'Days in Stock', value: row.daysInStock ?? 'Never Sold' },
                    { label: 'Unit Cost', value: currency(row.unitCost) },
                    { label: 'Stock Value', value: currency(row.stockValue) },
                    { label: 'Last Purchase Date', value: formatDate(row.lastPurchaseDate) },
                  ]}
                />
              ))}
              {!isLoading && rows.length === 0 && (
                <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>
                  {isFetching ? 'Loading…' : 'No slow moving items found for the selected criteria'}
                </Typography>
              )}
              {!isLoading && rows.length > 0 && (
                <Card variant="outlined" sx={{ mb: 1.5, bgcolor: 'action.hover' }}>
                  <CardContent sx={{ p: 2, '&:last-child': { pb: 2 } }}>
                    <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1 }}>Total</Typography>
                    <Stack spacing={0.75}>
                      {[
                        ['On-Hand Qty', number3(totals.onHandQty)], ['Stock Value', currency(totals.stockValue)],
                      ].map(([label, value]) => (
                        <Stack key={label} direction="row" justifyContent="space-between">
                          <Typography variant="caption" color="text.secondary">{label}</Typography>
                          <Typography variant="body2" fontWeight={700}>{value}</Typography>
                        </Stack>
                      ))}
                    </Stack>
                  </CardContent>
                </Card>
              )}
            </Box>
          ) : (
            <ScrollableTableContainer>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell>#</TableCell>
                    <SortableHeaderCell field="productCode" sort={table.sort} onSort={table.toggleSort}>Product Code</SortableHeaderCell>
                    <SortableHeaderCell field="productName" sort={table.sort} onSort={table.toggleSort}>Product Name</SortableHeaderCell>
                    <SortableHeaderCell field="productGroup" sort={table.sort} onSort={table.toggleSort}>Product Group</SortableHeaderCell>
                    <SortableHeaderCell field="warehouse" sort={table.sort} onSort={table.toggleSort}>Warehouse</SortableHeaderCell>
                    <SortableHeaderCell field="uom" sort={table.sort} onSort={table.toggleSort}>UOM</SortableHeaderCell>
                    <SortableHeaderCell field="onHandQty" sort={table.sort} onSort={table.toggleSort} align="right">On-Hand Qty</SortableHeaderCell>
                    <SortableHeaderCell field="lastSaleDate" sort={table.sort} onSort={table.toggleSort}>Last Sale Date</SortableHeaderCell>
                    <SortableHeaderCell field="daysInStock" sort={table.sort} onSort={table.toggleSort} align="right">Days in Stock</SortableHeaderCell>
                    <SortableHeaderCell field="unitCost" sort={table.sort} onSort={table.toggleSort} align="right">Unit Cost (₹)</SortableHeaderCell>
                    <SortableHeaderCell field="stockValue" sort={table.sort} onSort={table.toggleSort} align="right">Stock Value (₹)</SortableHeaderCell>
                    <SortableHeaderCell field="lastPurchaseDate" sort={table.sort} onSort={table.toggleSort}>Last Purchase Date</SortableHeaderCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {!isLoading && pagedRows.map((row, idx) => (
                    <TableRow key={row.productCode} hover>
                      <TableCell>{page * pageSize + idx + 1}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>
                        <Typography variant="body2" fontWeight={700} color="primary.main">{row.productCode}</Typography>
                      </TableCell>
                      <TableCell sx={{ minWidth: 150 }}>{row.productName}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.productGroup}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.warehouse}</TableCell>
                      <TableCell>{row.uom}</TableCell>
                      <TableCell align="right">{number3(row.onHandQty)}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{formatDate(row.lastSaleDate)}</TableCell>
                      <TableCell align="right">{row.daysInStock ?? 'Never Sold'}</TableCell>
                      <TableCell align="right" sx={{ whiteSpace: 'nowrap' }}>{currency(row.unitCost)}</TableCell>
                      <TableCell align="right" sx={{ whiteSpace: 'nowrap' }}>{currency(row.stockValue)}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{formatDate(row.lastPurchaseDate)}</TableCell>
                    </TableRow>
                  ))}
                  {!isLoading && rows.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={12}>
                        <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>
                          {isFetching ? 'Loading…' : 'No slow moving items found for the selected criteria'}
                        </Typography>
                      </TableCell>
                    </TableRow>
                  )}
                  {!isLoading && rows.length > 0 && (
                    <TableRow>
                      <TableCell colSpan={6}><Typography fontWeight={700}>Total</Typography></TableCell>
                      <TableCell align="right"><Typography fontWeight={700}>{number3(totals.onHandQty)}</Typography></TableCell>
                      <TableCell>—</TableCell>
                      <TableCell>—</TableCell>
                      <TableCell>—</TableCell>
                      <TableCell align="right"><Typography fontWeight={700}>{currency(totals.stockValue)}</Typography></TableCell>
                      <TableCell>—</TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </ScrollableTableContainer>
          )}

          <EntityListPagination total={rows.length} page={page} onChange={setPage} pageSize={pageSize} onPageSizeChange={(v) => { setPageSize(v); setPage(0); }} />
        </CardContent>
      </Card>

      <Grid container spacing={2}>
        <Grid item xs={12} md={3}>
          <Card variant="outlined" sx={{ height: '100%' }}>
            <CardContent>
              <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 1 }}>Slow Moving Stock by Days in Stock</Typography>
              <Box sx={{ width: '100%', height: 180, position: 'relative' }}>
                <ResponsiveContainer>
                  <PieChart>
                    <Pie data={slowMovingByDaysInStock} dataKey="value" nameKey="name" innerRadius={50} outerRadius={80} paddingAngle={2} strokeWidth={0}>
                      {slowMovingByDaysInStock.map((entry, i) => <Cell key={entry.name} fill={donutColors[i % donutColors.length]} />)}
                    </Pie>
                    <RechartsTooltip contentStyle={chartTooltipStyle} formatter={(v) => `${v} items`} />
                  </PieChart>
                </ResponsiveContainer>
                <Box sx={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', textAlign: 'center', pointerEvents: 'none' }}>
                  <Typography variant="caption" color="text.secondary" display="block">{stats.slowMovingItems ?? 0}</Typography>
                  <Typography variant="subtitle2" fontWeight={700}>Items</Typography>
                </Box>
              </Box>
              <Stack spacing={0.75} sx={{ mt: 1 }}>
                {slowMovingByDaysInStock.map((d, i) => (
                  <Stack key={d.name} direction="row" alignItems="center" justifyContent="space-between">
                    <Stack direction="row" alignItems="center" spacing={1} sx={{ minWidth: 0 }}>
                      <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: donutColors[i % donutColors.length], flexShrink: 0 }} />
                      <Typography variant="caption" color="text.secondary" noWrap>{d.name}</Typography>
                    </Stack>
                    <Typography variant="caption" color="text.secondary">{d.value} ({d.percent}%)</Typography>
                  </Stack>
                ))}
              </Stack>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={3}>
          <Card variant="outlined" sx={{ height: '100%' }}>
            <CardContent>
              <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 1 }}>Top 10 Slow Moving Items by Stock Value</Typography>
              <Box sx={{ width: '100%', height: 300, mt: 1 }}>
                <ResponsiveContainer>
                  <BarChart data={topSlowMovingItems} layout="vertical" margin={{ top: 5, right: 40, left: 10, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke={theme.palette.divider} horizontal={false} />
                    <XAxis type="number" tick={{ fontSize: 10, fill: theme.palette.text.secondary }} axisLine={false} tickLine={false} />
                    <YAxis type="category" dataKey="name" width={90} tick={{ fontSize: 9, fill: theme.palette.text.secondary }} axisLine={false} tickLine={false} />
                    <RechartsTooltip contentStyle={chartTooltipStyle} formatter={(v) => currency(v)} />
                    <Bar dataKey="value" fill={theme.palette.warning.main} radius={[0, 4, 4, 0]} maxBarSize={14}>
                      <LabelList dataKey="value" position="right" formatter={(v) => currency(v)} style={{ fontSize: 9, fill: theme.palette.text.secondary }} />
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={3}>
          <Card variant="outlined" sx={{ height: '100%' }}>
            <CardContent>
              <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 1 }}>Slow Moving Stock Value by Warehouse</Typography>
              <Box sx={{ width: '100%', height: 260, mt: 1 }}>
                <ResponsiveContainer>
                  <BarChart data={slowMovingByWarehouse} margin={{ top: 20, right: 8, left: -12, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke={theme.palette.divider} vertical={false} />
                    <XAxis dataKey="name" tick={{ fontSize: 9, fill: theme.palette.text.secondary }} axisLine={false} tickLine={false} interval={0} />
                    <YAxis tick={{ fontSize: 10, fill: theme.palette.text.secondary }} axisLine={false} tickLine={false} />
                    <RechartsTooltip contentStyle={chartTooltipStyle} formatter={(v) => currency(v)} />
                    <Bar dataKey="value" fill={theme.palette.primary.main} radius={[4, 4, 0, 0]} maxBarSize={36}>
                      <LabelList dataKey="value" position="top" formatter={(v) => currency(v)} style={{ fontSize: 9, fill: theme.palette.text.secondary }} />
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={3}>
          <Card variant="outlined" sx={{ height: '100%' }}>
            <CardContent>
              <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 1 }}>Slow Moving Stock by Product Group</Typography>
              <Box sx={{ width: '100%', height: 180, position: 'relative' }}>
                <ResponsiveContainer>
                  <PieChart>
                    <Pie data={slowMovingByGroup} dataKey="value" nameKey="name" innerRadius={50} outerRadius={80} paddingAngle={2} strokeWidth={0}>
                      {slowMovingByGroup.map((entry, i) => <Cell key={entry.name} fill={donutColors[i % donutColors.length]} />)}
                    </Pie>
                    <RechartsTooltip contentStyle={chartTooltipStyle} formatter={(v) => currency(v)} />
                  </PieChart>
                </ResponsiveContainer>
                <Box sx={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', textAlign: 'center', pointerEvents: 'none' }}>
                  <Typography variant="caption" color="text.secondary" display="block">Total Value</Typography>
                  <Typography variant="subtitle2" fontWeight={700}>{currency(stats.totalStockValue)}</Typography>
                </Box>
              </Box>
              <Stack spacing={0.75} sx={{ mt: 1 }}>
                {slowMovingByGroup.map((d, i) => (
                  <Stack key={d.name} direction="row" alignItems="center" justifyContent="space-between">
                    <Stack direction="row" alignItems="center" spacing={1} sx={{ minWidth: 0 }}>
                      <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: donutColors[i % donutColors.length], flexShrink: 0 }} />
                      <Typography variant="caption" color="text.secondary" noWrap>{d.name}</Typography>
                    </Stack>
                    <Typography variant="caption" color="text.secondary">{currency(d.value)} ({d.percent}%)</Typography>
                  </Stack>
                ))}
              </Stack>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}
