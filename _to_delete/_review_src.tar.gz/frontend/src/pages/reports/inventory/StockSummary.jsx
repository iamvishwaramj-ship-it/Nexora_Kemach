import React, { useMemo, useState } from 'react';
import { useForm, FormProvider } from 'react-hook-form';
import {
  Box, Typography, Button, Card, CardContent, Stack, Grid, Chip,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
} from '@mui/material';
import { useTheme } from '@mui/material/styles';
import {
  ResponsiveContainer, PieChart, Pie, Cell, Tooltip as RechartsTooltip,
  BarChart, Bar, XAxis, YAxis, CartesianGrid, LabelList,
} from 'recharts';
import Inventory2OutlinedIcon from '@mui/icons-material/Inventory2Outlined';
import SearchIcon from '@mui/icons-material/Search';
import FileDownloadOutlinedIcon from '@mui/icons-material/FileDownloadOutlined';
import PrintOutlinedIcon from '@mui/icons-material/PrintOutlined';
import Inventory2Icon from '@mui/icons-material/Inventory2';
import HomeOutlinedIcon from '@mui/icons-material/HomeOutlined';
import ShoppingCartOutlinedIcon from '@mui/icons-material/ShoppingCartOutlined';
import CurrencyRupeeOutlinedIcon from '@mui/icons-material/CurrencyRupeeOutlined';
import AssignmentOutlinedIcon from '@mui/icons-material/AssignmentOutlined';
import Inventory2OutlinedIconAlt from '@mui/icons-material/WidgetsOutlined';
import dayjs from 'dayjs';
import FormSelect from '../../../components/form/FormSelect';
import FormDatePicker from '../../../components/form/FormDatePicker';
import EntityHeaderCard from '../../../components/common/EntityHeaderCard';
import CompanyBadge from '../../../components/common/CompanyBadge';
import EntityListPagination from '../../../components/data-display/EntityListPagination';
import MobileRecordCard from '../../../components/data-display/MobileRecordCard';
import { useIsMobileListView } from '../../../components/data-display/useIsMobileListView';
import StatCard from '../../../components/data-display/StatCard';
import { branchApi, productGroupApi, productApi } from '../../../features/resources';
import { useWarehouseOptions } from '../../../lib/useWarehouseOptions';
import { useGetStockSummaryReportQuery } from '../../../features/inventory/stockSummaryReportApi';
import useTableFeatures from '../../../components/data-display/useTableFeatures';
import TableToolbar from '../../../components/data-display/TableToolbar';
import SortableHeaderCell from '../../../components/data-display/SortableHeaderCell';
import ScrollableTableContainer from '../../../components/data-display/ScrollableTableContainer';
import TableFilterPanel from '../../../components/data-display/TableFilterPanel';

const PAGE_SIZE = 10;

const PRODUCT_TYPE_OPTIONS = ['Raw Material', 'Semi-Finished Goods', 'Finished Goods', 'Trading Goods', 'Service', 'Consumable', 'Other'];

// Stock Type has no dedicated column anywhere in the data model — this
// list is filter-bar-only and currently a no-op on the backend, see the
// route comment in resources.js.
const STOCK_TYPE_OPTIONS = ['Raw Material', 'Finished Goods', 'Consumable', 'Trading'];

const STATUS_OPTIONS = ['Available', 'Low Stock', 'Out of Stock'];
const STATUS_COLORS = { Available: 'success', 'Low Stock': 'warning', 'Out of Stock': 'error' };

const currency = (v) => `₹ ${Number(v || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const number3 = (v) => Number(v || 0).toLocaleString('en-IN', { minimumFractionDigits: 3, maximumFractionDigits: 3 });
const formatDate = (d) => (d ? dayjs(d).format('DD/MM/YYYY') : '—');

const DEFAULT_FILTERS = { branch: '', warehouse: '', productGroup: '', product: '', itemCategory: '', stockType: '', stockStatus: '', asOnDate: dayjs().format('YYYY-MM-DD') };

export default function StockSummary() {
  const theme = useTheme();
  const isMobile = useIsMobileListView();

  const { data: branches } = branchApi.useList();
  const { data: productGroups } = productGroupApi.useList();
  const { data: products } = productApi.useList();

  const branchOptions = useMemo(() => ([
    { label: 'All Branches', value: '' },
    ...(branches || []).map((b) => ({ label: b.branchName, value: b.branchName })),
  ]), [branches]);

  // Warehouses come from the Warehouse Master — see lib/useWarehouseOptions.js.
  // This filter used to synthesise '<branch> Warehouse' strings, which matched
  // nothing any document had ever stored.
  const { options: warehouseOptions } = useWarehouseOptions({ allLabel: 'All Warehouses' });

  const productGroupOptions = useMemo(() => ([
    { label: 'All Groups', value: '' },
    ...(productGroups || []).map((g) => ({ label: g.groupName, value: g.groupName })),
  ]), [productGroups]);

  const productOptions = useMemo(() => ([
    { label: 'All Products', value: '' },
    ...(products || []).map((p) => ({ label: `${p.productCode} - ${p.productName}`, value: p.productCode })),
  ]), [products]);

  const itemCategoryOptions = useMemo(() => ([
    { label: 'All Categories', value: '' },
    ...PRODUCT_TYPE_OPTIONS.map((s) => ({ label: s, value: s })),
  ]), []);

  const stockTypeOptions = useMemo(() => ([
    { label: 'All', value: '' },
    ...STOCK_TYPE_OPTIONS.map((s) => ({ label: s, value: s })),
  ]), []);

  const statusOptions = useMemo(() => ([
    { label: 'All', value: '' },
    ...STATUS_OPTIONS.map((s) => ({ label: s, value: s })),
  ]), []);

  // Filter bar is a report toolbar, not a create/edit form — no Zod
  // validation or persisted mutation, same as other report pages.
  const methods = useForm({
    defaultValues: { branch: '', warehouse: '', productGroup: '', product: '', itemCategory: '', stockType: '', stockStatus: '', asOnDate: dayjs() },
  });
  const { handleSubmit, reset } = methods;

  const [appliedFilters, setAppliedFilters] = useState(DEFAULT_FILTERS);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(PAGE_SIZE);

  const { data, isLoading, isFetching } = useGetStockSummaryReportQuery(appliedFilters);
  const baseTableRows = data?.rows || [];
  const totals = data?.totals || {};
  const stats = data?.stats || {};
  const stockValueByGroup = data?.stockValueByGroup || [];
  const statusOverview = data?.statusOverview || [];
  const topLowStockItems = data?.topLowStockItems || [];
  const stockValueByWarehouse = data?.stockValueByWarehouse || [];
  // Column definitions drive the global search, the sort icons and the filter
  // popover — see components/data-display/useTableFeatures.js.
  const tableColumns = useMemo(() => ([
    { field: 'productCode', headerName: 'Product Code', filter: 'text' },
    { field: 'productName', headerName: 'Product Name', filter: 'text' },
    { field: 'productGroup', headerName: 'Product Group', filter: 'select' },
    { field: 'uom', headerName: 'UOM', filter: 'select' },
    { field: 'openingQty', headerName: 'Opening Qty', filter: 'numberRange', sortValue: (row) => Number(row.openingQty) || 0 },
    { field: 'openingValue', headerName: 'Opening Value', filter: 'numberRange', sortValue: (row) => Number(row.openingValue) || 0 },
    { field: 'inwardQty', headerName: 'Inward Qty', filter: 'numberRange', sortValue: (row) => Number(row.inwardQty) || 0 },
    { field: 'inwardValue', headerName: 'Inward Value', filter: 'numberRange', sortValue: (row) => Number(row.inwardValue) || 0 },
    { field: 'outwardQty', headerName: 'Outward Qty', filter: 'numberRange', sortValue: (row) => Number(row.outwardQty) || 0 },
    { field: 'outwardValue', headerName: 'Outward Value', filter: 'numberRange', sortValue: (row) => Number(row.outwardValue) || 0 },
    { field: 'closingQty', headerName: 'Closing Qty', filter: 'numberRange', sortValue: (row) => Number(row.closingQty) || 0 },
    { field: 'closingValue', headerName: 'Closing Value', filter: 'numberRange', sortValue: (row) => Number(row.closingValue) || 0 },
    { field: 'stockValue', headerName: 'Stock Value (₹)', filter: 'numberRange', sortValue: (row) => Number(row.stockValue) || 0 },
    { field: 'status', headerName: 'Stock Status', filter: 'select' },
  ]), []);
  const table = useTableFeatures(baseTableRows, tableColumns, { onChange: setPage });
  const rows = table.rows;

  const pagedRows = useMemo(() => rows.slice(page * pageSize, page * pageSize + pageSize), [rows, page, pageSize]);

  const onView = handleSubmit((values) => {
    setAppliedFilters({
      branch: values.branch || '',
      warehouse: values.warehouse || '',
      productGroup: values.productGroup || '',
      product: values.product || '',
      itemCategory: values.itemCategory || '',
      stockType: values.stockType || '',
      stockStatus: values.stockStatus || '',
      asOnDate: values.asOnDate ? dayjs(values.asOnDate).format('YYYY-MM-DD') : '',
    });
    setPage(0);
  });

  const onReset = () => {
    reset({ branch: '', warehouse: '', productGroup: '', product: '', itemCategory: '', stockType: '', stockStatus: '', asOnDate: dayjs() });
    setAppliedFilters(DEFAULT_FILTERS);
    setPage(0);
  };

  const statCards = [
    { icon: <Inventory2Icon fontSize="small" />, label: 'Total Products', value: stats.totalProducts ?? 0, color: 'primary' },
    { icon: <HomeOutlinedIcon fontSize="small" />, label: 'Warehouses', value: stats.totalWarehouses ?? 0, color: 'success' },
    { icon: <ShoppingCartOutlinedIcon fontSize="small" />, label: 'Total Stock Quantity', value: number3(stats.totalStockQuantity), color: 'warning' },
    { icon: <CurrencyRupeeOutlinedIcon fontSize="small" />, label: 'Total Stock Value (₹)', value: currency(stats.totalStockValue), color: 'secondary' },
    { icon: <AssignmentOutlinedIcon fontSize="small" />, label: 'Low Stock Items', value: stats.lowStockItems ?? 0, color: 'info' },
    { icon: <Inventory2OutlinedIconAlt fontSize="small" />, label: 'Out of Stock Items', value: stats.outOfStockItems ?? 0, color: 'error' },
  ];

  const donutColors = [
    theme.palette.primary.main, theme.palette.success.main, theme.palette.warning.main,
    theme.palette.secondary.main, theme.palette.error.main, theme.palette.grey[400],
  ];
  const statusDonutColors = [theme.palette.success.main, theme.palette.warning.main, theme.palette.error.main];
  const chartTooltipStyle = { backgroundColor: theme.palette.background.paper, border: `1px solid ${theme.palette.divider}`, borderRadius: 8 };

  // Export: current filtered rows to CSV — same client-side pattern used
  // elsewhere (PurchaseOrderRegister.jsx).
  const EXPORT_COLUMNS = [
    ['productCode', 'Product Code'], ['productName', 'Product Name'], ['productGroup', 'Product Group'], ['uom', 'UOM'],
    ['openingQty', 'Opening Qty'], ['openingValue', 'Opening Value'], ['inwardQty', 'Inward Qty'], ['inwardValue', 'Inward Value'],
    ['outwardQty', 'Outward Qty'], ['outwardValue', 'Outward Value'], ['closingQty', 'Closing Qty'], ['closingValue', 'Closing Value'],
    ['stockValue', 'Stock Value'], ['status', 'Stock Status'],
  ];
  const handleExport = () => {
    const header = EXPORT_COLUMNS.map(([, label]) => label).join(',');
    const lines = rows.map((r) => EXPORT_COLUMNS.map(([key]) => `"${String(r[key] ?? '').replace(/"/g, '""')}"`).join(','));
    const csv = [header, ...lines].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'stock-summary.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <Box>
      <EntityHeaderCard
        icon={<Inventory2OutlinedIcon />}
        title="Stock Summary"
        subtitle="Current on-hand stock across all warehouses."
        rightContent={<CompanyBadge />}
      />

      <Card variant="outlined" sx={{ mb: 2 }}>
        <CardContent>
          <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 2 }}>Filters</Typography>
          <FormProvider {...methods}>
            <Grid container spacing={2} alignItems="flex-start">
              <Grid item xs={12} sm={6} md={2}>
                <FormSelect name="branch" label="Branch" options={branchOptions} emptyValue="" />
              </Grid>
              <Grid item xs={12} sm={6} md={2}>
                <FormSelect name="warehouse" label="Warehouse" options={warehouseOptions} emptyValue="" />
              </Grid>
              <Grid item xs={12} sm={6} md={2}>
                <FormSelect name="productGroup" label="Product Group" options={productGroupOptions} emptyValue="" />
              </Grid>
              <Grid item xs={12} sm={6} md={2}>
                <FormSelect name="product" label="Product" options={productOptions} emptyValue="" />
              </Grid>
              <Grid item xs={12} sm={6} md={2}>
                <FormSelect name="itemCategory" label="Item Category" options={itemCategoryOptions} emptyValue="" />
              </Grid>
              <Grid item xs={12} sm={6} md={2}>
                <FormSelect name="stockType" label="Stock Type" options={stockTypeOptions} />
              </Grid>
              <Grid item xs={12} sm={6} md={2}>
                <FormSelect name="stockStatus" label="Stock Status" options={statusOptions} />
              </Grid>
              <Grid item xs={12} sm={6} md={2}>
                <FormDatePicker name="asOnDate" label="As On Date" />
              </Grid>
              <Grid item xs={12}>
                <Stack direction="row" spacing={1.5} justifyContent="flex-end" flexWrap="wrap" useFlexGap>
                  <Button
                    variant="contained"
                    color="primary"
                    startIcon={<SearchIcon />}
                    onClick={onView}
                    disabled={isFetching}
                    sx={{ height: 40, minWidth: 130, whiteSpace: 'nowrap' }}
                  >
                    View Report
                  </Button>
                  <Button variant="outlined" color="inherit" onClick={onReset} sx={{ height: 40, minWidth: 100 }}>
                    Reset
                  </Button>
                </Stack>
              </Grid>
            </Grid>
          </FormProvider>
        </CardContent>
      </Card>

      <Grid container spacing={2} sx={{ mb: 2 }}>
        {statCards.map((c) => (
          <Grid item xs={12} sm={6} md={2} key={c.label}>
            <StatCard {...c} />
          </Grid>
        ))}
      </Grid>

      <Card variant="outlined" sx={{ mb: 2 }}>
        <CardContent sx={{ p: 0 }}>
          <TableToolbar
            title="Stock Summary List"
            searchPlaceholder="Search products..."
            table={table}
            resultCount={table.rows.length}
            totalCount={table.totalCount}
            rightContent={(
              <Stack direction="row" spacing={1.5} flexWrap="wrap" useFlexGap>
                <Button variant="outlined" color="inherit" size="small" startIcon={<FileDownloadOutlinedIcon />} onClick={handleExport}>
                  Export
                </Button>
                <Button variant="outlined" color="inherit" size="small" startIcon={<PrintOutlinedIcon />} onClick={() => window.print()}>
                  Print
                </Button>
              </Stack>
            )}
          />
          <TableFilterPanel table={table} />

          {isMobile ? (
            <Box sx={{ px: 2, pb: 1 }}>
              {!isLoading && pagedRows.map((row, idx) => (
                <MobileRecordCard
                  key={row.productCode}
                  title={row.productName}
                  statusChip={<Chip size="small" label={row.status} color={STATUS_COLORS[row.status] || 'default'} variant="outlined" />}
                  fields={[
                    { label: '#', value: page * pageSize + idx + 1 },
                    { label: 'Product Code', value: row.productCode },
                    { label: 'Product Group', value: row.productGroup },
                    { label: 'UOM', value: row.uom },
                    { label: 'Opening Qty', value: number3(row.openingQty) },
                    { label: 'Inward Qty', value: number3(row.inwardQty) },
                    { label: 'Outward Qty', value: number3(row.outwardQty) },
                    { label: 'Closing Qty', value: number3(row.closingQty) },
                    { label: 'Stock Value', value: currency(row.stockValue) },
                  ]}
                />
              ))}
              {!isLoading && rows.length === 0 && (
                <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>
                  {isFetching ? 'Loading…' : 'No products found for the selected criteria'}
                </Typography>
              )}
              {!isLoading && rows.length > 0 && (
                <Card variant="outlined" sx={{ mb: 1.5, bgcolor: 'action.hover' }}>
                  <CardContent sx={{ p: 2, '&:last-child': { pb: 2 } }}>
                    <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1 }}>Total</Typography>
                    <Stack spacing={0.75}>
                      {[
                        ['Opening Value', currency(totals.openingValue)], ['Inward Value', currency(totals.inwardValue)],
                        ['Outward Value', currency(totals.outwardValue)], ['Closing Value', currency(totals.closingValue)],
                      ].map(([label, value]) => (
                        <Stack key={label} direction="row" justifyContent="space-between">
                          <Typography variant="caption" color="text.secondary">{label}</Typography>
                          <Typography variant="body2" fontWeight={700}>{value}</Typography>
                        </Stack>
                      ))}
                    </Stack>
                  </CardContent>
                </Card>
              )}
            </Box>
          ) : (
            <ScrollableTableContainer>
              <Table size="small" stickyHeader>
                <TableHead>
                  <TableRow>
                    <TableCell rowSpan={2}>#</TableCell>
                    <SortableHeaderCell field="productCode" sort={table.sort} onSort={table.toggleSort} rowSpan={2}>Product Code</SortableHeaderCell>
                    <SortableHeaderCell field="productName" sort={table.sort} onSort={table.toggleSort} rowSpan={2}>Product Name</SortableHeaderCell>
                    <SortableHeaderCell field="productGroup" sort={table.sort} onSort={table.toggleSort} rowSpan={2}>Product Group</SortableHeaderCell>
                    <SortableHeaderCell field="uom" sort={table.sort} onSort={table.toggleSort} rowSpan={2}>UOM</SortableHeaderCell>
                    <TableCell align="center" colSpan={2}>Opening Stock</TableCell>
                    <TableCell align="center" colSpan={2}>Inward</TableCell>
                    <TableCell align="center" colSpan={2}>Outward</TableCell>
                    <TableCell align="center" colSpan={2}>Closing Stock</TableCell>
                    <SortableHeaderCell field="stockValue" sort={table.sort} onSort={table.toggleSort} rowSpan={2} align="right">Stock Value (₹)</SortableHeaderCell>
                    <SortableHeaderCell field="status" sort={table.sort} onSort={table.toggleSort} rowSpan={2}>Stock Status</SortableHeaderCell>
                  </TableRow>
                  <TableRow>
                    <SortableHeaderCell field="openingQty" sort={table.sort} onSort={table.toggleSort} align="right">Qty</SortableHeaderCell>
                    <SortableHeaderCell field="openingValue" sort={table.sort} onSort={table.toggleSort} align="right">Value (₹)</SortableHeaderCell>
                    <SortableHeaderCell field="inwardQty" sort={table.sort} onSort={table.toggleSort} align="right">Qty</SortableHeaderCell>
                    <SortableHeaderCell field="inwardValue" sort={table.sort} onSort={table.toggleSort} align="right">Value (₹)</SortableHeaderCell>
                    <SortableHeaderCell field="outwardQty" sort={table.sort} onSort={table.toggleSort} align="right">Qty</SortableHeaderCell>
                    <SortableHeaderCell field="outwardValue" sort={table.sort} onSort={table.toggleSort} align="right">Value (₹)</SortableHeaderCell>
                    <SortableHeaderCell field="closingQty" sort={table.sort} onSort={table.toggleSort} align="right">Qty</SortableHeaderCell>
                    <SortableHeaderCell field="closingValue" sort={table.sort} onSort={table.toggleSort} align="right">Value (₹)</SortableHeaderCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {!isLoading && pagedRows.map((row, idx) => (
                    <TableRow key={row.productCode} hover>
                      <TableCell>{page * pageSize + idx + 1}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>
                        <Typography variant="body2" fontWeight={700} color="primary.main">{row.productCode}</Typography>
                      </TableCell>
                      <TableCell sx={{ minWidth: 150 }}>{row.productName}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.productGroup}</TableCell>
                      <TableCell>{row.uom}</TableCell>
                      <TableCell align="right">{number3(row.openingQty)}</TableCell>
                      <TableCell align="right" sx={{ whiteSpace: 'nowrap' }}>{currency(row.openingValue)}</TableCell>
                      <TableCell align="right">{number3(row.inwardQty)}</TableCell>
                      <TableCell align="right" sx={{ whiteSpace: 'nowrap' }}>{currency(row.inwardValue)}</TableCell>
                      <TableCell align="right">{number3(row.outwardQty)}</TableCell>
                      <TableCell align="right" sx={{ whiteSpace: 'nowrap' }}>{currency(row.outwardValue)}</TableCell>
                      <TableCell align="right">{number3(row.closingQty)}</TableCell>
                      <TableCell align="right" sx={{ whiteSpace: 'nowrap' }}>{currency(row.closingValue)}</TableCell>
                      <TableCell align="right" sx={{ whiteSpace: 'nowrap' }}>{currency(row.stockValue)}</TableCell>
                      <TableCell>
                        <Typography variant="body2" fontWeight={700} sx={{ color: `${STATUS_COLORS[row.status] || 'text.primary'}.main` }}>{row.status}</Typography>
                      </TableCell>
                    </TableRow>
                  ))}
                  {!isLoading && rows.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={14}>
                        <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>
                          {isFetching ? 'Loading…' : 'No products found for the selected criteria'}
                        </Typography>
                      </TableCell>
                    </TableRow>
                  )}
                  {!isLoading && rows.length > 0 && (
                    <TableRow>
                      <TableCell colSpan={5}><Typography fontWeight={700}>Total</Typography></TableCell>
                      <TableCell>—</TableCell>
                      <TableCell align="right"><Typography fontWeight={700}>{currency(totals.openingValue)}</Typography></TableCell>
                      <TableCell>—</TableCell>
                      <TableCell align="right"><Typography fontWeight={700}>{currency(totals.inwardValue)}</Typography></TableCell>
                      <TableCell>—</TableCell>
                      <TableCell align="right"><Typography fontWeight={700}>{currency(totals.outwardValue)}</Typography></TableCell>
                      <TableCell>—</TableCell>
                      <TableCell align="right"><Typography fontWeight={700}>{currency(totals.closingValue)}</Typography></TableCell>
                      <TableCell align="right"><Typography fontWeight={700}>{currency(totals.closingValue)}</Typography></TableCell>
                      <TableCell>—</TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </ScrollableTableContainer>
          )}

          <EntityListPagination total={rows.length} page={page} onChange={setPage} pageSize={pageSize} onPageSizeChange={(v) => { setPageSize(v); setPage(0); }} />
        </CardContent>
      </Card>

      <Grid container spacing={2}>
        <Grid item xs={12} md={3}>
          <Card variant="outlined" sx={{ height: '100%' }}>
            <CardContent>
              <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 1 }}>Stock Value by Product Group (Top 5)</Typography>
              <Box sx={{ width: '100%', height: 180, position: 'relative' }}>
                <ResponsiveContainer>
                  <PieChart>
                    <Pie data={stockValueByGroup} dataKey="value" nameKey="name" innerRadius={50} outerRadius={80} paddingAngle={2} strokeWidth={0}>
                      {stockValueByGroup.map((entry, i) => <Cell key={entry.name} fill={donutColors[i % donutColors.length]} />)}
                    </Pie>
                    <RechartsTooltip contentStyle={chartTooltipStyle} formatter={(v) => currency(v)} />
                  </PieChart>
                </ResponsiveContainer>
                <Box sx={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', textAlign: 'center', pointerEvents: 'none' }}>
                  <Typography variant="caption" color="text.secondary" display="block">Total</Typography>
                  <Typography variant="subtitle2" fontWeight={700}>{currency(stats.totalStockValue)}</Typography>
                </Box>
              </Box>
              <Stack spacing={0.75} sx={{ mt: 1 }}>
                {stockValueByGroup.map((d, i) => (
                  <Stack key={d.name} direction="row" alignItems="center" justifyContent="space-between">
                    <Stack direction="row" alignItems="center" spacing={1} sx={{ minWidth: 0 }}>
                      <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: donutColors[i % donutColors.length], flexShrink: 0 }} />
                      <Typography variant="caption" color="text.secondary" noWrap>{d.name}</Typography>
                    </Stack>
                    <Typography variant="caption" color="text.secondary">{d.percent}% (₹{d.value.toLocaleString('en-IN')})</Typography>
                  </Stack>
                ))}
              </Stack>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={3}>
          <Card variant="outlined" sx={{ height: '100%' }}>
            <CardContent>
              <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 1 }}>Stock Status Overview</Typography>
              <Box sx={{ width: '100%', height: 180, position: 'relative' }}>
                <ResponsiveContainer>
                  <PieChart>
                    <Pie data={statusOverview} dataKey="value" nameKey="name" innerRadius={50} outerRadius={80} paddingAngle={2} strokeWidth={0}>
                      {statusOverview.map((entry, i) => <Cell key={entry.name} fill={statusDonutColors[i % statusDonutColors.length]} />)}
                    </Pie>
                    <RechartsTooltip contentStyle={chartTooltipStyle} formatter={(v) => number3(v)} />
                  </PieChart>
                </ResponsiveContainer>
                <Box sx={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', textAlign: 'center', pointerEvents: 'none' }}>
                  <Typography variant="caption" color="text.secondary" display="block">Total Items</Typography>
                  <Typography variant="subtitle2" fontWeight={700}>{stats.totalProducts ?? 0}</Typography>
                </Box>
              </Box>
              <Stack spacing={0.75} sx={{ mt: 1 }}>
                {statusOverview.map((d, i) => {
                  const percent = stats.totalProducts ? Math.round((d.value / stats.totalProducts) * 1000) / 10 : 0;
                  return (
                    <Stack key={d.name} direction="row" alignItems="center" justifyContent="space-between">
                      <Stack direction="row" alignItems="center" spacing={1} sx={{ minWidth: 0 }}>
                        <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: statusDonutColors[i % statusDonutColors.length], flexShrink: 0 }} />
                        <Typography variant="caption" color="text.secondary" noWrap>{d.name}</Typography>
                      </Stack>
                      <Typography variant="caption" color="text.secondary">{d.value} ({percent}%)</Typography>
                    </Stack>
                  );
                })}
              </Stack>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={3}>
          <Card variant="outlined" sx={{ height: '100%' }}>
            <CardContent>
              <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 1 }}>Top 5 Low Stock Items</Typography>
              <Box sx={{ width: '100%', height: 240, mt: 1 }}>
                <ResponsiveContainer>
                  <BarChart data={topLowStockItems} layout="vertical" margin={{ top: 5, right: 40, left: 10, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke={theme.palette.divider} horizontal={false} />
                    <XAxis type="number" tick={{ fontSize: 10, fill: theme.palette.text.secondary }} axisLine={false} tickLine={false} />
                    <YAxis type="category" dataKey="name" width={90} tick={{ fontSize: 10, fill: theme.palette.text.secondary }} axisLine={false} tickLine={false} />
                    <RechartsTooltip contentStyle={chartTooltipStyle} formatter={(v, n, p) => [`${number3(v)} ${p.payload.uom}`, 'Closing Qty']} />
                    <Bar dataKey="value" fill={theme.palette.error.main} radius={[0, 4, 4, 0]} maxBarSize={16}>
                      <LabelList dataKey="value" position="right" formatter={(v) => number3(v)} style={{ fontSize: 9, fill: theme.palette.text.secondary }} />
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </Box>
              {topLowStockItems.length === 0 && (
                <Typography variant="caption" color="text.secondary" align="center" display="block">No low stock items</Typography>
              )}
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={3}>
          <Card variant="outlined" sx={{ height: '100%' }}>
            <CardContent>
              <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 1 }}>Stock Value by Warehouse (Top 5)</Typography>
              <Box sx={{ width: '100%', height: 240, mt: 1 }}>
                <ResponsiveContainer>
                  <BarChart data={stockValueByWarehouse} layout="vertical" margin={{ top: 5, right: 50, left: 10, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke={theme.palette.divider} horizontal={false} />
                    <XAxis type="number" tick={{ fontSize: 10, fill: theme.palette.text.secondary }} axisLine={false} tickLine={false} tickFormatter={(v) => `₹${v.toLocaleString('en-IN')}`} />
                    <YAxis type="category" dataKey="name" width={90} tick={{ fontSize: 10, fill: theme.palette.text.secondary }} axisLine={false} tickLine={false} />
                    <RechartsTooltip contentStyle={chartTooltipStyle} formatter={(v) => currency(v)} />
                    <Bar dataKey="value" fill={theme.palette.primary.main} radius={[0, 4, 4, 0]} maxBarSize={16}>
                      <LabelList dataKey="value" position="right" formatter={(v) => currency(v)} style={{ fontSize: 9, fill: theme.palette.text.secondary }} />
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </Box>
              {stockValueByWarehouse.length === 0 && (
                <Typography variant="caption" color="text.secondary" align="center" display="block">No warehouse movement data</Typography>
              )}
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}
