import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Box, Typography, Button, Card, CardContent, Stack, Table, TableBody, TableCell,
  TableHead, TableRow, Chip, IconButton, Menu, MenuItem, ListItemIcon, ListItemText, Grid,
  CircularProgress,
} from '@mui/material';
import { useFieldArray } from 'react-hook-form';
import dayjs from 'dayjs';
import AssignmentReturnOutlinedIcon from '@mui/icons-material/AssignmentReturnOutlined';
import AddIcon from '@mui/icons-material/Add';
import CloseIcon from '@mui/icons-material/Close';
import PrintOutlinedIcon from '@mui/icons-material/PrintOutlined';
import UploadFileIcon from '@mui/icons-material/UploadFile';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import EditIcon from '@mui/icons-material/EditOutlined';
import DeleteIcon from '@mui/icons-material/DeleteOutline';
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import Inventory2OutlinedIcon from '@mui/icons-material/Inventory2Outlined';
import AppForm, { FormGrid, FormSubmitButton } from '../../components/form/AppForm';
import FormTextField from '../../components/form/FormTextField';
import FormSelect from '../../components/form/FormSelect';
import FormDatePicker from '../../components/form/FormDatePicker';
import DocumentNoField from '../../components/form/DocumentNoField';
import EntityHeaderCard from '../../components/common/EntityHeaderCard';
import CompanyBadge from '../../components/common/CompanyBadge';
import BatchSerialSelectionDialog from '../../components/common/BatchSerialSelectionDialog';
import { CanAdd, CanEdit, CanDelete } from '../../components/common/PermissionGate';
import EntityListPagination from '../../components/data-display/EntityListPagination';
import MobileRecordCard from '../../components/data-display/MobileRecordCard';
import { useIsMobileListView } from '../../components/data-display/useIsMobileListView';
import { useNotify } from '../../components/feedback/NotificationProvider';
import { useConfirm } from '../../components/feedback/ConfirmationDialog';
import { applyServerErrors } from '../../lib/formErrors';
import { hoverExpandColumnSx, itemColumnBaseWidth } from '../../lib/columnWidth';
import { purchaseReturnSchema, PURCHASE_RETURN_STATUS_OPTIONS } from '../../lib/validation/purchaseSchemas';
import { buildDocument, round2, isInterState } from '../../lib/documentTotals';
import DocumentTotalsPanel from '../../components/form/DocumentTotalsPanel';
import { useGetCompanyDetailsQuery } from '../../features/company/companyDetailsApi';
import { buildTaxPercentOptions } from '../../lib/taxCodeOptions';
import { taxCodeApi, productApi } from '../../features/resources';
import { useWarehouseOptions, warehouseLabel } from '../../lib/useWarehouseOptions';
import { PAYMENT_TERMS_OPTIONS } from '../../lib/validation/partnerSchemas';
import { purchaseReturnApi, goodsReceivedNoteApi, purchaseInvoiceApi, purchaseOrderApi, supplierApi, branchApi } from '../../features/resources';
import useTableFeatures from '../../components/data-display/useTableFeatures';
import TableSearchFilter from '../../components/data-display/TableSearchFilter';
import TableFilterPanel from '../../components/data-display/TableFilterPanel';
import SortableHeaderCell from '../../components/data-display/SortableHeaderCell';
import ScrollableTableContainer from '../../components/data-display/ScrollableTableContainer';
import RouteMapButton from '../../components/common/RouteMapButton';
import RouteMapContextMenu from '../../components/common/RouteMapContextMenu';
import ContentCopyOutlinedIcon from '@mui/icons-material/ContentCopyOutlined';
import CopyFromDocumentDialog from '../../components/common/CopyFromDocumentDialog';

// Columns for the "Find Purchase Receipt" dialog opened by Copy From.
const GRN_COPY_COLUMNS = [
  { field: 'grnNo', headerName: 'Receipt No', nowrap: true },
  { field: 'supplier', headerName: 'Supplier Name' },
  { field: 'receivedDate', headerName: 'Document Date', type: 'date' },
  { field: 'notes', headerName: 'Comments', type: 'optional' },
];

const PAGE_SIZE = 10;

// Same default wording the other purchase documents open with, so a return
// printed alongside them reads consistently.
const DEFAULT_TERMS = [
  '1. Goods once sold will not be taken back.',
  '2. Delivery as per agreed schedule.',
  '3. Payment within the stipulated credit period.',
  '4. Subject to Bangalore jurisdiction.',
].join('\n');

const emptyItem = {
  productCode: '', productName: '', description: '', hsnCode: '', uom: '',
  receivedQuantity: 0, returnQuantity: 1, unitPrice: 0,
  discountPercent: 0, taxPercent: 0,
  // Populated via the "Batches Number - Selection" / "Serial Numbers -
  // Selection" dialog — see BatchSerialSelectionDialog. Empty unless the
  // selected product's Manage Item By is Batch or Serial.
  batchAllocations: [], serialAllocations: [],
};

/**
 * Blocks the return save when a Batch/Serial-tracked line's return quantity
 * isn't fully covered by its selected batches/serials — the client-side half
 * of the same rule the server enforces in assertBatchSerialIssueAllocation
 * (utils/businessRules.js). Mirrors DeliveryChallan.jsx's
 * validateBatchSerialAllocation — a return draws down stock exactly the same
 * way a despatch does.
 */
function validateBatchSerialAllocation(items, productsByCode) {
  for (let i = 0; i < (items || []).length; i++) {
    const item = items[i];
    const trackingMode = productsByCode[item.productCode]?.manageItemBy;
    if (trackingMode !== 'Batch' && trackingMode !== 'Serial') continue;
    const label = item.productCode || `Row ${i + 1}`;
    const qty = Number(item.returnQuantity) || 0;

    if (trackingMode === 'Batch') {
      const allocated = (item.batchAllocations || []).reduce((sum, b) => sum + (Number(b.quantity) || 0), 0);
      if (Math.abs(allocated - qty) > 0.005) {
        return `${label}: select ${qty} from batches via "Batches Number - Selection" — currently ${allocated}.`;
      }
    } else {
      const count = (item.serialAllocations || []).length;
      if (count !== qty) {
        return `${label}: select ${qty} serial number(s) via "Serial Numbers - Selection" — currently ${count}.`;
      }
    }
  }
  return null;
}

// Built fresh per "Add" click rather than held in a module constant, so the
// dates are today's whenever the form opens instead of whenever the JS module
// first loaded — the same reason the other transaction pages do this.
function getEmptyValues() {
  const today = new Date();
  return {
    returnNo: '', status: 'Open', grnNo: '', supplier: '', supplierName: '',
    contactPerson: '', supplierRefNo: '', branch: '', warehouse: '',
    documentDate: today, postingDate: today, dueDate: null,
    paymentTerms: '', billDoNo: '', billDoDate: null, reason: '', comments: '',
    placeOfSupply: '', discountPercent: 0,
    termsConditions: DEFAULT_TERMS, attachmentName: '',
    items: [{ ...emptyItem }],
  };
}

// DocumentTotalsPanel reads `discount` and `grandTotal`, which the shared
// engine does not return — every other purchase document derives them in a
// wrapper exactly like this one. Passing buildDocument's raw totals straight
// to the panel is what made it crash on totals.grandTotal.toFixed().
function computeReturnTotals(items, discountPercent, interState) {
  const { totals } = buildDocument(items, discountPercent, {
    quantityField: 'returnQuantity',
    interState,
    roundOff: true,
  });
  return {
    ...totals,
    discount: round2(totals.subtotal - totals.taxableAmount),
    grandTotal: totals.amount,
  };
}

const money = (v) => (Number(v) || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

function rowToFormValues(row) {
  const toDate = (v) => (v ? new Date(v) : null);
  return {
    ...getEmptyValues(),
    ...row,
    documentDate: toDate(row.documentDate),
    postingDate: toDate(row.postingDate),
    dueDate: toDate(row.dueDate),
    billDoDate: toDate(row.billDoDate),
    items: (row.items?.length ? row.items : [{ ...emptyItem }]).map((i) => ({
      productCode: i.productCode || '',
      productName: i.productName || '',
      description: i.description || '',
      hsnCode: i.hsnCode || '',
      uom: i.uom || '',
      receivedQuantity: Number(i.receivedQuantity) || 0,
      returnQuantity: Number(i.returnQuantity) || 0,
      unitPrice: Number(i.unitPrice) || 0,
      discountPercent: Number(i.discountPercent) || 0,
      taxPercent: Number(i.taxPercent) || 0,
      batchAllocations: (i.batchAllocations || []).map((b) => ({ batchNo: b.batchNo, quantity: Number(b.quantity) || 0 })),
      serialAllocations: (i.serialAllocations || []).map((s) => ({ serialNo: s.serialNo })),
    })),
  };
}

/**
 * Purchase Return — goods going back to a supplier, raised against a GRN.
 *
 * Totals, including the CGST/SGST vs IGST split, are computed by the shared
 * document engine and recomputed identically on the server, so the panel can
 * never disagree with what gets stored. The return posts no stock movement and
 * no payables adjustment: it records the value of what is going back only.
 */
export default function PurchaseReturn({ openDocNo } = {}) {
  const notify = useNotify();
  const confirmDialog = useConfirm();
  const isMobile = useIsMobileListView();

  const { data: rows, isLoading } = purchaseReturnApi.useList();
  const [create, { isLoading: creating }] = purchaseReturnApi.useCreate();
  const [update, { isLoading: updating }] = purchaseReturnApi.useUpdate();
  const [remove] = purchaseReturnApi.useDelete();
  const { data: grns } = goodsReceivedNoteApi.useList();
  // Needed to know which GRNs have already been invoiced — see copyableGrns.
  const { data: invoices } = purchaseInvoiceApi.useList();
  // GRN carries no Contact Person or Payment Terms of its own — those live one
  // level further up, on the Purchase Order it was received against. Needed
  // to pull them in transitively when a GRN is picked (see the poNo pull-in
  // effect below).
  const { data: purchaseOrders } = purchaseOrderApi.useList();
  const { data: suppliers } = supplierApi.useList();
  const { data: branches } = branchApi.useList();
  const { data: taxCodes } = taxCodeApi.useList();
  const { data: products } = productApi.useList();
  const { data: company } = useGetCompanyDetailsQuery();
  const taxPercentOptions = useMemo(() => buildTaxPercentOptions(taxCodes), [taxCodes]);
  // Looked up per row to decide whether the Batch/Serial column applies —
  // Product Master's Manage Item By select is what makes a line ask for it.
  const productsByCode = useMemo(
    () => Object.fromEntries((products || []).map((p) => [p.productCode, p])),
    [products]
  );

  const [view, setView] = useState('list');
  const [editingRow, setEditingRow] = useState(null);
  const [readOnly, setReadOnly] = useState(false);
  const [formKey, setFormKey] = useState(0);
  // Copy From ("Find Purchase Receipt") dialog. Held at page level rather than
  // inside AppForm's render prop so remounting the form on formKey change
  // can't leave a dialog orphaned open over a freshly reset form.
  const [copyFromOpen, setCopyFromOpen] = useState(false);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(PAGE_SIZE);
  const [rowMenuAnchor, setRowMenuAnchor] = useState(null);
  const [rowMenuTarget, setRowMenuTarget] = useState(null);
  // { index, mode } for the item row whose "Batches Number - Selection" /
  // "Serial Numbers - Selection" dialog is open; null when closed.
  const [batchDialog, setBatchDialog] = useState(null);

  const { warehouses } = useWarehouseOptions({ currentValue: editingRow?.warehouse });
  // Which of the two save buttons was pressed. A ref, not state: the click
  // handler has to record it before submit reads it, and setting state there
  // would re-render in the middle of the click.
  const pendingStatusRef = useRef(null);

  // Only GRNs that have NOT been invoiced can be returned against.
  //
  // Once a purchase invoice exists the goods have been billed, and sending
  // them back by return would leave the invoice standing against stock that
  // has gone — a Purchase Credit Memo is the instrument from then on. The
  // backend refuses these outright (assertReturnAllowed in utils/routeMap.js);
  // filtering here means the user never picks an option that will be rejected.
  //
  // A cancelled or draft invoice does not lock the GRN: neither has been
  // issued, so there is nothing yet to credit instead.
  const invoicedGrnNos = useMemo(() => new Set(
    (invoices || [])
      .filter((i) => !['Draft', 'Cancelled'].includes(i.status))
      .map((i) => i.grnNo)
      .filter(Boolean)
  ), [invoices]);

  // Per (grnNo, productCode), how much has already been returned by OTHER
  // purchase returns (i.e. not the one currently being edited). Used to cap
  // what THIS return can still take — two returns against the same GRN line
  // must share its quantity, not each get the full amount.
  const returnedByGrnProductOther = useMemo(() => {
    const totals = new Map();
    (rows || [])
      .filter((r) => r.status !== 'Cancelled' && r.grnNo && r.returnNo !== editingRow?.returnNo)
      .forEach((r) => {
        (r.items || []).forEach((item) => {
          if (!item.productCode) return;
          const key = `${r.grnNo}::${item.productCode}`;
          totals.set(key, (totals.get(key) || 0) + (Number(item.returnQuantity) || 0));
        });
      });
    return totals;
  }, [rows, editingRow]);

  // What the Copy From dialog is allowed to offer — an already-invoiced GRN is
  // excluded for the reason given above (the credit belongs on the invoice, so
  // the backend would reject it anyway).
  //
  // This used to build the options for a GRN dropdown; it is now the record
  // list handed to the dialog. The "the GRN already on the record being edited
  // stays selectable" case the dropdown needed is gone with it — the field is
  // read-only now, so an existing return's own link is simply displayed and
  // never has to survive a filter to keep showing.
  const copyableGrns = useMemo(
    () => (grns || []).filter((g) => !invoicedGrnNos.has(g.grnNo)),
    [grns, invoicedGrnNos]
  );
  const supplierOptions = useMemo(
    () => (suppliers || []).map((s) => ({ label: s.supplierName, value: s.supplierName })),
    [suppliers]
  );
  const branchOptions = useMemo(
    () => (branches || []).map((b) => ({ label: b.branchName, value: b.branchName })),
    [branches]
  );

  const tableColumns = useMemo(() => ([
    { field: 'returnNo', headerName: 'Return No.', filter: 'text' },
    { field: 'grnNo', headerName: 'GRN No.', filter: 'text' },
    { field: 'supplier', headerName: 'Supplier', filter: 'select' },
    {
      field: 'documentDate',
      headerName: 'Document Date',
      filter: 'dateRange',
      sortValue: (r) => (r.documentDate ? new Date(r.documentDate).getTime() : null),
      searchValue: (r) => (r.documentDate ? dayjs(r.documentDate).format('DD MMM YYYY') : ''),
    },
    { field: 'totalItems', headerName: 'Items', filter: 'numberRange' },
    { field: 'amount', headerName: 'Amount', filter: 'numberRange', sortValue: (r) => Number(r.amount) || 0 },
    { field: 'status', headerName: 'Status', filter: 'select' },
  ]), []);

  const table = useTableFeatures(rows || [], tableColumns, { onChange: setPage });
  const visibleRows = table.rows;
  const pagedRows = useMemo(
    () => visibleRows.slice(page * pageSize, page * pageSize + pageSize),
    [visibleRows, page, pageSize]
  );

  const backToList = () => { setView('list'); setEditingRow(null); setReadOnly(false); setCopyFromOpen(false); };

  const openCreate = () => {
    setEditingRow(null); setReadOnly(false); setFormKey((k) => k + 1); setView('form');
  };
  const handleEdit = (row) => {
    setEditingRow(row); setReadOnly(false); setFormKey((k) => k + 1);
    setView('form'); setRowMenuAnchor(null);
  };
  const handleView = (row) => {
    setEditingRow(row); setReadOnly(true); setFormKey((k) => k + 1);
    setView('form'); setRowMenuAnchor(null);
  };

  // Opened from the Route Map's document preview popup: jump straight into
  // this record's own read-only View, exactly as clicking it in the list
  // would, instead of requiring the user to find and click the row.
  useEffect(() => {
    if (!openDocNo) return;
    if (editingRow && editingRow.returnNo === openDocNo) return;
    const match = (rows || []).find((r) => r.returnNo === openDocNo);
    if (match) handleView(match);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [openDocNo, rows]);

  const handleDelete = async (row) => {
    setRowMenuAnchor(null);
    const ok = await confirmDialog({
      title: 'Delete purchase return',
      message: `Are you sure you want to delete "${row.returnNo}"? This cannot be undone.`,
      confirmLabel: 'Delete',
      severity: 'error',
    });
    if (!ok) return;
    try {
      await remove(row.id).unwrap();
      notify.success('Purchase return deleted');
    } catch (err) {
      notify.error(err?.data?.message || 'Delete failed');
    }
  };

  const handleSubmit = async (values, methods) => {
    // A Batch/Serial-tracked line whose return quantity isn't fully covered
    // by its selected batches/serials cannot be saved — see
    // validateBatchSerialAllocation above. The server enforces the same
    // rule so this is a fast local check, not the only line of defence.
    const allocationError = validateBatchSerialAllocation(values.items, productsByCode);
    if (allocationError) {
      notify.error(allocationError);
      return;
    }
    // "Save as Draft" is a shortcut that forces Draft regardless of what the
    // Status field shows. The main Save/Update button does NOT force a
    // status — it used to always set 'Open', silently discarding any other
    // value picked in the Status dropdown (Closed, Cancelled, ...): the
    // record would save, but always as Open, so editing to e.g. Cancelled
    // appeared to "not save" because the list kept showing Open.
    const payload = { ...values, status: pendingStatusRef.current || values.status };
    try {
      if (editingRow) {
        await update({ id: editingRow.id, ...payload }).unwrap();
        notify.success('Purchase return updated');
      } else {
        await create(payload).unwrap();
        notify.success('Purchase return created');
      }
      backToList();
    } catch (err) {
      notify.error(applyServerErrors(err, methods.setError));
    }
  };

  if (openDocNo && (!editingRow || editingRow.returnNo !== openDocNo)) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', py: 10 }}>
        <CircularProgress size={28} />
      </Box>
    );
  }

  return (
    <Box>
      <EntityHeaderCard
        icon={<AssignmentReturnOutlinedIcon />}
        title="Purchase Return"
        subtitle={view === 'form'
          ? 'Return received goods to a supplier against a GRN.'
          : 'Manage goods returned to suppliers.'}
        rightContent={<CompanyBadge />}
      />

      {view === 'form' ? (
        <RouteMapContextMenu flow="purchase" type="return" docNo={editingRow?.returnNo}>
        <AppForm
          key={formKey}
          readOnly={readOnly}
          schema={purchaseReturnSchema}
          defaultValues={editingRow ? rowToFormValues(editingRow) : getEmptyValues()}
          onSubmit={handleSubmit}
        >
          {(methods) => {
            const { control, watch, setValue } = methods;
            const { fields, append, remove: removeItem, replace: replaceItems } = useFieldArray({ control, name: 'items' });
            const watchedItems = watch('items') || [];

            // Product Code / Product Name are sized to the longest value the
            // column actually holds, instead of a fixed width that left almost
            // no room for text once the field's own padding — and, on a select,
            // its clear and dropdown buttons — were subtracted. Short data still
            // sits tight; anything past the cap is revealed on hover as before.
            const productCodeColumnWidth = itemColumnBaseWidth(
              watchedItems.map((i) => i?.productCode), { kind: 'code', field: 'text' },
            );
            const productNameColumnWidth = itemColumnBaseWidth(
              watchedItems.map((i) => i?.productName), { kind: 'name', field: 'text' },
            );
            const grnNo = watch('grnNo');
            const branch = watch('branch');

            // Once Branch is picked (directly, or via Copy From), the
            // Warehouse dropdown is scoped to that branch's warehouses only —
            // see useWarehouseOptions.js.
            const { options: branchWarehouseOptions } = useWarehouseOptions({ currentValue: editingRow?.warehouse, branch });

            // Copy From pulls the supplier block across and replaces the lines
            // with what that GRN received.
            //
            // This used to run as an effect watching the GRN No. dropdown,
            // guarded by a ref so it fired only on a real change. It is a plain
            // function now, called only from the dialog's Choose button: an
            // effect keyed on a form value also fires when that value is
            // restored on edit or reset, which is what the ref bookkeeping
            // existed to detect. An explicit call has no such ambiguity.
            //
            // Supplier is still set from the GRN, unlike the sibling purchase
            // pages: this form keeps supplierName and contactPerson alongside
            // it, so the pull has real work to do here, and the value it writes
            // is the supplier the dialog was already filtered by.
            const applyGrn = (grn) => {
              if (!grn) return;
              setValue('grnNo', grn.grnNo || '', { shouldValidate: true });
              setValue('supplier', grn.supplier || '');
              setValue('supplierName', grn.supplier || '');
              setValue('branch', grn.branch || '');
              setValue('termsConditions', grn.termsConditions || '');
              // Contact Person and Payment Terms live one level further up —
              // the GRN itself doesn't carry them, but the Purchase Order it
              // was received against does. Reached transitively via the
              // GRN's own poNo.
              const sourcePo = (purchaseOrders || []).find((p) => p.poNo === grn.poNo);
              if (sourcePo) {
                setValue('contactPerson', sourcePo.contactPerson || '');
                setValue('paymentTerms', sourcePo.paymentTerms || '');
              }
              // replace(), never setValue('items', ...) — the field array has to
              // remount so each row's inputs pick up the new values.
              //
              // receivedQuantity on each line is NOT the raw GRN quantity — it is
              // what is still left to return after every OTHER purchase return
              // against this GRN is subtracted (returnedByGrnProductOther, below).
              // Two separate returns against the same 10-unit GRN line must not
              // each be allowed up to 10; the second one only has what the first
              // didn't take. A line with nothing left is dropped rather than
              // pulled in at zero, matching the same rule used in Purchase
              // Invoice's GRN pull-in.
              // `line` is captured BEFORE the filter: base_line names the
              // row's position on the GRN, not in the filtered subset.
              const remaining = (grn.items || [])
                .map((i, n) => {
                  const received = Number(i.receivedQuantity) || 0;
                  const alreadyReturned = returnedByGrnProductOther.get(`${grn.grnNo}::${i.productCode}`) || 0;
                  return { item: i, line: n + 1, qty: round2(received - alreadyReturned) };
                })
                .filter(({ qty }) => qty > 0.005);
              replaceItems(
                remaining.length
                  ? remaining.map(({ item: i, line, qty }) => ({
                    productCode: i.productCode || '',
                    productName: i.productName || '',
                    description: i.description || '',
                    hsnCode: i.hsnCode || '',
                    uom: i.uom || '',
                    receivedQuantity: qty,
                    returnQuantity: qty,
                    unitPrice: Number(i.unitPrice) || 0,
                    discountPercent: Number(i.discountPercent) || 0,
                    taxPercent: Number(i.taxPercent) || 0,
                    // Copy From: a return is raised against the GRN.
                    baseType: 'Purchase GRN',
                    baseEntry: grn.id ?? null,
                    baseNo: grn.grnNo || null,
                    baseLine: line,
                  }))
                  : [{ ...emptyItem }]
              );
            };

            // Undo a Copy From: drop the link and the lines that came across
            // with it, rather than leaving a stale receipt's figures sitting in
            // a return that no longer claims to reference it.
            //
            // Supplier is deliberately NOT cleared. It is the user's own
            // selection — it is what made Copy From available in the first
            // place, and clearing it would close the dialog off and force a
            // re-pick just to try a different receipt from the same vendor.
            const clearGrn = () => {
              setValue('grnNo', '', { shouldValidate: true });
              setValue('contactPerson', '');
              setValue('paymentTerms', '');
              setValue('termsConditions', '');
              replaceItems([{ ...emptyItem }]);
            };

            // Switching Branch invalidates a Warehouse choice that doesn't
            // belong to the new branch. Skipped on the very first render so
            // loading an existing record for edit/view, or a Copy From that
            // sets branch and leaves warehouse untouched, doesn't wipe a value
            // it just loaded.
            const prevBranchRef = useRef(branch);
            useEffect(() => {
              if (prevBranchRef.current === branch) return;
              prevBranchRef.current = branch;
              const allowed = new Set(
                (warehouses || []).filter((w) => !branch || w.branch === branch).map((w) => w.whsCode)
              );
              if (watch('warehouse') && !allowed.has(watch('warehouse'))) setValue('warehouse', '');
              // eslint-disable-next-line react-hooks/exhaustive-deps
            }, [branch]);

            // Totals come from the shared document engine, given the same
            // inputs the server uses, so what the panel shows is what gets
            // saved. interState must be passed through explicitly — defaulting
            // it would show a CGST/SGST split on a document stored as IGST.
            const handleFile = (file) => {
              if (file) setValue('attachmentName', file.name, { shouldValidate: true });
            };

            const interState = isInterState(watch('placeOfSupply'), company?.state);
            const totals = computeReturnTotals(watchedItems, watch('discountPercent'), interState);

            return (
              <>
                <CopyFromDocumentDialog
                  open={copyFromOpen}
                  onClose={() => setCopyFromOpen(false)}
                  onChoose={applyGrn}
                  documents={copyableGrns}
                  party={watch('supplier')}
                  title="Find Purchase Receipt"
                  columns={GRN_COPY_COLUMNS}
                  emptyMessage="No uninvoiced goods receipts found for"
                />
                <Card variant="outlined" sx={{ mb: 2 }}>
                  <CardContent>
                    <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 2 }}>
                      {readOnly ? 'View Purchase Return' : editingRow ? 'Edit Purchase Return' : 'Add Purchase Return'}
                    </Typography>

                    <FormGrid columns={3}>
                      <DocumentNoField documentCode="PRT" name="returnNo" label="Return No. *" isCreate={!editingRow} />
                      <FormSelect
                        name="status"
                        label="Status *"
                        options={PURCHASE_RETURN_STATUS_OPTIONS.map((v) => ({ label: v, value: v }))}
                      />
                      {/* Filled only by Copy From — never typed. A return's
                          GRN reference has to be a receipt that actually
                          exists (the lines carry baseEntry/baseNo back to it,
                          and the remaining-quantity cap is computed from it),
                          so a free-text box could only ever produce a dangling
                          link. Left blank for a return with no receipt behind
                          it, which is now a valid return rather than a schema
                          error. */}
                      <FormTextField
                        name="grnNo"
                        label="GRN No."
                        placeholder="Use Copy From to select a GRN"
                        InputProps={{ readOnly: true }}
                      />

                      <FormSelect name="supplier" label="Supplier *" placeholder="Select supplier" options={supplierOptions} />
                      <FormTextField name="supplierName" label="Name" placeholder="Supplier name" />
                      <FormTextField name="contactPerson" label="Contact Person" placeholder="Enter contact person" />

                      <FormTextField name="supplierRefNo" label="Supplier Ref No." placeholder="Enter supplier ref no." />
                      <FormSelect name="branch" label="Branch *" placeholder="Select branch" options={branchOptions} />
                      <FormSelect
                        name="paymentTerms"
                        label="Payment Terms"
                        placeholder="Select payment terms"
                        options={PAYMENT_TERMS_OPTIONS}
                      />
                      {/* Where the goods physically leave from — see the
                          schema.prisma comment on PurchaseReturn.warehouse.
                          Scoped to the selected branch — see useWarehouseOptions.js. */}
                      <FormSelect
                        name="warehouse"
                        label="Warehouse *"
                        placeholder={branch ? 'Select warehouse' : 'Select a branch first'}
                        options={branchWarehouseOptions}
                        disabled={!branch}
                      />

                      <FormDatePicker name="documentDate" label="Document Date *" />
                      <FormDatePicker name="postingDate" label="Posting Date" />
                      <FormDatePicker name="dueDate" label="Due Date" />

                      <FormTextField name="billDoNo" label="Bill/DO No." placeholder="Enter bill/DO no." />
                      <FormDatePicker name="billDoDate" label="Bill/DO Date" />
                      <FormTextField name="reason" label="Reason" placeholder="Reason for return" />

                      <FormTextField name="comments" label="Comments" placeholder="Enter comments" />
                    </FormGrid>
                  </CardContent>
                </Card>

                <Card variant="outlined" sx={{ mb: 2 }}>
                  <CardContent>
                    <Stack direction="row" alignItems="center" justifyContent="space-between" sx={{ mb: 1.5 }}>
                      <Typography variant="subtitle1" fontWeight={700}>Items</Typography>
                      {!readOnly && (
                        <Button size="small" startIcon={<AddIcon />} onClick={() => append({ ...emptyItem })}>
                          Add Row
                        </Button>
                      )}
                    </Stack>

                    <ScrollableTableContainer>
                      <Table size="small">
                        <TableHead>
                          <TableRow>
                            <TableCell width={48}>#</TableCell>
                            <TableCell sx={{ minWidth: productCodeColumnWidth }}>Product Code</TableCell>
                            <TableCell sx={{ minWidth: productNameColumnWidth }}>Product Name</TableCell>
                            <TableCell>UOM</TableCell>
                            <TableCell align="right">Received Qty</TableCell>
                            <TableCell align="right">Return Qty</TableCell>
                            <TableCell align="right">Unit Price</TableCell>
                            <TableCell align="right">Disc %</TableCell>
                            <TableCell align="right">Tax %</TableCell>
                            <TableCell>Batch/Serial Selection</TableCell>
                            <TableCell align="right">Amount</TableCell>
                            {!readOnly && <TableCell align="right">Action</TableCell>}
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {fields.map((field, index) => {
                            const qty = Number(watch(`items.${index}.returnQuantity`)) || 0;
                            const price = Number(watch(`items.${index}.unitPrice`)) || 0;
                            const disc = Number(watch(`items.${index}.discountPercent`)) || 0;
                            const lineAmount = qty * price * (1 - disc / 100);
                            return (
                              <TableRow key={field.id}>
                                <TableCell>{index + 1}</TableCell>
                                <TableCell
                                  sx={hoverExpandColumnSx({
                                    base: productCodeColumnWidth,
                                    value: watch(`items.${index}.productCode`),
                                    max: 420,
                                    field: 'text',
                                  })}
                                >
                                  <FormTextField name={`items.${index}.productCode`} label="" placeholder="Product code" multiline />
                                </TableCell>
                                <TableCell
                                  sx={hoverExpandColumnSx({
                                    base: productNameColumnWidth,
                                    value: watch(`items.${index}.productName`),
                                    max: 640,
                                    field: 'text',
                                  })}
                                >
                                  <FormTextField name={`items.${index}.productName`} label="" placeholder="Product name" multiline />
                                </TableCell>
                                <TableCell sx={{ minWidth: 100 }}>
                                  <FormTextField name={`items.${index}.uom`} label="" placeholder="UOM" />
                                </TableCell>
                                <TableCell sx={{ minWidth: 120 }}>
                                  <FormTextField name={`items.${index}.receivedQuantity`} label="" type="number" disabled />
                                </TableCell>
                                <TableCell sx={{ minWidth: 120 }}>
                                  <FormTextField name={`items.${index}.returnQuantity`} label="" type="number" />
                                </TableCell>
                                <TableCell sx={{ minWidth: 130 }}>
                                  <FormTextField name={`items.${index}.unitPrice`} label="" type="number" />
                                </TableCell>
                                <TableCell sx={{ minWidth: 100 }}>
                                  <FormTextField name={`items.${index}.discountPercent`} label="" type="number" />
                                </TableCell>
                                <TableCell sx={{ minWidth: 110 }}>
                                  <FormSelect name={`items.${index}.taxPercent`} label="" options={taxPercentOptions} />
                                </TableCell>
                                <TableCell sx={{ minWidth: 140 }}>
                                  <BatchSerialCell index={index} methods={methods} product={productsByCode[watch(`items.${index}.productCode`)]} quantityField="returnQuantity" onOpen={(mode) => setBatchDialog({ index, mode })} />
                                </TableCell>
                                <TableCell align="right" sx={{ whiteSpace: 'nowrap' }}>
                                  {money(lineAmount)}
                                </TableCell>
                                {!readOnly && (
                                  <TableCell align="right">
                                    <IconButton
                                      size="small"
                                      color="error"
                                      aria-label="remove row"
                                      disabled={fields.length === 1}
                                      onClick={() => removeItem(index)}
                                    >
                                      <DeleteIcon fontSize="small" />
                                    </IconButton>
                                  </TableCell>
                                )}
                              </TableRow>
                            );
                          })}
                        </TableBody>
                      </Table>
                    </ScrollableTableContainer>

                  </CardContent>
                </Card>

                {batchDialog && batchDialog.index < fields.length && (
                  <BatchSerialSelectionDialog
                    open
                    onClose={() => setBatchDialog(null)}
                    mode={batchDialog.mode}
                    readOnly={readOnly}
                    docNo={editingRow?.returnNo}
                    itemNumber={watch(`items.${batchDialog.index}.productCode`)}
                    itemDescription={watch(`items.${batchDialog.index}.productName`)}
                    warehouseCode={watch('warehouse')}
                    warehouseName={warehouseLabel((warehouses || []).find((w) => w.whsCode === watch('warehouse')))}
                    totalNeeded={Number(watch(`items.${batchDialog.index}.returnQuantity`)) || 0}
                    productCode={watch(`items.${batchDialog.index}.productCode`)}
                    value={watch(`items.${batchDialog.index}.${batchDialog.mode === 'Batch' ? 'batchAllocations' : 'serialAllocations'}`)}
                    onSave={(rows) => setValue(
                      `items.${batchDialog.index}.${batchDialog.mode === 'Batch' ? 'batchAllocations' : 'serialAllocations'}`,
                      rows,
                      { shouldValidate: true }
                    )}
                  />
                )}

                {/* Terms, attachments and the money panel — the same footer the
                    other purchase documents carry, so a return reads and prints
                    consistently beside them. */}
                <Card variant="outlined" sx={{ mb: 2 }}>
                  <CardContent sx={{ p: { xs: 2, sm: 3 } }}>
                    <Grid container spacing={3}>
                      <Grid item xs={12} md={4}>
                        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1 }}>Terms &amp; Conditions</Typography>
                        <FormTextField name="termsConditions" label="" placeholder="Enter terms and conditions" multiline rows={6} />
                      </Grid>

                      <Grid item xs={12} md={4}>
                        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1 }}>Attachments</Typography>
                        <Box
                          onDragOver={(e) => e.preventDefault()}
                          onDrop={(e) => { e.preventDefault(); handleFile(e.dataTransfer.files?.[0]); }}
                          sx={{
                            border: '1px dashed', borderColor: 'divider', borderRadius: 1.5,
                            p: 3, textAlign: 'center', color: 'text.secondary',
                          }}
                        >
                          <UploadFileIcon sx={{ mb: 1 }} />
                          <Typography variant="body2" sx={{ mb: 1 }}>Drag and drop files here</Typography>
                          <Typography variant="body2" sx={{ mb: 1 }}>or</Typography>
                          <Button component="label" variant="outlined" size="small" disabled={readOnly}>
                            Browse Files
                            <input type="file" hidden onChange={(e) => handleFile(e.target.files?.[0])} />
                          </Button>
                          <Typography variant="caption" display="block" sx={{ mt: 1 }}>
                            Supported formats: PDF, JPG, PNG (Max. 5MB)
                          </Typography>
                          {watch('attachmentName') && (
                            <Chip
                              sx={{ mt: 1.5 }}
                              size="small"
                              label={watch('attachmentName')}
                              onDelete={readOnly ? undefined : () => setValue('attachmentName', '')}
                            />
                          )}
                        </Box>
                      </Grid>

                      <Grid item xs={12} md={4}>
                        <DocumentTotalsPanel totals={totals} interState={interState} subtotalLabel="Subtotal" showRoundOff={false} />
                      </Grid>
                    </Grid>

                    <Stack
                      direction={{ xs: 'column', sm: 'row' }}
                      spacing={1.5}
                      justifyContent={{ xs: 'stretch', sm: 'flex-end' }}
                      sx={{ mt: 3 }}
                    >
                      {/* Copy From sits immediately left of Cancel and stays
                          disabled until a Supplier is chosen — the dialog it
                          opens lists that supplier's goods receipts, so with no
                          supplier there is nothing for it to show. Hidden in
                          view mode, where nothing is being filled in. */}
                      {!readOnly && (
                        grnNo ? (
                          <Button
                            fullWidth={isMobile}
                            type="button"
                            variant="outlined"
                            color="inherit"
                            startIcon={<CloseIcon />}
                            onClick={clearGrn}
                            disabled={creating || updating}
                          >
                            Clear Copied GRN
                          </Button>
                        ) : (
                          <Button
                            fullWidth={isMobile}
                            type="button"
                            variant="outlined"
                            startIcon={<ContentCopyOutlinedIcon />}
                            onClick={() => setCopyFromOpen(true)}
                            disabled={!watch('supplier') || creating || updating}
                          >
                            Copy From
                          </Button>
                        )
                      )}
                      <Button fullWidth={isMobile} type="button" variant="outlined" color={readOnly ? 'error' : 'inherit'} startIcon={<CloseIcon />} onClick={backToList} disabled={creating || updating}>
                        {readOnly ? 'Close' : 'Cancel'}
                      </Button>
                      <Button fullWidth={isMobile} type="button" variant="outlined" startIcon={<PrintOutlinedIcon />} onClick={() => window.print()}>
                        Print
                      </Button>
                      {/* pendingStatusRef, not setValue: the click has to record
                          which button was pressed before submit reads it, and a
                          setValue here would re-render mid-click. */}
                      <FormSubmitButton
                        fullWidth={isMobile}
                        variant="outlined"
                        onClick={() => { pendingStatusRef.current = 'Draft'; }}
                        disabled={creating || updating}
                      >
                        Save as Draft
                      </FormSubmitButton>
                      <FormSubmitButton
                        fullWidth={isMobile}
                        onClick={() => { pendingStatusRef.current = null; }}
                        disabled={creating || updating}
                      >
                        {editingRow ? 'Update Purchase Return' : 'Save Purchase Return'}
                      </FormSubmitButton>
                    </Stack>
                  </CardContent>
                </Card>

              </>
            );
          }}
        </AppForm>
        </RouteMapContextMenu>
      ) : (
        <Card variant="outlined">
          <CardContent sx={{ p: 0 }}>
            <Stack direction="row" alignItems="center" justifyContent="space-between" flexWrap="wrap" gap={1.5} sx={{ px: 3, pt: 2.5, pb: 1.5 }}>
              <Typography variant="subtitle1" fontWeight={700}>Purchase Return List</Typography>
              <Stack direction="row" spacing={1.5} flexWrap="wrap" useFlexGap alignItems="center">
                <TableSearchFilter table={table} placeholder="Search by return no., GRN, supplier..." />
                <CanAdd>
                  <Button variant="contained" startIcon={<AddIcon />} onClick={openCreate} sx={{ whiteSpace: 'nowrap' }}>
                    Add Return
                  </Button>
                </CanAdd>
              </Stack>
            </Stack>

            <TableFilterPanel table={table} />

            {isMobile ? (
              <Box sx={{ px: 2, pb: 1 }}>
                {!isLoading && pagedRows.map((row) => (
                  <MobileRecordCard
                    key={row.id}
                    title={row.returnNo}
                    statusChip={<Chip size="small" label={row.status} variant="outlined" />}
                    fields={[
                      { label: 'GRN No.', value: row.grnNo },
                      { label: 'Supplier', value: row.supplier },
                      { label: 'Amount', value: money(row.amount) },
                    ]}
                    onView={() => handleView(row)}
                    onEdit={() => handleEdit(row)}
                    onDelete={() => handleDelete(row)}
                  />
                ))}
                {!isLoading && visibleRows.length === 0 && (
                  <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>
                    {table.isFiltering ? 'No returns match your search' : 'No purchase returns yet'}
                  </Typography>
                )}
              </Box>
            ) : (
              <ScrollableTableContainer>
                <Table size="small" stickyHeader>
                  <TableHead>
                    <TableRow>
                      <TableCell width={48}>#</TableCell>
                      <SortableHeaderCell field="returnNo" sort={table.sort} onSort={table.toggleSort}>Return No.</SortableHeaderCell>
                      <SortableHeaderCell field="grnNo" sort={table.sort} onSort={table.toggleSort}>GRN No.</SortableHeaderCell>
                      <SortableHeaderCell field="supplier" sort={table.sort} onSort={table.toggleSort}>Supplier</SortableHeaderCell>
                      <SortableHeaderCell field="documentDate" sort={table.sort} onSort={table.toggleSort}>Document Date</SortableHeaderCell>
                      <SortableHeaderCell field="totalItems" sort={table.sort} onSort={table.toggleSort}>Items</SortableHeaderCell>
                      <SortableHeaderCell field="amount" sort={table.sort} onSort={table.toggleSort}>Amount</SortableHeaderCell>
                      <SortableHeaderCell field="status" sort={table.sort} onSort={table.toggleSort}>Status</SortableHeaderCell>
                      <TableCell align="right">Action</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {!isLoading && pagedRows.map((row, i) => (
                      <TableRow key={row.id} hover>
                        <TableCell>{page * pageSize + i + 1}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.returnNo}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.grnNo || '—'}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.supplier || '—'}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>
                          {row.documentDate ? dayjs(row.documentDate).format('DD MMM YYYY') : '—'}
                        </TableCell>
                        <TableCell>{row.totalItems}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{money(row.amount)}</TableCell>
                        <TableCell>
                          <Chip size="small" label={row.status} variant="outlined" />
                        </TableCell>
                        <TableCell align="right">
                          <IconButton size="small" onClick={() => handleView(row)} aria-label="view">
                            <VisibilityOutlinedIcon fontSize="small" />
                          </IconButton>
                          <RouteMapButton flow="purchase" type="return" docNo={row.returnNo} />
                          <IconButton
                            size="small"
                            aria-label="more actions"
                            onClick={(e) => { setRowMenuAnchor(e.currentTarget); setRowMenuTarget(row); }}
                          >
                            <MoreVertIcon fontSize="small" />
                          </IconButton>
                        </TableCell>
                      </TableRow>
                    ))}
                    {!isLoading && visibleRows.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={9}>
                          <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>
                            {table.isFiltering ? 'No returns match your search' : 'No purchase returns yet'}
                          </Typography>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </ScrollableTableContainer>
            )}

            <Menu anchorEl={rowMenuAnchor} open={!!rowMenuAnchor} onClose={() => setRowMenuAnchor(null)}>
              <CanEdit>
                <MenuItem onClick={() => handleEdit(rowMenuTarget)}>
                  <ListItemIcon><EditIcon fontSize="small" /></ListItemIcon>
                  <ListItemText>Edit</ListItemText>
                </MenuItem>
              </CanEdit>
              <CanDelete>
                <MenuItem onClick={() => handleDelete(rowMenuTarget)}>
                  <ListItemIcon><DeleteIcon fontSize="small" color="error" /></ListItemIcon>
                  <ListItemText>Delete</ListItemText>
                </MenuItem>
              </CanDelete>
            </Menu>

            <EntityListPagination
              total={visibleRows.length}
              page={page}
              onChange={setPage}
              pageSize={pageSize}
              onPageSizeChange={(v) => { setPageSize(v); setPage(0); }}
            />
          </CardContent>
        </Card>
      )}
    </Box>
  );
}

// Shows nothing for a None-tracked (or unrecognised) product — the column
// only means something once Product Master's Manage Item By is Batch or
// Serial for the row's selected product. Otherwise a button that opens the
// matching "... - Selection" dialog, labelled with how much of the line is
// selected so far. Mirrors DeliveryChallan.jsx's BatchSerialCell.
function BatchSerialCell({ index, methods, product, quantityField = 'quantity', onOpen }) {
  const { watch } = methods;
  const trackingMode = product?.manageItemBy;
  if (trackingMode !== 'Batch' && trackingMode !== 'Serial') {
    return <Typography variant="caption" color="text.secondary">—</Typography>;
  }
  const needed = Number(watch(`items.${index}.${quantityField}`)) || 0;
  const batchAllocations = watch(`items.${index}.batchAllocations`) || [];
  const serialAllocations = watch(`items.${index}.serialAllocations`) || [];
  const selected = trackingMode === 'Batch'
    ? batchAllocations.reduce((sum, b) => sum + (Number(b.quantity) || 0), 0)
    : serialAllocations.length;
  const complete = needed > 0 && Math.abs(selected - needed) < 0.005;

  return (
    <Button
      type="button"
      size="small"
      variant="outlined"
      color={complete ? 'success' : 'warning'}
      startIcon={<Inventory2OutlinedIcon fontSize="small" />}
      onClick={() => onOpen(trackingMode)}
      sx={{ whiteSpace: 'nowrap' }}
    >
      {trackingMode}: {selected}/{needed}
    </Button>
  );
}
