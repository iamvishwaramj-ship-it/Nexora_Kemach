import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Box, Typography, Button, Card, CardContent, Stack, TextField, InputAdornment, Table,
  TableBody, TableCell, TableContainer, TableHead, TableRow, Chip, IconButton, Menu, MenuItem,
  ListItemIcon, ListItemText, Checkbox, Autocomplete, Popover, Grid, Tooltip,
  Collapse, CircularProgress,
} from '@mui/material';
import { useFieldArray } from 'react-hook-form';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import dayjs from 'dayjs';
import ReceiptOutlinedIcon from '@mui/icons-material/ReceiptOutlined';
import AddIcon from '@mui/icons-material/Add';
import CloseIcon from '@mui/icons-material/Close';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import SearchIcon from '@mui/icons-material/Search';
import FilterListIcon from '@mui/icons-material/FilterList';
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import PrintOutlinedIcon from '@mui/icons-material/PrintOutlined';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import EditIcon from '@mui/icons-material/EditOutlined';
import DeleteIcon from '@mui/icons-material/DeleteOutline';
import EventIcon from '@mui/icons-material/Event';
import UploadFileIcon from '@mui/icons-material/UploadFile';
import AppForm, { FormGrid, FormSubmitButton } from '../../components/form/AppForm';
import FormTextField from '../../components/form/FormTextField';
import FormSelect from '../../components/form/FormSelect';
import FormDatePicker from '../../components/form/FormDatePicker';
import EntityHeaderCard from '../../components/common/EntityHeaderCard';
import CompanyBadge from '../../components/common/CompanyBadge';
import EntityListPagination from '../../components/data-display/EntityListPagination';
import FilterAutocomplete from '../../components/data-display/FilterAutocomplete';
import MobileRecordCard from '../../components/data-display/MobileRecordCard';
import MobileItemCard from '../../components/data-display/MobileItemCard';
import { useIsMobileListView } from '../../components/data-display/useIsMobileListView';
import useDragScroll from '../../components/data-display/useDragScroll';
import { useNotify } from '../../components/feedback/NotificationProvider';
import { applyServerErrors } from '../../lib/formErrors';
import { useConfirm } from '../../components/feedback/ConfirmationDialog';
import { purchaseInvoiceSchema, INVOICE_STATUS_OPTIONS, PAYMENT_STATUS_OPTIONS } from '../../lib/validation/purchaseSchemas';
import { buildDocument, round2, isInterState } from '../../lib/documentTotals';
import DocumentTotalsPanel from '../../components/form/DocumentTotalsPanel';
import { CURRENCY_OPTIONS, SUPPLIER_PAYMENT_TERMS_OPTIONS } from '../../lib/validation/partnerSchemas';
import { getStateOptions } from '../../lib/constants/locations';
import { purchaseInvoiceApi, goodsReceivedNoteApi, purchaseReturnApi, purchaseOrderApi, supplierApi, productApi, branchApi, taxCodeApi } from '../../features/resources';
import { productOptionsFor, PRODUCT_USAGE } from '../../lib/productUsage';
import { buildTaxPercentOptions } from '../../lib/taxCodeOptions';
import { hoverExpandColumnSx, itemColumnBaseWidth } from '../../lib/columnWidth';
import { useWarehouseOptions } from '../../lib/useWarehouseOptions';
import { useGetCompanyDetailsQuery } from '../../features/company/companyDetailsApi';
import DocumentNoField from '../../components/form/DocumentNoField';
import PurchaseInvoicePrintable from '../../components/print/PurchaseInvoicePrintable';
import useTableFeatures from '../../components/data-display/useTableFeatures';
import TableSearchFilter from '../../components/data-display/TableSearchFilter';
import SortableHeaderCell from '../../components/data-display/SortableHeaderCell';
import ScrollableTableContainer, { dragScrollbarSx } from '../../components/data-display/ScrollableTableContainer';

import { CanAdd, CanEdit, CanDelete } from '../../components/common/PermissionGate';
import TableFilterPanel from '../../components/data-display/TableFilterPanel';
import RouteMapButton from '../../components/common/RouteMapButton';
import RouteMapContextMenu from '../../components/common/RouteMapContextMenu';
import ContentCopyOutlinedIcon from '@mui/icons-material/ContentCopyOutlined';
import CopyFromDocumentDialog from '../../components/common/CopyFromDocumentDialog';

// A purchase invoice can be raised off either step of the chain above it: the
// Purchase Order (billed before or without a receipt) or the GRN (billed
// against what actually arrived). Copy From therefore asks which one first,
// then opens the matching Find dialog. Each source gets its own columns
// because each document names things differently.
const PO_COPY_COLUMNS = [
  { field: 'poNo', headerName: 'Order No', nowrap: true },
  { field: 'supplier', headerName: 'Vendor Name' },
  { field: 'poDate', headerName: 'Order Date', type: 'date' },
  { field: 'remarks', headerName: 'Comments', type: 'optional' },
];

const GRN_COPY_COLUMNS = [
  { field: 'grnNo', headerName: 'Receipt No', nowrap: true },
  { field: 'supplier', headerName: 'Supplier Name' },
  { field: 'receivedDate', headerName: 'Document Date', type: 'date' },
  { field: 'notes', headerName: 'Comments', type: 'optional' },
];
const PLACE_OF_SUPPLY_OPTIONS = getStateOptions('India');

const emptyItem = { productCode: '', productName: '', description: '', hsnCode: '', uom: '', quantity: 1, unitPrice: 0, discountPercent: 0, taxPercent: 18 };

const DEFAULT_TERMS = [
  '1. Goods once sold will not be taken back.',
  '2. Payment within the stipulated credit period.',
  '3. All disputes are subject to Bangalore jurisdiction.',
].join('\n');

function getEmptyValues() {
  return {
    invoiceNo: '', branch: '', supplier: '', invoiceDate: new Date(), grnNo: '', poNo: '',
    warehouse: '',
    currency: 'INR', paymentTerms: '', dueDate: null,
    placeOfSupply: '', billFrom: '', shipTo: '', notes: '',
    termsConditions: DEFAULT_TERMS, attachmentName: '', discountPercent: 0,
    status: 'Draft', paymentStatus: 'Unpaid',
    items: [{ ...emptyItem }],
  };
}

// Totals come from the shared engine in lib/documentTotals.js, which the
// backend mirrors exactly — the figures shown here while editing are the
// figures that get saved. Each page used to carry its own copy of this
// arithmetic and the copies had drifted apart; this document in particular
// used to hard-code CGST and SGST at 9% each regardless of what the goods
// actually attract.
//
// `grandTotal` and `discount` are kept in the returned shape because the
// totals panel below reads those names.
// `interState` must be passed through rather than defaulted: the server
// decides CGST/SGST vs IGST by comparing this document's Place of Supply
// against the company's registered state, and for a long time no page passed
// the flag at all — so an inter-state document displayed a CGST/SGST split
// while the record it saved held IGST.
//
function computeTotals(items, discountPercent, interState = false) {
  const { totals } = buildDocument(items, discountPercent, {
    interState,
    roundOff: true,
  });
  return {
    ...totals,
    discount: round2(totals.subtotal - totals.taxableAmount),
    grandTotal: totals.amount,
  };
}

function rowToFormValues(row) {
  return {
    invoiceNo: row.invoiceNo, branch: row.branch || '', supplier: row.supplier || '', invoiceDate: row.invoiceDate,
    grnNo: row.grnNo || '', poNo: row.poNo || '',
    warehouse: row.warehouse || '',
    currency: row.currency || 'INR', paymentTerms: row.paymentTerms || '', dueDate: row.dueDate,
    placeOfSupply: row.placeOfSupply || '', billFrom: row.billFrom || '', shipTo: row.shipTo || '',
    notes: row.notes || '', termsConditions: row.termsConditions || '', attachmentName: row.attachmentName || '',
    discountPercent: row.discountPercent != null ? Number(row.discountPercent) : 0,
    status: row.status || 'Draft', paymentStatus: row.paymentStatus || 'Unpaid',
    items: (row.items && row.items.length ? row.items : [{ ...emptyItem }]).map((i) => ({
      productCode: i.productCode || '', productName: i.productName || '', description: i.description || '',
      hsnCode: i.hsnCode || '', uom: i.uom || '',
      quantity: i.quantity != null ? Number(i.quantity) : 1,
      unitPrice: i.unitPrice != null ? Number(i.unitPrice) : 0,
      discountPercent: i.discountPercent != null ? Number(i.discountPercent) : 0,
      taxPercent: i.taxPercent != null ? Number(i.taxPercent) : 18,
    })),
  };
}

function formatAddress(entity) {
  if (!entity) return '';
  const line1 = entity.billingAddress || entity.address || '';
  const parts = [line1, entity.city, entity.state, entity.pincode, entity.country].filter(Boolean);
  return parts.join(', ');
}

const PAGE_SIZE = 10;
const STATUS_FILTERS = ['All Status', ...INVOICE_STATUS_OPTIONS];
const PAYMENT_STATUS_FILTERS = ['All', ...PAYMENT_STATUS_OPTIONS];

const STATUS_COLORS = { Draft: 'info', Posted: 'success', Cancelled: 'error' };
const PAYMENT_STATUS_COLORS = { Unpaid: 'error', 'Partially Paid': 'warning', Paid: 'success' };

export default function PurchaseInvoice({ openDocNo } = {}) {
  const notify = useNotify();
  const confirmDialog = useConfirm();
  const isMobile = useIsMobileListView();
  const itemScrollRef = useDragScroll();
  const { data: invoices, isLoading } = purchaseInvoiceApi.useList();
  const { data: grns } = goodsReceivedNoteApi.useList();
  // Needed to know which GRNs have already had a Purchase Return raised
  // against them — see copyableGrns below.
  const { data: purchaseReturns } = purchaseReturnApi.useList();
  const { data: purchaseOrders } = purchaseOrderApi.useList();
  const { data: suppliers } = supplierApi.useList();
  const { data: products } = productApi.useList();
  const { data: branches } = branchApi.useList();
  // Warehouse master, for validating a warehouse still belongs to the branch
  // when the branch changes — see the effect in the form body.
  const { warehouses } = useWarehouseOptions();
  const { data: taxCodes } = taxCodeApi.useList();
  const taxPercentOptions = useMemo(() => buildTaxPercentOptions(taxCodes), [taxCodes]);
  const { data: company } = useGetCompanyDetailsQuery();
  const [create, { isLoading: creating }] = purchaseInvoiceApi.useCreate();
  const [update, { isLoading: updating }] = purchaseInvoiceApi.useUpdate();
  const [remove] = purchaseInvoiceApi.useDelete();

  const supplierOptions = (suppliers || []).map((s) => ({ label: s.supplierName, value: s.supplierName }));
  const branchOptions = (branches || []).map((b) => ({ label: b.branchName, value: b.branchName }));
  // Purchase orders and GRNs are no longer offered as dropdowns on the form —
  // they are picked through the Copy From dialogs, which scope their lists to
  // the selected supplier. Those dialogs take the raw record lists.
  const companyShipTo = useMemo(() => {
    if (!company) return '';
    const lines = [company.companyName ? `${company.companyName} - Head Office` : '', formatAddress(company)].filter(Boolean);
    return lines.join('\n');
  }, [company]);

  // View toggles between the invoice list and the full-page Create/Edit
  // form — same page, no dialog/popup, per the standard CRUD page template.
  const [view, setView] = useState('list');
  const [editingRow, setEditingRow] = useState(null);

  // Only products flagged for the purchase flow on Product Master are offered
  // here — see lib/productUsage.js. `products` itself stays unfiltered below,
  // because the line lookups (price, tax, UOM, batch/serial mode) must still
  // resolve a product this document already names even if it has since been
  // re-flagged; passing the saved lines' codes as `keepCodes` is what keeps
  // reopening an existing document from silently blanking its own rows.
  const selectableProducts = productOptionsFor(
    products,
    PRODUCT_USAGE.PURCHASE,
    (editingRow?.items || []).map((i) => i.productCode)
  );
  const productCodeOptions = selectableProducts.map((p) => ({ label: p.productCode, value: p.productCode }));
  const productNameOptions = selectableProducts.map((p) => ({ label: p.productName, value: p.productCode }));
  const [readOnly, setReadOnly] = useState(false);
  const [formKey, setFormKey] = useState(0);
  // Copy From. Two pieces of state because it is a two-step control: the
  // button opens a source menu (anchored to it), and the chosen source then
  // opens the matching Find dialog. Both live at page level rather than inside
  // AppForm's render prop so remounting the form on formKey change can't leave
  // a menu or dialog orphaned open over a freshly reset form.
  const [copyFromAnchor, setCopyFromAnchor] = useState(null);
  const [copyFromSource, setCopyFromSource] = useState(null); // 'po' | 'grn' | null

  // A GRN can be picked here for as long as ANY of its lines still has
  // quantity that hasn't gone back on a return — quantity-aware, not merely
  // "has this GRN ever had a return raised against it": ordering 10 and
  // returning 1-9 still leaves something to invoice, and only returning the
  // full 10 empties it out. (A return itself can only be raised before the
  // GRN is invoiced — see assertReturnAllowed in utils/routeMap.js — so this
  // is the matching guard on the other side of that same rule.)
  //
  // Returned-so-far is summed per product code across every non-cancelled
  // Purchase Return raised against the GRN — a GRN can be returned against
  // more than once over time, and each one only carries its own increment.
  const returnedByGrnProduct = useMemo(() => {
    const totals = new Map(); // "<grnNo>::<productCode>" -> quantity returned
    (purchaseReturns || [])
      .filter((r) => r.status !== 'Cancelled' && r.grnNo)
      .forEach((r) => {
        (r.items || []).forEach((item) => {
          if (!item.productCode) return;
          const key = `${r.grnNo}::${item.productCode}`;
          totals.set(key, (totals.get(key) || 0) + (Number(item.returnQuantity) || 0));
        });
      });
    return totals;
  }, [purchaseReturns]);

  // A GRN with no lines at all is left alone (nothing to judge it by) rather
  // than being treated as fully returned.
  const fullyReturnedGrnNos = useMemo(() => {
    const fully = new Set();
    (grns || []).forEach((g) => {
      const items = g.items || [];
      if (!items.length) return;
      const somethingRemains = items.some((item) => {
        const received = Number(item.receivedQuantity) || 0;
        const returned = returnedByGrnProduct.get(`${g.grnNo}::${item.productCode}`) || 0;
        return received - returned > 0.005;
      });
      if (!somethingRemains) fully.add(g.grnNo);
    });
    return fully;
  }, [grns, returnedByGrnProduct]);

  // What the Copy From > Purchase GRN dialog is allowed to offer. A GRN whose
  // every line has already gone back on a purchase return has nothing left to
  // bill, so copying from it could only produce an invoice for goods the
  // supplier no longer holds our money for.
  //
  // This used to build the options for a GRN dropdown; it is now the record
  // list handed to the dialog. The "already on the record being edited stays
  // selectable" case the dropdown needed is gone with it — the field is
  // read-only now, so an existing invoice's own link is simply displayed and
  // never has to survive a filter to keep showing.
  const copyableGrns = useMemo(
    () => (grns || []).filter((g) => !fullyReturnedGrnNos.has(g.grnNo)),
    [grns, fullyReturnedGrnNos]
  );

  const [search, setSearch] = useState('');
  const [supplierFilter, setSupplierFilter] = useState(null);
  const [statusFilter, setStatusFilter] = useState('All Status');
  const [paymentStatusFilter, setPaymentStatusFilter] = useState('All');
  const [refFilter, setRefFilter] = useState('');
  const [dateFrom, setDateFrom] = useState(null);
  const [dateTo, setDateTo] = useState(null);
  const [dateAnchor, setDateAnchor] = useState(null);
  const [showFilters, setShowFilters] = useState(false);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(PAGE_SIZE);
  const [checkedIds, setCheckedIds] = useState([]);
  const [rowMenuAnchor, setRowMenuAnchor] = useState(null);
  const [rowMenuTarget, setRowMenuTarget] = useState(null);
  const pendingStatusRef = useRef('Draft');

  const rows = invoices || [];

  const baseTableRows = useMemo(() => {
    const q = '';
    const ref = refFilter.trim().toLowerCase();
    return rows.filter((r) => {
      const matchesSearch = !q || [r.invoiceNo, r.supplier, r.grnNo, r.poNo].some((v) => String(v || '').toLowerCase().includes(q));
      const matchesSupplier = !supplierFilter || r.supplier === supplierFilter.value;
      const matchesStatus = statusFilter === 'All Status' || r.status === statusFilter;
      const matchesPaymentStatus = paymentStatusFilter === 'All' || r.paymentStatus === paymentStatusFilter;
      const matchesRef = !ref || [r.grnNo, r.poNo].some((v) => String(v || '').toLowerCase().includes(ref));
      const id = r.invoiceDate ? dayjs(r.invoiceDate) : null;
      const matchesFrom = !dateFrom || (id && !id.isBefore(dateFrom, 'day'));
      const matchesTo = !dateTo || (id && !id.isAfter(dateTo, 'day'));
      return matchesSearch && matchesSupplier && matchesStatus && matchesPaymentStatus && matchesRef && matchesFrom && matchesTo;
    });
  }, [rows, supplierFilter, statusFilter, paymentStatusFilter, refFilter, dateFrom, dateTo]);

  // Column definitions drive the global search, the sort icons and the filter
  // popover — see components/data-display/useTableFeatures.js.
  const tableColumns = useMemo(() => ([
    { field: 'id', headerName: 'Select', filter: false, searchable: false },
    { field: 'invoiceNo', headerName: 'Invoice No.', filter: 'text' },
    { field: 'supplier', headerName: 'Supplier', filter: 'text' },
    { field: 'grnNo', headerName: 'GRN No.', filter: 'text' },
    { field: 'invoiceDate', headerName: 'Invoice Date', filter: 'dateRange', sortValue: (row) => (row.invoiceDate ? new Date(row.invoiceDate).getTime() : null) },
    { field: 'dueDate', headerName: 'Due Date', filter: 'dateRange', sortValue: (row) => (row.dueDate ? new Date(row.dueDate).getTime() : null) },
    { field: 'amount', headerName: 'Amount (₹)', filter: 'numberRange', sortValue: (row) => (row.amount == null || row.amount === '' ? null : Number(row.amount)) },
    { field: 'status', headerName: 'Status', filter: 'select' },
    { field: 'paymentStatus', headerName: 'Payment Status', filter: 'select' },
  ]), []);
  const table = useTableFeatures(baseTableRows, tableColumns, { onChange: setPage });
  const filteredRows = table.rows;

  const pagedRows = useMemo(
    () => filteredRows.slice(page * pageSize, page * pageSize + pageSize),
    [filteredRows, page, pageSize]
  );

  const openCreate = () => {
    setEditingRow(null);
    setReadOnly(false);
    setFormKey((k) => k + 1);
    setView('form');
  };

  const backToList = () => {
    setView('list');
    setEditingRow(null);
    setReadOnly(false);
    setCopyFromAnchor(null);
    setCopyFromSource(null);
  };

  const handleView = (row) => {
    setEditingRow(row);
    setReadOnly(true);
    setFormKey((k) => k + 1);
    setView('form');
  };

  // Opened from the Route Map's document preview popup: jump straight into
  // this record's own read-only View, exactly as clicking it in the list
  // would, instead of requiring the user to find and click the row.
  useEffect(() => {
    if (!openDocNo) return;
    if (editingRow && editingRow.invoiceNo === openDocNo) return;
    const match = rows.find((r) => r.invoiceNo === openDocNo);
    if (match) handleView(match);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [openDocNo, rows]);

  const handleEdit = (row) => {
    setEditingRow(row);
    setReadOnly(false);
    setFormKey((k) => k + 1);
    setView('form');
    setRowMenuAnchor(null);
  };

  const handlePrint = (row) => {
    setRowMenuAnchor(null);
    handleView(row);
    setTimeout(() => window.print(), 300);
  };

  const handleDelete = async (row) => {
    setRowMenuAnchor(null);
    const ok = await confirmDialog({
      title: 'Delete purchase invoice',
      message: `Are you sure you want to delete "${row.invoiceNo}"? This cannot be undone.`,
      confirmLabel: 'Delete',
      severity: 'error',
    });
    if (!ok) return;
    try {
      await remove(row.id).unwrap();
      notify.success('Purchase invoice deleted');
    } catch (err) {
      notify.error(err?.data?.message || 'Delete failed');
    }
  };

  const removeSelected = async () => {
    const ok = await confirmDialog({
      title: 'Delete selected purchase invoices',
      message: `Delete ${checkedIds.length} selected purchase invoice${checkedIds.length > 1 ? 's' : ''}? This cannot be undone.`,
      confirmLabel: 'Delete',
      severity: 'error',
    });
    if (!ok) return;
    try {
      await Promise.all(checkedIds.map((id) => remove(id).unwrap()));
      notify.success('Selected purchase invoices deleted');
      setCheckedIds([]);
    } catch (err) {
      notify.error(err?.data?.message || 'Delete failed');
    }
  };

  const handleSubmit = async (values, formMethods) => {
    const payload = { ...values, status: pendingStatusRef.current };
    try {
      if (editingRow) {
        await update({ id: editingRow.id, ...payload }).unwrap();
        notify.success('Purchase invoice updated');
      } else {
        await create(payload).unwrap();
        notify.success('Purchase invoice saved');
      }
      backToList();
    } catch (err) {
      notify.error(applyServerErrors(err, formMethods.setError));
    }
  };

  const dateRangeLabel = dateFrom && dateTo
    ? `${dateFrom.format('DD/MM/YYYY')} - ${dateTo.format('DD/MM/YYYY')}`
    : 'Select date range';

  if (openDocNo && (!editingRow || editingRow.invoiceNo !== openDocNo)) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', py: 10 }}>
        <CircularProgress size={28} />
      </Box>
    );
  }

  return (
    <Box>
      <EntityHeaderCard
        icon={<ReceiptOutlinedIcon />}
        title="Purchase Invoice"
        subtitle={view === 'form' ? 'Create a new purchase invoice.' : 'Manage and track all purchase invoices.'}
        rightContent={<CompanyBadge />}
      />

      {view === 'form' ? (
        <RouteMapContextMenu flow="purchase" type="invoice" docNo={editingRow?.invoiceNo}>
        <AppForm
          key={formKey}
          schema={purchaseInvoiceSchema}
          defaultValues={editingRow ? rowToFormValues(editingRow) : getEmptyValues()}
          onSubmit={handleSubmit}
        >
          {(methods) => {
            const { control, watch, setValue } = methods;
            const { fields, append, remove: removeItem, replace: replaceItems } = useFieldArray({ control, name: 'items' });
            const watchedItems = watch('items') || [];

            // A purchase invoice with no GRN behind it is the document that
            // receives the goods (see the purchaseInvoice headerFilter in
            // backend utils/stockLedger.js), so it — and only it — has to name
            // a warehouse. With a GRN this invoice is finance-only.
            const grnNo = watch('grnNo');
            const isDirectInvoice = !grnNo || String(grnNo).trim() === '';
            const branch = watch('branch');
            const { options: branchWarehouseOptions } = useWarehouseOptions({
              currentValue: editingRow?.warehouse, branch,
            });

            // Switching branch invalidates a warehouse from the old one.
            // Skipped on first render so loading a record for edit/view does
            // not wipe the value it just loaded.
            const prevBranchRef = useRef(branch);
            useEffect(() => {
              if (prevBranchRef.current === branch) return;
              prevBranchRef.current = branch;
              const allowed = new Set(
                (warehouses || []).filter((w) => !branch || w.branch === branch).map((w) => w.whsCode)
              );
              if (watch('warehouse') && !allowed.has(watch('warehouse'))) setValue('warehouse', '');
              // eslint-disable-next-line react-hooks/exhaustive-deps
            }, [branch]);

            // Product Code / Product Name are sized to the longest value the
            // column actually holds, instead of a fixed width that left almost
            // no room for text once the field's own padding — and, on a select,
            // its clear and dropdown buttons — were subtracted. Short data still
            // sits tight; anything past the cap is revealed on hover as before.
            const productCodeColumnWidth = itemColumnBaseWidth(
              watchedItems.map((i) => i?.productCode), { kind: 'code', field: 'select' },
            );
            const productNameColumnWidth = itemColumnBaseWidth(
              watchedItems.map((i) => i?.productName), { kind: 'name', field: 'select' },
            );
            // The Discount % box in the totals panel is a mirror of the item
            // row's Discount %, not a second deduction — the line's discount
            // is already baked into its Amount (and therefore the Subtotal)
            // above, so computeTotals is always called with 0 here to avoid
            // subtracting the same discount twice. Which row "wins" when
            // there's more than one item is whichever the user edited most
            // recently (see the sync effect below).
            // Discount % in the totals panel is a header-level discount taken
            // off the sum of the (already line-discounted) item amounts —
            // exactly what the server does with the `discountPercent` it
            // receives.
            //
            // It used to be a read-only mirror of whichever item row was
            // edited last, and computeTotals was called with a hard-coded 0
            // so the mirrored figure wouldn't deduct the line discount twice
            // on screen. But the mirrored figure was still posted, and the
            // server had no way to know it was only meant for display: it
            // applied that percentage on top of line amounts that already had
            // it baked in, saving a total below the one the user approved.
            const discountPercent = watch('discountPercent');
            // Inter-state supplies are taxed wholly as IGST. The server works
            // this out by comparing Place of Supply against the company's
            // registered state; passing the same flag here is what stops the
            // panel showing a CGST/SGST split for a record saved as IGST.
            const interState = isInterState(watch('placeOfSupply'), company?.state);
            const totals = computeTotals(watchedItems, discountPercent, interState);

            const allValues = watch();
            const printSupplierRecord = (suppliers || []).find((s) => s.supplierName === allValues.supplier);
            const printGrnRecord = (grns || []).find((g) => g.grnNo === allValues.grnNo);
            const printPoRecord = (purchaseOrders || []).find((p) => p.poNo === allValues.poNo);
            const printOrder = { ...allValues, status: editingRow?.status || 'Draft' };

            const supplierValue = watch('supplier');
            const prevSupplier = useRef(editingRow ? editingRow.supplier : null);
            useEffect(() => {
              if (supplierValue !== prevSupplier.current) {
                const found = (suppliers || []).find((s) => s.supplierName === supplierValue);
                if (found) {
                  setValue('billFrom', [found.supplierName, formatAddress(found)].filter(Boolean).join('\n'), { shouldValidate: true });
                  if (found.paymentTerms) setValue('paymentTerms', found.paymentTerms, { shouldValidate: true });
                }
                prevSupplier.current = supplierValue;
              }
              // eslint-disable-next-line react-hooks/exhaustive-deps
            }, [supplierValue]);

            // Default Ship To (our own billing address) once, when the
            // company record loads and the field is still empty.
            useEffect(() => {
              if (companyShipTo && !editingRow && !watch('shipTo')) {
                setValue('shipTo', companyShipTo, { shouldValidate: true });
              }
              // eslint-disable-next-line react-hooks/exhaustive-deps
            }, [companyShipTo]);

            useEffect(() => {
              if (company?.state && !editingRow && !watch('placeOfSupply')) {
                setValue('placeOfSupply', company.state, { shouldValidate: true });
              }
              // eslint-disable-next-line react-hooks/exhaustive-deps
            }, [company]);

            // Copy From > Purchase GRN pulls PO No. and the item details
            // (product, HSN/SAC, unit, quantity, unit price) straight from that
            // GRN as a starting point.
            //
            // Supplier is NOT pulled across, because on this form supplier is
            // now the input rather than the output: it is what the user picks
            // first, what enables Copy From, and what the dialogs filter their
            // lists by. Every record they can offer already belongs to that
            // supplier, so copying it back would only re-set it to the value it
            // already holds.
            //
            // The pulled item columns used to render `disabled`, on the
            // grounds that they mirror the GRN and aren't invoice-specific
            // data. In practice that made it impossible to record what a
            // supplier invoice actually says: a line billed at a different
            // rate than the GRN, a corrected HSN/unit, or a charge with no
            // GRN line behind it at all. They are editable now; the GRN
            // lookup still pre-fills them, it just no longer forbids a
            // correction. Nothing downstream depends on these columns
            // matching the GRN — the invoice is its own record of what was
            // billed.
            //
            // Everything else on this form (invoice no./date, currency,
            // payment terms, due date, place of supply, bill from/ship to,
            // notes, terms, attachment) was already editable.
            //
            // This used to run as an effect watching the GRN No. dropdown. It
            // is a plain function now, called only from the dialog's Choose
            // button: an effect keyed on a form value also fires when that
            // value is restored on edit or reset, which is why it needed the
            // prevGrn bookkeeping to tell "user picked a GRN" apart from "form
            // loaded". An explicit call has no such ambiguity.
            const applyGrn = (found) => {
                if (found) {
                  setValue('grnNo', found.grnNo || '', { shouldValidate: true });
                  setValue('branch', found.branch || '', { shouldValidate: true });
                  setValue('poNo', found.poNo || '', { shouldValidate: true });
                  setValue('termsConditions', found.termsConditions || '', { shouldValidate: true });
                  setValue('notes', found.notes || '', { shouldValidate: true });
                  // The GRN itself carries no currency/ship-to — those live one
                  // level further up, on the Purchase Order it was received
                  // against. Reached transitively via the GRN's own poNo,
                  // same idea as the terms/notes just pulled straight off the
                  // GRN above.
                  const sourcePo = (purchaseOrders || []).find((p) => p.poNo === found.poNo);
                  if (sourcePo) {
                    setValue('currency', sourcePo.currency || 'INR', { shouldValidate: true });
                    setValue('shipTo', sourcePo.shipTo || '', { shouldValidate: true });
                  }
                  if (found.items && found.items.length) {
                    // Invoice only what the GRN received MINUS what has already
                    // gone back on a Purchase Return against it — pulling the
                    // full received quantity would let goods that were already
                    // returned get invoiced anyway. returnedByGrnProduct is the
                    // same per-product return total the GRN dropdown itself is
                    // filtered by (see fullyReturnedGrnNos above), so the two
                    // can never disagree about what's left. A line with nothing
                    // remaining is dropped rather than pulled in at zero — a
                    // zero-quantity line would fail validation anyway.
                    // `line` is captured BEFORE the filter: base_line has to
                    // name the row's position on the GRN, not its position in
                    // whatever subset survived the remaining-quantity filter.
                    const remaining = found.items
                      .map((i, n) => {
                        const received = i.receivedQuantity != null ? Number(i.receivedQuantity) : 0;
                        const returned = returnedByGrnProduct.get(`${found.grnNo}::${i.productCode}`) || 0;
                        return { item: i, line: n + 1, qty: round2(received - returned) };
                      })
                      .filter(({ qty }) => qty > 0.005);
                    replaceItems(remaining.length
                      ? remaining.map(({ item: i, line, qty }) => ({
                        productCode: i.productCode || '', productName: i.productName || '', description: i.description || '',
                        hsnCode: i.hsnCode || '', uom: i.uom || '',
                        quantity: qty,
                        unitPrice: i.unitPrice != null ? Number(i.unitPrice) : 0,
                        discountPercent: 0,
                        taxPercent: 18,
                        // Copy From: the GRN, which is the immediate source —
                        // not the PO behind it, even though the PO started the
                        // chain.
                        baseType: 'Purchase GRN',
                        baseEntry: found.id ?? null,
                        baseNo: found.grnNo || null,
                        baseLine: line,
                      }))
                      : [{ ...emptyItem }]);
                  }
                }
            };

            // Copy From > Purchase Order. Billing straight off the order —
            // before any goods are received, or for a charge that never passes
            // through a GRN at all — so the full ordered quantity is pulled
            // and there is no returns arithmetic to do: nothing can have gone
            // back on goods that were never received.
            //
            // grnNo is cleared, not left as it was: the invoice now references
            // this PO directly, and leaving a stale receipt number beside it
            // would claim a provenance the lines no longer have (their
            // baseType/baseNo below name the order).
            const applyOrder = (found) => {
              if (!found) return;
              setValue('poNo', found.poNo || '', { shouldValidate: true });
              setValue('grnNo', '', { shouldValidate: true });
              setValue('branch', found.branch || '', { shouldValidate: true });
              setValue('currency', found.currency || 'INR', { shouldValidate: true });
              setValue('paymentTerms', found.paymentTerms || '', { shouldValidate: true });
              setValue('shipTo', found.shipTo || '', { shouldValidate: true });
              setValue('termsConditions', found.termsConditions || '', { shouldValidate: true });
              setValue('notes', found.remarks || '', { shouldValidate: true });
              if (found.items && found.items.length) {
                replaceItems(found.items.map((i, n) => ({
                  productCode: i.productCode || '', productName: i.productName || '', description: i.description || '',
                  hsnCode: i.hsnCode || '', uom: i.uom || '',
                  quantity: i.quantity != null ? Number(i.quantity) : 1,
                  unitPrice: i.unitPrice != null ? Number(i.unitPrice) : 0,
                  discountPercent: 0,
                  taxPercent: i.taxPercent != null ? Number(i.taxPercent) : 18,
                  // Copy From: the PO, which is the immediate source here —
                  // this invoice was raised against the order, not a receipt.
                  baseType: 'Purchase Order',
                  baseEntry: found.id ?? null,
                  baseNo: found.poNo || null,
                  baseLine: n + 1,
                })));
              }
            };

            // Undo a Copy From: drop both links and the values that came
            // across with them, rather than leaving a stale document's figures
            // sitting in an invoice that no longer claims to reference it.
            //
            // Supplier is deliberately NOT cleared. It is the user's own
            // selection — it is what made Copy From available in the first
            // place, and clearing it would close the dialogs off and force a
            // re-pick just to try a different source from the same vendor.
            const grnValue = watch('grnNo');
            const poValue = watch('poNo');
            const clearSource = () => {
              setValue('grnNo', '', { shouldValidate: true });
              setValue('poNo', '', { shouldValidate: true });
              setValue('termsConditions', '', { shouldValidate: true });
              setValue('notes', '', { shouldValidate: true });
              setValue('currency', 'INR', { shouldValidate: true });
              setValue('shipTo', companyShipTo || '', { shouldValidate: true });
              replaceItems([{ ...emptyItem }]);
            };

            const handleFile = (file) => {
              if (file) setValue('attachmentName', file.name, { shouldValidate: true });
            };

            return (
              // minWidth: 0 is required — fieldsets default to min-width: min-content,
              // which lets the wide item table blow out the page width on mobile.
              // The Back to List button is kept outside the fieldset so it stays
              // clickable in read-only (view) mode -- a native <fieldset disabled>
              // disables every descendant control, buttons included.
              <>
              {/* One dialog component, two configurations — which one is
                  mounted follows the source picked from the Copy From menu. */}
              <CopyFromDocumentDialog
                open={copyFromSource === 'po'}
                onClose={() => setCopyFromSource(null)}
                onChoose={applyOrder}
                documents={purchaseOrders || []}
                party={supplierValue}
                title="Find Purchase Order"
                columns={PO_COPY_COLUMNS}
                emptyMessage="No purchase orders found for"
              />
              <CopyFromDocumentDialog
                open={copyFromSource === 'grn'}
                onClose={() => setCopyFromSource(null)}
                onChoose={applyGrn}
                documents={copyableGrns}
                party={supplierValue}
                title="Find Purchase Receipt"
                columns={GRN_COPY_COLUMNS}
                emptyMessage="No goods receipts left to invoice for"
              />
              <Menu
                anchorEl={copyFromAnchor}
                open={Boolean(copyFromAnchor)}
                onClose={() => setCopyFromAnchor(null)}
              >
                <MenuItem onClick={() => { setCopyFromAnchor(null); setCopyFromSource('po'); }}>
                  <ListItemText primary="Purchase Order" secondary="Bill against an order" />
                </MenuItem>
                <MenuItem onClick={() => { setCopyFromAnchor(null); setCopyFromSource('grn'); }}>
                  <ListItemText primary="Purchase GRN" secondary="Bill against goods received" />
                </MenuItem>
              </Menu>
              <PurchaseInvoicePrintable
                order={printOrder}
                company={company}
                supplierRecord={printSupplierRecord}
                grnRecord={printGrnRecord}
                poRecord={printPoRecord}
              />
              <Card variant="outlined" sx={{ mb: 2 }}>
                <CardContent sx={{ p: { xs: 2, sm: 3 } }}>
                  <Stack direction="row" alignItems="center" justifyContent="space-between" flexWrap="wrap" gap={1.5} sx={{ mb: 2 }}>
                    <Typography variant="subtitle1" fontWeight={700}>
                      {readOnly ? 'Supplier & Document Details (View Only)' : 'Supplier & Document Details'}
                    </Typography>
                    <Button type="button" variant="outlined" color="inherit" startIcon={<ArrowBackIcon />} onClick={backToList}>
                      Back to List
                    </Button>
                  </Stack>

                  <fieldset disabled={readOnly} style={{ border: 0, padding: 0, margin: 0, minWidth: 0, width: '100%', display: 'block' }}>
                    <FormGrid columns={4} singleColumnOnMobile>
                      <DocumentNoField documentCode="PI" name="invoiceNo" label="Invoice No. *" placeholder="Enter invoice number" isCreate={!editingRow} />
                      <FormSelect name="branch" label="Branch *" placeholder="Select branch" options={branchOptions} />
                      <FormDatePicker name="invoiceDate" label="Invoice Date *" />
                      {/* Both reference fields are filled only by Copy From —
                          never typed. An invoice's GRN/PO reference has to be
                          a document that actually exists (the lines carry
                          baseEntry/baseNo back to it, and the server recomputes
                          that document's billing status from this invoice), so
                          a free-text box could only ever produce a dangling
                          link. Both stay blank for a direct supplier invoice
                          with nothing upstream, which is now a valid invoice
                          rather than a schema error. */}
                      <FormTextField
                        name="grnNo"
                        label="GRN No."
                        placeholder="Use Copy From to select a GRN"
                        InputProps={{ readOnly: true }}
                      />
                      <FormTextField
                        name="poNo"
                        label="PO No."
                        placeholder="Use Copy From to select an order"
                        InputProps={{ readOnly: true }}
                      />
                      {/* Shown only on the direct path — an invoice with no GRN
                          behind it is the document that receives the goods, so
                          it has to say where they land. With a GRN the receipt
                          already put them somewhere and this invoice moves no
                          stock, so the field would only invite naming a second
                          warehouse nothing was ever put into. Scoped to the
                          selected branch, same as every other warehouse
                          picker — see lib/useWarehouseOptions.js. */}
                      {isDirectInvoice && (
                        <FormSelect
                          name="warehouse"
                          label="Warehouse *"
                          placeholder={branch ? 'Select warehouse' : 'Select a branch first'}
                          options={branchWarehouseOptions}
                          disabled={!branch}
                        />
                      )}

                      {/* Supplier drives this form now: it is picked first, it
                          enables Copy From, and it scopes the lists both
                          dialogs show. It used to be disabled and filled only
                          by the GRN dropdown, which made an invoice without a
                          GRN impossible to enter. */}
                      <FormSelect name="supplier" label="Supplier *" placeholder="Select supplier" options={supplierOptions} />
                      <FormSelect name="currency" label="Currency *" options={CURRENCY_OPTIONS} />
                      <FormSelect name="paymentTerms" label="Payment Terms" placeholder="Select payment terms" options={SUPPLIER_PAYMENT_TERMS_OPTIONS} />
                      <FormDatePicker name="dueDate" label="Due Date *" />

                      <FormSelect name="placeOfSupply" label="Place of Supply *" placeholder="Select state" options={PLACE_OF_SUPPLY_OPTIONS} />
                      <FormTextField name="billFrom" label="Bill From" placeholder="Supplier billing address" multiline rows={3} />
                      <FormTextField name="shipTo" label="Ship To (Billing Address)" placeholder="Company billing address" multiline rows={3} />
                      <FormTextField name="notes" label="Notes" placeholder="Enter any additional notes (optional)" multiline rows={3} />
                    </FormGrid>
                  </fieldset>
                </CardContent>
              </Card>

              <fieldset disabled={readOnly} style={{ border: 0, padding: 0, margin: 0, minWidth: 0, width: '100%', display: 'block' }}>
                <Card variant="outlined" sx={{ mb: 2 }}>
                  <CardContent sx={{ p: { xs: 2, sm: 3 } }}>
                    <Stack direction="row" alignItems="center" justifyContent="space-between" flexWrap="wrap" gap={1.5} sx={{ mb: 2 }}>
                      <Typography variant="subtitle1" fontWeight={700}>Item Details</Typography>
                      <Button type="button" variant="outlined" size="small" startIcon={<AddIcon />} onClick={() => append({ ...emptyItem })}>
                        Add Item
                      </Button>
                    </Stack>

                    {isMobile ? (
                      <Box>
                        {fields.map((field, index) => {
                          const qty = Number(watch(`items.${index}.quantity`)) || 0;
                          const price = Number(watch(`items.${index}.unitPrice`)) || 0;
                          const itemDiscount = Number(watch(`items.${index}.discountPercent`)) || 0;
                          const gross = qty * price;
                          const rowAmount = gross - gross * (itemDiscount / 100);
                          return (
                            <MobileItemCard
                              key={field.id}
                              index={index}
                              amount={rowAmount.toFixed(2)}
                              onRemove={() => removeItem(index)}
                              removeDisabled={fields.length <= 1}
                            >
                              <ProductCell index={index} methods={methods} options={productCodeOptions} products={products} label="Product Code" placeholder="Select product" />
                              <ProductCell index={index} methods={methods} options={productNameOptions} products={products} label="Product Name" placeholder="Select product" />
                              <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', columnGap: 1.5, rowGap: 1.5 }}>
                                <FormTextField name={`items.${index}.hsnCode`} label="HSN/SAC" placeholder="4, 6 or 8 digits" digitsOnly maxLength={8} />
                                <FormTextField name={`items.${index}.uom`} label="Unit" placeholder="Unit" />
                                <FormTextField name={`items.${index}.quantity`} label="Quantity *" type="number" />
                                <FormTextField name={`items.${index}.unitPrice`} label="Unit Price (₹) *" type="number" />
                                <FormTextField name={`items.${index}.discountPercent`} label="Discount (%)" type="number" />
                                <FormSelect name={`items.${index}.taxPercent`} label="Tax (%)" options={taxPercentOptions} />
                              </Box>
                            </MobileItemCard>
                          );
                        })}
                      </Box>
                    ) : (
                    <TableContainer ref={itemScrollRef} sx={{ overflowX: 'auto', WebkitOverflowScrolling: 'touch', cursor: 'grab', ...dragScrollbarSx }}>
                      <Table size="small" sx={{ '& tbody .MuiFormHelperText-root:not(.Mui-error)': { display: 'none' } }}>
                        <TableHead>
                          <TableRow>
                            <TableCell width={40}>#</TableCell>
                            <TableCell sx={{ minWidth: productCodeColumnWidth }}>Product Code</TableCell>
                            <TableCell sx={{ minWidth: productNameColumnWidth }}>Product Name</TableCell>
                            <TableCell sx={{ minWidth: 140 }}>HSN/SAC</TableCell>
                            <TableCell sx={{ minWidth: 110 }}>Unit</TableCell>
                            <TableCell sx={{ minWidth: 110 }}>Quantity *</TableCell>
                            <TableCell sx={{ minWidth: 150 }}>Unit Price (₹) *</TableCell>
                            <TableCell sx={{ minWidth: 90 }}>Discount (%)</TableCell>
                            <TableCell sx={{ minWidth: 120 }}>Tax (%)</TableCell>
                            <TableCell sx={{ minWidth: 110 }}>Amount (₹)</TableCell>
                            <TableCell width={48} />
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {fields.map((field, index) => {
                            const qty = Number(watch(`items.${index}.quantity`)) || 0;
                            const price = Number(watch(`items.${index}.unitPrice`)) || 0;
                            const itemDiscount = Number(watch(`items.${index}.discountPercent`)) || 0;
                            const gross = qty * price;
                            const rowAmount = gross - gross * (itemDiscount / 100);
                            return (
                              <TableRow key={field.id} sx={{ '& > td': { verticalAlign: 'middle' } }}>
                                <TableCell>{index + 1}</TableCell>
                                <TableCell
                                  sx={hoverExpandColumnSx({
                                    base: productCodeColumnWidth,
                                    value: watch(`items.${index}.productCode`),
                                    max: 420,
                                    field: 'select',
                                  })}
                                >
                                  <ProductCell index={index} methods={methods} options={productCodeOptions} products={products} placeholder="Select product" multiline />
                                </TableCell>
                                <TableCell
                                  sx={hoverExpandColumnSx({
                                    base: productNameColumnWidth,
                                    value: watch(`items.${index}.productName`),
                                    max: 640,
                                    field: 'select',
                                  })}
                                >
                                  <ProductCell index={index} methods={methods} options={productNameOptions} products={products} placeholder="Select product" multiline />
                                </TableCell>
                                <TableCell>
                                  <FormTextField name={`items.${index}.hsnCode`} label="" placeholder="HSN/SAC" digitsOnly maxLength={8} />
                                </TableCell>
                                <TableCell>
                                  <FormTextField name={`items.${index}.uom`} label="" placeholder="Unit" />
                                </TableCell>
                                <TableCell>
                                  <FormTextField name={`items.${index}.quantity`} label="" type="number" />
                                </TableCell>
                                <TableCell>
                                  <FormTextField name={`items.${index}.unitPrice`} label="" type="number" />
                                </TableCell>
                                <TableCell>
                                  <FormTextField name={`items.${index}.discountPercent`} label="" type="number" />
                                </TableCell>
                                <TableCell>
                                  <FormSelect name={`items.${index}.taxPercent`} label="" options={taxPercentOptions} disableClearable sx={{ minWidth: 96 }} />
                                </TableCell>
                                <TableCell sx={{ whiteSpace: 'nowrap' }}>{rowAmount.toFixed(2)}</TableCell>
                                <TableCell>
                                  <IconButton
                                    type="button"
                                    size="small"
                                    color="error"
                                    onClick={() => removeItem(index)}
                                    disabled={fields.length <= 1}
                                    aria-label="remove item"
                                  >
                                    <DeleteIcon fontSize="small" />
                                  </IconButton>
                                </TableCell>
                              </TableRow>
                            );
                          })}
                        </TableBody>
                      </Table>
                    </TableContainer>
                    )}
                  </CardContent>
                </Card>
              </fieldset>

              <Card variant="outlined">
                <CardContent sx={{ p: { xs: 2, sm: 3 } }}>
                  <fieldset disabled={readOnly} style={{ border: 0, padding: 0, margin: 0, minWidth: 0, width: '100%', display: 'block' }}>
                    <Grid container spacing={3}>
                      <Grid item xs={12} md={4}>
                        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1 }}>Terms & Conditions</Typography>
                        <FormTextField name="termsConditions" label="" placeholder="Enter terms and conditions" multiline rows={6} />
                      </Grid>

                      <Grid item xs={12} md={4}>
                        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1 }}>Attachments</Typography>
                        <Box
                          onDragOver={(e) => e.preventDefault()}
                          onDrop={(e) => { e.preventDefault(); handleFile(e.dataTransfer.files?.[0]); }}
                          sx={{
                            border: '1px dashed', borderColor: 'divider', borderRadius: 1.5,
                            p: 3, textAlign: 'center', color: 'text.secondary',
                          }}
                        >
                          <UploadFileIcon sx={{ mb: 1 }} />
                          <Typography variant="body2" sx={{ mb: 1 }}>Drag and drop files here</Typography>
                          <Typography variant="body2" sx={{ mb: 1 }}>or</Typography>
                          <Button component="label" variant="outlined" size="small">
                            Browse Files
                            <input type="file" hidden onChange={(e) => handleFile(e.target.files?.[0])} />
                          </Button>
                          <Typography variant="caption" display="block" sx={{ mt: 1 }}>Supported formats: PDF, JPG, PNG (Max. 5MB)</Typography>
                          {watch('attachmentName') && (
                            <Chip
                              sx={{ mt: 1.5 }}
                              size="small"
                              label={watch('attachmentName')}
                              onDelete={() => setValue('attachmentName', '')}
                            />
                          )}
                        </Box>
                      </Grid>

                      <Grid item xs={12} md={4}>
                        <DocumentTotalsPanel totals={totals} interState={interState} />
                      </Grid>
                    </Grid>
                  </fieldset>

                    <Stack
                      direction={{ xs: 'column', sm: 'row' }}
                      spacing={1.5}
                      justifyContent={{ xs: 'stretch', sm: 'flex-end' }}
                      sx={{ mt: 3 }}
                    >
                      {/* Copy From sits immediately left of Cancel and stays
                          disabled until a Supplier is chosen — the dialogs it
                          leads to list that supplier's orders and receipts, so
                          with no supplier there is nothing for them to show.
                          Hidden in view mode, where nothing is being filled
                          in. */}
                      {!readOnly && (
                        (grnValue || poValue) ? (
                          <Button
                            fullWidth={isMobile}
                            type="button"
                            variant="outlined"
                            color="inherit"
                            startIcon={<CloseIcon />}
                            onClick={clearSource}
                            disabled={creating || updating}
                          >
                            Clear Copied {grnValue ? 'GRN' : 'Order'}
                          </Button>
                        ) : (
                          <Button
                            fullWidth={isMobile}
                            type="button"
                            variant="outlined"
                            startIcon={<ContentCopyOutlinedIcon />}
                            endIcon={<ArrowDropDownIcon />}
                            onClick={(e) => setCopyFromAnchor(e.currentTarget)}
                            disabled={!supplierValue || creating || updating}
                          >
                            Copy From
                          </Button>
                        )
                      )}
                      <Button fullWidth={isMobile} type="button" variant="outlined" color="inherit" startIcon={<CloseIcon />} onClick={backToList} disabled={creating || updating}>
                        Cancel
                      </Button>
                      <Button fullWidth={isMobile} type="button" variant="outlined" startIcon={<PrintOutlinedIcon />} onClick={() => window.print()}>
                        Print
                      </Button>
                      {!readOnly && (
                        <>
                          <FormSubmitButton
                            fullWidth={isMobile}
                            variant="outlined"
                            onClick={() => { pendingStatusRef.current = 'Draft'; }}
                            disabled={creating || updating}
                          >
                            Save as Draft
                          </FormSubmitButton>
                          <FormSubmitButton
                            fullWidth={isMobile}
                            onClick={() => { pendingStatusRef.current = 'Posted'; }}
                            disabled={creating || updating}
                          >
                            {editingRow ? 'Update Invoice' : 'Save & Post Invoice'}
                          </FormSubmitButton>
                        </>
                      )}
                    </Stack>
                  </CardContent>
                </Card>
              </>
            );
          }}
        </AppForm>
        </RouteMapContextMenu>
      ) : (
        <Card variant="outlined">
          <CardContent sx={{ p: 0 }}>
            <Stack
              direction={{ xs: 'column', md: 'row' }}
              alignItems={{ xs: 'stretch', md: 'center' }}
              justifyContent="space-between"
              flexWrap="wrap"
              gap={1.5}
              sx={{ px: { xs: 2, sm: 3 }, pt: 2.5, pb: 1.5 }}
            >
              <Typography variant="subtitle1" fontWeight={700}>Purchase Invoice List</Typography>
              <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.5} flexWrap="wrap" useFlexGap sx={{ width: { xs: '100%', md: 'auto' } }}>
                <TableSearchFilter table={table} placeholder="Search by invoice no., supplier, GRN/PO..." showFilter={false} />
                <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.5} flexWrap="wrap" useFlexGap>
                  <Button
                    variant="outlined"
                    color="inherit"
                    startIcon={<FilterListIcon />}
                    onClick={() => setShowFilters((v) => !v)}
                    sx={{ width: { xs: '100%', sm: 'auto' }, height: 40, whiteSpace: 'nowrap' }}
                  >
                    Filter
                  </Button>
                  <CanAdd>
                    <Button
                      variant="contained"
                      startIcon={<AddIcon />}
                      endIcon={<ArrowDropDownIcon />}
                      onClick={openCreate}
                      sx={{ width: { xs: '100%', sm: 'auto' }, height: 40, whiteSpace: 'nowrap' }}
                    >
                      Create Invoice
                    </Button>
                  </CanAdd>
                </Stack>
              </Stack>
            </Stack>

            <Collapse in={showFilters} unmountOnExit>
            <Box sx={{ px: { xs: 2, sm: 3 }, pb: 2 }}>
              <FormGrid columns={5} singleColumnOnMobile>
                <FilterAutocomplete
                  label="Supplier"
                  allLabel="All Suppliers"
                  fullWidth
                  options={supplierOptions}
                  value={supplierFilter}
                  onChange={(v) => { setSupplierFilter(v); setPage(0); }}
                />
                <Autocomplete
                  size="small"
                  fullWidth
                  options={STATUS_FILTERS}
                  value={statusFilter}
                  onChange={(_e, v) => { setStatusFilter(v || 'All Status'); setPage(0); }}
                  disableClearable
                  renderInput={(params) => <TextField {...params} label="Status" InputLabelProps={{ shrink: true }} />}
                />
                <TextField
                  size="small"
                  fullWidth
                  label="Date Range"
                  value={dateRangeLabel}
                  onClick={(e) => setDateAnchor(e.currentTarget)}
                  InputProps={{
                    readOnly: true,
                    startAdornment: <InputAdornment position="start"><EventIcon fontSize="small" /></InputAdornment>,
                    endAdornment: (dateFrom || dateTo) ? (
                      <InputAdornment position="end">
                        <IconButton size="small" onClick={(e) => { e.stopPropagation(); setDateFrom(null); setDateTo(null); setPage(0); }}>
                          <CloseIcon fontSize="small" />
                        </IconButton>
                      </InputAdornment>
                    ) : null,
                  }}
                  InputLabelProps={{ shrink: true }}
                  sx={{ cursor: 'pointer' }}
                />
                <TextField
                  size="small"
                  fullWidth
                  label="Reference (GRN / PO No.)"
                  value={refFilter}
                  onChange={(e) => { setRefFilter(e.target.value); setPage(0); }}
                  placeholder="Enter GRN or PO no."
                  InputLabelProps={{ shrink: true }}
                />
                <Autocomplete
                  size="small"
                  fullWidth
                  options={PAYMENT_STATUS_FILTERS}
                  value={paymentStatusFilter}
                  onChange={(_e, v) => { setPaymentStatusFilter(v || 'All'); setPage(0); }}
                  disableClearable
                  renderInput={(params) => <TextField {...params} label="Payment Status" InputLabelProps={{ shrink: true }} />}
                />
              </FormGrid>

              <Popover
                open={!!dateAnchor}
                anchorEl={dateAnchor}
                onClose={() => setDateAnchor(null)}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
              >
                <Stack direction="row" spacing={2} sx={{ p: 2 }}>
                  <DatePicker label="From" value={dateFrom} onChange={(v) => { setDateFrom(v); setPage(0); }} slotProps={{ textField: { size: 'small' } }} />
                  <DatePicker label="To" value={dateTo} onChange={(v) => { setDateTo(v); setPage(0); }} slotProps={{ textField: { size: 'small' } }} />
                </Stack>
              </Popover>
              <TableFilterPanel table={table} embedded open />
            </Box>
            </Collapse>

            {checkedIds.length > 0 && (
              <Box sx={{ px: { xs: 2, sm: 3 }, pb: 1.5 }}>
                <Button variant="outlined" color="error" size="small" startIcon={<DeleteIcon />} onClick={removeSelected}>
                  Delete Selected ({checkedIds.length})
                </Button>
              </Box>
            )}

            {isMobile ? (
              <Box sx={{ px: 2, pb: 1 }}>
                {!isLoading && pagedRows.map((row) => (
                  <MobileRecordCard
                    key={row.id}
                    title={row.invoiceNo}
                    statusChip={<Chip size="small" label={row.status} color={STATUS_COLORS[row.status] || 'default'} variant="outlined" />}
                    fields={[
                      { label: 'Supplier', value: row.supplier || '—' },
                      { label: 'GRN No.', value: row.grnNo || '—' },
                      { label: 'Invoice Date', value: row.invoiceDate ? dayjs(row.invoiceDate).format('DD/MM/YYYY') : '—' },
                      { label: 'Due Date', value: row.dueDate ? dayjs(row.dueDate).format('DD/MM/YYYY') : '—' },
                      { label: 'Amount', value: `₹${Number(row.amount).toFixed(2)}` },
                      { label: 'Payment Status', value: row.paymentStatus || '—' },
                    ]}
                    onEdit={() => handleEdit(row)}
                    onDelete={() => handleDelete(row)}
                  />
                ))}
                {!isLoading && filteredRows.length === 0 && (
                  <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>No purchase invoices found</Typography>
                )}
              </Box>
            ) : (
              <ScrollableTableContainer>
                <Table size="small" stickyHeader>
                  <TableHead>
                    <TableRow>
                      <SortableHeaderCell field="id" sort={table.sort} onSort={table.toggleSort} padding="checkbox">
                        <Checkbox
                          size="small"
                          checked={pagedRows.length > 0 && pagedRows.every((r) => checkedIds.includes(r.id))}
                          indeterminate={pagedRows.some((r) => checkedIds.includes(r.id)) && !pagedRows.every((r) => checkedIds.includes(r.id))}
                          onChange={(e) => {
                            const ids = pagedRows.map((r) => r.id);
                            setCheckedIds((prev) => e.target.checked
                              ? Array.from(new Set([...prev, ...ids]))
                              : prev.filter((c) => !ids.includes(c)));
                          }}
                        />
                      </SortableHeaderCell>
                      <TableCell width={40}>#</TableCell>
                      <SortableHeaderCell field="invoiceNo" sort={table.sort} onSort={table.toggleSort}>Invoice No.</SortableHeaderCell>
                      <SortableHeaderCell field="supplier" sort={table.sort} onSort={table.toggleSort}>Supplier</SortableHeaderCell>
                      <SortableHeaderCell field="grnNo" sort={table.sort} onSort={table.toggleSort}>GRN No.</SortableHeaderCell>
                      <SortableHeaderCell field="invoiceDate" sort={table.sort} onSort={table.toggleSort}>Invoice Date</SortableHeaderCell>
                      <SortableHeaderCell field="dueDate" sort={table.sort} onSort={table.toggleSort}>Due Date</SortableHeaderCell>
                      <SortableHeaderCell field="amount" sort={table.sort} onSort={table.toggleSort}>Amount (₹)</SortableHeaderCell>
                      <SortableHeaderCell field="status" sort={table.sort} onSort={table.toggleSort}>Status</SortableHeaderCell>
                      <SortableHeaderCell field="paymentStatus" sort={table.sort} onSort={table.toggleSort}>Payment Status</SortableHeaderCell>
                      <TableCell align="right">Action</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {!isLoading && pagedRows.map((row, i) => (
                      <TableRow key={row.id} hover>
                        <TableCell padding="checkbox">
                          <Checkbox
                            size="small"
                            checked={checkedIds.includes(row.id)}
                            onChange={() => setCheckedIds((prev) => prev.includes(row.id) ? prev.filter((c) => c !== row.id) : [...prev, row.id])}
                          />
                        </TableCell>
                        <TableCell>{page * pageSize + i + 1}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.invoiceNo}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.supplier || '—'}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.grnNo || '—'}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.invoiceDate ? dayjs(row.invoiceDate).format('DD/MM/YYYY') : '—'}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.dueDate ? dayjs(row.dueDate).format('DD/MM/YYYY') : '—'}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{Number(row.amount).toFixed(2)}</TableCell>
                        <TableCell>
                          <Chip size="small" label={row.status} color={STATUS_COLORS[row.status] || 'default'} variant="outlined" />
                        </TableCell>
                        <TableCell>
                          <Chip size="small" label={row.paymentStatus} color={PAYMENT_STATUS_COLORS[row.paymentStatus] || 'default'} variant="outlined" />
                        </TableCell>
                        <TableCell align="right">
                          <Stack direction="row" spacing={0.5} justifyContent="flex-end">
                            <Tooltip title="View">
                              <IconButton size="small" onClick={() => handleView(row)} aria-label="view">
                                <VisibilityOutlinedIcon fontSize="small" />
                              </IconButton>
                            </Tooltip>
                            <RouteMapButton flow="purchase" type="invoice" docNo={row.invoiceNo} />
                            <Tooltip title="Print">
                              <IconButton size="small" onClick={() => handlePrint(row)} aria-label="print">
                                <PrintOutlinedIcon fontSize="small" />
                              </IconButton>
                            </Tooltip>
                            <IconButton
                              size="small"
                              onClick={(e) => { setRowMenuAnchor(e.currentTarget); setRowMenuTarget(row); }}
                              aria-label="more actions"
                            >
                              <MoreVertIcon fontSize="small" />
                            </IconButton>
                          </Stack>
                        </TableCell>
                      </TableRow>
                    ))}
                    {!isLoading && filteredRows.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={11}>
                          <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>No purchase invoices found</Typography>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </ScrollableTableContainer>
            )}

            <Menu anchorEl={rowMenuAnchor} open={!!rowMenuAnchor} onClose={() => setRowMenuAnchor(null)}>
              <CanEdit>
                <MenuItem onClick={() => handleEdit(rowMenuTarget)}>
                  <ListItemIcon><EditIcon fontSize="small" /></ListItemIcon>
                  <ListItemText>Edit</ListItemText>
                </MenuItem>
              </CanEdit>
              <CanDelete>
                <MenuItem onClick={() => handleDelete(rowMenuTarget)}>
                  <ListItemIcon><DeleteIcon fontSize="small" color="error" /></ListItemIcon>
                  <ListItemText>Delete</ListItemText>
                </MenuItem>
              </CanDelete>
            </Menu>

            <EntityListPagination total={filteredRows.length} page={page} onChange={setPage} pageSize={pageSize} onPageSizeChange={(v) => { setPageSize(v); setPage(0); }} />
          </CardContent>
        </Card>
      )}
    </Box>
  );
}

// Isolated so the per-row product-select auto-fill effect only re-runs for
// the row whose product actually changed, not every row on every keystroke.
// Both the Product Code and Product Name columns are selects over the same
// underlying items.{index}.productCode field — Product Code lists codes,
// Product Name lists names. Both render disabled here: invoice items come
// straight from the selected GRN's item list (see the grnNo effect above,
// which calls replaceItems), so the product on an invoice row isn't
// something the user picks by hand — it's whatever the GRN said, read-only.
function ProductCell({ index, methods, options, products, label = '', placeholder = 'Select product', disabled = false, multiline = false, sx }) {
  const { watch, setValue } = methods;
  const productCodeValue = watch(`items.${index}.productCode`);
  const prevValue = useRef(productCodeValue);

  useEffect(() => {
    if (productCodeValue !== prevValue.current) {
      const found = (products || []).find((p) => p.productCode === productCodeValue);
      if (found) {
        setValue(`items.${index}.productName`, found.productName, { shouldValidate: true });
        setValue(`items.${index}.description`, found.productName, { shouldValidate: true });
        setValue(`items.${index}.hsnCode`, found.hsnCode || '', { shouldValidate: true });
        setValue(`items.${index}.uom`, found.uom || '', { shouldValidate: true });
        setValue(`items.${index}.unitPrice`, found.costPrice != null ? Number(found.costPrice) : 0, { shouldValidate: true });
      }
      prevValue.current = productCodeValue;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [productCodeValue]);

  return <FormSelect name={`items.${index}.productCode`} label={label} placeholder={placeholder} options={options} disabled={disabled} multiline={multiline} sx={sx} />;
}
