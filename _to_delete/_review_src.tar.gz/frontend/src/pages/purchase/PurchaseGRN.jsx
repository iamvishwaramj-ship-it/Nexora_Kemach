import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Box, Typography, Button, Card, CardContent, Stack, TextField, InputAdornment, Table,
  TableBody, TableCell, TableContainer, TableHead, TableRow, Chip, IconButton, Menu, MenuItem,
  ListItemIcon, ListItemText, Checkbox, Autocomplete, Popover, Grid, Tooltip,
  Collapse, CircularProgress,
} from '@mui/material';
import { useFieldArray } from 'react-hook-form';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import dayjs from 'dayjs';
import ReceiptLongOutlinedIcon from '@mui/icons-material/ReceiptLongOutlined';
import AddIcon from '@mui/icons-material/Add';
import CloseIcon from '@mui/icons-material/Close';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import SearchIcon from '@mui/icons-material/Search';
import FilterListIcon from '@mui/icons-material/FilterList';
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import PrintOutlinedIcon from '@mui/icons-material/PrintOutlined';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import EditIcon from '@mui/icons-material/EditOutlined';
import DeleteIcon from '@mui/icons-material/DeleteOutline';
import EventIcon from '@mui/icons-material/Event';
import UploadFileIcon from '@mui/icons-material/UploadFile';
import Inventory2OutlinedIcon from '@mui/icons-material/Inventory2Outlined';
import AppForm, { FormGrid } from '../../components/form/AppForm';
import BatchSerialSetupDialog from '../../components/common/BatchSerialSetupDialog';
import FormTextField from '../../components/form/FormTextField';
import FormSelect from '../../components/form/FormSelect';
import FormDatePicker from '../../components/form/FormDatePicker';
import EntityHeaderCard from '../../components/common/EntityHeaderCard';
import CompanyBadge from '../../components/common/CompanyBadge';
import EntityListPagination from '../../components/data-display/EntityListPagination';
import FilterAutocomplete from '../../components/data-display/FilterAutocomplete';
import MobileRecordCard from '../../components/data-display/MobileRecordCard';
import MobileItemCard from '../../components/data-display/MobileItemCard';
import { useIsMobileListView } from '../../components/data-display/useIsMobileListView';
import useDragScroll from '../../components/data-display/useDragScroll';
import { useNotify } from '../../components/feedback/NotificationProvider';
import { applyServerErrors } from '../../lib/formErrors';
import { useConfirm } from '../../components/feedback/ConfirmationDialog';
import { goodsReceivedNoteSchema, GRN_STATUS_OPTIONS } from '../../lib/validation/purchaseSchemas';
import { buildDocument, round2, isInterState } from '../../lib/documentTotals';
import DocumentTotalsPanel from '../../components/form/DocumentTotalsPanel';
import { goodsReceivedNoteApi, purchaseOrderApi, supplierApi, productApi, branchApi, taxCodeApi } from '../../features/resources';
import { productOptionsFor, PRODUCT_USAGE } from '../../lib/productUsage';
import { useWarehouseOptions } from '../../lib/useWarehouseOptions';
import { buildTaxPercentOptions } from '../../lib/taxCodeOptions';
import { hoverExpandColumnSx, itemColumnBaseWidth } from '../../lib/columnWidth';
import { useGetCompanyDetailsQuery } from '../../features/company/companyDetailsApi';
import DocumentNoField from '../../components/form/DocumentNoField';
import useTableFeatures from '../../components/data-display/useTableFeatures';
import TableSearchFilter from '../../components/data-display/TableSearchFilter';
import SortableHeaderCell from '../../components/data-display/SortableHeaderCell';
import ScrollableTableContainer, { dragScrollbarSx } from '../../components/data-display/ScrollableTableContainer';

import { CanAdd, CanEdit, CanDelete } from '../../components/common/PermissionGate';
import TableFilterPanel from '../../components/data-display/TableFilterPanel';
import RouteMapButton from '../../components/common/RouteMapButton';
import RouteMapContextMenu from '../../components/common/RouteMapContextMenu';
import ContentCopyOutlinedIcon from '@mui/icons-material/ContentCopyOutlined';
import CopyFromDocumentDialog from '../../components/common/CopyFromDocumentDialog';

// Columns for the "Find Purchase Order" dialog opened by Copy From.
const PO_COPY_COLUMNS = [
  { field: 'poNo', headerName: 'Order No', nowrap: true },
  { field: 'supplier', headerName: 'Vendor Name' },
  { field: 'poDate', headerName: 'Order Date', type: 'date' },
  { field: 'remarks', headerName: 'Comments', type: 'optional' },
];

const emptyItem = {
  productCode: '', productName: '', description: '', hsnCode: '', uom: '',
  poQuantity: 0, previouslyReceived: 0, receivedQuantity: 1, unitPrice: 0,
  taxPercent: 0,
  // Populated via the "Batches - Setup" / "Serial Numbers - Setup" dialog —
  // see BatchSerialSetupDialog and the Batch/Serial column below. Empty
  // unless the selected product's Manage Item By is Batch or Serial.
  batches: [], serials: [],
};

/**
 * Blocks the GRN save when a Batch/Serial-tracked line's received quantity
 * isn't fully accounted for — the client-side half of the same rule the
 * server enforces in assertBatchSerialAllocation (utils/businessRules.js).
 * Runs here too so the user sees the problem immediately, on the row that
 * has it, instead of waiting on a round trip to be told the same thing.
 */
function validateBatchSerialAllocation(items, productsByCode) {
  // Batch and serial numbers are unique system-wide (see the ProductBatch /
  // ProductSerial schema comments), so this also checks for the same number
  // reused across two different lines of this GRN — not just within one
  // line's own "Batches - Setup" rows. Reuse against a number saved on an
  // earlier receipt is caught server-side (assertUniqueBatchesAndSerials in
  // utils/businessRules.js), since this form has no visibility into what
  // already exists in the database.
  const seenBatchNos = new Map();
  const seenSerialNos = new Map();

  for (let i = 0; i < (items || []).length; i++) {
    const item = items[i];
    const trackingMode = productsByCode[item.productCode]?.manageItemBy;
    const label = item.productCode || `Row ${i + 1}`;

    for (const b of item.batches || []) {
      const no = (b.batchNo || '').trim();
      if (!no) continue;
      if (seenBatchNos.has(no)) return `Batch number "${no}" is used on more than one line.`;
      seenBatchNos.set(no, i);
    }
    for (const s of item.serials || []) {
      const no = (s.serialNo || '').trim();
      if (!no) continue;
      if (seenSerialNos.has(no)) return `Serial number "${no}" is used on more than one line.`;
      seenSerialNos.set(no, i);
    }

    if (trackingMode !== 'Batch' && trackingMode !== 'Serial') continue;
    const qty = Number(item.receivedQuantity) || 0;

    if (trackingMode === 'Batch') {
      const allocated = (item.batches || []).reduce((sum, b) => sum + (Number(b.quantity) || 0), 0);
      if (Math.abs(allocated - qty) > 0.005) {
        return `${label}: allocate ${qty} to batches via "Batches - Setup" — currently ${allocated}.`;
      }
    } else {
      const count = (item.serials || []).length;
      if (count !== qty) {
        return `${label}: assign ${qty} serial number(s) via "Serial Numbers - Setup" — currently ${count}.`;
      }
    }
  }
  return null;
}

const DEFAULT_TERMS = [
  '1. Goods once received will not be returned.',
  '2. Shortage/damage must be reported within 24 hours.',
  '3. All goods are subject to inspection and acceptance.',
].join('\n');

function getEmptyValues() {
  return {
    grnNo: '', branch: '', supplier: '', receivedDate: new Date(),
    poNo: '', poDate: null, deliveryChallanNo: '', challanDate: null, deliveryDate: null,
    warehouse: '', receivedBy: '', notes: '',
    termsConditions: DEFAULT_TERMS, attachmentName: '', status: 'Open',
    items: [{ ...emptyItem }],
  };
}

// Totals come from the shared engine in lib/documentTotals.js, which the
// backend mirrors exactly — the figures shown here while editing are the
// figures that get saved. Each page used to carry its own copy of this
// arithmetic and the copies had drifted apart; this document in particular
// used to hard-code CGST and SGST at 9% each regardless of what the goods
// actually attract.
//
// `grandTotal` and `discount` are kept in the returned shape because the
// totals panel below reads those names.
// `interState` must be passed through rather than defaulted: the server
// decides CGST/SGST vs IGST by comparing this document's Place of Supply
// against the company's registered state, and for a long time no page passed
// the flag at all — so an inter-state document displayed a CGST/SGST split
// while the record it saved held IGST.
//
function computeTotals(items, discountPercent, interState = false) {
  const { totals } = buildDocument(items, discountPercent, {
    quantityField: 'receivedQuantity',
    interState,
    roundOff: true,
  });
  return {
    ...totals,
    totalItems: (items || []).length,
    discount: round2(totals.subtotal - totals.taxableAmount),
    grandTotal: totals.amount,
  };
}

function rowToFormValues(row) {
  return {
    grnNo: row.grnNo, branch: row.branch || '', supplier: row.supplier || '', receivedDate: row.receivedDate,
    poNo: row.poNo || '', poDate: row.poDate || null, deliveryChallanNo: row.deliveryChallanNo || '',
    challanDate: row.challanDate || null, deliveryDate: row.deliveryDate || null,
    warehouse: row.warehouse || '', receivedBy: row.receivedBy || '', notes: row.notes || '',
    termsConditions: row.termsConditions || '', attachmentName: row.attachmentName || '',
    status: row.status || 'Open',
    items: (row.items && row.items.length ? row.items : [{ ...emptyItem }]).map((i) => ({
      productCode: i.productCode || '', productName: i.productName || '', description: i.description || '',
      hsnCode: i.hsnCode || '', uom: i.uom || '',
      poQuantity: i.poQuantity != null ? Number(i.poQuantity) : 0,
      previouslyReceived: i.previouslyReceived != null ? Number(i.previouslyReceived) : 0,
      receivedQuantity: i.receivedQuantity != null ? Number(i.receivedQuantity) : 1,
      unitPrice: i.unitPrice != null ? Number(i.unitPrice) : 0,
      taxPercent: i.taxPercent != null ? Number(i.taxPercent) : 0,
      batches: i.batches || [], serials: i.serials || [],
    })),
  };
}

const PAGE_SIZE = 10;
const STATUS_FILTERS = ['All Status', ...GRN_STATUS_OPTIONS];

// Draft (saved but nothing received, no stock posted) grey, Open (received,
// not yet fully invoiced) blue, Closed (fully invoiced) green, Cancelled red.
// Only Draft vs Open is chosen by the user — via which save button they
// press; Open -> Closed is the server's, see recomputeGrnStatus in backend
// utils/documentFlow.js.
const STATUS_COLORS = {
  Draft: 'default', Open: 'info', Closed: 'success', Cancelled: 'error',
};

export default function PurchaseGRN({ openDocNo } = {}) {
  const notify = useNotify();
  const confirmDialog = useConfirm();
  const isMobile = useIsMobileListView();
  const itemScrollRef = useDragScroll();
  const { data: grns, isLoading } = goodsReceivedNoteApi.useList();
  const { data: purchaseOrders } = purchaseOrderApi.useList();
  const { data: suppliers } = supplierApi.useList();
  const { data: products } = productApi.useList();
  const { data: branches } = branchApi.useList();
  const { data: taxCodes } = taxCodeApi.useList();
  const taxPercentOptions = useMemo(() => buildTaxPercentOptions(taxCodes), [taxCodes]);
  const { data: company } = useGetCompanyDetailsQuery();
  const [create, { isLoading: creating }] = goodsReceivedNoteApi.useCreate();
  const [update, { isLoading: updating }] = goodsReceivedNoteApi.useUpdate();
  const [remove] = goodsReceivedNoteApi.useDelete();

  const supplierOptions = (suppliers || []).map((s) => ({ label: s.supplierName, value: s.supplierName }));
  // Looked up per row to decide whether the Batch/Serial column applies —
  // Product Master's Manage Item By select is what makes a line ask for it.
  const productsByCode = useMemo(
    () => Object.fromEntries((products || []).map((p) => [p.productCode, p])),
    [products]
  );
  // Purchase orders are no longer offered as a dropdown on the form — they
  // are picked through the Copy From dialog, which scopes the list to the
  // selected supplier. That dialog takes the raw `purchaseOrders` list.
  const branchOptions = useMemo(
    () => (branches || []).map((b) => ({ label: b.branchName, value: b.branchName })),
    [branches]
  );

  // View toggles between the GRN list and the full-page Create/Edit form —
  // same page, no dialog/popup, per the standard CRUD page template.
  const [view, setView] = useState('list');
  const [editingRow, setEditingRow] = useState(null);

  // Only products flagged for the purchase flow on Product Master are offered
  // here — see lib/productUsage.js. `products` itself stays unfiltered below,
  // because the line lookups (price, tax, UOM, batch/serial mode) must still
  // resolve a product this document already names even if it has since been
  // re-flagged; passing the saved lines' codes as `keepCodes` is what keeps
  // reopening an existing document from silently blanking its own rows.
  const selectableProducts = productOptionsFor(
    products,
    PRODUCT_USAGE.PURCHASE,
    (editingRow?.items || []).map((i) => i.productCode)
  );
  const productCodeOptions = selectableProducts.map((p) => ({ label: p.productCode, value: p.productCode }));
  const productNameOptions = selectableProducts.map((p) => ({ label: p.productName, value: p.productCode }));

  // Warehouses come from the Warehouse Master, like every other warehouse
  // dropdown in the app now — see lib/useWarehouseOptions.js. This list used to
  // be the literal string 'Main Warehouse' plus every BRANCH name, which are
  // not warehouses at all, so a warehouse picked here could never be filtered
  // for in a stock report.
  //
  // The record's stored value is passed in because documents saved under that
  // old list hold values no warehouse matches. Without it the select would
  // render blank on those documents and the next save would rewrite a posted
  // movement's warehouse to null.
  //
  // No list-view Warehouse filter exists on this page, so only the raw
  // `warehouses` array is needed here — it feeds the branch-scoped options
  // computed inside the form below, and the branch-change clear effect.
  const { warehouses } = useWarehouseOptions({ currentValue: editingRow?.warehouse });
  const [readOnly, setReadOnly] = useState(false);
  const [formKey, setFormKey] = useState(0);
  // Copy From ("Find Purchase Order") dialog. Held at page level rather than
  // inside AppForm's render prop so remounting the form on formKey change
  // can't leave a dialog orphaned open over a freshly reset form.
  const [copyFromOpen, setCopyFromOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [supplierFilter, setSupplierFilter] = useState(null);
  const [statusFilter, setStatusFilter] = useState('All Status');
  const [poFilter, setPoFilter] = useState('');
  const [refFilter, setRefFilter] = useState('');
  const [dateFrom, setDateFrom] = useState(null);
  const [dateTo, setDateTo] = useState(null);
  const [dateAnchor, setDateAnchor] = useState(null);
  const [showFilters, setShowFilters] = useState(false);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(PAGE_SIZE);
  const [checkedIds, setCheckedIds] = useState([]);
  const [rowMenuAnchor, setRowMenuAnchor] = useState(null);
  const [rowMenuTarget, setRowMenuTarget] = useState(null);
  // { index, mode } for the item row whose "Batches - Setup" / "Serial
  // Numbers - Setup" dialog is open; null when closed.
  const [batchDialog, setBatchDialog] = useState(null);

  const rows = grns || [];

  const baseTableRows = useMemo(() => {
    const q = '';
    const po = poFilter.trim().toLowerCase();
    const ref = refFilter.trim().toLowerCase();
    return rows.filter((r) => {
      const matchesSearch = !q || [r.grnNo, r.supplier, r.poNo].some((v) => String(v || '').toLowerCase().includes(q));
      const matchesSupplier = !supplierFilter || r.supplier === supplierFilter.value;
      const matchesStatus = statusFilter === 'All Status' || r.status === statusFilter;
      const matchesPo = !po || String(r.poNo || '').toLowerCase().includes(po);
      const matchesRef = !ref || String(r.deliveryChallanNo || '').toLowerCase().includes(ref);
      const gd = r.receivedDate ? dayjs(r.receivedDate) : null;
      const matchesFrom = !dateFrom || (gd && !gd.isBefore(dateFrom, 'day'));
      const matchesTo = !dateTo || (gd && !gd.isAfter(dateTo, 'day'));
      return matchesSearch && matchesSupplier && matchesStatus && matchesPo && matchesRef && matchesFrom && matchesTo;
    });
  }, [rows, supplierFilter, statusFilter, poFilter, refFilter, dateFrom, dateTo]);

  // Column definitions drive the global search, the sort icons and the filter
  // popover — see components/data-display/useTableFeatures.js.
  const tableColumns = useMemo(() => ([
    { field: 'id', headerName: 'Select', filter: false, searchable: false },
    { field: 'grnNo', headerName: 'GRN No.', filter: 'text' },
    { field: 'supplier', headerName: 'Supplier', filter: 'text' },
    { field: 'poNo', headerName: 'PO No.', filter: 'text' },
    { field: 'receivedDate', headerName: 'GRN Date', filter: 'dateRange', sortValue: (row) => (row.receivedDate ? new Date(row.receivedDate).getTime() : null) },
    { field: 'totalItems', headerName: 'Total Items', filter: 'text', searchValue: (row) => [row.totalItems, row.items.length].join(' ') },
    { field: 'amount', headerName: 'Amount (₹)', filter: 'numberRange', sortValue: (row) => (row.amount == null || row.amount === '' ? null : Number(row.amount)) },
    { field: 'status', headerName: 'Status', filter: 'select' },
    { field: 'deliveryChallanNo', headerName: 'Delivery No.', filter: 'text' },
  ]), []);
  const table = useTableFeatures(baseTableRows, tableColumns, { onChange: setPage });
  const filteredRows = table.rows;

  const pagedRows = useMemo(
    () => filteredRows.slice(page * pageSize, page * pageSize + pageSize),
    [filteredRows, page, pageSize]
  );

  const openCreate = () => {
    setEditingRow(null);
    setReadOnly(false);
    setFormKey((k) => k + 1);
    setView('form');
  };

  const backToList = () => {
    setView('list');
    setEditingRow(null);
    setReadOnly(false);
    setCopyFromOpen(false);
  };

  const handleView = (row) => {
    setEditingRow(row);
    setReadOnly(true);
    setFormKey((k) => k + 1);
    setView('form');
  };

  // Opened from the Route Map's document preview popup: jump straight into
  // this record's own read-only View, exactly as clicking it in the list
  // would, instead of requiring the user to find and click the row.
  useEffect(() => {
    if (!openDocNo) return;
    if (editingRow && editingRow.grnNo === openDocNo) return;
    const match = rows.find((r) => r.grnNo === openDocNo);
    if (match) handleView(match);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [openDocNo, rows]);

  const handleEdit = (row) => {
    setEditingRow(row);
    setReadOnly(false);
    setFormKey((k) => k + 1);
    setView('form');
    setRowMenuAnchor(null);
  };

  const handlePrint = (row) => {
    setRowMenuAnchor(null);
    handleView(row);
    setTimeout(() => window.print(), 300);
  };

  const handleDelete = async (row) => {
    setRowMenuAnchor(null);
    const ok = await confirmDialog({
      title: 'Delete GRN',
      message: `Are you sure you want to delete "${row.grnNo}"? This cannot be undone.`,
      confirmLabel: 'Delete',
      severity: 'error',
    });
    if (!ok) return;
    try {
      await remove(row.id).unwrap();
      notify.success('GRN deleted');
    } catch (err) {
      notify.error(err?.data?.message || 'Delete failed');
    }
  };

  const removeSelected = async () => {
    const ok = await confirmDialog({
      title: 'Delete selected GRNs',
      message: `Delete ${checkedIds.length} selected GRN${checkedIds.length > 1 ? 's' : ''}? This cannot be undone.`,
      confirmLabel: 'Delete',
      severity: 'error',
    });
    if (!ok) return;
    try {
      await Promise.all(checkedIds.map((id) => remove(id).unwrap()));
      notify.success('Selected GRNs deleted');
      setCheckedIds([]);
    } catch (err) {
      notify.error(err?.data?.message || 'Delete failed');
    }
  };

  const handleSubmit = async (values, status, setError) => {
    // A Batch/Serial-tracked line whose received quantity isn't fully
    // covered by its batches/serials cannot be saved — see
    // validateBatchSerialAllocation above. The server enforces the same
    // rule (assertBatchSerialAllocation) so this is a fast local check, not
    // the only line of defence.
    const allocationError = validateBatchSerialAllocation(values.items, productsByCode);
    if (allocationError) {
      notify.error(allocationError);
      return;
    }
    const payload = { ...values, status };
    try {
      if (editingRow) {
        await update({ id: editingRow.id, ...payload }).unwrap();
        notify.success('GRN updated');
      } else {
        await create(payload).unwrap();
        notify.success('GRN saved');
      }
      backToList();
    } catch (err) {
      notify.error(applyServerErrors(err, setError));
    }
  };

  const dateRangeLabel = dateFrom && dateTo
    ? `${dateFrom.format('DD/MM/YYYY')} - ${dateTo.format('DD/MM/YYYY')}`
    : 'Select date range';

  if (openDocNo && (!editingRow || editingRow.grnNo !== openDocNo)) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', py: 10 }}>
        <CircularProgress size={28} />
      </Box>
    );
  }

  return (
    <Box>
      <EntityHeaderCard
        icon={<ReceiptLongOutlinedIcon />}
        title="Purchase GRN"
        subtitle={view === 'form' ? 'Create a new goods receipt note.' : 'Manage and track all goods receipt notes.'}
        rightContent={<CompanyBadge />}
      />

      {view === 'form' ? (
        <RouteMapContextMenu flow="purchase" type="grn" docNo={editingRow?.grnNo}>
        <AppForm
          key={formKey}
          schema={goodsReceivedNoteSchema}
          defaultValues={editingRow ? rowToFormValues(editingRow) : getEmptyValues()}
          onSubmit={() => {}}
        >
          {(methods) => {
            const { control, watch, setValue, handleSubmit: rhfHandleSubmit } = methods;
            const { fields, append, remove: removeItem, replace: replaceItems } = useFieldArray({ control, name: 'items' });
            const watchedItems = watch('items') || [];

            // Product Code / Product Name are sized to the longest value the
            // column actually holds, instead of a fixed width that left almost
            // no room for text once the field's own padding — and, on a select,
            // its clear and dropdown buttons — were subtracted. Short data still
            // sits tight; anything past the cap is revealed on hover as before.
            const productCodeColumnWidth = itemColumnBaseWidth(
              watchedItems.map((i) => i?.productCode), { kind: 'code', field: 'select' },
            );
            const productNameColumnWidth = itemColumnBaseWidth(
              watchedItems.map((i) => i?.productName), { kind: 'name', field: 'select' },
            );
            // Inter-state supplies are taxed wholly as IGST. The server works
            // this out by comparing Place of Supply against the company's
            // registered state; passing the same flag here is what stops the
            // panel showing a CGST/SGST split for a record saved as IGST.
            const interState = isInterState(watch('placeOfSupply'), company?.state);
            const totals = computeTotals(watchedItems, 0, interState);

            const branch = watch('branch');

            // Once Branch is picked, the Warehouse dropdown is scoped to
            // that branch's warehouses only — see useWarehouseOptions.js.
            const { options: branchWarehouseOptions } = useWarehouseOptions({ currentValue: editingRow?.warehouse, branch });

            const submitWithStatus = (status) => rhfHandleSubmit((values) => handleSubmit(values, status, methods.setError))();

            // Copy From pulls Branch, PO Date, delivery date, terms and the
            // item details (product, HSN/SAC, unit, PO quantity, unit price)
            // straight from the chosen PO.
            //
            // Supplier is NOT pulled across, because on this form supplier is
            // now the input rather than the output: it is what the user picks
            // first, what enables Copy From, and what the dialog filters its
            // list by. Every PO the dialog can offer already belongs to that
            // supplier, so copying it back would only ever re-set it to the
            // value it already holds.
            //
            // The pulled columns used to render `disabled`, on the grounds
            // that they aren't GRN-specific data. In practice that made the
            // item table unusable for the things a goods receipt actually has
            // to record: a delivery of something not on the PO, a substituted
            // product, a corrected unit price, or a receipt with no PO behind
            // it at all — "Add Item" produced a row whose product, HSN, unit
            // and price could never be filled in. They are editable now; the
            // PO lookup still pre-fills them, it just no longer forbids a
            // correction.
            //
            // Nothing downstream depends on those columns matching the PO:
            // PO fulfilment is recomputed from the GRN's actual
            // receivedQuantity (recomputePurchaseOrder in
            // backend/src/utils/documentFlow.js), and poQuantity /
            // previouslyReceived are stored on the line purely as the
            // reference figures shown to whoever checks the delivery.
            //
            // This used to run as an effect watching the PO No. dropdown. It
            // is a plain function now, called only from the dialog's Choose
            // button: an effect keyed on a form value also fires when that
            // value is restored on edit or reset, which is why it needed the
            // prevPo bookkeeping to tell "user picked a PO" apart from "form
            // loaded". An explicit call has no such ambiguity.
            const applyOrder = (found) => {
                if (found) {
                  setValue('poNo', found.poNo || '', { shouldValidate: true });
                  setValue('branch', found.branch || '', { shouldValidate: true });
                  setValue('poDate', found.poDate || null, { shouldValidate: true });
                  setValue('deliveryDate', found.deliveryDate || null, { shouldValidate: true });
                  setValue('termsConditions', found.termsConditions || '', { shouldValidate: true });
                  if (found.items && found.items.length) {
                    replaceItems(found.items.map((i, n) => ({
                      productCode: i.productCode || '', productName: i.productName || '', description: i.description || '',
                      hsnCode: i.hsnCode || '', uom: i.uom || '',
                      poQuantity: i.quantity != null ? Number(i.quantity) : 0,
                      previouslyReceived: 0,
                      receivedQuantity: i.quantity != null ? Number(i.quantity) : 1,
                      unitPrice: i.unitPrice != null ? Number(i.unitPrice) : 0,
                      // Copy From: this line came from the PO's line n.
                      baseType: 'Purchase Order',
                      baseEntry: found.id ?? null,
                      baseNo: found.poNo || null,
                      baseLine: n + 1,
                      // Carried across like every other line field. Omitting
                      // it left each row's Tax % undefined after a PO was
                      // picked, which rendered the cell blank and taxed the
                      // whole receipt at 0% unless someone retyped every rate
                      // by hand — the Zod schema defaults it to 0, so nothing
                      // complained.
                      taxPercent: i.taxPercent != null ? Number(i.taxPercent) : 0,
                      batches: [], serials: [],
                    })));
                  }
                }
            };

            // Undo a Copy From: drop the link and the values that came across
            // with it, rather than leaving a stale PO's figures sitting in a
            // GRN that no longer claims to reference it.
            //
            // Supplier is deliberately NOT cleared. It is the user's own
            // selection — it is what made Copy From available in the first
            // place, and clearing it would close the dialog off and force a
            // re-pick just to try a different order from the same vendor.
            const poValue = watch('poNo');
            const clearOrder = () => {
              setValue('poNo', '', { shouldValidate: true });
              setValue('poDate', null, { shouldValidate: true });
              setValue('deliveryDate', null, { shouldValidate: true });
              setValue('termsConditions', '', { shouldValidate: true });
              replaceItems([{ ...emptyItem }]);
            };

            const handleFile = (file) => {
              if (file) setValue('attachmentName', file.name, { shouldValidate: true });
            };

            // Switching Branch invalidates a Warehouse choice that doesn't
            // belong to the new branch. Skipped on the very first render so
            // loading an existing record for edit/view doesn't wipe a value
            // it just loaded.
            const prevBranchRef = useRef(branch);
            useEffect(() => {
              if (prevBranchRef.current === branch) return;
              prevBranchRef.current = branch;
              const allowed = new Set(
                (warehouses || []).filter((w) => !branch || w.branch === branch).map((w) => w.whsCode)
              );
              if (watch('warehouse') && !allowed.has(watch('warehouse'))) setValue('warehouse', '');
              // eslint-disable-next-line react-hooks/exhaustive-deps
            }, [branch]);

            return (
              // minWidth: 0 is required — fieldsets default to min-width: min-content,
              // which lets the wide item table blow out the page width on mobile.
              // The Back to List / Cancel buttons are kept outside the fieldset(s)
              // so they stay clickable in read-only (view) mode -- a native
              // <fieldset disabled> disables every descendant control, buttons
              // included.
              <>
              <CopyFromDocumentDialog
                open={copyFromOpen}
                onClose={() => setCopyFromOpen(false)}
                onChoose={applyOrder}
                documents={purchaseOrders || []}
                party={watch('supplier')}
                title="Find Purchase Order"
                columns={PO_COPY_COLUMNS}
                emptyMessage="No purchase orders found for"
              />
              <Card variant="outlined" sx={{ mb: 2 }}>
                <CardContent sx={{ p: { xs: 2, sm: 3 } }}>
                  <Stack direction="row" alignItems="center" justifyContent="space-between" flexWrap="wrap" gap={1.5} sx={{ mb: 2 }}>
                    <Typography variant="subtitle1" fontWeight={700}>
                      {readOnly ? 'Supplier & Document Details (View Only)' : 'Supplier & Document Details'}
                    </Typography>
                    <Button type="button" variant="outlined" color="inherit" startIcon={<ArrowBackIcon />} onClick={backToList}>
                      Back to List
                    </Button>
                  </Stack>

                  <fieldset disabled={readOnly} style={{ border: 0, padding: 0, margin: 0, minWidth: 0, width: '100%', display: 'block' }}>
                    <FormGrid columns={4} singleColumnOnMobile>
                      <DocumentNoField documentCode="GRN" name="grnNo" label="GRN No. *" placeholder="Enter GRN number" isCreate={!editingRow} />
                      <FormSelect name="branch" label="Branch *" placeholder="Select branch" options={branchOptions} />
                      <FormDatePicker name="receivedDate" label="GRN Date *" />
                      {/* Filled only by Copy From — never typed. A GRN's PO
                          reference has to be an order that actually exists
                          (the lines carry baseEntry/baseNo back to it, and
                          the server recomputes that order's fulfilment from
                          this receipt), so a free-text box here could only
                          ever produce a dangling link. Left blank for a
                          receipt with no PO behind it, which is now a valid
                          GRN rather than a schema error. */}
                      <FormTextField
                        name="poNo"
                        label="PO No."
                        placeholder="Use Copy From to select an order"
                        InputProps={{ readOnly: true }}
                      />
                      <FormDatePicker name="poDate" label="PO Date" />

                      {/* Supplier drives this form now: it is picked first,
                          it enables Copy From, and it scopes the order list
                          that dialog shows. It used to be disabled and filled
                          only by the PO dropdown, which made a GRN without a
                          PO impossible to enter. */}
                      <FormSelect name="supplier" label="Supplier *" placeholder="Select supplier" options={supplierOptions} />
                      <FormTextField name="deliveryChallanNo" label="Delivery Challan No." placeholder="Enter challan number" />
                      <FormDatePicker name="challanDate" label="Challan Date" />
                      <FormDatePicker name="deliveryDate" label="Delivery Date" />

                      <FormSelect
                        name="warehouse"
                        label="Warehouse *"
                        placeholder={branch ? 'Select warehouse' : 'Select a branch first'}
                        options={branchWarehouseOptions}
                        disabled={!branch}
                      />
                      <FormTextField name="receivedBy" label="Received By *" placeholder="Enter receiver name" />
                      <FormTextField name="notes" label="Notes" placeholder="Enter notes" />
                    </FormGrid>
                  </fieldset>
                </CardContent>
              </Card>

              <fieldset disabled={readOnly} style={{ border: 0, padding: 0, margin: 0, minWidth: 0, width: '100%', display: 'block' }}>
                <Card variant="outlined" sx={{ mb: 2 }}>
                  <CardContent sx={{ p: { xs: 2, sm: 3 } }}>
                    <Stack direction="row" alignItems="center" justifyContent="space-between" flexWrap="wrap" gap={1.5} sx={{ mb: 2 }}>
                      <Typography variant="subtitle1" fontWeight={700}>Item Details</Typography>
                      <Button type="button" variant="outlined" size="small" startIcon={<AddIcon />} onClick={() => append({ ...emptyItem })}>
                        Add Item
                      </Button>
                    </Stack>

                    {isMobile ? (
                      <Box>
                        {fields.map((field, index) => {
                          const qty = Number(watch(`items.${index}.receivedQuantity`)) || 0;
                          const price = Number(watch(`items.${index}.unitPrice`)) || 0;
                          const rowAmount = qty * price;
                          return (
                            <MobileItemCard
                              key={field.id}
                              index={index}
                              amount={rowAmount.toFixed(2)}
                              onRemove={() => removeItem(index)}
                              removeDisabled={fields.length <= 1}
                            >
                              <ProductCell index={index} methods={methods} options={productCodeOptions} products={products} label="Product Code" placeholder="Select product" />
                              <ProductCell index={index} methods={methods} options={productNameOptions} products={products} label="Product Name" placeholder="Select product" />
                              <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', columnGap: 1.5, rowGap: 1.5 }}>
                                <FormTextField name={`items.${index}.hsnCode`} label="HSN/SAC" placeholder="4, 6 or 8 digits" digitsOnly maxLength={8} />
                                <FormTextField name={`items.${index}.uom`} label="Unit" placeholder="Unit" />
                                <FormTextField name={`items.${index}.poQuantity`} label="PO Quantity" type="number" />
                                <FormTextField name={`items.${index}.previouslyReceived`} label="Previously Received" type="number" />
                                <FormTextField name={`items.${index}.receivedQuantity`} label="Received Qty *" type="number" />
                                <FormSelect name={`items.${index}.taxPercent`} label="Tax %" options={taxPercentOptions} />
                                <FormTextField name={`items.${index}.unitPrice`} label="Unit Price (₹)" type="number" />
                              </Box>
                              <Box sx={{ mt: 1.5 }}>
                                <BatchSerialCell index={index} methods={methods} product={productsByCode[watch(`items.${index}.productCode`)]} onOpen={(mode) => setBatchDialog({ index, mode })} />
                              </Box>
                            </MobileItemCard>
                          );
                        })}
                      </Box>
                    ) : (
                    <TableContainer ref={itemScrollRef} sx={{ overflowX: 'auto', WebkitOverflowScrolling: 'touch', cursor: 'grab', ...dragScrollbarSx }}>
                      <Table size="small" sx={{ '& tbody .MuiFormHelperText-root:not(.Mui-error)': { display: 'none' } }}>
                        <TableHead>
                          <TableRow>
                            <TableCell width={40}>#</TableCell>
                            <TableCell sx={{ minWidth: productCodeColumnWidth }}>Product Code</TableCell>
                            <TableCell sx={{ minWidth: productNameColumnWidth }}>Product Name</TableCell>
                            <TableCell sx={{ minWidth: 140 }}>HSN/SAC</TableCell>
                            <TableCell sx={{ minWidth: 110 }}>Unit</TableCell>
                            <TableCell sx={{ minWidth: 110 }}>PO Qty</TableCell>
                            <TableCell sx={{ minWidth: 130 }}>Previously Received</TableCell>
                            <TableCell sx={{ minWidth: 140 }}>Received Quantity *</TableCell>
                            <TableCell sx={{ minWidth: 150 }}>Unit Price (₹)</TableCell>
                            <TableCell sx={{ minWidth: 225 }}>Tax %</TableCell>
                            <TableCell sx={{ minWidth: 140 }}>Batch / Serial</TableCell>
                            <TableCell sx={{ minWidth: 110 }}>Amount (₹)</TableCell>
                            <TableCell width={48} />
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {fields.map((field, index) => {
                            const qty = Number(watch(`items.${index}.receivedQuantity`)) || 0;
                            const price = Number(watch(`items.${index}.unitPrice`)) || 0;
                            const rowAmount = qty * price;
                            return (
                              <TableRow key={field.id} sx={{ '& > td': { verticalAlign: 'middle' } }}>
                                <TableCell>{index + 1}</TableCell>
                                <TableCell
                                  sx={hoverExpandColumnSx({
                                    base: productCodeColumnWidth,
                                    value: watch(`items.${index}.productCode`),
                                    max: 420,
                                    field: 'select',
                                  })}
                                >
                                  <ProductCell index={index} methods={methods} options={productCodeOptions} products={products} placeholder="Select product" multiline />
                                </TableCell>
                                <TableCell
                                  sx={hoverExpandColumnSx({
                                    base: productNameColumnWidth,
                                    value: watch(`items.${index}.productName`),
                                    max: 640,
                                    field: 'select',
                                  })}
                                >
                                  <ProductCell index={index} methods={methods} options={productNameOptions} products={products} placeholder="Select product" multiline />
                                </TableCell>
                                <TableCell>
                                  <FormTextField name={`items.${index}.hsnCode`} label="" placeholder="HSN/SAC" digitsOnly maxLength={8} />
                                </TableCell>
                                <TableCell>
                                  <FormTextField name={`items.${index}.uom`} label="" placeholder="Unit" />
                                </TableCell>
                                <TableCell>
                                  <FormTextField name={`items.${index}.poQuantity`} label="" type="number" />
                                </TableCell>
                                <TableCell>
                                  <FormTextField name={`items.${index}.previouslyReceived`} label="" type="number" />
                                </TableCell>
                                <TableCell>
                                  <FormTextField name={`items.${index}.receivedQuantity`} label="" type="number" />
                                </TableCell>
                                <TableCell>
                                  <FormTextField name={`items.${index}.unitPrice`} label="" type="number" />
                                </TableCell>
                                <TableCell>
                                  <FormSelect name={`items.${index}.taxPercent`} label="" options={taxPercentOptions} />
                                </TableCell>
                                <TableCell>
                                  <BatchSerialCell index={index} methods={methods} product={productsByCode[watch(`items.${index}.productCode`)]} onOpen={(mode) => setBatchDialog({ index, mode })} />
                                </TableCell>
                                <TableCell sx={{ whiteSpace: 'nowrap' }}>{rowAmount.toFixed(2)}</TableCell>
                                <TableCell>
                                  <IconButton
                                    type="button"
                                    size="small"
                                    color="error"
                                    onClick={() => removeItem(index)}
                                    disabled={fields.length <= 1}
                                    aria-label="remove item"
                                  >
                                    <DeleteIcon fontSize="small" />
                                  </IconButton>
                                </TableCell>
                              </TableRow>
                            );
                          })}
                        </TableBody>
                      </Table>
                    </TableContainer>
                    )}
                  </CardContent>
                </Card>
              </fieldset>

              <Card variant="outlined">
                <CardContent sx={{ p: { xs: 2, sm: 3 } }}>
                  <fieldset disabled={readOnly} style={{ border: 0, padding: 0, margin: 0, minWidth: 0, width: '100%', display: 'block' }}>
                    <Grid container spacing={3}>
                      <Grid item xs={12} md={4}>
                        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1 }}>Terms & Conditions</Typography>
                        <FormTextField name="termsConditions" label="" placeholder="Enter terms and conditions" multiline rows={6} />
                      </Grid>

                      <Grid item xs={12} md={4}>
                        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1 }}>Attachments</Typography>
                        <Box
                          onDragOver={(e) => e.preventDefault()}
                          onDrop={(e) => { e.preventDefault(); handleFile(e.dataTransfer.files?.[0]); }}
                          sx={{
                            border: '1px dashed', borderColor: 'divider', borderRadius: 1.5,
                            p: 3, textAlign: 'center', color: 'text.secondary',
                          }}
                        >
                          <UploadFileIcon sx={{ mb: 1 }} />
                          <Typography variant="body2" sx={{ mb: 1 }}>Drag and drop files here</Typography>
                          <Typography variant="body2" sx={{ mb: 1 }}>or</Typography>
                          <Button component="label" variant="outlined" size="small">
                            Browse Files
                            <input type="file" hidden onChange={(e) => handleFile(e.target.files?.[0])} />
                          </Button>
                          <Typography variant="caption" display="block" sx={{ mt: 1 }}>Supported formats: PDF, JPG, PNG (Max. 5MB)</Typography>
                          {watch('attachmentName') && (
                            <Chip
                              sx={{ mt: 1.5 }}
                              size="small"
                              label={watch('attachmentName')}
                              onDelete={() => setValue('attachmentName', '')}
                            />
                          )}
                        </Box>
                      </Grid>

                      <Grid item xs={12} md={4}>
                        <DocumentTotalsPanel totals={totals} interState={interState} discountField={null} />
                      </Grid>
                    </Grid>
                  </fieldset>

                    <Stack
                      direction={{ xs: 'column', sm: 'row' }}
                      spacing={1.5}
                      justifyContent={{ xs: 'stretch', sm: 'flex-end' }}
                      sx={{ mt: 3 }}
                    >
                      {/* Copy From sits immediately left of Cancel and stays
                          disabled until a Supplier is chosen — the dialog it
                          opens lists that supplier's purchase orders, so with
                          no supplier there is nothing for it to show. Hidden
                          in view mode, where nothing is being filled in. */}
                      {!readOnly && (
                        poValue ? (
                          <Button
                            fullWidth={isMobile}
                            type="button"
                            variant="outlined"
                            color="inherit"
                            startIcon={<CloseIcon />}
                            onClick={clearOrder}
                            disabled={creating || updating}
                          >
                            Clear Copied Order
                          </Button>
                        ) : (
                          <Button
                            fullWidth={isMobile}
                            type="button"
                            variant="outlined"
                            startIcon={<ContentCopyOutlinedIcon />}
                            onClick={() => setCopyFromOpen(true)}
                            disabled={!watch('supplier') || creating || updating}
                          >
                            Copy From
                          </Button>
                        )
                      )}
                      <Button fullWidth={isMobile} type="button" variant="outlined" color="inherit" startIcon={<CloseIcon />} onClick={backToList} disabled={creating || updating}>
                        Cancel
                      </Button>
                      {!readOnly && (
                        <>
                          <Button
                            fullWidth={isMobile}
                            variant="outlined"
                            type="button"
                            onClick={() => submitWithStatus('Draft')}
                            disabled={creating || updating}
                          >
                            Save as Draft
                          </Button>
                          <Button
                            fullWidth={isMobile}
                            variant="contained"
                            type="button"
                            onClick={() => submitWithStatus('Open')}
                            disabled={creating || updating}
                          >
                            {editingRow ? 'Update GRN' : 'Save GRN'}
                          </Button>
                        </>
                      )}
                    </Stack>
                  </CardContent>
                </Card>

                {batchDialog && batchDialog.index < fields.length && (
                  <BatchSerialSetupDialog
                    open
                    onClose={() => setBatchDialog(null)}
                    mode={batchDialog.mode}
                    readOnly={readOnly}
                    docNo={editingRow?.grnNo}
                    itemNumber={watch(`items.${batchDialog.index}.productCode`)}
                    itemDescription={watch(`items.${batchDialog.index}.productName`)}
                    warehouseCode={watch('warehouse')}
                    warehouseName={(branchWarehouseOptions.find((w) => w.value === watch('warehouse')) || {}).label}
                    totalNeeded={Number(watch(`items.${batchDialog.index}.receivedQuantity`)) || 0}
                    value={watch(`items.${batchDialog.index}.${batchDialog.mode === 'Batch' ? 'batches' : 'serials'}`)}
                    onSave={(rows) => setValue(
                      `items.${batchDialog.index}.${batchDialog.mode === 'Batch' ? 'batches' : 'serials'}`,
                      rows,
                      { shouldValidate: true }
                    )}
                  />
                )}
              </>
            );
          }}
        </AppForm>
        </RouteMapContextMenu>
      ) : (
        <Card variant="outlined">
          <CardContent sx={{ p: 0 }}>
            <Stack
              direction={{ xs: 'column', md: 'row' }}
              alignItems={{ xs: 'stretch', md: 'center' }}
              justifyContent="space-between"
              flexWrap="wrap"
              gap={1.5}
              sx={{ px: { xs: 2, sm: 3 }, pt: 2.5, pb: 1.5 }}
            >
              <Typography variant="subtitle1" fontWeight={700}>Purchase GRN List</Typography>
              <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.5} flexWrap="wrap" useFlexGap sx={{ width: { xs: '100%', md: 'auto' } }}>
                <TableSearchFilter table={table} placeholder="Search by GRN no., supplier, PO no..." showFilter={false} />
                <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.5} flexWrap="wrap" useFlexGap>
                  <Button
                    variant="outlined"
                    color="inherit"
                    startIcon={<FilterListIcon />}
                    onClick={() => setShowFilters((v) => !v)}
                    sx={{ width: { xs: '100%', sm: 'auto' }, height: 40, whiteSpace: 'nowrap' }}
                  >
                    Filter
                  </Button>
                  <CanAdd>
                    <Button
                      variant="contained"
                      startIcon={<AddIcon />}
                      endIcon={<ArrowDropDownIcon />}
                      onClick={openCreate}
                      sx={{ width: { xs: '100%', sm: 'auto' }, height: 40, whiteSpace: 'nowrap' }}
                    >
                      Create GRN
                    </Button>
                  </CanAdd>
                </Stack>
              </Stack>
            </Stack>

            <Collapse in={showFilters} unmountOnExit>
            <Box sx={{ px: { xs: 2, sm: 3 }, pb: 2 }}>
              <FormGrid columns={5} singleColumnOnMobile>
                <FilterAutocomplete
                  label="Supplier"
                  allLabel="All Suppliers"
                  options={supplierOptions}
                  value={supplierFilter}
                  onChange={(v) => { setSupplierFilter(v); setPage(0); }}
                />
                <Autocomplete
                  size="small"
                  options={STATUS_FILTERS}
                  value={statusFilter}
                  onChange={(_e, v) => { setStatusFilter(v || 'All Status'); setPage(0); }}
                  disableClearable
                  renderInput={(params) => <TextField {...params} label="Status" InputLabelProps={{ shrink: true }} />}
                />
                <TextField
                  size="small"
                  fullWidth
                  label="Date Range"
                  value={dateRangeLabel}
                  onClick={(e) => setDateAnchor(e.currentTarget)}
                  InputProps={{
                    readOnly: true,
                    startAdornment: <InputAdornment position="start"><EventIcon fontSize="small" /></InputAdornment>,
                    endAdornment: (dateFrom || dateTo) ? (
                      <InputAdornment position="end">
                        <IconButton size="small" onClick={(e) => { e.stopPropagation(); setDateFrom(null); setDateTo(null); setPage(0); }}>
                          <CloseIcon fontSize="small" />
                        </IconButton>
                      </InputAdornment>
                    ) : null,
                  }}
                  InputLabelProps={{ shrink: true }}
                  sx={{ cursor: 'pointer' }}
                />
                <TextField
                  size="small"
                  fullWidth
                  label="PO No."
                  value={poFilter}
                  onChange={(e) => { setPoFilter(e.target.value); setPage(0); }}
                  placeholder="Enter PO no."
                  InputLabelProps={{ shrink: true }}
                />
                <TextField
                  size="small"
                  fullWidth
                  label="Reference No."
                  value={refFilter}
                  onChange={(e) => { setRefFilter(e.target.value); setPage(0); }}
                  placeholder="Enter reference no."
                  InputLabelProps={{ shrink: true }}
                />
              </FormGrid>

              <Popover
                open={!!dateAnchor}
                anchorEl={dateAnchor}
                onClose={() => setDateAnchor(null)}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
              >
                <Stack direction="row" spacing={2} sx={{ p: 2 }}>
                  <DatePicker label="From" value={dateFrom} onChange={(v) => { setDateFrom(v); setPage(0); }} slotProps={{ textField: { size: 'small' } }} />
                  <DatePicker label="To" value={dateTo} onChange={(v) => { setDateTo(v); setPage(0); }} slotProps={{ textField: { size: 'small' } }} />
                </Stack>
              </Popover>
              <TableFilterPanel table={table} embedded open />
            </Box>
            </Collapse>

            {checkedIds.length > 0 && (
              <Box sx={{ px: { xs: 2, sm: 3 }, pb: 1.5 }}>
                <Button variant="outlined" color="error" size="small" startIcon={<DeleteIcon />} onClick={removeSelected}>
                  Delete Selected ({checkedIds.length})
                </Button>
              </Box>
            )}

            {isMobile ? (
              <Box sx={{ px: 2, pb: 1 }}>
                {!isLoading && pagedRows.map((row) => (
                  <MobileRecordCard
                    key={row.id}
                    title={row.grnNo}
                    statusChip={<Chip size="small" label={row.status} color={STATUS_COLORS[row.status] || 'default'} variant="outlined" />}
                    fields={[
                      { label: 'Supplier', value: row.supplier || '—' },
                      { label: 'PO No.', value: row.poNo || '—' },
                      { label: 'GRN Date', value: row.receivedDate ? dayjs(row.receivedDate).format('DD/MM/YYYY') : '—' },
                      { label: 'Total Items', value: row.totalItems ?? (row.items?.length || 0) },
                      { label: 'Amount', value: `₹${Number(row.amount).toFixed(2)}` },
                      { label: 'Delivery No.', value: row.deliveryChallanNo || '—' },
                    ]}
                    onEdit={() => handleEdit(row)}
                    onDelete={() => handleDelete(row)}
                  />
                ))}
                {!isLoading && filteredRows.length === 0 && (
                  <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>No GRNs found</Typography>
                )}
              </Box>
            ) : (
              <ScrollableTableContainer>
                <Table size="small" stickyHeader>
                  <TableHead>
                    <TableRow>
                      <SortableHeaderCell field="id" sort={table.sort} onSort={table.toggleSort} padding="checkbox">
                        <Checkbox
                          size="small"
                          checked={pagedRows.length > 0 && pagedRows.every((r) => checkedIds.includes(r.id))}
                          indeterminate={pagedRows.some((r) => checkedIds.includes(r.id)) && !pagedRows.every((r) => checkedIds.includes(r.id))}
                          onChange={(e) => {
                            const ids = pagedRows.map((r) => r.id);
                            setCheckedIds((prev) => e.target.checked
                              ? Array.from(new Set([...prev, ...ids]))
                              : prev.filter((c) => !ids.includes(c)));
                          }}
                        />
                      </SortableHeaderCell>
                      <TableCell width={40}>#</TableCell>
                      <SortableHeaderCell field="grnNo" sort={table.sort} onSort={table.toggleSort}>GRN No.</SortableHeaderCell>
                      <SortableHeaderCell field="supplier" sort={table.sort} onSort={table.toggleSort}>Supplier</SortableHeaderCell>
                      <SortableHeaderCell field="poNo" sort={table.sort} onSort={table.toggleSort}>PO No.</SortableHeaderCell>
                      <SortableHeaderCell field="receivedDate" sort={table.sort} onSort={table.toggleSort}>GRN Date</SortableHeaderCell>
                      <SortableHeaderCell field="totalItems" sort={table.sort} onSort={table.toggleSort}>Total Items</SortableHeaderCell>
                      <SortableHeaderCell field="amount" sort={table.sort} onSort={table.toggleSort}>Amount (₹)</SortableHeaderCell>
                      <SortableHeaderCell field="status" sort={table.sort} onSort={table.toggleSort}>Status</SortableHeaderCell>
                      <SortableHeaderCell field="deliveryChallanNo" sort={table.sort} onSort={table.toggleSort}>Delivery No.</SortableHeaderCell>
                      <TableCell align="right">Action</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {!isLoading && pagedRows.map((row, i) => (
                      <TableRow key={row.id} hover>
                        <TableCell padding="checkbox">
                          <Checkbox
                            size="small"
                            checked={checkedIds.includes(row.id)}
                            onChange={() => setCheckedIds((prev) => prev.includes(row.id) ? prev.filter((c) => c !== row.id) : [...prev, row.id])}
                          />
                        </TableCell>
                        <TableCell>{page * pageSize + i + 1}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.grnNo}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.supplier || '—'}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.poNo || '—'}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.receivedDate ? dayjs(row.receivedDate).format('DD/MM/YYYY') : '—'}</TableCell>
                        <TableCell>{row.totalItems ?? (row.items?.length || 0)}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{Number(row.amount).toFixed(2)}</TableCell>
                        <TableCell>
                          <Chip size="small" label={row.status} color={STATUS_COLORS[row.status] || 'default'} variant="outlined" />
                        </TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.deliveryChallanNo || '-'}</TableCell>
                        <TableCell align="right">
                          <Stack direction="row" spacing={0.5} justifyContent="flex-end">
                            <Tooltip title="View">
                              <IconButton size="small" onClick={() => handleView(row)} aria-label="view">
                                <VisibilityOutlinedIcon fontSize="small" />
                              </IconButton>
                            </Tooltip>
                            <RouteMapButton flow="purchase" type="grn" docNo={row.grnNo} />
                            <Tooltip title="Print">
                              <IconButton size="small" onClick={() => handlePrint(row)} aria-label="print">
                                <PrintOutlinedIcon fontSize="small" />
                              </IconButton>
                            </Tooltip>
                            <IconButton
                              size="small"
                              onClick={(e) => { setRowMenuAnchor(e.currentTarget); setRowMenuTarget(row); }}
                              aria-label="more actions"
                            >
                              <MoreVertIcon fontSize="small" />
                            </IconButton>
                          </Stack>
                        </TableCell>
                      </TableRow>
                    ))}
                    {!isLoading && filteredRows.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={10}>
                          <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>No GRNs found</Typography>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </ScrollableTableContainer>
            )}

            <Menu anchorEl={rowMenuAnchor} open={!!rowMenuAnchor} onClose={() => setRowMenuAnchor(null)}>
              <CanEdit>
                <MenuItem onClick={() => handleEdit(rowMenuTarget)}>
                  <ListItemIcon><EditIcon fontSize="small" /></ListItemIcon>
                  <ListItemText>Edit</ListItemText>
                </MenuItem>
              </CanEdit>
              <CanDelete>
                <MenuItem onClick={() => handleDelete(rowMenuTarget)}>
                  <ListItemIcon><DeleteIcon fontSize="small" color="error" /></ListItemIcon>
                  <ListItemText>Delete</ListItemText>
                </MenuItem>
              </CanDelete>
            </Menu>

            <EntityListPagination total={filteredRows.length} page={page} onChange={setPage} pageSize={pageSize} onPageSizeChange={(v) => { setPageSize(v); setPage(0); }} />
          </CardContent>
        </Card>
      )}
    </Box>
  );
}

// Isolated so the per-row product-select auto-fill effect only re-runs for
// the row whose product actually changed, not every row on every keystroke.
// Both the Product Code and Product Name columns are selects over the same
// underlying items.{index}.productCode field — Product Code lists codes,
// Product Name lists names, and picking either fills the rest of the row from
// the product master.
//
// Selecting a PO pre-fills these rows (see the poNo effect above, which calls
// replaceItems), but the user can still change them: a delivery does not
// always match its order, and a GRN can be raised without a PO at all.
function ProductCell({ index, methods, options, products, label = '', placeholder = 'Select product', disabled = false, multiline = false, sx }) {
  const { watch, setValue } = methods;
  const productCodeValue = watch(`items.${index}.productCode`);
  const prevValue = useRef(productCodeValue);

  useEffect(() => {
    if (productCodeValue !== prevValue.current) {
      const found = (products || []).find((p) => p.productCode === productCodeValue);
      if (found) {
        setValue(`items.${index}.productName`, found.productName, { shouldValidate: true });
        setValue(`items.${index}.description`, found.productName, { shouldValidate: true });
        setValue(`items.${index}.hsnCode`, found.hsnCode || '', { shouldValidate: true });
        setValue(`items.${index}.uom`, found.uom || '', { shouldValidate: true });
        setValue(`items.${index}.taxPercent`, found.taxRate != null ? Number(found.taxRate) : 0, { shouldValidate: true });
        setValue(`items.${index}.unitPrice`, found.costPrice != null ? Number(found.costPrice) : 0, { shouldValidate: true });
      }
      prevValue.current = productCodeValue;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [productCodeValue]);

  return <FormSelect name={`items.${index}.productCode`} label={label} placeholder={placeholder} options={options} disabled={disabled} multiline={multiline} sx={sx} />;
}

// Shows nothing for a None-tracked (or unrecognised) product — the column
// only means something once Product Master's Manage Item By is Batch or
// Serial for the row's selected product. Otherwise a button that opens the
// matching setup dialog, labelled with how much of the line is allocated so
// far so an incomplete line is visible without opening it.
function BatchSerialCell({ index, methods, product, onOpen }) {
  const { watch } = methods;
  const trackingMode = product?.manageItemBy;
  if (trackingMode !== 'Batch' && trackingMode !== 'Serial') {
    return <Typography variant="caption" color="text.secondary">—</Typography>;
  }
  const needed = Number(watch(`items.${index}.receivedQuantity`)) || 0;
  const batches = watch(`items.${index}.batches`) || [];
  const serials = watch(`items.${index}.serials`) || [];
  const allocated = trackingMode === 'Batch'
    ? batches.reduce((sum, b) => sum + (Number(b.quantity) || 0), 0)
    : serials.length;
  const complete = needed > 0 && Math.abs(allocated - needed) < 0.005;

  return (
    <Button
      type="button"
      size="small"
      variant="outlined"
      color={complete ? 'success' : 'warning'}
      startIcon={<Inventory2OutlinedIcon fontSize="small" />}
      onClick={() => onOpen(trackingMode)}
      sx={{ whiteSpace: 'nowrap' }}
    >
      {trackingMode}: {allocated}/{needed}
    </Button>
  );
}
