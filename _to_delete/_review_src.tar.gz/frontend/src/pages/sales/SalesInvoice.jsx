import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Box, Typography, Button, Card, CardContent, Stack, TextField, InputAdornment, Table,
  TableBody, TableCell, TableContainer, TableHead, TableRow, Chip, IconButton, Menu, MenuItem,
  ListItemIcon, ListItemText, Checkbox, Autocomplete, Popover, Grid, Tooltip,
  Collapse, CircularProgress,
} from '@mui/material';
import { useFieldArray } from 'react-hook-form';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import dayjs from 'dayjs';
import ReceiptOutlinedIcon from '@mui/icons-material/ReceiptOutlined';
import AddIcon from '@mui/icons-material/Add';
import CloseIcon from '@mui/icons-material/Close';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import SearchIcon from '@mui/icons-material/Search';
import FilterListIcon from '@mui/icons-material/FilterList';
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import PrintOutlinedIcon from '@mui/icons-material/PrintOutlined';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import EditIcon from '@mui/icons-material/EditOutlined';
import DeleteIcon from '@mui/icons-material/DeleteOutline';
import EventIcon from '@mui/icons-material/Event';
import AppForm, { FormGrid, FormSubmitButton } from '../../components/form/AppForm';
import FormTextField from '../../components/form/FormTextField';
import FormSelect from '../../components/form/FormSelect';
import FormDatePicker from '../../components/form/FormDatePicker';
import EntityHeaderCard from '../../components/common/EntityHeaderCard';
import CompanyBadge from '../../components/common/CompanyBadge';
import EntityListPagination from '../../components/data-display/EntityListPagination';
import FilterAutocomplete from '../../components/data-display/FilterAutocomplete';
import MobileRecordCard from '../../components/data-display/MobileRecordCard';
import MobileItemCard from '../../components/data-display/MobileItemCard';
import { useIsMobileListView } from '../../components/data-display/useIsMobileListView';
import useDragScroll from '../../components/data-display/useDragScroll';
import { useNotify } from '../../components/feedback/NotificationProvider';
import { applyServerErrors } from '../../lib/formErrors';
import { useConfirm } from '../../components/feedback/ConfirmationDialog';
import { salesInvoiceSchema, SALES_INVOICE_STATUS_OPTIONS, SALES_INVOICE_PAYMENT_STATUS_OPTIONS, ENQUIRY_SOURCE_OPTIONS } from '../../lib/validation/salesSchemas';
import { buildDocument, round2, isInterState } from '../../lib/documentTotals';
import DocumentTotalsPanel from '../../components/form/DocumentTotalsPanel';
import { CURRENCY_OPTIONS, PAYMENT_TERMS_OPTIONS } from '../../lib/validation/partnerSchemas';
import { getStateOptions } from '../../lib/constants/locations';
import { salesInvoiceApi, deliveryChallanApi, salesReturnApi, salesOrderApi, customerApi, productApi, salesEmployeeApi, branchApi, taxCodeApi, houseBankApi } from '../../features/resources';
import { productOptionsFor, PRODUCT_USAGE } from '../../lib/productUsage';
import { buildTaxPercentOptions } from '../../lib/taxCodeOptions';
import { hoverExpandColumnSx, itemColumnBaseWidth } from '../../lib/columnWidth';
import { useWarehouseOptions } from '../../lib/useWarehouseOptions';
import { useGetCompanyDetailsQuery } from '../../features/company/companyDetailsApi';
import DocumentNoField from '../../components/form/DocumentNoField';
import SalesInvoicePrintable from '../../components/print/SalesInvoicePrintable';
import useTableFeatures from '../../components/data-display/useTableFeatures';
import TableSearchFilter from '../../components/data-display/TableSearchFilter';
import SortableHeaderCell from '../../components/data-display/SortableHeaderCell';
import ScrollableTableContainer, { dragScrollbarSx } from '../../components/data-display/ScrollableTableContainer';

import { CanAdd, CanEdit, CanDelete } from '../../components/common/PermissionGate';
import TableFilterPanel from '../../components/data-display/TableFilterPanel';
import RouteMapButton from '../../components/common/RouteMapButton';
import RouteMapContextMenu from '../../components/common/RouteMapContextMenu';
import ContentCopyOutlinedIcon from '@mui/icons-material/ContentCopyOutlined';
import CopyFromDocumentDialog from '../../components/common/CopyFromDocumentDialog';

// A sales invoice can be raised off either step of the chain above it: the
// Sales Order (billed before or without a despatch) or the Delivery Challan
// (billed against what actually shipped). Copy From therefore asks which one
// first, then opens the matching Find dialog. Each source gets its own columns
// because each document names things differently.
//
// "Due Date" on the order reads off its `deliveryDate` — a sales order has no
// `dueDate` of its own, and the date it is due is the date it promised
// delivery.
const SALES_ORDER_COPY_COLUMNS = [
  { field: 'orderNo', headerName: 'Order No', nowrap: true },
  { field: 'customer', headerName: 'Customer Name' },
  { field: 'deliveryDate', headerName: 'Due Date', type: 'date' },
  { field: 'remarks', headerName: 'Comments', type: 'optional' },
];

const CHALLAN_COPY_COLUMNS = [
  { field: 'challanNo', headerName: 'Delivery No', nowrap: true },
  { field: 'customer', headerName: 'Customer Name' },
  { field: 'deliveryDate', headerName: 'Delivery Date', type: 'date' },
  { field: 'remarks', headerName: 'Comments', type: 'optional' },
];
const PLACE_OF_SUPPLY_OPTIONS = getStateOptions('India');

const emptyItem = { productCode: '', productName: '', description: '', hsnCode: '', uom: '', quantity: 1, unitPrice: 0, discountPercent: 0, taxPercent: 18 };

const DEFAULT_TERMS = [
  '1. Goods once sold will not be taken back.',
  '2. Payment to be made within the payment terms mentioned.',
  '3. All disputes are subject to Bangalore jurisdiction.',
].join('\n');

function getEmptyValues() {
  return {
    invoiceNo: '', branch: '', customer: '', invoiceDate: new Date(), orderNo: '', orderDate: null,
    deliveryChallanNo: '', challanDate: null, dueDate: null,
    warehouse: '',
    currency: 'INR', paymentTerms: '', salesPerson: '', source: '', placeOfSupply: '',
    billingAddress: '', shippingAddress: '', remarks: '', termsConditions: DEFAULT_TERMS,
    discountPercent: 0, status: 'Draft', paymentStatus: 'Unpaid',
    items: [{ ...emptyItem }],
  };
}

// Totals come from the shared engine in lib/documentTotals.js, which the
// backend mirrors exactly — the figures shown here while editing are the
// figures that get saved. Each page used to carry its own copy of this
// arithmetic and the copies had drifted apart; this document in particular
// used to hard-code CGST and SGST at 9% each regardless of what the goods
// actually attract.
//
// `interState` must be passed through rather than defaulted: the server
// decides CGST/SGST vs IGST by comparing this document's Place of Supply
// against the company's registered state, and for a long time this page
// never passed the flag at all — so an inter-state invoice displayed a
// CGST/SGST split while the record it saved held IGST.
//
// `grandTotal` and `discount` are kept in the returned shape because the
// totals panel below reads those names.
function computeTotals(items, discountPercent, interState = false) {
  const { totals } = buildDocument(items, discountPercent, {
    interState,
    roundOff: true,
  });
  return {
    ...totals,
    discount: round2(totals.subtotal - totals.taxableAmount),
    grandTotal: totals.amount,
  };
}

function rowToFormValues(row) {
  return {
    invoiceNo: row.invoiceNo, branch: row.branch || '', customer: row.customer || '', invoiceDate: row.invoiceDate,
    orderNo: row.orderNo || '', orderDate: row.orderDate || null,
    deliveryChallanNo: row.deliveryChallanNo || '', challanDate: row.challanDate || null, dueDate: row.dueDate,
    warehouse: row.warehouse || '',
    currency: row.currency || 'INR', paymentTerms: row.paymentTerms || '', salesPerson: row.salesPerson || '',
    source: row.source || '',
    placeOfSupply: row.placeOfSupply || '', billingAddress: row.billingAddress || '', shippingAddress: row.shippingAddress || '',
    remarks: row.remarks || '', termsConditions: row.termsConditions || '',
    discountPercent: row.discountPercent != null ? Number(row.discountPercent) : 0,
    status: row.status || 'Draft', paymentStatus: row.paymentStatus || 'Unpaid',
    items: (row.items && row.items.length ? row.items : [{ ...emptyItem }]).map((i) => ({
      productCode: i.productCode || '', productName: i.productName || '', description: i.description || '',
      hsnCode: i.hsnCode || '', uom: i.uom || '',
      quantity: i.quantity != null ? Number(i.quantity) : 1,
      unitPrice: i.unitPrice != null ? Number(i.unitPrice) : 0,
      discountPercent: i.discountPercent != null ? Number(i.discountPercent) : 0,
      taxPercent: i.taxPercent != null ? Number(i.taxPercent) : 18,
    })),
  };
}

const PAGE_SIZE = 10;
const STATUS_FILTERS = ['All Status', ...SALES_INVOICE_STATUS_OPTIONS];
const PAYMENT_STATUS_FILTERS = ['All Payment Status', ...SALES_INVOICE_PAYMENT_STATUS_OPTIONS];

const STATUS_COLORS = { Draft: 'default', Sent: 'info', Paid: 'success', Overdue: 'error', Cancelled: 'error' };
const PAYMENT_STATUS_COLORS = { Unpaid: 'error', 'Partially Paid': 'warning', Paid: 'success' };

export default function SalesInvoice({ openDocNo } = {}) {
  const notify = useNotify();
  const confirmDialog = useConfirm();
  const isMobile = useIsMobileListView();
  const itemScrollRef = useDragScroll();
  const { data: invoices, isLoading } = salesInvoiceApi.useList();
  const { data: deliveryChallans } = deliveryChallanApi.useList();
  // Needed to know which challans have already had a Sales Return raised
  // against them — see copyableChallans below.
  const { data: salesReturns } = salesReturnApi.useList();
  const { data: salesOrders } = salesOrderApi.useList();
  const { data: customers } = customerApi.useList();
  const { data: products } = productApi.useList();
  const { data: salesEmployees } = salesEmployeeApi.useList();
  const { data: branches } = branchApi.useList();
  // Warehouse master, for validating a warehouse still belongs to the branch
  // when the branch changes — see the effect in the form body.
  const { warehouses } = useWarehouseOptions();
  const { data: taxCodes } = taxCodeApi.useList();
  const taxPercentOptions = useMemo(() => buildTaxPercentOptions(taxCodes), [taxCodes]);
  // The printed invoice's "Company's Bank Details" block — the first Active
  // house bank, so the details are maintained in the House Bank master rather
  // than hardcoded into the print template.
  const { data: houseBanks } = houseBankApi.useList();
  const printHouseBank = useMemo(
    () => (houseBanks || []).find((b) => b.status === 'Active') || null,
    [houseBanks]
  );
  const { data: company } = useGetCompanyDetailsQuery();
  const [create, { isLoading: creating }] = salesInvoiceApi.useCreate();
  const [update, { isLoading: updating }] = salesInvoiceApi.useUpdate();
  const [remove] = salesInvoiceApi.useDelete();

  const customerOptions = (customers || []).map((c) => ({ label: c.customerName, value: c.customerName }));
  const salesPersonOptions = (salesEmployees || []).map((s) => ({ label: s.employeeName, value: s.employeeName }));
  // Sales orders and delivery challans are no longer offered as dropdowns on
  // the form — they are picked through the Copy From dialogs, which scope
  // their lists to the selected customer. Those dialogs take the raw record
  // lists.
  const sourceOptions = ENQUIRY_SOURCE_OPTIONS.map((s) => ({ label: s, value: s }));
  const branchOptions = (branches || []).map((b) => ({ label: b.branchName, value: b.branchName }));

  // View toggles between the invoice list and the full-page Create/Edit
  // form — same page, no dialog/popup, per the standard CRUD page template.
  const [view, setView] = useState('list');
  const [editingRow, setEditingRow] = useState(null);

  // Only products flagged for the sales flow on Product Master are offered
  // here — see lib/productUsage.js. `products` itself stays unfiltered below,
  // because the line lookups (price, tax, UOM, batch/serial mode) must still
  // resolve a product this document already names even if it has since been
  // re-flagged; passing the saved lines' codes as `keepCodes` is what keeps
  // reopening an existing document from silently blanking its own rows.
  const selectableProducts = productOptionsFor(
    products,
    PRODUCT_USAGE.SALES,
    (editingRow?.items || []).map((i) => i.productCode)
  );
  const productCodeOptions = selectableProducts.map((p) => ({ label: p.productCode, value: p.productCode }));
  const productNameOptions = selectableProducts.map((p) => ({ label: p.productName, value: p.productCode }));
  const [readOnly, setReadOnly] = useState(false);
  const [formKey, setFormKey] = useState(0);
  // Copy From. Two pieces of state because it is a two-step control: the
  // button opens a source menu (anchored to it), and the chosen source then
  // opens the matching Find dialog. Both live at page level rather than inside
  // AppForm's render prop so remounting the form on formKey change can't leave
  // a menu or dialog orphaned open over a freshly reset form.
  const [copyFromAnchor, setCopyFromAnchor] = useState(null);
  const [copyFromSource, setCopyFromSource] = useState(null); // 'order' | 'challan' | null

  // A delivery challan can be picked here for as long as ANY of its lines
  // still has quantity that hasn't gone back on a return — quantity-aware,
  // not merely "has this challan ever had a return raised against it":
  // shipping 10 and returning 1-9 still leaves something to invoice, and
  // only returning the full 10 empties it out. (A return itself can only be
  // raised before the challan is invoiced — see assertReturnAllowed in
  // utils/routeMap.js — so this is the matching guard on the other side of
  // that same rule.)
  //
  // Returned-so-far is summed per product code across every non-cancelled
  // Sales Return raised against the challan — a challan can be returned
  // against more than once over time, and each one only carries its own
  // increment.
  const returnedByChallanProduct = useMemo(() => {
    const totals = new Map(); // "<challanNo>::<productCode>" -> quantity returned
    (salesReturns || [])
      .filter((r) => r.status !== 'Cancelled' && r.challanNo)
      .forEach((r) => {
        (r.items || []).forEach((item) => {
          if (!item.productCode) return;
          const key = `${r.challanNo}::${item.productCode}`;
          totals.set(key, (totals.get(key) || 0) + (Number(item.returnQuantity) || 0));
        });
      });
    return totals;
  }, [salesReturns]);

  // A challan with no lines at all is left alone (nothing to judge it by)
  // rather than being treated as fully returned.
  const fullyReturnedChallanNos = useMemo(() => {
    const fully = new Set();
    (deliveryChallans || []).forEach((c) => {
      const items = c.items || [];
      if (!items.length) return;
      const somethingRemains = items.some((item) => {
        const delivered = Number(item.quantity) || 0;
        const returned = returnedByChallanProduct.get(`${c.challanNo}::${item.productCode}`) || 0;
        return delivered - returned > 0.005;
      });
      if (!somethingRemains) fully.add(c.challanNo);
    });
    return fully;
  }, [deliveryChallans, returnedByChallanProduct]);

  // What the Copy From > Delivery Challan dialog is allowed to offer. A challan
  // whose every line has already come back on a sales return has nothing left
  // to bill, so copying from it could only produce an invoice for goods the
  // customer no longer holds.
  //
  // This used to build the options for a challan dropdown; it is now the
  // record list handed to the dialog. The "already on the record being edited
  // stays selectable" case the dropdown needed is gone with it — the field is
  // read-only now, so an existing invoice's own link is simply displayed and
  // never has to survive a filter to keep showing.
  const copyableChallans = useMemo(
    () => (deliveryChallans || []).filter((c) => !fullyReturnedChallanNos.has(c.challanNo)),
    [deliveryChallans, fullyReturnedChallanNos]
  );

  const [search, setSearch] = useState('');
  const [customerFilter, setCustomerFilter] = useState(null);
  const [statusFilter, setStatusFilter] = useState('All Status');
  const [paymentStatusFilter, setPaymentStatusFilter] = useState('All Payment Status');
  const [salesPersonFilter, setSalesPersonFilter] = useState(null);
  const [dateFrom, setDateFrom] = useState(null);
  const [dateTo, setDateTo] = useState(null);
  const [dateAnchor, setDateAnchor] = useState(null);
  const [showFilters, setShowFilters] = useState(false);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(PAGE_SIZE);
  const [checkedIds, setCheckedIds] = useState([]);
  const [rowMenuAnchor, setRowMenuAnchor] = useState(null);
  const [rowMenuTarget, setRowMenuTarget] = useState(null);
  const pendingStatusRef = useRef('Draft');

  const rows = invoices || [];

  const baseTableRows = useMemo(() => {
    const q = '';
    return rows.filter((r) => {
      const matchesSearch = !q || [r.invoiceNo, r.orderNo, r.customer].some((v) => String(v || '').toLowerCase().includes(q));
      const matchesCustomer = !customerFilter || r.customer === customerFilter.value;
      const matchesStatus = statusFilter === 'All Status' || r.status === statusFilter;
      const matchesPaymentStatus = paymentStatusFilter === 'All Payment Status' || r.paymentStatus === paymentStatusFilter;
      const matchesSalesPerson = !salesPersonFilter || r.salesPerson === salesPersonFilter.value;
      const id = r.invoiceDate ? dayjs(r.invoiceDate) : null;
      const matchesFrom = !dateFrom || (id && !id.isBefore(dateFrom, 'day'));
      const matchesTo = !dateTo || (id && !id.isAfter(dateTo, 'day'));
      return matchesSearch && matchesCustomer && matchesStatus && matchesPaymentStatus && matchesSalesPerson && matchesFrom && matchesTo;
    });
  }, [rows, customerFilter, statusFilter, paymentStatusFilter, salesPersonFilter, dateFrom, dateTo]);

  // Column definitions drive the global search, the sort icons and the filter
  // popover — see components/data-display/useTableFeatures.js.
  const tableColumns = useMemo(() => ([
    { field: 'id', headerName: 'Select', filter: false, searchable: false },
    { field: 'invoiceNo', headerName: 'Invoice No.', filter: 'text' },
    { field: 'invoiceDate', headerName: 'Invoice Date', filter: 'dateRange', sortValue: (row) => (row.invoiceDate ? new Date(row.invoiceDate).getTime() : null) },
    { field: 'customer', headerName: 'Customer', filter: 'text' },
    { field: 'orderNo', headerName: 'Order No.', filter: 'text' },
    { field: 'dueDate', headerName: 'Due Date', filter: 'dateRange', sortValue: (row) => (row.dueDate ? new Date(row.dueDate).getTime() : null) },
    { field: 'amount', headerName: 'Amount (₹)', filter: 'numberRange', sortValue: (row) => (row.amount == null || row.amount === '' ? null : Number(row.amount)) },
    { field: 'status', headerName: 'Status', filter: 'select' },
    { field: 'paymentStatus', headerName: 'Payment Status', filter: 'select' },
  ]), []);
  const table = useTableFeatures(baseTableRows, tableColumns, { onChange: setPage });
  const filteredRows = table.rows;

  const pagedRows = useMemo(
    () => filteredRows.slice(page * pageSize, page * pageSize + pageSize),
    [filteredRows, page, pageSize]
  );

  const openCreate = () => {
    setEditingRow(null);
    setReadOnly(false);
    setFormKey((k) => k + 1);
    setView('form');
  };

  const backToList = () => {
    setView('list');
    setEditingRow(null);
    setReadOnly(false);
    setCopyFromAnchor(null);
    setCopyFromSource(null);
  };

  const handleView = (row) => {
    setEditingRow(row);
    setReadOnly(true);
    setFormKey((k) => k + 1);
    setView('form');
  };

  // Opened from the Route Map's document preview popup: jump straight into
  // this record's own read-only View, exactly as clicking it in the list
  // would, instead of requiring the user to find and click the row.
  useEffect(() => {
    if (!openDocNo) return;
    if (editingRow && editingRow.invoiceNo === openDocNo) return;
    const match = rows.find((r) => r.invoiceNo === openDocNo);
    if (match) handleView(match);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [openDocNo, rows]);

  const handleEdit = (row) => {
    setEditingRow(row);
    setReadOnly(false);
    setFormKey((k) => k + 1);
    setView('form');
    setRowMenuAnchor(null);
  };

  const handlePrint = (row) => {
    setRowMenuAnchor(null);
    handleView(row);
    setTimeout(() => window.print(), 300);
  };

  const handleDelete = async (row) => {
    setRowMenuAnchor(null);
    const ok = await confirmDialog({
      title: 'Delete sales invoice',
      message: `Are you sure you want to delete "${row.invoiceNo}"? This cannot be undone.`,
      confirmLabel: 'Delete',
      severity: 'error',
    });
    if (!ok) return;
    try {
      await remove(row.id).unwrap();
      notify.success('Sales invoice deleted');
    } catch (err) {
      notify.error(err?.data?.message || 'Delete failed');
    }
  };

  const removeSelected = async () => {
    const ok = await confirmDialog({
      title: 'Delete selected invoices',
      message: `Delete ${checkedIds.length} selected invoice${checkedIds.length > 1 ? 's' : ''}? This cannot be undone.`,
      confirmLabel: 'Delete',
      severity: 'error',
    });
    if (!ok) return;
    try {
      await Promise.all(checkedIds.map((id) => remove(id).unwrap()));
      notify.success('Selected invoices deleted');
      setCheckedIds([]);
    } catch (err) {
      notify.error(err?.data?.message || 'Delete failed');
    }
  };

  const handleSubmit = async (values, formMethods) => {
    const payload = { ...values, status: pendingStatusRef.current };
    try {
      if (editingRow) {
        await update({ id: editingRow.id, ...payload }).unwrap();
        notify.success('Sales invoice updated');
      } else {
        await create(payload).unwrap();
        notify.success('Sales invoice saved');
      }
      backToList();
    } catch (err) {
      notify.error(applyServerErrors(err, formMethods.setError));
    }
  };

  const dateRangeLabel = dateFrom && dateTo
    ? `${dateFrom.format('DD/MM/YYYY')} - ${dateTo.format('DD/MM/YYYY')}`
    : 'Select date range';

  if (openDocNo && (!editingRow || editingRow.invoiceNo !== openDocNo)) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', py: 10 }}>
        <CircularProgress size={28} />
      </Box>
    );
  }

  return (
    <Box>
      <EntityHeaderCard
        icon={<ReceiptOutlinedIcon />}
        title="Sales Invoice"
        subtitle={view === 'form' ? 'Create a new sales invoice.' : 'Manage and track all sales invoices.'}
        rightContent={<CompanyBadge />}
      />

      {view === 'form' ? (
        <RouteMapContextMenu flow="sales" type="invoice" docNo={editingRow?.invoiceNo}>
        <AppForm
          key={formKey}
          schema={salesInvoiceSchema}
          defaultValues={editingRow ? rowToFormValues(editingRow) : getEmptyValues()}
          onSubmit={handleSubmit}
        >
          {(methods) => {
            const { control, watch, setValue } = methods;
            const { fields, append, remove: removeItem, replace: replaceItems } = useFieldArray({ control, name: 'items' });
            const watchedItems = watch('items') || [];

            // A sales invoice with no delivery challan behind it is the
            // document that despatches the goods (see the salesInvoice
            // headerFilter in backend utils/stockLedger.js), so it — and only
            // it — has to name the warehouse they leave from. With a challan
            // this invoice is finance-only.
            const deliveryChallanNo = watch('deliveryChallanNo');
            const isDirectInvoice = !deliveryChallanNo || String(deliveryChallanNo).trim() === '';
            const branch = watch('branch');
            const { options: branchWarehouseOptions } = useWarehouseOptions({
              currentValue: editingRow?.warehouse, branch,
            });

            // Switching branch invalidates a warehouse from the old one.
            // Skipped on first render so loading a record for edit/view does
            // not wipe the value it just loaded.
            const prevBranchRef = useRef(branch);
            useEffect(() => {
              if (prevBranchRef.current === branch) return;
              prevBranchRef.current = branch;
              const allowed = new Set(
                (warehouses || []).filter((w) => !branch || w.branch === branch).map((w) => w.whsCode)
              );
              if (watch('warehouse') && !allowed.has(watch('warehouse'))) setValue('warehouse', '');
              // eslint-disable-next-line react-hooks/exhaustive-deps
            }, [branch]);

            // Product Code / Product Name are sized to the longest value the
            // column actually holds, instead of a fixed width that left almost
            // no room for text once the field's own padding — and, on a select,
            // its clear and dropdown buttons — were subtracted. Short data still
            // sits tight; anything past the cap is revealed on hover as before.
            const productCodeColumnWidth = itemColumnBaseWidth(
              watchedItems.map((i) => i?.productCode), { kind: 'code', field: 'select' },
            );
            const productNameColumnWidth = itemColumnBaseWidth(
              watchedItems.map((i) => i?.productName), { kind: 'name', field: 'select' },
            );
            // Discount % in the totals panel is a header-level discount taken
            // off the sum of the (already line-discounted) item amounts —
            // exactly what the server does with the `discountPercent` it
            // receives.
            //
            // It used to be a read-only mirror of whichever item row was
            // edited last, and computeTotals was called with a hard-coded 0
            // so the mirrored figure wouldn't deduct the line discount twice
            // on screen. But the mirrored figure was still posted, and the
            // server had no way to know it was only meant for display: it
            // applied that percentage on top of line amounts that already had
            // it baked in. A 10% line discount saved an invoice ~10% below
            // the total the user had just approved.
            const discountPercent = watch('discountPercent');
            const interState = isInterState(watch('placeOfSupply'), company?.state);
            const totals = computeTotals(watchedItems, discountPercent, interState);

            const allValues = watch();
            const printCustomerRecord = (customers || []).find((c) => c.customerName === allValues.customer);
            const printSalesEmployeeRecord = (salesEmployees || []).find((s) => s.employeeName === allValues.salesPerson);
            const printOrder = { ...allValues, status: editingRow?.status || 'Draft' };

            const customerValue = watch('customer');
            const prevCustomer = useRef(editingRow ? editingRow.customer : null);
            useEffect(() => {
              if (customerValue !== prevCustomer.current) {
                const found = (customers || []).find((c) => c.customerName === customerValue);
                if (found) {
                  setValue('billingAddress', found.billingAddress || '', { shouldValidate: true });
                  setValue('shippingAddress', found.shippingAddress || '', { shouldValidate: true });
                  if (found.paymentTerms) setValue('paymentTerms', found.paymentTerms, { shouldValidate: true });
                  if (found.state) setValue('placeOfSupply', found.state, { shouldValidate: true });
                }
                prevCustomer.current = customerValue;
              }
              // eslint-disable-next-line react-hooks/exhaustive-deps
            }, [customerValue]);

            // Copy From > Delivery Challan pulls every field that exists
            // on that challan across onto the invoice — order no.,
            // challan date, sales person, billing/shipping address, terms &
            // conditions, remarks, and item lines (product, HSN/SAC, unit,
            // quantity, unit price).
            //
            // Those fields used to be marked `disabled` on the grounds that
            // they aren't invoice-specific data. But the Delivery Challan is
            // optional, and locking them made a direct invoice impossible to
            // write: Customer and Sales Person are required yet unfillable,
            // and "Add Item" produced a row with no typeable product,
            // quantity or rate. They are editable now — the challan lookup
            // still pre-fills them, it just no longer forbids a correction or
            // a from-scratch invoice. Also syncs the customer-effect's own
            // "previous value" ref so it doesn't re-fire and clobber the
            // values just set here from the challan's snapshot (same class
            // of bug fixed on Purchase Order's Reference/Contact Person).
            //
            // The customer is not copied back — the dialog was already
            // filtered by it, so it can only hold the value it already has.
            //
            // This used to run as an effect watching the Delivery Challan No.
            // dropdown. It is a plain function now, called only from the
            // dialog's Choose button: an effect keyed on a form value also
            // fires when that value is restored on edit or reset, which is why
            // it needed the prevChallan bookkeeping to tell "user picked a
            // challan" apart from "form loaded". An explicit call has no such
            // ambiguity.
            const applyChallan = (found) => {
                if (found) {
                  setValue('deliveryChallanNo', found.challanNo || '', { shouldValidate: true });
                  setValue('branch', found.branch || '', { shouldValidate: true });
                  prevCustomer.current = found.customer || '';
                  setValue('orderNo', found.orderNo || '', { shouldValidate: true });
                  setValue('challanDate', found.challanDate || null, { shouldValidate: true });
                  setValue('salesPerson', found.salesPerson || '', { shouldValidate: true });
                  setValue('billingAddress', found.billingAddress || '', { shouldValidate: true });
                  setValue('shippingAddress', found.shippingAddress || '', { shouldValidate: true });
                  setValue('termsConditions', found.termsConditions || '', { shouldValidate: true });
                  setValue('remarks', found.remarks || '', { shouldValidate: true });
                  const order = (salesOrders || []).find((o) => o.orderNo === found.orderNo);
                  if (order) {
                    setValue('orderDate', order.orderDate || null, { shouldValidate: true });
                    // The Delivery Challan itself carries no currency/source —
                    // those live one level further up, on the Sales Order it
                    // was despatched against. order is already looked up here
                    // for orderDate, so no extra fetch is needed.
                    setValue('currency', order.currency || 'INR', { shouldValidate: true });
                    setValue('source', order.source || '', { shouldValidate: true });
                  }
                  if (found.items && found.items.length) {
                    // Invoice only what the challan shipped MINUS what has
                    // already gone back on a Sales Return against it — pulling
                    // the full delivered quantity would let goods that were
                    // already returned get invoiced anyway.
                    // returnedByChallanProduct is the same per-product return
                    // total the challan dropdown itself is filtered by (see
                    // fullyReturnedChallanNos above), so the two can never
                    // disagree about what's left. A line with nothing
                    // remaining is dropped rather than pulled in at zero — a
                    // zero-quantity line would fail validation anyway.
                    // `line` is captured BEFORE the filter: base_line has to
                    // name the row's position on the challan, not its position
                    // in whatever subset survived the remaining-quantity filter.
                    const remaining = found.items
                      .map((i, n) => {
                        const delivered = i.quantity != null ? Number(i.quantity) : 0;
                        const returned = returnedByChallanProduct.get(`${found.challanNo}::${i.productCode}`) || 0;
                        return { item: i, line: n + 1, qty: round2(delivered - returned) };
                      })
                      .filter(({ qty }) => qty > 0.005);
                    replaceItems(remaining.length
                      ? remaining.map(({ item: i, line, qty }) => ({
                        productCode: i.productCode || '', productName: i.productName || '', description: i.description || '',
                        hsnCode: i.hsnCode || '', uom: i.uom || '',
                        quantity: qty,
                        unitPrice: i.unitPrice != null ? Number(i.unitPrice) : 0,
                        discountPercent: 0,
                        taxPercent: 18,
                        // Copy From: the challan, which is the immediate
                        // source — not the order behind it.
                        baseType: 'Delivery Challan',
                        baseEntry: found.id ?? null,
                        baseNo: found.challanNo || null,
                        baseLine: line,
                      }))
                      : [{ ...emptyItem }]);
                  }
                }
            };

            // Copy From > Sales Order. Billing straight off the order — before
            // anything is despatched, or for a charge that never passes through
            // a challan at all — so the full ordered quantity is pulled and
            // there is no returns arithmetic to do: nothing can have come back
            // on goods that were never delivered.
            //
            // The challan link is cleared, not left as it was: the invoice now
            // references this order directly, and leaving a stale despatch
            // number beside it would claim a provenance the lines no longer
            // have (their baseType/baseNo below name the order).
            const applyOrder = (found) => {
              if (!found) return;
              setValue('orderNo', found.orderNo || '', { shouldValidate: true });
              setValue('deliveryChallanNo', '', { shouldValidate: true });
              setValue('challanDate', null, { shouldValidate: true });
              setValue('branch', found.branch || '', { shouldValidate: true });
              prevCustomer.current = found.customer || '';
              setValue('orderDate', found.orderDate || null, { shouldValidate: true });
              setValue('currency', found.currency || 'INR', { shouldValidate: true });
              setValue('source', found.source || '', { shouldValidate: true });
              setValue('salesPerson', found.salesPerson || '', { shouldValidate: true });
              setValue('billingAddress', found.billingAddress || '', { shouldValidate: true });
              setValue('shippingAddress', found.shippingAddress || '', { shouldValidate: true });
              setValue('termsConditions', found.termsConditions || '', { shouldValidate: true });
              setValue('remarks', found.remarks || '', { shouldValidate: true });
              if (found.items && found.items.length) {
                replaceItems(found.items.map((i, n) => ({
                  productCode: i.productCode || '', productName: i.productName || '', description: i.description || '',
                  hsnCode: i.hsnCode || '', uom: i.uom || '',
                  quantity: i.quantity != null ? Number(i.quantity) : 1,
                  unitPrice: i.unitPrice != null ? Number(i.unitPrice) : 0,
                  discountPercent: i.discountPercent != null ? Number(i.discountPercent) : 0,
                  taxPercent: i.taxPercent != null ? Number(i.taxPercent) : 18,
                  // Copy From: the order, which is the immediate source here —
                  // this invoice was raised against it, not against a despatch.
                  baseType: 'Sales Order',
                  baseEntry: found.id ?? null,
                  baseNo: found.orderNo || null,
                  baseLine: n + 1,
                })));
              }
            };

            // Undo a Copy From: drop both links and the values that came across
            // with them, rather than leaving a stale document's figures sitting
            // in an invoice that no longer claims to reference it.
            //
            // The customer is deliberately NOT cleared. It is the user's own
            // selection — it is what made Copy From available in the first
            // place, and clearing it would close the dialogs off and force a
            // re-pick just to try a different source from the same customer.
            // The addresses stay too: they belong to the customer.
            const challanValue = watch('deliveryChallanNo');
            const orderValue = watch('orderNo');
            const clearSource = () => {
              setValue('deliveryChallanNo', '', { shouldValidate: true });
              setValue('orderNo', '', { shouldValidate: true });
              setValue('challanDate', null, { shouldValidate: true });
              setValue('orderDate', null, { shouldValidate: true });
              setValue('currency', 'INR', { shouldValidate: true });
              setValue('source', '', { shouldValidate: true });
              setValue('salesPerson', '', { shouldValidate: true });
              setValue('termsConditions', '', { shouldValidate: true });
              setValue('remarks', '', { shouldValidate: true });
              replaceItems([{ ...emptyItem }]);
            };

            // Selecting a Payment Terms option ("Net 15", "Net 30", ...)
            // computes Due Date as Invoice Date + that many days —
            // "Immediate" (no number in the label) resolves to the invoice
            // date itself. Also recomputes if Invoice Date is edited
            // afterwards while a term is still selected, so the two stay in
            // sync rather than leaving Due Date pinned to whatever the
            // invoice date happened to be at the moment Payment Terms was
            // picked. Stored the same way FormDatePicker itself stores a
            // pick: a UTC-midnight Date, not a local-time one, so the value
            // that round-trips back through the picker doesn't drift a day
            // depending on the browser's timezone. Only fires on an actual
            // user change to either field, not on initial load of an
            // existing invoice, so it doesn't clobber a due date that was
            // manually adjusted away from the term's default.
            const paymentTermsValue = watch('paymentTerms');
            const invoiceDateValue = watch('invoiceDate');
            const prevPaymentTerms = useRef(editingRow ? editingRow.paymentTerms : null);
            const prevInvoiceDate = useRef(editingRow ? editingRow.invoiceDate : null);
            useEffect(() => {
              const termsChanged = paymentTermsValue !== prevPaymentTerms.current;
              const dateChanged = invoiceDateValue !== prevInvoiceDate.current;
              if (termsChanged || dateChanged) {
                if (paymentTermsValue) {
                  const days = Number(paymentTermsValue.match(/\d+/)?.[0] || 0);
                  const base = invoiceDateValue ? dayjs(invoiceDateValue) : dayjs();
                  const due = base.add(days, 'day');
                  setValue('dueDate', new Date(Date.UTC(due.year(), due.month(), due.date())), { shouldValidate: true });
                }
                prevPaymentTerms.current = paymentTermsValue;
                prevInvoiceDate.current = invoiceDateValue;
              }
              // eslint-disable-next-line react-hooks/exhaustive-deps
            }, [paymentTermsValue, invoiceDateValue]);

            return (
              // minWidth: 0 is required — fieldsets default to min-width: min-content,
              // which lets the wide item table blow out the page width on mobile.
              // The Back to List / Cancel buttons are kept outside the fieldset(s)
              // so they stay clickable in read-only (view) mode -- a native
              // <fieldset disabled> disables every descendant control, buttons
              // included.
              <>
              {/* One dialog component, two configurations — which one is
                  mounted follows the source picked from the Copy From menu. */}
              <CopyFromDocumentDialog
                open={copyFromSource === 'order'}
                onClose={() => setCopyFromSource(null)}
                onChoose={applyOrder}
                documents={salesOrders || []}
                party={customerValue}
                partyField="customer"
                partyLabel="customer"
                title="Find Sales Order"
                columns={SALES_ORDER_COPY_COLUMNS}
                emptyMessage="No sales orders found for"
              />
              <CopyFromDocumentDialog
                open={copyFromSource === 'challan'}
                onClose={() => setCopyFromSource(null)}
                onChoose={applyChallan}
                documents={copyableChallans}
                party={customerValue}
                partyField="customer"
                partyLabel="customer"
                title="Find Sales Delivery"
                columns={CHALLAN_COPY_COLUMNS}
                emptyMessage="No deliveries left to invoice for"
              />
              <Menu
                anchorEl={copyFromAnchor}
                open={Boolean(copyFromAnchor)}
                onClose={() => setCopyFromAnchor(null)}
              >
                <MenuItem onClick={() => { setCopyFromAnchor(null); setCopyFromSource('order'); }}>
                  <ListItemText primary="Sales Order" secondary="Bill against an order" />
                </MenuItem>
                <MenuItem onClick={() => { setCopyFromAnchor(null); setCopyFromSource('challan'); }}>
                  <ListItemText primary="Delivery Challan" secondary="Bill against goods despatched" />
                </MenuItem>
              </Menu>
              <SalesInvoicePrintable
                order={printOrder}
                company={company}
                customerRecord={printCustomerRecord}
                salesEmployeeRecord={printSalesEmployeeRecord}
                houseBank={printHouseBank}
              />
              <Card variant="outlined" sx={{ mb: 2 }}>
                <CardContent sx={{ p: { xs: 2, sm: 3 } }}>
                  <Stack direction="row" alignItems="center" justifyContent="space-between" flexWrap="wrap" gap={1.5} sx={{ mb: 2 }}>
                    <Typography variant="subtitle1" fontWeight={700}>
                      {readOnly ? 'Customer & Invoice Details (View Only)' : 'Customer & Invoice Details'}
                    </Typography>
                    <Button type="button" variant="outlined" color="inherit" startIcon={<ArrowBackIcon />} onClick={backToList}>
                      Back to List
                    </Button>
                  </Stack>

                  <fieldset disabled={readOnly} style={{ border: 0, padding: 0, margin: 0, minWidth: 0, width: '100%', display: 'block' }}>
                    <FormGrid columns={4}>
                      <DocumentNoField documentCode="SI" name="invoiceNo" label="Invoice No. *" placeholder="Enter invoice number" isCreate={!editingRow} />
                      <FormSelect name="branch" label="Branch *" placeholder="Select branch" options={branchOptions} />
                      <FormDatePicker name="invoiceDate" label="Invoice Date *" />
                      {/* Both reference fields are filled only by Copy From —
                          never typed. An invoice's challan/order reference has
                          to be a document that actually exists (the lines carry
                          baseEntry/baseNo back to it, and the server recomputes
                          that document's billing status from this invoice), so
                          a free-text box could only ever produce a dangling
                          link. Both stay blank for a direct invoice with
                          nothing upstream. */}
                      <FormTextField
                        name="deliveryChallanNo"
                        label="Delivery Challan No."
                        placeholder="Use Copy From to select a challan"
                        InputProps={{ readOnly: true }}
                      />
                      <FormDatePicker name="challanDate" label="Delivery Challan Date" />
                      <FormTextField
                        name="orderNo"
                        label="Order No."
                        placeholder="Use Copy From to select an order"
                        InputProps={{ readOnly: true }}
                      />
                      {/* Shown only on the direct path — an invoice with no
                          challan behind it is the document that despatches the
                          goods, so it has to say which warehouse they leave
                          from. With a challan the despatch already took them
                          out of its own fromWarehouse and this invoice moves no
                          stock. Scoped to the selected branch — see
                          lib/useWarehouseOptions.js. */}
                      {isDirectInvoice && (
                        <FormSelect
                          name="warehouse"
                          label="Warehouse *"
                          placeholder={branch ? 'Select warehouse' : 'Select a branch first'}
                          options={branchWarehouseOptions}
                          disabled={!branch}
                        />
                      )}
                      <FormDatePicker name="orderDate" label="Sales Order Date" />
                      <FormSelect name="customer" label="Customer *" placeholder="Select customer" options={customerOptions} />

                      <FormDatePicker name="dueDate" label="Due Date *" />
                      <FormSelect name="paymentTerms" label="Payment Terms" placeholder="Select payment terms" options={PAYMENT_TERMS_OPTIONS} />
                      <FormSelect name="currency" label="Currency *" options={CURRENCY_OPTIONS} />
                      <FormSelect name="placeOfSupply" label="Place of Supply" placeholder="Select state" options={PLACE_OF_SUPPLY_OPTIONS} />
                      <FormSelect name="salesPerson" label="Sales Person *" placeholder="Select sales person" options={salesPersonOptions} />
                      <FormSelect name="source" label="Source" placeholder="Select source" options={sourceOptions} />

                      <FormTextField name="billingAddress" label="Billing Address" placeholder="Auto-filled from challan/customer" multiline rows={3} />
                      <FormTextField name="shippingAddress" label="Shipping Address" placeholder="Auto-filled from challan/customer" multiline rows={3} />
                    </FormGrid>
                  </fieldset>
                </CardContent>
              </Card>

              <fieldset disabled={readOnly} style={{ border: 0, padding: 0, margin: 0, minWidth: 0, width: '100%', display: 'block' }}>
                <Card variant="outlined" sx={{ mb: 2 }}>
                  <CardContent sx={{ p: { xs: 2, sm: 3 } }}>
                    <Stack direction="row" alignItems="center" justifyContent="space-between" flexWrap="wrap" gap={1.5} sx={{ mb: 2 }}>
                      <Typography variant="subtitle1" fontWeight={700}>Item Details</Typography>
                      <Button type="button" variant="outlined" size="small" startIcon={<AddIcon />} onClick={() => append({ ...emptyItem })}>
                        Add Item
                      </Button>
                    </Stack>

                    {isMobile ? (
                      <Box>
                        {fields.map((field, index) => {
                          const qty = Number(watch(`items.${index}.quantity`)) || 0;
                          const price = Number(watch(`items.${index}.unitPrice`)) || 0;
                          const itemDiscount = Number(watch(`items.${index}.discountPercent`)) || 0;
                          const gross = qty * price;
                          const rowAmount = gross - gross * (itemDiscount / 100);
                          return (
                            <MobileItemCard
                              key={field.id}
                              index={index}
                              amount={rowAmount.toFixed(2)}
                              onRemove={() => removeItem(index)}
                              removeDisabled={fields.length <= 1}
                            >
                              <ProductCell index={index} methods={methods} options={productCodeOptions} products={products} label="Product Code *" placeholder="Select product code" />
                              <ProductCell index={index} methods={methods} options={productNameOptions} products={products} label="Product Name" placeholder="Select product name" />
                              <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', columnGap: 1.5, rowGap: 1.5 }}>
                                <FormTextField name={`items.${index}.hsnCode`} label="HSN/SAC" placeholder="4, 6 or 8 digits" digitsOnly maxLength={8} />
                                <FormTextField name={`items.${index}.uom`} label="Unit" placeholder="Unit" />
                                <FormTextField name={`items.${index}.quantity`} label="Quantity *" type="number" />
                                <FormTextField name={`items.${index}.unitPrice`} label="Rate (₹) *" type="number" />
                                <FormTextField name={`items.${index}.discountPercent`} label="Discount (%)" type="number" />
                                <FormSelect name={`items.${index}.taxPercent`} label="Tax (%)" options={taxPercentOptions} />
                              </Box>
                            </MobileItemCard>
                          );
                        })}
                      </Box>
                    ) : (
                    <TableContainer ref={itemScrollRef} sx={{ overflowX: 'auto', WebkitOverflowScrolling: 'touch', cursor: 'grab', ...dragScrollbarSx }}>
                      <Table size="small" sx={{ '& tbody .MuiFormHelperText-root': { display: 'none' } }}>
                        <TableHead>
                          <TableRow>
                            <TableCell width={40}>#</TableCell>
                            <TableCell sx={{ minWidth: productCodeColumnWidth }}>Product Code *</TableCell>
                            <TableCell sx={{ minWidth: productNameColumnWidth }}>Product Name</TableCell>
                            <TableCell sx={{ minWidth: 140 }}>HSN/SAC</TableCell>
                            <TableCell sx={{ minWidth: 110 }}>Unit</TableCell>
                            <TableCell sx={{ minWidth: 110 }}>Quantity *</TableCell>
                            <TableCell sx={{ minWidth: 150 }}>Rate (₹) *</TableCell>
                            <TableCell sx={{ minWidth: 100 }}>Discount (%)</TableCell>
                            <TableCell sx={{ minWidth: 150 }}>Tax (%)</TableCell>
                            <TableCell sx={{ minWidth: 110 }}>Amount (₹)</TableCell>
                            <TableCell width={48} />
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {fields.map((field, index) => {
                            const qty = Number(watch(`items.${index}.quantity`)) || 0;
                            const price = Number(watch(`items.${index}.unitPrice`)) || 0;
                            const itemDiscount = Number(watch(`items.${index}.discountPercent`)) || 0;
                            const gross = qty * price;
                            const rowAmount = gross - gross * (itemDiscount / 100);
                            return (
                              <TableRow key={field.id} sx={{ '& > td': { verticalAlign: 'middle' } }}>
                                <TableCell>{index + 1}</TableCell>
                                <TableCell
                                  sx={hoverExpandColumnSx({
                                    base: productCodeColumnWidth,
                                    value: watch(`items.${index}.productCode`),
                                    max: 420,
                                    field: 'select',
                                  })}
                                >
                                  <ProductCell index={index} methods={methods} options={productCodeOptions} products={products} placeholder="Select product code" multiline />
                                </TableCell>
                                <TableCell
                                  sx={hoverExpandColumnSx({
                                    base: productNameColumnWidth,
                                    value: watch(`items.${index}.productName`),
                                    max: 640,
                                    field: 'select',
                                  })}
                                >
                                  <ProductCell index={index} methods={methods} options={productNameOptions} products={products} placeholder="Select product name" multiline />
                                </TableCell>
                                <TableCell>
                                  <FormTextField name={`items.${index}.hsnCode`} label="" placeholder="HSN/SAC" digitsOnly maxLength={8} />
                                </TableCell>
                                <TableCell>
                                  <FormTextField name={`items.${index}.uom`} label="" placeholder="Unit" />
                                </TableCell>
                                <TableCell>
                                  <FormTextField name={`items.${index}.quantity`} label="" type="number" />
                                </TableCell>
                                <TableCell>
                                  <FormTextField name={`items.${index}.unitPrice`} label="" type="number" />
                                </TableCell>
                                <TableCell>
                                  <FormTextField name={`items.${index}.discountPercent`} label="" type="number" />
                                </TableCell>
                                <TableCell>
                                  <FormSelect name={`items.${index}.taxPercent`} label="" options={taxPercentOptions} />
                                </TableCell>
                                <TableCell sx={{ whiteSpace: 'nowrap' }}>{rowAmount.toFixed(2)}</TableCell>
                                <TableCell>
                                  <IconButton
                                    type="button"
                                    size="small"
                                    color="error"
                                    onClick={() => removeItem(index)}
                                    disabled={fields.length <= 1}
                                    aria-label="remove item"
                                  >
                                    <DeleteIcon fontSize="small" />
                                  </IconButton>
                                </TableCell>
                              </TableRow>
                            );
                          })}
                        </TableBody>
                      </Table>
                    </TableContainer>
                    )}
                  </CardContent>
                </Card>
              </fieldset>

              <Card variant="outlined">
                <CardContent sx={{ p: { xs: 2, sm: 3 } }}>
                  <fieldset disabled={readOnly} style={{ border: 0, padding: 0, margin: 0, minWidth: 0, width: '100%', display: 'block' }}>
                    <Grid container spacing={3}>
                      <Grid item xs={12} md={4}>
                        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1 }}>Remarks</Typography>
                        <FormTextField name="remarks" label="" placeholder="Enter any remarks (optional)" multiline rows={6} />
                      </Grid>

                      <Grid item xs={12} md={4}>
                        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1 }}>Terms & Conditions</Typography>
                        <FormTextField name="termsConditions" label="" placeholder="Enter terms and conditions" multiline rows={6} />
                      </Grid>

                      <Grid item xs={12} md={4}>
                        <DocumentTotalsPanel totals={totals} interState={interState} />
                      </Grid>
                    </Grid>
                  </fieldset>

                    <Stack
                      direction={{ xs: 'column', sm: 'row' }}
                      spacing={1.5}
                      justifyContent={{ xs: 'stretch', sm: 'flex-end' }}
                      sx={{ mt: 3 }}
                    >
                      {/* Copy From sits immediately left of Cancel and stays
                          disabled until a Customer is chosen — the dialogs it
                          leads to list that customer's orders and deliveries,
                          so with no customer there is nothing for them to
                          show. Hidden in view mode, where nothing is being
                          filled in. */}
                      {!readOnly && (
                        (challanValue || orderValue) ? (
                          <Button
                            fullWidth={isMobile}
                            type="button"
                            variant="outlined"
                            color="inherit"
                            startIcon={<CloseIcon />}
                            onClick={clearSource}
                            disabled={creating || updating}
                          >
                            Clear Copied {challanValue ? 'Challan' : 'Order'}
                          </Button>
                        ) : (
                          <Button
                            fullWidth={isMobile}
                            type="button"
                            variant="outlined"
                            startIcon={<ContentCopyOutlinedIcon />}
                            endIcon={<ArrowDropDownIcon />}
                            onClick={(e) => setCopyFromAnchor(e.currentTarget)}
                            disabled={!customerValue || creating || updating}
                          >
                            Copy From
                          </Button>
                        )
                      )}
                      <Button fullWidth={isMobile} type="button" variant="outlined" color="inherit" startIcon={<CloseIcon />} onClick={backToList} disabled={creating || updating}>
                        Cancel
                      </Button>
                      <Button fullWidth={isMobile} type="button" variant="outlined" startIcon={<PrintOutlinedIcon />} onClick={() => window.print()}>
                        Print
                      </Button>
                      {!readOnly && (
                        <>
                          <FormSubmitButton
                            fullWidth={isMobile}
                            variant="outlined"
                            onClick={() => { pendingStatusRef.current = 'Draft'; }}
                            disabled={creating || updating}
                          >
                            Save as Draft
                          </FormSubmitButton>
                          <FormSubmitButton
                            fullWidth={isMobile}
                            onClick={() => { pendingStatusRef.current = 'Sent'; }}
                            disabled={creating || updating}
                          >
                            {editingRow ? 'Update Invoice' : 'Save & Send Invoice'}
                          </FormSubmitButton>
                        </>
                      )}
                    </Stack>
                  </CardContent>
                </Card>
              </>
            );
          }}
        </AppForm>
        </RouteMapContextMenu>
      ) : (
        <Card variant="outlined">
          <CardContent sx={{ p: 0 }}>
            <Stack
              direction={{ xs: 'column', md: 'row' }}
              alignItems={{ xs: 'stretch', md: 'center' }}
              justifyContent="space-between"
              flexWrap="wrap"
              gap={1.5}
              sx={{ px: { xs: 2, sm: 3 }, pt: 2.5, pb: 1.5 }}
            >
              <Typography variant="subtitle1" fontWeight={700}>Sales Invoice List</Typography>
              <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.5} flexWrap="wrap" useFlexGap sx={{ width: { xs: '100%', md: 'auto' } }}>
                <TableSearchFilter table={table} placeholder="Search by invoice no., order no., customer..." showFilter={false} />
                <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.5} flexWrap="wrap" useFlexGap>
                  <Button
                    size="small"
                    variant="outlined"
                    color="inherit"
                    startIcon={<FilterListIcon />}
                    onClick={() => setShowFilters((v) => !v)}
                    sx={{ width: { xs: '100%', sm: 'auto' }, whiteSpace: 'nowrap' }}
                  >
                    Filter
                  </Button>
                  <CanAdd>
                    <Button
                      size="small"
                      variant="contained"
                      startIcon={<AddIcon />}
                      endIcon={<ArrowDropDownIcon />}
                      onClick={openCreate}
                      sx={{ width: { xs: '100%', sm: 'auto' }, whiteSpace: 'nowrap' }}
                    >
                      Create Invoice
                    </Button>
                  </CanAdd>
                </Stack>
              </Stack>
            </Stack>

            <Collapse in={showFilters} unmountOnExit>
            <Box sx={{ px: { xs: 2, sm: 3 }, pb: 2 }}>
              <FormGrid columns={5}>
                <FilterAutocomplete
                  label="Customer"
                  allLabel="All Customers"
                  options={customerOptions}
                  value={customerFilter}
                  onChange={(v) => { setCustomerFilter(v); setPage(0); }}
                />
                <Autocomplete
                  size="small"
                  options={STATUS_FILTERS}
                  value={statusFilter}
                  onChange={(_e, v) => { setStatusFilter(v || 'All Status'); setPage(0); }}
                  disableClearable
                  renderInput={(params) => <TextField {...params} label="Status" InputLabelProps={{ shrink: true }} />}
                />
                <TextField
                  size="small"
                  fullWidth
                  label="Date Range"
                  value={dateRangeLabel}
                  onClick={(e) => setDateAnchor(e.currentTarget)}
                  InputProps={{
                    readOnly: true,
                    startAdornment: <InputAdornment position="start"><EventIcon fontSize="small" /></InputAdornment>,
                    endAdornment: (dateFrom || dateTo) ? (
                      <InputAdornment position="end">
                        <IconButton size="small" onClick={(e) => { e.stopPropagation(); setDateFrom(null); setDateTo(null); setPage(0); }}>
                          <CloseIcon fontSize="small" />
                        </IconButton>
                      </InputAdornment>
                    ) : null,
                  }}
                  InputLabelProps={{ shrink: true }}
                  sx={{ cursor: 'pointer' }}
                />
                <Autocomplete
                  size="small"
                  options={PAYMENT_STATUS_FILTERS}
                  value={paymentStatusFilter}
                  onChange={(_e, v) => { setPaymentStatusFilter(v || 'All Payment Status'); setPage(0); }}
                  disableClearable
                  renderInput={(params) => <TextField {...params} label="Payment Status" InputLabelProps={{ shrink: true }} />}
                />
                <FilterAutocomplete
                  label="Sales Person"
                  allLabel="All Sales Persons"
                  options={salesPersonOptions}
                  value={salesPersonFilter}
                  onChange={(v) => { setSalesPersonFilter(v); setPage(0); }}
                />
              </FormGrid>

              <Popover
                open={!!dateAnchor}
                anchorEl={dateAnchor}
                onClose={() => setDateAnchor(null)}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
              >
                <Stack direction="row" spacing={2} sx={{ p: 2 }}>
                  <DatePicker label="From" value={dateFrom} onChange={(v) => { setDateFrom(v); setPage(0); }} slotProps={{ textField: { size: 'small' } }} />
                  <DatePicker label="To" value={dateTo} onChange={(v) => { setDateTo(v); setPage(0); }} slotProps={{ textField: { size: 'small' } }} />
                </Stack>
              </Popover>
              <TableFilterPanel table={table} embedded open />
            </Box>
            </Collapse>

            {checkedIds.length > 0 && (
              <Box sx={{ px: { xs: 2, sm: 3 }, pb: 1.5 }}>
                <Button variant="outlined" color="error" size="small" startIcon={<DeleteIcon />} onClick={removeSelected}>
                  Delete Selected ({checkedIds.length})
                </Button>
              </Box>
            )}

            {isMobile ? (
              <Box sx={{ px: 2, pb: 1 }}>
                {!isLoading && pagedRows.map((row) => (
                  <MobileRecordCard
                    key={row.id}
                    title={row.invoiceNo}
                    statusChip={<Chip size="small" label={row.status} color={STATUS_COLORS[row.status] || 'default'} variant="outlined" />}
                    fields={[
                      { label: 'Customer', value: row.customer || '—' },
                      { label: 'Order No.', value: row.orderNo || '—' },
                      { label: 'Invoice Date', value: row.invoiceDate ? dayjs(row.invoiceDate).format('DD/MM/YYYY') : '—' },
                      { label: 'Due Date', value: row.dueDate ? dayjs(row.dueDate).format('DD/MM/YYYY') : '—' },
                      { label: 'Amount', value: `₹${Number(row.amount).toFixed(2)}` },
                      { label: 'Payment Status', value: row.paymentStatus || '—' },
                    ]}
                    onEdit={() => handleEdit(row)}
                    onDelete={() => handleDelete(row)}
                  />
                ))}
                {!isLoading && filteredRows.length === 0 && (
                  <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>No sales invoices found</Typography>
                )}
              </Box>
            ) : (
              <ScrollableTableContainer>
                <Table size="small" stickyHeader>
                  <TableHead>
                    <TableRow>
                      <SortableHeaderCell field="id" sort={table.sort} onSort={table.toggleSort} padding="checkbox">
                        <Checkbox
                          size="small"
                          checked={pagedRows.length > 0 && pagedRows.every((r) => checkedIds.includes(r.id))}
                          indeterminate={pagedRows.some((r) => checkedIds.includes(r.id)) && !pagedRows.every((r) => checkedIds.includes(r.id))}
                          onChange={(e) => {
                            const ids = pagedRows.map((r) => r.id);
                            setCheckedIds((prev) => e.target.checked
                              ? Array.from(new Set([...prev, ...ids]))
                              : prev.filter((c) => !ids.includes(c)));
                          }}
                        />
                      </SortableHeaderCell>
                      <TableCell width={40}>#</TableCell>
                      <SortableHeaderCell field="invoiceNo" sort={table.sort} onSort={table.toggleSort}>Invoice No.</SortableHeaderCell>
                      <SortableHeaderCell field="invoiceDate" sort={table.sort} onSort={table.toggleSort}>Invoice Date</SortableHeaderCell>
                      <SortableHeaderCell field="customer" sort={table.sort} onSort={table.toggleSort}>Customer</SortableHeaderCell>
                      <SortableHeaderCell field="orderNo" sort={table.sort} onSort={table.toggleSort}>Order No.</SortableHeaderCell>
                      <SortableHeaderCell field="dueDate" sort={table.sort} onSort={table.toggleSort}>Due Date</SortableHeaderCell>
                      <SortableHeaderCell field="amount" sort={table.sort} onSort={table.toggleSort}>Amount (₹)</SortableHeaderCell>
                      <SortableHeaderCell field="status" sort={table.sort} onSort={table.toggleSort}>Status</SortableHeaderCell>
                      <SortableHeaderCell field="paymentStatus" sort={table.sort} onSort={table.toggleSort}>Payment Status</SortableHeaderCell>
                      <TableCell align="right">Action</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {!isLoading && pagedRows.map((row, i) => (
                      <TableRow key={row.id} hover>
                        <TableCell padding="checkbox">
                          <Checkbox
                            size="small"
                            checked={checkedIds.includes(row.id)}
                            onChange={() => setCheckedIds((prev) => prev.includes(row.id) ? prev.filter((c) => c !== row.id) : [...prev, row.id])}
                          />
                        </TableCell>
                        <TableCell>{page * pageSize + i + 1}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.invoiceNo}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.invoiceDate ? dayjs(row.invoiceDate).format('DD/MM/YYYY') : '—'}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.customer || '—'}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.orderNo || '—'}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.dueDate ? dayjs(row.dueDate).format('DD/MM/YYYY') : '—'}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{Number(row.amount).toFixed(2)}</TableCell>
                        <TableCell>
                          <Chip size="small" label={row.status} color={STATUS_COLORS[row.status] || 'default'} variant="outlined" />
                        </TableCell>
                        <TableCell>
                          <Chip size="small" label={row.paymentStatus} color={PAYMENT_STATUS_COLORS[row.paymentStatus] || 'default'} variant="outlined" />
                        </TableCell>
                        <TableCell align="right">
                          <Stack direction="row" spacing={0.5} justifyContent="flex-end">
                            <Tooltip title="View">
                              <IconButton size="small" onClick={() => handleView(row)} aria-label="view">
                                <VisibilityOutlinedIcon fontSize="small" />
                              </IconButton>
                            </Tooltip>
                            <RouteMapButton flow="sales" type="invoice" docNo={row.invoiceNo} />
                            <Tooltip title="Print">
                              <IconButton size="small" onClick={() => handlePrint(row)} aria-label="print">
                                <PrintOutlinedIcon fontSize="small" />
                              </IconButton>
                            </Tooltip>
                            <IconButton
                              size="small"
                              onClick={(e) => { setRowMenuAnchor(e.currentTarget); setRowMenuTarget(row); }}
                              aria-label="more actions"
                            >
                              <MoreVertIcon fontSize="small" />
                            </IconButton>
                          </Stack>
                        </TableCell>
                      </TableRow>
                    ))}
                    {!isLoading && filteredRows.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={11}>
                          <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>No sales invoices found</Typography>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </ScrollableTableContainer>
            )}

            <Menu anchorEl={rowMenuAnchor} open={!!rowMenuAnchor} onClose={() => setRowMenuAnchor(null)}>
              <CanEdit>
                <MenuItem onClick={() => handleEdit(rowMenuTarget)}>
                  <ListItemIcon><EditIcon fontSize="small" /></ListItemIcon>
                  <ListItemText>Edit</ListItemText>
                </MenuItem>
              </CanEdit>
              <CanDelete>
                <MenuItem onClick={() => handleDelete(rowMenuTarget)}>
                  <ListItemIcon><DeleteIcon fontSize="small" color="error" /></ListItemIcon>
                  <ListItemText>Delete</ListItemText>
                </MenuItem>
              </CanDelete>
            </Menu>

            <EntityListPagination total={filteredRows.length} page={page} onChange={setPage} pageSize={pageSize} onPageSizeChange={(v) => { setPageSize(v); setPage(0); }} />
          </CardContent>
        </Card>
      )}
    </Box>
  );
}

// Both the Product Code and Product Name columns are selects over the same
// underlying items.{index}.productCode field — Product Code lists codes,
// Product Name lists names, and picking either fills the rest of the row
// from the product master. Isolated so the per-row auto-fill effect only
// re-runs for the row whose product actually changed, not every row on every
// keystroke.
function ProductCell({ index, methods, options, products, label = '', placeholder = 'Select product', disabled = false, multiline = false, sx }) {
  const { watch, setValue } = methods;
  const productCodeValue = watch(`items.${index}.productCode`);
  const prevValue = useRef(productCodeValue);

  useEffect(() => {
    if (productCodeValue !== prevValue.current) {
      const found = (products || []).find((p) => p.productCode === productCodeValue);
      if (found) {
        setValue(`items.${index}.productName`, found.productName, { shouldValidate: true });
        setValue(`items.${index}.description`, found.productName, { shouldValidate: true });
        setValue(`items.${index}.hsnCode`, found.hsnCode || '', { shouldValidate: true });
        setValue(`items.${index}.uom`, found.uom || '', { shouldValidate: true });
        setValue(`items.${index}.unitPrice`, found.salesPrice != null ? Number(found.salesPrice) : 0, { shouldValidate: true });
      }
      prevValue.current = productCodeValue;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [productCodeValue]);

  return <FormSelect name={`items.${index}.productCode`} label={label} placeholder={placeholder} options={options} disabled={disabled} multiline={multiline} sx={sx} />;
}
