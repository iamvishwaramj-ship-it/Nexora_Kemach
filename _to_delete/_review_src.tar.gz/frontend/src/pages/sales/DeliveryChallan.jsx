import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Box, Typography, Button, Card, CardContent, Stack, TextField, InputAdornment, Table,
  TableBody, TableCell, TableContainer, TableHead, TableRow, Chip, IconButton, Menu, MenuItem,
  ListItemIcon, ListItemText, Checkbox, Autocomplete, Popover, Grid, Tooltip,
  Collapse, CircularProgress,
} from '@mui/material';
import { useFieldArray } from 'react-hook-form';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import dayjs from 'dayjs';
import LocalShippingOutlinedIcon from '@mui/icons-material/LocalShippingOutlined';
import AddIcon from '@mui/icons-material/Add';
import CloseIcon from '@mui/icons-material/Close';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import SearchIcon from '@mui/icons-material/Search';
import FilterListIcon from '@mui/icons-material/FilterList';
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import PrintOutlinedIcon from '@mui/icons-material/PrintOutlined';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import EditIcon from '@mui/icons-material/EditOutlined';
import DeleteIcon from '@mui/icons-material/DeleteOutline';
import EventIcon from '@mui/icons-material/Event';
import Inventory2OutlinedIcon from '@mui/icons-material/Inventory2Outlined';
import AppForm, { FormGrid, FormSubmitButton } from '../../components/form/AppForm';
import BatchSerialSelectionDialog from '../../components/common/BatchSerialSelectionDialog';
import FormTextField from '../../components/form/FormTextField';
import FormSelect from '../../components/form/FormSelect';
import FormDatePicker from '../../components/form/FormDatePicker';
import EntityHeaderCard from '../../components/common/EntityHeaderCard';
import CompanyBadge from '../../components/common/CompanyBadge';
import EntityListPagination from '../../components/data-display/EntityListPagination';
import FilterAutocomplete from '../../components/data-display/FilterAutocomplete';
import MobileRecordCard from '../../components/data-display/MobileRecordCard';
import MobileItemCard from '../../components/data-display/MobileItemCard';
import { useIsMobileListView } from '../../components/data-display/useIsMobileListView';
import useDragScroll from '../../components/data-display/useDragScroll';
import { useNotify } from '../../components/feedback/NotificationProvider';
import { applyServerErrors } from '../../lib/formErrors';
import { useConfirm } from '../../components/feedback/ConfirmationDialog';
import { deliveryChallanSchema, CHALLAN_STATUS_OPTIONS } from '../../lib/validation/salesSchemas';
import { buildDocument, round2, isInterState } from '../../lib/documentTotals';
import DocumentTotalsPanel from '../../components/form/DocumentTotalsPanel';
import { deliveryChallanApi, customerApi, productApi, salesEmployeeApi, salesOrderApi, branchApi, taxCodeApi } from '../../features/resources';
import { productOptionsFor, PRODUCT_USAGE } from '../../lib/productUsage';
import { useWarehouseOptions } from '../../lib/useWarehouseOptions';
import { buildTaxPercentOptions } from '../../lib/taxCodeOptions';
import { hoverExpandColumnSx, itemColumnBaseWidth } from '../../lib/columnWidth';
import { useGetCompanyDetailsQuery } from '../../features/company/companyDetailsApi';
import DocumentNoField from '../../components/form/DocumentNoField';
import DeliveryChallanPrintable from '../../components/print/DeliveryChallanPrintable';
import useTableFeatures from '../../components/data-display/useTableFeatures';
import TableSearchFilter from '../../components/data-display/TableSearchFilter';
import SortableHeaderCell from '../../components/data-display/SortableHeaderCell';
import ScrollableTableContainer, { dragScrollbarSx } from '../../components/data-display/ScrollableTableContainer';

import { CanAdd, CanEdit, CanDelete } from '../../components/common/PermissionGate';
import TableFilterPanel from '../../components/data-display/TableFilterPanel';
import RouteMapButton from '../../components/common/RouteMapButton';
import RouteMapContextMenu from '../../components/common/RouteMapContextMenu';
import ContentCopyOutlinedIcon from '@mui/icons-material/ContentCopyOutlined';
import CopyFromDocumentDialog from '../../components/common/CopyFromDocumentDialog';

// Columns for the "Find Sales Order" dialog opened by Copy From.
//
// "Due Date" reads off the order's `deliveryDate`: a sales order has no `dueDate`
// of its own — the date it is due is the date it promised delivery, which is
// exactly what this column is asking about.
const SALES_ORDER_COPY_COLUMNS = [
  { field: 'orderNo', headerName: 'Order No', nowrap: true },
  { field: 'customer', headerName: 'Customer Name' },
  { field: 'deliveryDate', headerName: 'Due Date', type: 'date' },
  { field: 'remarks', headerName: 'Comments', type: 'optional' },
];
const emptyItem = {
  productCode: '', productName: '', description: '', hsnCode: '', uom: '', quantity: 1, unitPrice: 0, taxPercent: 0, batchNo: '',
  // Populated via the "Batches Number - Selection" / "Serial Numbers -
  // Selection" dialog — see BatchSerialSelectionDialog and the Batch/Serial
  // column below. Empty unless the selected product's Manage Item By is
  // Batch or Serial.
  batchAllocations: [], serialAllocations: [],
};

/**
 * Blocks the challan save when a Batch/Serial-tracked line's quantity isn't
 * fully covered by its selected batches/serials — the client-side half of
 * the same rule the server enforces in assertBatchSerialIssueAllocation
 * (utils/businessRules.js). Mirrors PurchaseGRN.jsx's
 * validateBatchSerialAllocation, but checks batchAllocations/
 * serialAllocations (numbers SELECTED from existing stock) rather than
 * batches/serials (numbers CREATED on a receipt) — a despatch draws down
 * stock, it doesn't add to it, so the same batch/serial number legitimately
 * appears on more than one document over its life and is not flagged as a
 * duplicate here the way a GRN's own new numbers are.
 */
function validateBatchSerialAllocation(items, productsByCode) {
  for (let i = 0; i < (items || []).length; i++) {
    const item = items[i];
    const trackingMode = productsByCode[item.productCode]?.manageItemBy;
    if (trackingMode !== 'Batch' && trackingMode !== 'Serial') continue;
    const label = item.productCode || `Row ${i + 1}`;
    const qty = Number(item.quantity) || 0;

    if (trackingMode === 'Batch') {
      const allocated = (item.batchAllocations || []).reduce((sum, b) => sum + (Number(b.quantity) || 0), 0);
      if (Math.abs(allocated - qty) > 0.005) {
        return `${label}: select ${qty} from batches via "Batches Number - Selection" — currently ${allocated}.`;
      }
    } else {
      const count = (item.serialAllocations || []).length;
      if (count !== qty) {
        return `${label}: select ${qty} serial number(s) via "Serial Numbers - Selection" — currently ${count}.`;
      }
    }
  }
  return null;
}

function getEmptyValues() {
  return {
    challanNo: '', branch: '', customer: '', contactPerson: '', orderNo: '',
    challanDate: new Date(), deliveryDate: null, fromWarehouse: '', salesPerson: '',
    billingAddress: '', shippingAddress: '', termsConditions: '', remarks: '', status: 'Pending',
    items: [{ ...emptyItem }],
  };
}

// Totals come from the shared engine in lib/documentTotals.js, which the
// backend mirrors exactly — the figures shown here while editing are the
// figures that get saved. Each page used to carry its own copy of this
// arithmetic and the copies had drifted apart; this document in particular
// used to hard-code CGST and SGST at 9% each regardless of what the goods
// actually attract.
//
// `grandTotal` and `discount` are kept in the returned shape because the
// totals panel below reads those names.
// `interState` must be passed through rather than defaulted: the server
// decides CGST/SGST vs IGST by comparing this document's Place of Supply
// against the company's registered state, and for a long time no page passed
// the flag at all — so an inter-state document displayed a CGST/SGST split
// while the record it saved held IGST.
//
function computeTotals(items, discountPercent, interState = false) {
  const { totals } = buildDocument(items, discountPercent, {
    interState,
    roundOff: true,
  });
  return {
    ...totals,
    discount: round2(totals.subtotal - totals.taxableAmount),
    grandTotal: totals.amount,
  };
}

function rowToFormValues(row) {
  return {
    challanNo: row.challanNo, branch: row.branch || '', customer: row.customer || '', contactPerson: row.contactPerson || '',
    orderNo: row.orderNo || '', challanDate: row.challanDate, deliveryDate: row.deliveryDate,
    fromWarehouse: row.fromWarehouse || '', salesPerson: row.salesPerson || '',
    billingAddress: row.billingAddress || '', shippingAddress: row.shippingAddress || '',
    termsConditions: row.termsConditions || '', remarks: row.remarks || '', status: row.status || 'Pending',
    items: (row.items && row.items.length ? row.items : [{ ...emptyItem }]).map((i) => ({
      productCode: i.productCode || '', productName: i.productName || '', description: i.description || '',
      hsnCode: i.hsnCode || '', uom: i.uom || '',
      quantity: i.quantity != null ? Number(i.quantity) : 1,
      unitPrice: i.unitPrice != null ? Number(i.unitPrice) : 0,
      taxPercent: i.taxPercent != null ? Number(i.taxPercent) : 0,
      batchNo: i.batchNo || '',
      batchAllocations: (i.batchAllocations || []).map((b) => ({ batchNo: b.batchNo, quantity: Number(b.quantity) || 0 })),
      serialAllocations: (i.serialAllocations || []).map((s) => ({ serialNo: s.serialNo })),
    })),
  };
}

const PAGE_SIZE = 10;
const STATUS_FILTERS = ['All Status', ...CHALLAN_STATUS_OPTIONS];

// Pending (saved as draft, nothing despatched, no stock posted) grey, Open
// (despatched, not yet fully invoiced) blue, Closed (fully invoiced) green,
// Cancelled red. Only Pending vs Open is chosen by the user — via which save
// button they press; Open -> Closed is the server's, see
// recomputeDeliveryChallanStatus in backend utils/documentFlow.js.
const STATUS_COLORS = { Pending: 'default', Open: 'info', Closed: 'success', Cancelled: 'error' };

export default function DeliveryChallan({ openDocNo } = {}) {
  const notify = useNotify();
  const confirmDialog = useConfirm();
  const isMobile = useIsMobileListView();
  const itemScrollRef = useDragScroll();
  const { data: challans, isLoading } = deliveryChallanApi.useList();
  const { data: customers } = customerApi.useList();
  const { data: products } = productApi.useList();
  const { data: salesEmployees } = salesEmployeeApi.useList();
  const { data: salesOrders } = salesOrderApi.useList();
  const { data: branches } = branchApi.useList();
  const { data: taxCodes } = taxCodeApi.useList();
  const taxPercentOptions = useMemo(() => buildTaxPercentOptions(taxCodes), [taxCodes]);
  const { data: company } = useGetCompanyDetailsQuery();
  const [create, { isLoading: creating }] = deliveryChallanApi.useCreate();
  const [update, { isLoading: updating }] = deliveryChallanApi.useUpdate();
  const [remove] = deliveryChallanApi.useDelete();

  const customerOptions = (customers || []).map((c) => ({ label: c.customerName, value: c.customerName }));
  // Looked up per row to decide whether the Batch/Serial column applies —
  // Product Master's Manage Item By select is what makes a line ask for it.
  const productsByCode = useMemo(
    () => Object.fromEntries((products || []).map((p) => [p.productCode, p])),
    [products]
  );
  const salesPersonOptions = (salesEmployees || []).map((s) => ({ label: s.employeeName, value: s.employeeName }));
  // Sales orders are no longer offered as a dropdown on the form — they are
  // picked through the Copy From dialog, which scopes the list to the selected
  // customer. The raw `salesOrders` list is what that dialog takes.
  const branchOptions = (branches || []).map((b) => ({ label: b.branchName, value: b.branchName }));

  // View toggles between the challan list and the full-page Create/Edit
  // form — same page, no dialog/popup, per the standard CRUD page template.
  const [view, setView] = useState('list');
  const [editingRow, setEditingRow] = useState(null);

  // Only products flagged for the sales flow on Product Master are offered
  // here — see lib/productUsage.js. `products` itself stays unfiltered below,
  // because the line lookups (price, tax, UOM, batch/serial mode) must still
  // resolve a product this document already names even if it has since been
  // re-flagged; passing the saved lines' codes as `keepCodes` is what keeps
  // reopening an existing document from silently blanking its own rows.
  const selectableProducts = productOptionsFor(
    products,
    PRODUCT_USAGE.SALES,
    (editingRow?.items || []).map((i) => i.productCode)
  );
  const productCodeOptions = selectableProducts.map((p) => ({ label: p.productCode, value: p.productCode }));
  const productNameOptions = selectableProducts.map((p) => ({ label: p.productName, value: p.productCode }));

  // Warehouses come from the Warehouse Master, like every other warehouse
  // dropdown in the app now — see lib/useWarehouseOptions.js. This list used to
  // be the literal string 'Main Warehouse' plus every BRANCH name, which are
  // not warehouses at all, so a warehouse picked here could never be filtered
  // for in a stock report.
  //
  // The record's stored value is passed in because documents saved under that
  // old list hold values no warehouse matches. Without it the select would
  // render blank on those documents and the next save would rewrite a posted
  // movement's warehouse to null.
  const { options: allWarehouseOptions, warehouses } = useWarehouseOptions({ currentValue: editingRow?.fromWarehouse });
  const [readOnly, setReadOnly] = useState(false);
  const [formKey, setFormKey] = useState(0);
  // Copy From ("Find Sales Order") dialog. Held at page level rather than
  // inside AppForm's render prop so remounting the form on formKey change
  // can't leave a dialog orphaned open over a freshly reset form.
  const [copyFromOpen, setCopyFromOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [customerFilter, setCustomerFilter] = useState(null);
  const [statusFilter, setStatusFilter] = useState('All Status');
  const [warehouseFilter, setWarehouseFilter] = useState(null);
  const [salesPersonFilter, setSalesPersonFilter] = useState(null);
  const [dateFrom, setDateFrom] = useState(null);
  const [dateTo, setDateTo] = useState(null);
  const [dateAnchor, setDateAnchor] = useState(null);
  const [showFilters, setShowFilters] = useState(false);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(PAGE_SIZE);
  const [checkedIds, setCheckedIds] = useState([]);
  const [rowMenuAnchor, setRowMenuAnchor] = useState(null);
  const [rowMenuTarget, setRowMenuTarget] = useState(null);
  const pendingStatusRef = useRef('Pending');
  // { index, mode } for the item row whose "Batches Number - Selection" /
  // "Serial Numbers - Selection" dialog is open; null when closed.
  const [batchDialog, setBatchDialog] = useState(null);

  const rows = challans || [];

  const baseTableRows = useMemo(() => {
    const q = '';
    return rows.filter((r) => {
      const matchesSearch = !q || [r.challanNo, r.orderNo, r.customer].some((v) => String(v || '').toLowerCase().includes(q));
      const matchesCustomer = !customerFilter || r.customer === customerFilter.value;
      const matchesStatus = statusFilter === 'All Status' || r.status === statusFilter;
      const matchesWarehouse = !warehouseFilter || r.fromWarehouse === warehouseFilter.value;
      const matchesSalesPerson = !salesPersonFilter || r.salesPerson === salesPersonFilter.value;
      const cd = r.challanDate ? dayjs(r.challanDate) : null;
      const matchesFrom = !dateFrom || (cd && !cd.isBefore(dateFrom, 'day'));
      const matchesTo = !dateTo || (cd && !cd.isAfter(dateTo, 'day'));
      return matchesSearch && matchesCustomer && matchesStatus && matchesWarehouse && matchesSalesPerson && matchesFrom && matchesTo;
    });
  }, [rows, customerFilter, statusFilter, warehouseFilter, salesPersonFilter, dateFrom, dateTo]);

  // Column definitions drive the global search, the sort icons and the filter
  // popover — see components/data-display/useTableFeatures.js.
  const tableColumns = useMemo(() => ([
    { field: 'id', headerName: 'Select', filter: false, searchable: false },
    { field: 'challanNo', headerName: 'Challan No.', filter: 'text' },
    { field: 'orderNo', headerName: 'Order No.', filter: 'text' },
    { field: 'customer', headerName: 'Customer', filter: 'text' },
    { field: 'challanDate', headerName: 'Challan Date', filter: 'dateRange', sortValue: (row) => (row.challanDate ? new Date(row.challanDate).getTime() : null) },
    { field: 'deliveryDate', headerName: 'Delivery Date', filter: 'dateRange', sortValue: (row) => (row.deliveryDate ? new Date(row.deliveryDate).getTime() : null) },
    { field: 'fromWarehouse', headerName: 'From Warehouse', filter: 'text' },
    { field: 'amount', headerName: 'Amount (₹)', filter: 'numberRange', sortValue: (row) => (row.amount == null || row.amount === '' ? null : Number(row.amount)) },
    { field: 'status', headerName: 'Status', filter: 'select' },
  ]), []);
  const table = useTableFeatures(baseTableRows, tableColumns, { onChange: setPage });
  const filteredRows = table.rows;

  const pagedRows = useMemo(
    () => filteredRows.slice(page * pageSize, page * pageSize + pageSize),
    [filteredRows, page, pageSize]
  );

  const openCreate = () => {
    setEditingRow(null);
    setReadOnly(false);
    setFormKey((k) => k + 1);
    setView('form');
  };

  const backToList = () => {
    setView('list');
    setEditingRow(null);
    setReadOnly(false);
    setCopyFromOpen(false);
  };

  const handleView = (row) => {
    setEditingRow(row);
    setReadOnly(true);
    setFormKey((k) => k + 1);
    setView('form');
  };

  // Opened from the Route Map's document preview popup: jump straight into
  // this record's own read-only View, exactly as clicking it in the list
  // would, instead of requiring the user to find and click the row.
  useEffect(() => {
    if (!openDocNo) return;
    if (editingRow && editingRow.challanNo === openDocNo) return;
    const match = rows.find((r) => r.challanNo === openDocNo);
    if (match) handleView(match);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [openDocNo, rows]);

  const handleEdit = (row) => {
    setEditingRow(row);
    setReadOnly(false);
    setFormKey((k) => k + 1);
    setView('form');
    setRowMenuAnchor(null);
  };

  const handlePrint = (row) => {
    setRowMenuAnchor(null);
    handleView(row);
    setTimeout(() => window.print(), 300);
  };

  const handleDelete = async (row) => {
    setRowMenuAnchor(null);
    const ok = await confirmDialog({
      title: 'Delete challan',
      message: `Are you sure you want to delete "${row.challanNo}"? This cannot be undone.`,
      confirmLabel: 'Delete',
      severity: 'error',
    });
    if (!ok) return;
    try {
      await remove(row.id).unwrap();
      notify.success('Challan deleted');
    } catch (err) {
      notify.error(err?.data?.message || 'Delete failed');
    }
  };

  const removeSelected = async () => {
    const ok = await confirmDialog({
      title: 'Delete selected challans',
      message: `Delete ${checkedIds.length} selected challan${checkedIds.length > 1 ? 's' : ''}? This cannot be undone.`,
      confirmLabel: 'Delete',
      severity: 'error',
    });
    if (!ok) return;
    try {
      await Promise.all(checkedIds.map((id) => remove(id).unwrap()));
      notify.success('Selected challans deleted');
      setCheckedIds([]);
    } catch (err) {
      notify.error(err?.data?.message || 'Delete failed');
    }
  };

  const handleSubmit = async (values, formMethods) => {
    // A Batch/Serial-tracked line whose quantity isn't fully covered by its
    // selected batches/serials cannot be saved — see
    // validateBatchSerialAllocation above. The server enforces the same
    // rule (assertBatchSerialIssueAllocation) so this is a fast local
    // check, not the only line of defence.
    const allocationError = validateBatchSerialAllocation(values.items, productsByCode);
    if (allocationError) {
      notify.error(allocationError);
      return;
    }
    const payload = { ...values, status: pendingStatusRef.current };
    try {
      if (editingRow) {
        await update({ id: editingRow.id, ...payload }).unwrap();
        notify.success('Challan updated');
      } else {
        await create(payload).unwrap();
        notify.success('Challan saved');
      }
      backToList();
    } catch (err) {
      notify.error(applyServerErrors(err, formMethods.setError));
    }
  };

  const dateRangeLabel = dateFrom && dateTo
    ? `${dateFrom.format('DD/MM/YYYY')} - ${dateTo.format('DD/MM/YYYY')}`
    : 'Select date range';

  if (openDocNo && (!editingRow || editingRow.challanNo !== openDocNo)) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', py: 10 }}>
        <CircularProgress size={28} />
      </Box>
    );
  }

  return (
    <Box>
      <EntityHeaderCard
        icon={<LocalShippingOutlinedIcon />}
        title="Delivery Challan"
        subtitle={view === 'form' ? 'Create a new delivery challan.' : 'Manage and track all delivery challans.'}
        rightContent={<CompanyBadge />}
      />

      {view === 'form' ? (
        <RouteMapContextMenu flow="sales" type="challan" docNo={editingRow?.challanNo}>
        <AppForm
          key={formKey}
          schema={deliveryChallanSchema}
          defaultValues={editingRow ? rowToFormValues(editingRow) : getEmptyValues()}
          onSubmit={handleSubmit}
        >
          {(methods) => {
            const { control, watch, setValue } = methods;
            const { fields, append, remove: removeItem, replace: replaceItems } = useFieldArray({ control, name: 'items' });
            const watchedItems = watch('items') || [];

            // Product Code / Product Name are sized to the longest value the
            // column actually holds, instead of a fixed width that left almost
            // no room for text once the field's own padding — and, on a select,
            // its clear and dropdown buttons — were subtracted. Short data still
            // sits tight; anything past the cap is revealed on hover as before.
            const productCodeColumnWidth = itemColumnBaseWidth(
              watchedItems.map((i) => i?.productCode), { kind: 'code', field: 'select' },
            );
            const productNameColumnWidth = itemColumnBaseWidth(
              watchedItems.map((i) => i?.productName), { kind: 'name', field: 'select' },
            );
            // Inter-state supplies are taxed wholly as IGST. The server works
            // this out by comparing Place of Supply against the company's
            // registered state; passing the same flag here is what stops the
            // panel showing a CGST/SGST split for a record saved as IGST.
            const interState = isInterState(watch('placeOfSupply'), company?.state);
            const totals = computeTotals(watchedItems, 0, interState);

            const branch = watch('branch');

            // Once Branch is picked, the Warehouse dropdown is scoped to
            // that branch's warehouses only — see useWarehouseOptions.js.
            const { options: branchWarehouseOptions } = useWarehouseOptions({ currentValue: editingRow?.fromWarehouse, branch });

            const allValues = watch();
            const printCustomerRecord = (customers || []).find((c) => c.customerName === allValues.customer);
            const printSalesOrderRecord = (salesOrders || []).find((o) => o.orderNo === allValues.orderNo);
            const printOrder = { ...allValues, status: editingRow?.status || 'Pending' };

            const customerValue = watch('customer');
            const prevCustomer = useRef(editingRow ? editingRow.customer : null);
            useEffect(() => {
              if (customerValue !== prevCustomer.current) {
                const found = (customers || []).find((c) => c.customerName === customerValue);
                if (found) {
                  setValue('contactPerson', found.salesPerson || '', { shouldValidate: true });
                  setValue('billingAddress', found.billingAddress || '', { shouldValidate: true });
                  setValue('shippingAddress', found.shippingAddress || '', { shouldValidate: true });
                }
                prevCustomer.current = customerValue;
              }
              // eslint-disable-next-line react-hooks/exhaustive-deps
            }, [customerValue]);

            // Copy From pulls in every field that exists on the chosen order —
            // contact person, addresses, sales person, delivery date, terms &
            // conditions, remarks, and item lines — so the challan doesn't
            // have to be re-keyed from scratch.
            //
            // Those header fields used to render `disabled`, on the grounds
            // that they aren't challan-specific data. That also made a challan
            // with no order behind it impossible to enter: with Customer
            // itself locked, there was no way to fill the form at all. They are
            // editable now.
            //
            // The customer is not copied back either — the dialog was already
            // filtered by it, so it can only hold the value it already has.
            //
            // The item columns used to render `disabled` too, but a delivery
            // does not always match its order exactly — a substituted
            // product, a corrected HSN/unit/rate, or a challan raised
            // against no order at all ("Add Item" produced a row that could
            // never be filled in). They are editable now; the order lookup
            // still pre-fills them, it just no longer forbids a correction.
            //
            // Challan No./Date, From Warehouse, and each item's Batch/Serial
            // No. aren't part of a sales order and were already editable.
            // Also syncs the customer-effect's own "previous value" ref so
            // it doesn't re-fire and clobber the values just set here from
            // the order's snapshot (same class of bug fixed on Purchase
            // Order's Reference/Contact Person).
            //
            // This used to run as an effect watching the Sales Order No.
            // dropdown. It is a plain function now, called only from the
            // dialog's Choose button: an effect keyed on a form value also
            // fires when that value is restored on edit or reset, which is why
            // it needed the prevOrderNo bookkeeping to tell "user picked an
            // order" apart from "form loaded". An explicit call has no such
            // ambiguity.
            const applyOrder = (found) => {
                if (found) {
                  setValue('orderNo', found.orderNo || '', { shouldValidate: true });
                  setValue('branch', found.branch || '', { shouldValidate: true });
                  prevCustomer.current = found.customer || '';
                  setValue('contactPerson', found.contactPerson || '', { shouldValidate: true });
                  setValue('salesPerson', found.salesPerson || '', { shouldValidate: true });
                  setValue('billingAddress', found.billingAddress || '', { shouldValidate: true });
                  setValue('shippingAddress', found.shippingAddress || '', { shouldValidate: true });
                  setValue('deliveryDate', found.deliveryDate || null, { shouldValidate: true });
                  setValue('termsConditions', found.termsConditions || '', { shouldValidate: true });
                  setValue('remarks', found.remarks || '', { shouldValidate: true });
                  if (found.items && found.items.length) {
                    // replaceItems(), not setValue('items', ...) — replace()
                    // is useFieldArray's own API and gives every row a fresh
                    // field id, which remounts each ProductCell instead of
                    // reusing the old one. That matters because ProductCell
                    // has its own auto-fill effect keyed off productCode
                    // changing; reused (not remounted) cells saw productCode
                    // change from '' to the order's value, treated it as a
                    // user picking a product, and overwrote the tax rate and
                    // unit price we just set here with the *product master's*
                    // defaults — so a line saved at 18% on the order silently
                    // came in as whatever the product's own default tax rate
                    // was (e.g. 12%) on the challan.
                    replaceItems(found.items.map((i, n) => ({
                      productCode: i.productCode || '', productName: i.productName || '', description: i.description || '',
                      hsnCode: i.hsnCode || '', uom: i.uom || '',
                      quantity: i.quantity != null ? Number(i.quantity) : 1,
                      unitPrice: i.unitPrice != null ? Number(i.unitPrice) : 0,
                      taxPercent: i.taxPercent != null ? Number(i.taxPercent) : 0,
                      batchNo: '',
                      batchAllocations: [], serialAllocations: [],
                      // Copy From: this line came from the order's line n.
                      baseType: 'Sales Order',
                      baseEntry: found.id ?? null,
                      baseNo: found.orderNo || null,
                      baseLine: n + 1,
                    })));
                  }
                }
            };

            // Undo a Copy From: drop the link and the values that came across
            // with it, rather than leaving a stale order's figures sitting in a
            // challan that no longer claims to reference it.
            //
            // The customer is deliberately NOT cleared. It is the user's own
            // selection — it is what made Copy From available in the first
            // place, and clearing it would close the dialog off and force a
            // re-pick just to try a different order from the same customer.
            // Contact Person and the addresses stay too: they belong to the
            // customer, not the order.
            const orderNoValue = watch('orderNo');
            const clearOrder = () => {
              setValue('orderNo', '', { shouldValidate: true });
              setValue('salesPerson', '', { shouldValidate: true });
              setValue('deliveryDate', null, { shouldValidate: true });
              setValue('termsConditions', '', { shouldValidate: true });
              setValue('remarks', '', { shouldValidate: true });
              replaceItems([{ ...emptyItem }]);
            };

            // Switching Branch invalidates a Warehouse choice that doesn't
            // belong to the new branch. Skipped on the very first render so
            // loading an existing record for edit/view doesn't wipe a value
            // it just loaded.
            const prevBranchRef = useRef(branch);
            useEffect(() => {
              if (prevBranchRef.current === branch) return;
              prevBranchRef.current = branch;
              const allowed = new Set(
                (warehouses || []).filter((w) => !branch || w.branch === branch).map((w) => w.whsCode)
              );
              if (watch('fromWarehouse') && !allowed.has(watch('fromWarehouse'))) setValue('fromWarehouse', '');
              // eslint-disable-next-line react-hooks/exhaustive-deps
            }, [branch]);

            return (
              // minWidth: 0 is required — fieldsets default to min-width: min-content,
              // which lets the wide item table blow out the page width on mobile.
              // The Back to List / Cancel buttons are kept outside the fieldset(s)
              // so they stay clickable in read-only (view) mode -- a native
              // <fieldset disabled> disables every descendant control, buttons
              // included.
              <>
              <CopyFromDocumentDialog
                open={copyFromOpen}
                onClose={() => setCopyFromOpen(false)}
                onChoose={applyOrder}
                documents={salesOrders || []}
                party={customerValue}
                partyField="customer"
                partyLabel="customer"
                title="Find Sales Order"
                columns={SALES_ORDER_COPY_COLUMNS}
                emptyMessage="No sales orders found for"
              />
              <DeliveryChallanPrintable
                order={printOrder}
                company={company}
                customerRecord={printCustomerRecord}
                salesOrderRecord={printSalesOrderRecord}
              />
              <Card variant="outlined" sx={{ mb: 2 }}>
                <CardContent sx={{ p: { xs: 2, sm: 3 } }}>
                  <Stack direction="row" alignItems="center" justifyContent="space-between" flexWrap="wrap" gap={1.5} sx={{ mb: 2 }}>
                    <Typography variant="subtitle1" fontWeight={700}>
                      {readOnly ? 'Customer & Document Details (View Only)' : 'Customer & Document Details'}
                    </Typography>
                    <Button type="button" variant="outlined" color="inherit" startIcon={<ArrowBackIcon />} onClick={backToList}>
                      Back to List
                    </Button>
                  </Stack>

                  <fieldset disabled={readOnly} style={{ border: 0, padding: 0, margin: 0, minWidth: 0, width: '100%', display: 'block' }}>
                    <FormGrid columns={3}>
                      <DocumentNoField documentCode="DC" name="challanNo" label="Challan No. *" placeholder="Enter challan number" isCreate={!editingRow} />
                      <FormSelect name="branch" label="Branch *" placeholder="Select branch" options={branchOptions} />
                      <FormDatePicker name="challanDate" label="Challan Date *" />
                      {/* Filled only by Copy From — never typed. A challan's
                          order reference has to be an order that actually
                          exists (the lines carry baseEntry/baseNo back to it,
                          and the server recomputes that order's fulfilment
                          from this despatch), so a free-text box could only
                          ever produce a dangling link. Left blank for a
                          despatch with no order behind it, which the schema
                          already allowed. */}
                      <FormTextField
                        name="orderNo"
                        label="Sales Order No."
                        placeholder="Use Copy From to select an order"
                        InputProps={{ readOnly: true }}
                      />

                      {/* Customer drives this form now: it is picked first, it
                          enables Copy From, and it scopes the order list that
                          dialog shows. It used to be disabled and filled only
                          by the order dropdown, which made a challan without
                          an order impossible to enter. The fields below it are
                          auto-filled but left editable for the same reason —
                          a delivery often goes to a different contact or
                          address than the order recorded. */}
                      <FormSelect name="customer" label="Customer *" placeholder="Select customer" options={customerOptions} />
                      <FormTextField name="contactPerson" label="Contact Person" placeholder="Auto-filled from order/customer" />

                      <FormTextField name="billingAddress" label="Billing Address" placeholder="Auto-filled from order/customer" multiline rows={2} />
                      <FormTextField name="shippingAddress" label="Shipping Address" placeholder="Auto-filled from order/customer" multiline rows={2} />

                      <FormSelect name="salesPerson" label="Sales Person" placeholder="Select sales person" options={salesPersonOptions} />
                      <FormDatePicker name="deliveryDate" label="Delivery Date *" />

                      <FormSelect
                        name="fromWarehouse"
                        label="From Warehouse *"
                        placeholder={branch ? 'Select warehouse' : 'Select a branch first'}
                        options={branchWarehouseOptions}
                        disabled={!branch}
                      />
                    </FormGrid>
                  </fieldset>
                </CardContent>
              </Card>

              <fieldset disabled={readOnly} style={{ border: 0, padding: 0, margin: 0, minWidth: 0, width: '100%', display: 'block' }}>
                <Card variant="outlined" sx={{ mb: 2 }}>
                  <CardContent sx={{ p: { xs: 2, sm: 3 } }}>
                    <Stack direction="row" alignItems="center" justifyContent="space-between" flexWrap="wrap" gap={1.5} sx={{ mb: 2 }}>
                      <Typography variant="subtitle1" fontWeight={700}>Item Details</Typography>
                      <Button type="button" variant="outlined" size="small" startIcon={<AddIcon />} onClick={() => append({ ...emptyItem })}>
                        Add Item
                      </Button>
                    </Stack>

                    {isMobile ? (
                      <Box>
                        {fields.map((field, index) => {
                          const qty = Number(watch(`items.${index}.quantity`)) || 0;
                          const price = Number(watch(`items.${index}.unitPrice`)) || 0;
                          const rowAmount = qty * price;
                          return (
                            <MobileItemCard
                              key={field.id}
                              index={index}
                              amount={rowAmount.toFixed(2)}
                              onRemove={() => removeItem(index)}
                              removeDisabled={fields.length <= 1}
                            >
                              <ProductCell index={index} methods={methods} options={productCodeOptions} products={products} label="Product Code *" placeholder="Select product code" />
                              <ProductCell index={index} methods={methods} options={productNameOptions} products={products} label="Product Name" placeholder="Select product name" />
                              <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', columnGap: 1.5, rowGap: 1.5 }}>
                                <FormTextField name={`items.${index}.hsnCode`} label="HSN/SAC" placeholder="4, 6 or 8 digits" digitsOnly maxLength={8} />
                                <FormTextField name={`items.${index}.uom`} label="Unit" placeholder="Unit" />
                                <FormTextField name={`items.${index}.quantity`} label="Quantity *" type="number" />
                                <FormTextField name={`items.${index}.unitPrice`} label="Rate (₹) *" type="number" />
                                <Box sx={{ gridColumn: '1 / -1' }}><FormTextField name={`items.${index}.batchNo`} label="Batch/Serial No." placeholder="Batch/Serial No." /></Box>
                              </Box>
                              <Box sx={{ mt: 1.5 }}>
                                <BatchSerialCell index={index} methods={methods} product={productsByCode[watch(`items.${index}.productCode`)]} onOpen={(mode) => setBatchDialog({ index, mode })} />
                              </Box>
                            </MobileItemCard>
                          );
                        })}
                      </Box>
                    ) : (
                    <TableContainer ref={itemScrollRef} sx={{ overflowX: 'auto', WebkitOverflowScrolling: 'touch', cursor: 'grab', ...dragScrollbarSx }}>
                      <Table size="small" sx={{ '& tbody .MuiFormHelperText-root:not(.Mui-error)': { display: 'none' } }}>
                        <TableHead>
                          <TableRow>
                            <TableCell width={40}>#</TableCell>
                            <TableCell sx={{ minWidth: productCodeColumnWidth }}>Product Code *</TableCell>
                            <TableCell sx={{ minWidth: productNameColumnWidth }}>Product Name</TableCell>
                            <TableCell sx={{ minWidth: 140 }}>HSN/SAC</TableCell>
                            <TableCell sx={{ minWidth: 110 }}>Unit</TableCell>
                            <TableCell sx={{ minWidth: 110 }}>Quantity *</TableCell>
                            <TableCell sx={{ minWidth: 150 }}>Rate (₹) *</TableCell>
                            <TableCell sx={{ minWidth: 130 }}>Batch/Serial No.</TableCell>
                            <TableCell sx={{ minWidth: 225 }}>Tax %</TableCell>
                            <TableCell sx={{ minWidth: 140 }}>Batch/Serial Selection</TableCell>
                            <TableCell sx={{ minWidth: 110 }}>Amount (₹)</TableCell>
                            <TableCell width={48} />
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {fields.map((field, index) => {
                            const qty = Number(watch(`items.${index}.quantity`)) || 0;
                            const price = Number(watch(`items.${index}.unitPrice`)) || 0;
                            const rowAmount = qty * price;
                            return (
                              <TableRow key={field.id} sx={{ '& > td': { verticalAlign: 'middle' } }}>
                                <TableCell>{index + 1}</TableCell>
                                <TableCell
                                  sx={hoverExpandColumnSx({
                                    base: productCodeColumnWidth,
                                    value: watch(`items.${index}.productCode`),
                                    max: 420,
                                    field: 'select',
                                  })}
                                >
                                  <ProductCell index={index} methods={methods} options={productCodeOptions} products={products} placeholder="Select product code" multiline />
                                </TableCell>
                                <TableCell
                                  sx={hoverExpandColumnSx({
                                    base: productNameColumnWidth,
                                    value: watch(`items.${index}.productName`),
                                    max: 640,
                                    field: 'select',
                                  })}
                                >
                                  <ProductCell index={index} methods={methods} options={productNameOptions} products={products} placeholder="Select product name" multiline />
                                </TableCell>
                                <TableCell>
                                  <FormTextField name={`items.${index}.hsnCode`} label="" placeholder="HSN/SAC" digitsOnly maxLength={8} />
                                </TableCell>
                                <TableCell>
                                  <FormTextField name={`items.${index}.uom`} label="" placeholder="Unit" />
                                </TableCell>
                                <TableCell>
                                  <FormTextField name={`items.${index}.quantity`} label="" type="number" />
                                </TableCell>
                                <TableCell>
                                  <FormTextField name={`items.${index}.unitPrice`} label="" type="number" />
                                </TableCell>
                                <TableCell>
                                  <FormTextField name={`items.${index}.batchNo`} label="" placeholder="Batch/Serial No." />
                                </TableCell>
                                <TableCell>
                                  <FormSelect name={`items.${index}.taxPercent`} label="" options={taxPercentOptions} />
                                </TableCell>
                                <TableCell>
                                  <BatchSerialCell index={index} methods={methods} product={productsByCode[watch(`items.${index}.productCode`)]} onOpen={(mode) => setBatchDialog({ index, mode })} />
                                </TableCell>
                                <TableCell sx={{ whiteSpace: 'nowrap' }}>{rowAmount.toFixed(2)}</TableCell>
                                <TableCell>
                                  <IconButton
                                    type="button"
                                    size="small"
                                    color="error"
                                    onClick={() => removeItem(index)}
                                    disabled={fields.length <= 1}
                                    aria-label="remove item"
                                  >
                                    <DeleteIcon fontSize="small" />
                                  </IconButton>
                                </TableCell>
                              </TableRow>
                            );
                          })}
                        </TableBody>
                      </Table>
                    </TableContainer>
                    )}
                  </CardContent>
                </Card>
              </fieldset>

              <Card variant="outlined">
                <CardContent sx={{ p: { xs: 2, sm: 3 } }}>
                  <fieldset disabled={readOnly} style={{ border: 0, padding: 0, margin: 0, minWidth: 0, width: '100%', display: 'block' }}>
                    <Grid container spacing={3}>
                      <Grid item xs={12} md={4}>
                        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1 }}>Remarks</Typography>
                        <FormTextField name="remarks" label="" placeholder="Enter any remarks (optional)" multiline rows={6} disabled />
                      </Grid>

                      <Grid item xs={12} md={4}>
                        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1 }}>Terms & Conditions</Typography>
                        <FormTextField name="termsConditions" label="" placeholder="Enter terms and conditions" multiline rows={6} disabled />
                      </Grid>

                      <Grid item xs={12} md={4}>
                        <DocumentTotalsPanel totals={totals} interState={interState} discountField={null} />
                      </Grid>
                    </Grid>
                  </fieldset>

                    <Stack
                      direction={{ xs: 'column', sm: 'row' }}
                      spacing={1.5}
                      justifyContent={{ xs: 'stretch', sm: 'flex-end' }}
                      sx={{ mt: 3 }}
                    >
                      {/* Copy From sits immediately left of Cancel and stays
                          disabled until a Customer is chosen — the dialog it
                          opens lists that customer's sales orders, so with no
                          customer there is nothing for it to show. Hidden in
                          view mode, where nothing is being filled in. */}
                      {!readOnly && (
                        orderNoValue ? (
                          <Button
                            fullWidth={isMobile}
                            type="button"
                            variant="outlined"
                            color="inherit"
                            startIcon={<CloseIcon />}
                            onClick={clearOrder}
                            disabled={creating || updating}
                          >
                            Clear Copied Order
                          </Button>
                        ) : (
                          <Button
                            fullWidth={isMobile}
                            type="button"
                            variant="outlined"
                            startIcon={<ContentCopyOutlinedIcon />}
                            onClick={() => setCopyFromOpen(true)}
                            disabled={!customerValue || creating || updating}
                          >
                            Copy From
                          </Button>
                        )
                      )}
                      <Button fullWidth={isMobile} type="button" variant="outlined" color="inherit" startIcon={<CloseIcon />} onClick={backToList} disabled={creating || updating}>
                        Cancel
                      </Button>
                      <Button fullWidth={isMobile} type="button" variant="outlined" startIcon={<PrintOutlinedIcon />} onClick={() => window.print()}>
                        Print
                      </Button>
                      {!readOnly && (
                        <>
                          <FormSubmitButton
                            fullWidth={isMobile}
                            variant="outlined"
                            onClick={() => { pendingStatusRef.current = 'Pending'; }}
                            disabled={creating || updating}
                          >
                            Save as Draft
                          </FormSubmitButton>
                          <FormSubmitButton
                            fullWidth={isMobile}
                            startIcon={<PrintOutlinedIcon />}
                            onClick={() => { pendingStatusRef.current = 'Open'; }}
                            disabled={creating || updating}
                          >
                            {editingRow ? 'Update Challan' : 'Save & Print'}
                          </FormSubmitButton>
                        </>
                      )}
                    </Stack>
                  </CardContent>
                </Card>

                {batchDialog && batchDialog.index < fields.length && (
                  <BatchSerialSelectionDialog
                    open
                    onClose={() => setBatchDialog(null)}
                    mode={batchDialog.mode}
                    readOnly={readOnly}
                    docNo={editingRow?.challanNo}
                    itemNumber={watch(`items.${batchDialog.index}.productCode`)}
                    itemDescription={watch(`items.${batchDialog.index}.productName`)}
                    warehouseCode={watch('fromWarehouse')}
                    warehouseName={(branchWarehouseOptions.find((w) => w.value === watch('fromWarehouse')) || {}).label}
                    totalNeeded={Number(watch(`items.${batchDialog.index}.quantity`)) || 0}
                    productCode={watch(`items.${batchDialog.index}.productCode`)}
                    value={watch(`items.${batchDialog.index}.${batchDialog.mode === 'Batch' ? 'batchAllocations' : 'serialAllocations'}`)}
                    onSave={(rows) => setValue(
                      `items.${batchDialog.index}.${batchDialog.mode === 'Batch' ? 'batchAllocations' : 'serialAllocations'}`,
                      rows,
                      { shouldValidate: true }
                    )}
                  />
                )}
              </>
            );
          }}
        </AppForm>
        </RouteMapContextMenu>
      ) : (
        <Card variant="outlined">
          <CardContent sx={{ p: 0 }}>
            <Stack
              direction={{ xs: 'column', sm: 'row' }}
              alignItems={{ xs: 'stretch', sm: 'center' }}
              justifyContent="space-between"
              flexWrap="wrap"
              gap={1.5}
              sx={{ px: { xs: 2, sm: 3 }, pt: 2.5, pb: 1.5 }}
            >
              <Typography variant="subtitle1" fontWeight={700}>Delivery Challan List</Typography>
              <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.5} flexWrap="wrap" useFlexGap sx={{ width: { xs: '100%', sm: 'auto' } }}>
                <TableSearchFilter table={table} placeholder="Search by challan no., order no., customer..." showFilter={false} />
                <Stack direction="row" spacing={1.5}>
                  <Button size="small" variant="outlined" color="inherit" startIcon={<FilterListIcon />} onClick={() => setShowFilters((v) => !v)} sx={{ whiteSpace: 'nowrap', flexShrink: 0 }}>
                    Filter
                  </Button>
                  <CanAdd>
                    <Button size="small" variant="contained" startIcon={<AddIcon />} onClick={openCreate} sx={{ whiteSpace: 'nowrap', flexShrink: 0 }}>
                      Create Challan
                    </Button>
                  </CanAdd>
                </Stack>
              </Stack>
            </Stack>

            <Collapse in={showFilters} unmountOnExit>
            <Box sx={{ px: { xs: 2, sm: 3 }, pb: 2 }}>
              <FormGrid columns={5}>
                <FilterAutocomplete
                  label="Customer"
                  allLabel="All Customers"
                  options={customerOptions}
                  value={customerFilter}
                  onChange={(v) => { setCustomerFilter(v); setPage(0); }}
                />
                <Autocomplete
                  size="small"
                  options={STATUS_FILTERS}
                  value={statusFilter}
                  onChange={(_e, v) => { setStatusFilter(v || 'All Status'); setPage(0); }}
                  disableClearable
                  renderInput={(params) => <TextField {...params} label="Status" InputLabelProps={{ shrink: true }} />}
                />
                <TextField
                  size="small"
                  fullWidth
                  label="Date Range"
                  value={dateRangeLabel}
                  onClick={(e) => setDateAnchor(e.currentTarget)}
                  InputProps={{
                    readOnly: true,
                    startAdornment: <InputAdornment position="start"><EventIcon fontSize="small" /></InputAdornment>,
                    endAdornment: (dateFrom || dateTo) ? (
                      <InputAdornment position="end">
                        <IconButton size="small" onClick={(e) => { e.stopPropagation(); setDateFrom(null); setDateTo(null); setPage(0); }}>
                          <CloseIcon fontSize="small" />
                        </IconButton>
                      </InputAdornment>
                    ) : null,
                  }}
                  InputLabelProps={{ shrink: true }}
                  sx={{ cursor: 'pointer' }}
                />
                <FilterAutocomplete
                  label="From Warehouse"
                  allLabel="All Warehouses"
                  options={allWarehouseOptions}
                  value={warehouseFilter}
                  onChange={(v) => { setWarehouseFilter(v); setPage(0); }}
                />
                <FilterAutocomplete
                  label="Sales Person"
                  allLabel="All Sales Persons"
                  options={salesPersonOptions}
                  value={salesPersonFilter}
                  onChange={(v) => { setSalesPersonFilter(v); setPage(0); }}
                />
              </FormGrid>

              <Popover
                open={!!dateAnchor}
                anchorEl={dateAnchor}
                onClose={() => setDateAnchor(null)}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
              >
                <Stack direction="row" spacing={2} sx={{ p: 2 }}>
                  <DatePicker label="From" value={dateFrom} onChange={(v) => { setDateFrom(v); setPage(0); }} slotProps={{ textField: { size: 'small' } }} />
                  <DatePicker label="To" value={dateTo} onChange={(v) => { setDateTo(v); setPage(0); }} slotProps={{ textField: { size: 'small' } }} />
                </Stack>
              </Popover>
              <TableFilterPanel table={table} embedded open />
            </Box>
            </Collapse>

            {checkedIds.length > 0 && (
              <Box sx={{ px: { xs: 2, sm: 3 }, pb: 1.5 }}>
                <Button variant="outlined" color="error" size="small" startIcon={<DeleteIcon />} onClick={removeSelected}>
                  Delete Selected ({checkedIds.length})
                </Button>
              </Box>
            )}

            {isMobile ? (
              <Box sx={{ px: 2, pb: 1 }}>
                {!isLoading && pagedRows.map((row) => (
                  <MobileRecordCard
                    key={row.id}
                    title={row.challanNo}
                    statusChip={<Chip size="small" label={row.status} color={STATUS_COLORS[row.status] || 'default'} variant="outlined" />}
                    fields={[
                      { label: 'Customer', value: row.customer || '—' },
                      { label: 'Order No.', value: row.orderNo || '—' },
                      { label: 'Challan Date', value: row.challanDate ? dayjs(row.challanDate).format('DD/MM/YYYY') : '—' },
                      { label: 'Delivery Date', value: row.deliveryDate ? dayjs(row.deliveryDate).format('DD/MM/YYYY') : '—' },
                      { label: 'Amount', value: `₹${Number(row.amount).toFixed(2)}` },
                    ]}
                    onEdit={() => handleEdit(row)}
                    onDelete={() => handleDelete(row)}
                  />
                ))}
                {!isLoading && filteredRows.length === 0 && (
                  <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>No delivery challans found</Typography>
                )}
              </Box>
            ) : (
              <ScrollableTableContainer>
                <Table size="small" stickyHeader>
                  <TableHead>
                    <TableRow>
                      <SortableHeaderCell field="id" sort={table.sort} onSort={table.toggleSort} padding="checkbox">
                        <Checkbox
                          size="small"
                          checked={pagedRows.length > 0 && pagedRows.every((r) => checkedIds.includes(r.id))}
                          indeterminate={pagedRows.some((r) => checkedIds.includes(r.id)) && !pagedRows.every((r) => checkedIds.includes(r.id))}
                          onChange={(e) => {
                            const ids = pagedRows.map((r) => r.id);
                            setCheckedIds((prev) => e.target.checked
                              ? Array.from(new Set([...prev, ...ids]))
                              : prev.filter((c) => !ids.includes(c)));
                          }}
                        />
                      </SortableHeaderCell>
                      <TableCell width={40}>#</TableCell>
                      <SortableHeaderCell field="challanNo" sort={table.sort} onSort={table.toggleSort}>Challan No.</SortableHeaderCell>
                      <SortableHeaderCell field="orderNo" sort={table.sort} onSort={table.toggleSort}>Order No.</SortableHeaderCell>
                      <SortableHeaderCell field="customer" sort={table.sort} onSort={table.toggleSort}>Customer</SortableHeaderCell>
                      <SortableHeaderCell field="challanDate" sort={table.sort} onSort={table.toggleSort}>Challan Date</SortableHeaderCell>
                      <SortableHeaderCell field="deliveryDate" sort={table.sort} onSort={table.toggleSort}>Delivery Date</SortableHeaderCell>
                      <SortableHeaderCell field="fromWarehouse" sort={table.sort} onSort={table.toggleSort}>From Warehouse</SortableHeaderCell>
                      <SortableHeaderCell field="amount" sort={table.sort} onSort={table.toggleSort}>Amount (₹)</SortableHeaderCell>
                      <SortableHeaderCell field="status" sort={table.sort} onSort={table.toggleSort}>Status</SortableHeaderCell>
                      <TableCell align="right">Action</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {!isLoading && pagedRows.map((row, i) => (
                      <TableRow key={row.id} hover>
                        <TableCell padding="checkbox">
                          <Checkbox
                            size="small"
                            checked={checkedIds.includes(row.id)}
                            onChange={() => setCheckedIds((prev) => prev.includes(row.id) ? prev.filter((c) => c !== row.id) : [...prev, row.id])}
                          />
                        </TableCell>
                        <TableCell>{page * pageSize + i + 1}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.challanNo}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.orderNo || '—'}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.customer || '—'}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.challanDate ? dayjs(row.challanDate).format('DD/MM/YYYY') : '—'}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.deliveryDate ? dayjs(row.deliveryDate).format('DD/MM/YYYY') : '—'}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.fromWarehouse || '—'}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{Number(row.amount).toFixed(2)}</TableCell>
                        <TableCell>
                          <Chip size="small" label={row.status} color={STATUS_COLORS[row.status] || 'default'} variant="outlined" />
                        </TableCell>
                        <TableCell align="right">
                          <Stack direction="row" spacing={0.5} justifyContent="flex-end">
                            <Tooltip title="View">
                              <IconButton size="small" onClick={() => handleView(row)} aria-label="view">
                                <VisibilityOutlinedIcon fontSize="small" />
                              </IconButton>
                            </Tooltip>
                            <RouteMapButton flow="sales" type="challan" docNo={row.challanNo} />
                            <Tooltip title="Print">
                              <IconButton size="small" onClick={() => handlePrint(row)} aria-label="print">
                                <PrintOutlinedIcon fontSize="small" />
                              </IconButton>
                            </Tooltip>
                            <IconButton
                              size="small"
                              onClick={(e) => { setRowMenuAnchor(e.currentTarget); setRowMenuTarget(row); }}
                              aria-label="more actions"
                            >
                              <MoreVertIcon fontSize="small" />
                            </IconButton>
                          </Stack>
                        </TableCell>
                      </TableRow>
                    ))}
                    {!isLoading && filteredRows.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={11}>
                          <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>No delivery challans found</Typography>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </ScrollableTableContainer>
            )}

            <Menu anchorEl={rowMenuAnchor} open={!!rowMenuAnchor} onClose={() => setRowMenuAnchor(null)}>
              <CanEdit>
                <MenuItem onClick={() => handleEdit(rowMenuTarget)}>
                  <ListItemIcon><EditIcon fontSize="small" /></ListItemIcon>
                  <ListItemText>Edit</ListItemText>
                </MenuItem>
              </CanEdit>
              <CanDelete>
                <MenuItem onClick={() => handleDelete(rowMenuTarget)}>
                  <ListItemIcon><DeleteIcon fontSize="small" color="error" /></ListItemIcon>
                  <ListItemText>Delete</ListItemText>
                </MenuItem>
              </CanDelete>
            </Menu>

            <EntityListPagination total={filteredRows.length} page={page} onChange={setPage} pageSize={pageSize} onPageSizeChange={(v) => { setPageSize(v); setPage(0); }} />
          </CardContent>
        </Card>
      )}
    </Box>
  );
}

// Both the Product Code and Product Name columns are selects over the same
// underlying items.{index}.productCode field — Product Code lists codes,
// Product Name lists names, and picking either fills the rest of the row
// from the product master. Isolated so the per-row auto-fill effect only
// re-runs for the row whose product actually changed, not every row on every
// keystroke.
function ProductCell({ index, methods, options, products, label = '', placeholder = 'Select product', disabled = false, multiline = false, sx }) {
  const { watch, setValue } = methods;
  const productCodeValue = watch(`items.${index}.productCode`);
  const prevValue = useRef(productCodeValue);

  useEffect(() => {
    if (productCodeValue !== prevValue.current) {
      const found = (products || []).find((p) => p.productCode === productCodeValue);
      if (found) {
        setValue(`items.${index}.productName`, found.productName, { shouldValidate: true });
        setValue(`items.${index}.description`, found.productName, { shouldValidate: true });
        setValue(`items.${index}.hsnCode`, found.hsnCode || '', { shouldValidate: true });
        setValue(`items.${index}.uom`, found.uom || '', { shouldValidate: true });
        setValue(`items.${index}.taxPercent`, found.taxRate != null ? Number(found.taxRate) : 0, { shouldValidate: true });
        setValue(`items.${index}.unitPrice`, found.salesPrice != null ? Number(found.salesPrice) : 0, { shouldValidate: true });
      }
      prevValue.current = productCodeValue;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [productCodeValue]);

  return <FormSelect name={`items.${index}.productCode`} label={label} placeholder={placeholder} options={options} disabled={disabled} multiline={multiline} sx={sx} />;
}

// Shows nothing for a None-tracked (or unrecognised) product — the column
// only means something once Product Master's Manage Item By is Batch or
// Serial for the row's selected product. Otherwise a button that opens the
// matching "... - Selection" dialog, labelled with how much of the line is
// selected so far so an incomplete line is visible without opening it.
function BatchSerialCell({ index, methods, product, onOpen }) {
  const { watch } = methods;
  const trackingMode = product?.manageItemBy;
  if (trackingMode !== 'Batch' && trackingMode !== 'Serial') {
    return <Typography variant="caption" color="text.secondary">—</Typography>;
  }
  const needed = Number(watch(`items.${index}.quantity`)) || 0;
  const batchAllocations = watch(`items.${index}.batchAllocations`) || [];
  const serialAllocations = watch(`items.${index}.serialAllocations`) || [];
  const selected = trackingMode === 'Batch'
    ? batchAllocations.reduce((sum, b) => sum + (Number(b.quantity) || 0), 0)
    : serialAllocations.length;
  const complete = needed > 0 && Math.abs(selected - needed) < 0.005;

  return (
    <Button
      type="button"
      size="small"
      variant="outlined"
      color={complete ? 'success' : 'warning'}
      startIcon={<Inventory2OutlinedIcon fontSize="small" />}
      onClick={() => onOpen(trackingMode)}
      sx={{ whiteSpace: 'nowrap' }}
    >
      {trackingMode}: {selected}/{needed}
    </Button>
  );
}
