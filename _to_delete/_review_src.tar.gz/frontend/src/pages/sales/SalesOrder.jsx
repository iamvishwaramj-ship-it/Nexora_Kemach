import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Box, Typography, Button, Card, CardContent, Stack, TextField, InputAdornment, Table,
  TableBody, TableCell, TableContainer, TableHead, TableRow, Chip, IconButton, Menu, MenuItem,
  ListItemIcon, ListItemText, Checkbox, Autocomplete, Popover, Grid, Tooltip,
  Collapse, CircularProgress,
} from '@mui/material';
import { useFieldArray } from 'react-hook-form';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import dayjs from 'dayjs';
import ShoppingCartOutlinedIcon from '@mui/icons-material/ShoppingCartOutlined';
import AddIcon from '@mui/icons-material/Add';
import CloseIcon from '@mui/icons-material/Close';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import SearchIcon from '@mui/icons-material/Search';
import FilterListIcon from '@mui/icons-material/FilterList';
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import ContentCopyOutlinedIcon from '@mui/icons-material/ContentCopyOutlined';
import PrintOutlinedIcon from '@mui/icons-material/PrintOutlined';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import EditIcon from '@mui/icons-material/EditOutlined';
import DeleteIcon from '@mui/icons-material/DeleteOutline';
import EventIcon from '@mui/icons-material/Event';
import AppForm, { FormGrid, FormSubmitButton } from '../../components/form/AppForm';
import FormTextField from '../../components/form/FormTextField';
import FormSelect from '../../components/form/FormSelect';
import FormDatePicker from '../../components/form/FormDatePicker';
import EntityHeaderCard from '../../components/common/EntityHeaderCard';
import CompanyBadge from '../../components/common/CompanyBadge';
import EntityListPagination from '../../components/data-display/EntityListPagination';
import FilterAutocomplete from '../../components/data-display/FilterAutocomplete';
import MobileRecordCard from '../../components/data-display/MobileRecordCard';
import MobileItemCard from '../../components/data-display/MobileItemCard';
import { useIsMobileListView } from '../../components/data-display/useIsMobileListView';
import useDragScroll from '../../components/data-display/useDragScroll';
import { useNotify } from '../../components/feedback/NotificationProvider';
import { applyServerErrors } from '../../lib/formErrors';
import { useConfirm } from '../../components/feedback/ConfirmationDialog';
import { salesOrderSchema, ORDER_STATUS_OPTIONS, ORDER_PAYMENT_STATUS_OPTIONS, ENQUIRY_SOURCE_OPTIONS } from '../../lib/validation/salesSchemas';
import { buildDocument, round2, isInterState } from '../../lib/documentTotals';
import DocumentTotalsPanel from '../../components/form/DocumentTotalsPanel';
import { CURRENCY_OPTIONS, PAYMENT_TERMS_OPTIONS } from '../../lib/validation/partnerSchemas';
import { salesOrderApi, salesQuotationApi, customerApi, productApi, salesEmployeeApi, branchApi, taxCodeApi } from '../../features/resources';
import { productOptionsFor, PRODUCT_USAGE } from '../../lib/productUsage';
import { buildTaxPercentOptions } from '../../lib/taxCodeOptions';
import { hoverExpandColumnSx, itemColumnBaseWidth } from '../../lib/columnWidth';
import { useGetCompanyDetailsQuery, usePeekDocumentNumberMutation } from '../../features/company/companyDetailsApi';
import DocumentNoField, { peekNextDocumentNumber } from '../../components/form/DocumentNoField';
import SalesOrderPrintable from '../../components/print/SalesOrderPrintable';
import useTableFeatures from '../../components/data-display/useTableFeatures';
import TableSearchFilter from '../../components/data-display/TableSearchFilter';
import SortableHeaderCell from '../../components/data-display/SortableHeaderCell';
import ScrollableTableContainer, { dragScrollbarSx } from '../../components/data-display/ScrollableTableContainer';


import { CanAdd, CanEdit, CanDelete } from '../../components/common/PermissionGate';
import TableFilterPanel from '../../components/data-display/TableFilterPanel';
import RouteMapButton from '../../components/common/RouteMapButton';
import RouteMapContextMenu from '../../components/common/RouteMapContextMenu';
import CopyFromDocumentDialog from '../../components/common/CopyFromDocumentDialog';

// Columns for the "Find Sales Quotation" dialog opened by Copy From. A sales
// quotation names its party `customer`, which is what the dialog filters on.
const QUOTATION_COPY_COLUMNS = [
  { field: 'quotationNo', headerName: 'Quotation No', nowrap: true },
  { field: 'customer', headerName: 'Customer Name' },
  { field: 'quotationDate', headerName: 'Document Date', type: 'date' },
  { field: 'status', headerName: 'Status' },
];
const emptyItem = { productCode: '', productName: '', description: '', hsnCode: '', uom: '', quantity: 1, unitPrice: 0, discountPercent: 0, taxPercent: 18 };

function getEmptyValues() {
  return {
    orderNo: '', branch: '', quotationNo: '', customer: '', contactPerson: '', phone: '', email: '',
    orderDate: new Date(), deliveryDate: null, referenceNo: '',
    currency: 'INR', paymentTerms: '', salesPerson: '', source: '', billingAddress: '', shippingAddress: '',
    termsConditions: '', remarks: '', discountPercent: 0, status: 'Draft', paymentStatus: 'Unpaid', invoiceNo: '',
    items: [{ ...emptyItem }],
  };
}

// Totals come from the shared engine in lib/documentTotals.js, which the
// backend mirrors exactly — the figures shown here while editing are the
// figures that get saved. Each page used to carry its own copy of this
// arithmetic and the copies had drifted apart; this document in particular
// used to hard-code CGST and SGST at 9% each regardless of what the goods
// actually attract.
//
// `grandTotal` and `discount` are kept in the returned shape because the
// totals panel below reads those names.
// `interState` must be passed through rather than defaulted: the server
// decides CGST/SGST vs IGST by comparing this document's Place of Supply
// against the company's registered state, and for a long time no page passed
// the flag at all — so an inter-state document displayed a CGST/SGST split
// while the record it saved held IGST.
//
function computeTotals(items, discountPercent, interState = false) {
  const { totals } = buildDocument(items, discountPercent, {
    interState,
    roundOff: true,
  });
  return {
    ...totals,
    discount: round2(totals.subtotal - totals.taxableAmount),
    grandTotal: totals.amount,
  };
}

function rowToFormValues(row) {
  return {
    orderNo: row.orderNo, branch: row.branch || '', quotationNo: row.quotationNo || '', customer: row.customer || '', contactPerson: row.contactPerson || '',
    phone: row.phone || '', email: row.email || '',
    orderDate: row.orderDate, deliveryDate: row.deliveryDate, referenceNo: row.referenceNo || '',
    currency: row.currency || 'INR', paymentTerms: row.paymentTerms || '', salesPerson: row.salesPerson || '',
    source: row.source || '',
    billingAddress: row.billingAddress || '', shippingAddress: row.shippingAddress || '',
    termsConditions: row.termsConditions || '', remarks: row.remarks || '',
    discountPercent: row.discountPercent != null ? Number(row.discountPercent) : 0,
    status: row.status || 'Draft', paymentStatus: row.paymentStatus || 'Unpaid', invoiceNo: row.invoiceNo || '',
    items: (row.items && row.items.length ? row.items : [{ ...emptyItem }]).map((i) => ({
      productCode: i.productCode || '', productName: i.productName || '', description: i.description || '',
      hsnCode: i.hsnCode || '', uom: i.uom || '',
      quantity: i.quantity != null ? Number(i.quantity) : 1,
      unitPrice: i.unitPrice != null ? Number(i.unitPrice) : 0,
      discountPercent: i.discountPercent != null ? Number(i.discountPercent) : 0,
      taxPercent: i.taxPercent != null ? Number(i.taxPercent) : 18,
    })),
  };
}

const PAGE_SIZE = 10;
const STATUS_FILTERS = ['All Status', ...ORDER_STATUS_OPTIONS];
const PAYMENT_STATUS_FILTERS = ['All', ...ORDER_PAYMENT_STATUS_OPTIONS];

const STATUS_COLORS = { Draft: 'default', Confirmed: 'success', Pending: 'warning', Shipped: 'info', Delivered: 'success', Cancelled: 'error' };
const PAYMENT_STATUS_COLORS = { Unpaid: 'error', 'Partially Paid': 'warning', Paid: 'success' };

export default function SalesOrder({ openDocNo } = {}) {
  const notify = useNotify();
  const confirmDialog = useConfirm();
  const isMobile = useIsMobileListView();
  const itemScrollRef = useDragScroll();
  const { data: orders, isLoading } = salesOrderApi.useList();
  const { data: quotations } = salesQuotationApi.useList();
  const { data: customers } = customerApi.useList();
  const { data: products } = productApi.useList();
  const { data: salesEmployees } = salesEmployeeApi.useList();
  const { data: branches } = branchApi.useList();
  const { data: taxCodes } = taxCodeApi.useList();
  const taxPercentOptions = useMemo(() => buildTaxPercentOptions(taxCodes), [taxCodes]);
  const { data: company } = useGetCompanyDetailsQuery();
  const [create, { isLoading: creating }] = salesOrderApi.useCreate();
  const [update, { isLoading: updating }] = salesOrderApi.useUpdate();
  const [remove] = salesOrderApi.useDelete();
  const [peekDocumentNumber] = usePeekDocumentNumberMutation();

  const customerOptions = (customers || []).map((c) => ({ label: c.customerName, value: c.customerName }));
  const salesPersonOptions = (salesEmployees || []).map((s) => ({ label: s.employeeName, value: s.employeeName }));
  // Quotations are no longer offered as a dropdown on the form — they are
  // picked through the Copy From dialog, which scopes the list to the selected
  // customer. The raw `quotations` list is what that dialog takes.
  const sourceOptions = ENQUIRY_SOURCE_OPTIONS.map((s) => ({ label: s, value: s }));
  const branchOptions = (branches || []).map((b) => ({ label: b.branchName, value: b.branchName }));

  // View toggles between the order list and the full-page Create/Edit
  // form — same page, no dialog/popup, per the standard CRUD page template.
  const [view, setView] = useState('list');
  const [editingRow, setEditingRow] = useState(null);

  // Only products flagged for the sales flow on Product Master are offered
  // here — see lib/productUsage.js. `products` itself stays unfiltered below,
  // because the line lookups (price, tax, UOM, batch/serial mode) must still
  // resolve a product this document already names even if it has since been
  // re-flagged; passing the saved lines' codes as `keepCodes` is what keeps
  // reopening an existing document from silently blanking its own rows.
  const selectableProducts = productOptionsFor(
    products,
    PRODUCT_USAGE.SALES,
    (editingRow?.items || []).map((i) => i.productCode)
  );
  const productCodeOptions = selectableProducts.map((p) => ({ label: p.productCode, value: p.productCode }));
  const productNameOptions = selectableProducts.map((p) => ({ label: p.productName, value: p.productCode }));
  const [readOnly, setReadOnly] = useState(false);
  const [formKey, setFormKey] = useState(0);
  // Copy From ("Find Sales Quotation") dialog. Held at page level rather than
  // inside AppForm's render prop so remounting the form on formKey change
  // can't leave a dialog orphaned open over a freshly reset form.
  const [copyFromOpen, setCopyFromOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [customerFilter, setCustomerFilter] = useState(null);
  const [statusFilter, setStatusFilter] = useState('All Status');
  const [salesPersonFilter, setSalesPersonFilter] = useState(null);
  const [paymentStatusFilter, setPaymentStatusFilter] = useState('All');
  const [dateFrom, setDateFrom] = useState(null);
  const [dateTo, setDateTo] = useState(null);
  const [dateAnchor, setDateAnchor] = useState(null);
  const [showFilters, setShowFilters] = useState(false);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(PAGE_SIZE);
  const [checkedIds, setCheckedIds] = useState([]);
  const [rowMenuAnchor, setRowMenuAnchor] = useState(null);
  const [rowMenuTarget, setRowMenuTarget] = useState(null);
  const pendingStatusRef = useRef(null);

  const rows = orders || [];

  const baseTableRows = useMemo(() => {
    const q = '';
    return rows.filter((r) => {
      const matchesSearch = !q || [r.orderNo, r.customer, r.referenceNo].some((v) => String(v || '').toLowerCase().includes(q));
      const matchesCustomer = !customerFilter || r.customer === customerFilter.value;
      const matchesStatus = statusFilter === 'All Status' || r.status === statusFilter;
      const matchesSalesPerson = !salesPersonFilter || r.salesPerson === salesPersonFilter.value;
      const matchesPaymentStatus = paymentStatusFilter === 'All' || r.paymentStatus === paymentStatusFilter;
      const od = r.orderDate ? dayjs(r.orderDate) : null;
      const matchesFrom = !dateFrom || (od && !od.isBefore(dateFrom, 'day'));
      const matchesTo = !dateTo || (od && !od.isAfter(dateTo, 'day'));
      return matchesSearch && matchesCustomer && matchesStatus && matchesSalesPerson && matchesPaymentStatus && matchesFrom && matchesTo;
    });
  }, [rows, customerFilter, statusFilter, salesPersonFilter, paymentStatusFilter, dateFrom, dateTo]);

  // Column definitions drive the global search, the sort icons and the filter
  // popover — see components/data-display/useTableFeatures.js.
  const tableColumns = useMemo(() => ([
    { field: 'id', headerName: 'Select', filter: false, searchable: false },
    { field: 'orderNo', headerName: 'Order No.', filter: 'text' },
    { field: 'orderDate', headerName: 'Order Date', filter: 'dateRange', sortValue: (row) => (row.orderDate ? new Date(row.orderDate).getTime() : null) },
    { field: 'customer', headerName: 'Customer', filter: 'text' },
    { field: 'deliveryDate', headerName: 'Delivery Date', filter: 'dateRange', sortValue: (row) => (row.deliveryDate ? new Date(row.deliveryDate).getTime() : null) },
    { field: 'amount', headerName: 'Amount (₹)', filter: 'numberRange', sortValue: (row) => (row.amount == null || row.amount === '' ? null : Number(row.amount)) },
    { field: 'status', headerName: 'Status', filter: 'select' },
    { field: 'paymentStatus', headerName: 'Payment Status', filter: 'select' },
  ]), []);
  const table = useTableFeatures(baseTableRows, tableColumns, { onChange: setPage });
  const filteredRows = table.rows;

  const pagedRows = useMemo(
    () => filteredRows.slice(page * pageSize, page * pageSize + pageSize),
    [filteredRows, page, pageSize]
  );

  const openCreate = () => {
    setEditingRow(null);
    setReadOnly(false);
    setFormKey((k) => k + 1);
    setView('form');
  };

  const backToList = () => {
    setView('list');
    setEditingRow(null);
    setReadOnly(false);
    setCopyFromOpen(false);
  };

  const handleView = (row) => {
    setEditingRow(row);
    setReadOnly(true);
    setFormKey((k) => k + 1);
    setView('form');
  };

  // Opened from the Route Map's document preview popup: jump straight into
  // this record's own read-only View, exactly as clicking it in the list
  // would, instead of requiring the user to find and click the row.
  useEffect(() => {
    if (!openDocNo) return;
    if (editingRow && editingRow.orderNo === openDocNo) return;
    const match = rows.find((r) => r.orderNo === openDocNo);
    if (match) handleView(match);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [openDocNo, rows]);

  const handleEdit = (row) => {
    setEditingRow(row);
    setReadOnly(false);
    setFormKey((k) => k + 1);
    setView('form');
    setRowMenuAnchor(null);
  };

  const handlePrint = (row) => {
    setRowMenuAnchor(null);
    handleView(row);
    setTimeout(() => window.print(), 300);
  };

  const handleDuplicate = async (row) => {
    const orderNo = await peekNextDocumentNumber(peekDocumentNumber, 'SO', notify);
    const payload = { ...rowToFormValues(row), orderNo, status: 'Draft', paymentStatus: 'Unpaid' };
    try {
      await create(payload).unwrap();
      notify.success('Order duplicated as a new draft');
    } catch (err) {
      notify.error(err?.data?.message || 'Duplicate failed');
    }
  };

  const handleDelete = async (row) => {
    setRowMenuAnchor(null);
    const ok = await confirmDialog({
      title: 'Delete order',
      message: `Are you sure you want to delete "${row.orderNo}"? This cannot be undone.`,
      confirmLabel: 'Delete',
      severity: 'error',
    });
    if (!ok) return;
    try {
      await remove(row.id).unwrap();
      notify.success('Order deleted');
    } catch (err) {
      notify.error(err?.data?.message || 'Delete failed');
    }
  };

  const removeSelected = async () => {
    const ok = await confirmDialog({
      title: 'Delete selected orders',
      message: `Delete ${checkedIds.length} selected order${checkedIds.length > 1 ? 's' : ''}? This cannot be undone.`,
      confirmLabel: 'Delete',
      severity: 'error',
    });
    if (!ok) return;
    try {
      await Promise.all(checkedIds.map((id) => remove(id).unwrap()));
      notify.success('Selected orders deleted');
      setCheckedIds([]);
    } catch (err) {
      notify.error(err?.data?.message || 'Delete failed');
    }
  };

  const handleSubmit = async (values, formMethods) => {
    // "Save as Draft" is a shortcut that forces Draft. The main Save/Update
    // button does NOT force a status — it used to always set 'Confirmed',
    // which silently downgraded an already Partially Delivered / Closed
    // order back to Confirmed on every edit, even one that only changed an
    // unrelated field (status here is mostly system-derived — see
    // recomputeSalesOrder). Falling back to values.status just keeps
    // whatever the record's current status already is.
    const payload = { ...values, status: pendingStatusRef.current || values.status };
    try {
      if (editingRow) {
        await update({ id: editingRow.id, ...payload }).unwrap();
        notify.success('Order updated');
      } else {
        await create(payload).unwrap();
        notify.success('Order saved');
      }
      backToList();
    } catch (err) {
      notify.error(applyServerErrors(err, formMethods.setError));
    }
  };

  const dateRangeLabel = dateFrom && dateTo
    ? `${dateFrom.format('DD/MM/YYYY')} - ${dateTo.format('DD/MM/YYYY')}`
    : 'Select date range';

  if (openDocNo && (!editingRow || editingRow.orderNo !== openDocNo)) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', py: 10 }}>
        <CircularProgress size={28} />
      </Box>
    );
  }

  return (
    <Box>
      <EntityHeaderCard
        icon={<ShoppingCartOutlinedIcon />}
        title="Sales Order"
        subtitle={view === 'form' ? 'Create a new sales order.' : 'Manage and track all sales orders.'}
        rightContent={<CompanyBadge />}
      />

      {view === 'form' ? (
        <RouteMapContextMenu flow="sales" type="order" docNo={editingRow?.orderNo}>
        <AppForm
          key={formKey}
          schema={salesOrderSchema}
          defaultValues={editingRow ? rowToFormValues(editingRow) : getEmptyValues()}
          onSubmit={handleSubmit}
        >
          {(methods) => {
            const { control, watch, setValue } = methods;
            const { fields, append, remove: removeItem, replace: replaceItems } = useFieldArray({ control, name: 'items' });
            const watchedItems = watch('items') || [];

            // Product Code / Product Name are sized to the longest value the
            // column actually holds, instead of a fixed width that left almost
            // no room for text once the field's own padding — and, on a select,
            // its clear and dropdown buttons — were subtracted. Short data still
            // sits tight; anything past the cap is revealed on hover as before.
            const productCodeColumnWidth = itemColumnBaseWidth(
              watchedItems.map((i) => i?.productCode), { kind: 'code', field: 'select' },
            );
            const productNameColumnWidth = itemColumnBaseWidth(
              watchedItems.map((i) => i?.productName), { kind: 'name', field: 'select' },
            );
            // The Discount % box in the totals panel is a mirror of the item
            // row's Discount %, not a second deduction — the line's discount
            // is already baked into its Amount (and therefore the Subtotal)
            // above, so computeTotals is always called with 0 here to avoid
            // subtracting the same discount twice. Which row "wins" when
            // there's more than one item is whichever the user edited most
            // recently (see the sync effect below).
            // Discount % in the totals panel is a header-level discount taken
            // off the sum of the (already line-discounted) item amounts —
            // exactly what the server does with the `discountPercent` it
            // receives.
            //
            // It used to be a read-only mirror of whichever item row was
            // edited last, and computeTotals was called with a hard-coded 0
            // so the mirrored figure wouldn't deduct the line discount twice
            // on screen. But the mirrored figure was still posted, and the
            // server had no way to know it was only meant for display: it
            // applied that percentage on top of line amounts that already had
            // it baked in, saving a total below the one the user approved.
            const discountPercent = watch('discountPercent');
            // Inter-state supplies are taxed wholly as IGST. The server works
            // this out by comparing Place of Supply against the company's
            // registered state; passing the same flag here is what stops the
            // panel showing a CGST/SGST split for a record saved as IGST.
            const interState = isInterState(watch('placeOfSupply'), company?.state);
            const totals = computeTotals(watchedItems, discountPercent, interState);

            const allValues = watch();
            const printCustomerRecord = (customers || []).find((c) => c.customerName === allValues.customer);
            const printSalesEmployeeRecord = (salesEmployees || []).find((s) => s.employeeName === allValues.salesPerson);
            const printQuotationRecord = (quotations || []).find((q) => q.quotationNo === allValues.quotationNo);
            const printOrder = { ...allValues, status: editingRow?.status || 'Draft' };

            const customerValue = watch('customer');
            const prevCustomer = useRef(editingRow ? editingRow.customer : null);
            useEffect(() => {
              if (customerValue !== prevCustomer.current) {
                const found = (customers || []).find((c) => c.customerName === customerValue);
                if (found) {
                  setValue('contactPerson', found.salesPerson || '', { shouldValidate: true });
                  setValue('phone', found.phone || '', { shouldValidate: true });
                  setValue('email', found.email || '', { shouldValidate: true });
                  setValue('billingAddress', found.billingAddress || '', { shouldValidate: true });
                  setValue('shippingAddress', found.shippingAddress || '', { shouldValidate: true });
                  setValue('paymentTerms', found.paymentTerms || '', { shouldValidate: true });
                }
                prevCustomer.current = customerValue;
              }
              // eslint-disable-next-line react-hooks/exhaustive-deps
            }, [customerValue]);

            // Copy From pulls every field that exists on a
            // quotation across onto the order — contact info,
            // currency, billing/shipping address, reference no., terms &
            // conditions, discount, and items. Order No./Date, Delivery
            // Date, Payment Terms, and Sales Person are the only header
            // fields the user actually fills in themselves, since none of
            // those exist on a quotation.
            //
            // The item columns (product, HSN, unit, quantity, rate,
            // discount, tax) used to render `disabled`, on the grounds that
            // they mirror the quotation. In practice an order is not always
            // identical to the quotation it was raised from — the customer
            // negotiates a different rate, swaps a product, or the order has
            // no quotation behind it at all ("Add Item" produced a row that
            // could never be filled in). They are editable now; the
            // quotation lookup still pre-fills them, it just no longer
            // forbids a correction.
            //
            // This used to run as an effect watching the Quotation No.
            // dropdown. It is a plain function now, called only from the
            // dialog's Choose button: an effect keyed on a form value also
            // fires when that value is restored on edit or reset, which is why
            // it needed the prevQuotation bookkeeping to tell "user picked a
            // quotation" apart from "form loaded". An explicit call has no such
            // ambiguity.
            const applyQuotation = (found) => {
                if (found) {
                  setValue('quotationNo', found.quotationNo || '', { shouldValidate: true });
                  setValue('branch', found.branch || '', { shouldValidate: true });
                  // The customer is not copied back — the dialog was already
                  // filtered by it, so it can only hold the value it already
                  // has. The customer-effect's "previous value" ref is still
                  // synced, so that effect doesn't think a new customer was
                  // just picked and re-fire on the next render: it looks up
                  // Contact/Phone/Email/Billing/Shipping fresh from Customer
                  // Master, which would clobber the values just set from the
                  // quotation's snapshot below (same class of bug fixed on
                  // Purchase Order's Reference/Contact Person).
                  prevCustomer.current = found.customer || '';
                  setValue('contactPerson', found.contactPerson || '', { shouldValidate: true });
                  setValue('phone', found.phone || '', { shouldValidate: true });
                  setValue('email', found.email || '', { shouldValidate: true });
                  setValue('currency', found.currency || 'INR', { shouldValidate: true });
                  setValue('referenceNo', found.referenceNo || '', { shouldValidate: true });
                  setValue('billingAddress', found.billingAddress || '', { shouldValidate: true });
                  setValue('shippingAddress', found.shippingAddress || '', { shouldValidate: true });
                  setValue('termsConditions', found.termsConditions || '', { shouldValidate: true });
                  setValue('discountPercent', found.discountPercent != null ? Number(found.discountPercent) : 0, { shouldValidate: true });
                  setValue('remarks', found.notes || '', { shouldValidate: true });
                  if (found.items && found.items.length) {
                    // replaceItems(), not setValue('items', ...) — see the
                    // same fix on Delivery Challan's quotation/order-fetch
                    // effect. replace() (useFieldArray's own API) gives every
                    // row a fresh field id, remounting each ProductCell
                    // instead of reusing the old one — reused cells saw
                    // productCode change from '' to the quotation's value,
                    // read that as a user picking a product, and overwrote
                    // the tax rate/unit price just set here with the
                    // *product master's* defaults instead of the quotation's.
                    replaceItems(found.items.map((i, n) => ({
                      productCode: i.productCode || '', productName: i.productName || '', description: i.description || '',
                      hsnCode: i.hsnCode || '', uom: i.uom || '',
                      quantity: i.quantity != null ? Number(i.quantity) : 1,
                      unitPrice: i.unitPrice != null ? Number(i.unitPrice) : 0,
                      discountPercent: i.discountPercent != null ? Number(i.discountPercent) : 0,
                      taxPercent: i.taxPercent != null ? Number(i.taxPercent) : 18,
                      // Copy From: this line came from the quotation's line n.
                      baseType: 'Sales Quotation',
                      baseEntry: found.id ?? null,
                      baseNo: found.quotationNo || null,
                      baseLine: n + 1,
                    })));
                  }
                }
            };

            // Undo a Copy From: drop the link and the values that came across
            // with it, rather than leaving a stale quotation's figures sitting
            // in an order that no longer claims to reference it.
            //
            // The customer is deliberately NOT cleared. It is the user's own
            // selection — it is what made Copy From available in the first
            // place, and clearing it would close the dialog off and force a
            // re-pick just to try a different quotation from the same customer.
            // Contact Person / Phone / Email / addresses stay too: they belong
            // to the customer, not the quotation.
            const quotationValue = watch('quotationNo');
            const clearQuotation = () => {
              setValue('quotationNo', '', { shouldValidate: true });
              setValue('currency', 'INR', { shouldValidate: true });
              setValue('referenceNo', '', { shouldValidate: true });
              setValue('termsConditions', '', { shouldValidate: true });
              setValue('discountPercent', 0, { shouldValidate: true });
              setValue('remarks', '', { shouldValidate: true });
              replaceItems([{ ...emptyItem }]);
            };

            return (
              // minWidth: 0 is required — fieldsets default to min-width: min-content,
              // which lets the wide item table blow out the page width on mobile.
              // The Back to List / Cancel buttons are kept outside the fieldset(s)
              // so they stay clickable in read-only (view) mode -- a native
              // <fieldset disabled> disables every descendant control, buttons
              // included.
              <>
              <CopyFromDocumentDialog
                open={copyFromOpen}
                onClose={() => setCopyFromOpen(false)}
                onChoose={applyQuotation}
                documents={quotations || []}
                party={customerValue}
                partyField="customer"
                partyLabel="customer"
                title="Find Sales Quotation"
                columns={QUOTATION_COPY_COLUMNS}
                emptyMessage="No quotations found for"
              />
              <SalesOrderPrintable
                order={printOrder}
                company={company}
                customerRecord={printCustomerRecord}
                salesEmployeeRecord={printSalesEmployeeRecord}
                quotationRecord={printQuotationRecord}
              />
              <Card variant="outlined" sx={{ mb: 2 }}>
                <CardContent sx={{ p: { xs: 2, sm: 3 } }}>
                  <Stack direction="row" alignItems="center" justifyContent="space-between" flexWrap="wrap" gap={1.5} sx={{ mb: 2 }}>
                    <Typography variant="subtitle1" fontWeight={700}>
                      {readOnly ? 'Customer & Order Details (View Only)' : 'Customer & Order Details'}
                    </Typography>
                    <Button type="button" variant="outlined" color="inherit" startIcon={<ArrowBackIcon />} onClick={backToList}>
                      Back to List
                    </Button>
                  </Stack>

                  <fieldset disabled={readOnly} style={{ border: 0, padding: 0, margin: 0, minWidth: 0, width: '100%', display: 'block' }}>
                    <FormGrid columns={3}>
                      <DocumentNoField documentCode="SO" name="orderNo" label="Order No. *" placeholder="Enter order number" isCreate={!editingRow} />
                      <FormSelect name="branch" label="Branch *" placeholder="Select branch" options={branchOptions} />
                      <FormDatePicker name="orderDate" label="Order Date *" />
                      {/* Filled only by Copy From — never typed. An order's
                          quotation reference has to be a quotation that
                          actually exists (the lines carry baseEntry/baseNo
                          back to it, and the Route Map joins the two through
                          it), so a free-text box could only ever produce a
                          dangling link. Left blank for an order raised
                          directly, which was already allowed here. */}
                      <FormTextField
                        name="quotationNo"
                        label="Quotation No."
                        placeholder="Use Copy From to select a quotation"
                        InputProps={{ readOnly: true }}
                      />

                      {/* Customer drives this form now: it is picked first, it
                          enables Copy From, and it scopes the quotation list
                          that dialog shows. It used to be disabled and filled
                          only by the quotation dropdown, which made an order
                          without a quotation impossible to enter.

                          The fields below it are auto-filled from the
                          quotation or Customer Master but left editable for
                          the same reason: an order is often placed against a
                          different contact, reference or currency than the
                          master holds. */}
                      <FormSelect name="customer" label="Customer *" placeholder="Select customer" options={customerOptions} />
                      <FormTextField name="contactPerson" label="Contact" placeholder="Auto-filled from quotation/customer" />
                      <FormTextField name="email" label="Email" placeholder="Auto-filled from quotation/customer" />
                      <FormTextField name="referenceNo" label="Reference No." placeholder="Auto-filled from quotation" />
                      <FormSelect name="currency" label="Currency *" options={CURRENCY_OPTIONS} />
                      <FormSelect name="paymentTerms" label="Payment Terms" placeholder="Select payment terms" options={PAYMENT_TERMS_OPTIONS} />

                      <FormDatePicker name="deliveryDate" label="Delivery Date *" />

                      <FormTextField name="billingAddress" label="Billing Address" placeholder="Auto-filled from quotation/customer" multiline rows={2} />
                      <FormSelect name="salesPerson" label="Sales Person *" placeholder="Select sales person" options={salesPersonOptions} />
                      <FormTextField name="shippingAddress" label="Shipping Address" placeholder="Auto-filled from quotation/customer" multiline rows={2} />

                      <FormSelect name="source" label="Source" placeholder="Select source" options={sourceOptions} />
                    </FormGrid>
                  </fieldset>
                </CardContent>
              </Card>

              <fieldset disabled={readOnly} style={{ border: 0, padding: 0, margin: 0, minWidth: 0, width: '100%', display: 'block' }}>
                <Card variant="outlined" sx={{ mb: 2 }}>
                  <CardContent sx={{ p: { xs: 2, sm: 3 } }}>
                    <Stack direction="row" alignItems="center" justifyContent="space-between" sx={{ mb: 2 }}>
                      <Typography variant="subtitle1" fontWeight={700}>Item Details</Typography>
                      <Button type="button" variant="outlined" size="small" startIcon={<AddIcon />} onClick={() => append({ ...emptyItem })}>
                        Add Item
                      </Button>
                    </Stack>

                    {isMobile ? (
                      <Box>
                        {fields.map((field, index) => {
                          const qty = Number(watch(`items.${index}.quantity`)) || 0;
                          const price = Number(watch(`items.${index}.unitPrice`)) || 0;
                          const disc = Number(watch(`items.${index}.discountPercent`)) || 0;
                          const gross = qty * price;
                          const rowAmount = gross - gross * (disc / 100);
                          return (
                            <MobileItemCard
                              key={field.id}
                              index={index}
                              amount={rowAmount.toFixed(2)}
                              onRemove={() => removeItem(index)}
                              removeDisabled={fields.length <= 1}
                            >
                              <ProductCell index={index} methods={methods} options={productCodeOptions} products={products} label="Product Code *" placeholder="Select product code" />
                              <ProductCell index={index} methods={methods} options={productNameOptions} products={products} label="Product Name" placeholder="Select product name" />
                              <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', columnGap: 1.5, rowGap: 1.5 }}>
                                <FormTextField name={`items.${index}.hsnCode`} label="HSN/SAC" placeholder="4, 6 or 8 digits" digitsOnly maxLength={8} />
                                <FormTextField name={`items.${index}.uom`} label="Unit" placeholder="Unit" />
                                <FormTextField name={`items.${index}.quantity`} label="Quantity *" type="number" />
                                <FormTextField name={`items.${index}.unitPrice`} label="Rate (₹) *" type="number" />
                                <FormTextField name={`items.${index}.discountPercent`} label="Discount (%)" type="number" />
                                <FormSelect name={`items.${index}.taxPercent`} label="Tax (%)" options={taxPercentOptions} />
                              </Box>
                            </MobileItemCard>
                          );
                        })}
                      </Box>
                    ) : (
                    <TableContainer ref={itemScrollRef} sx={{ overflowX: 'auto', WebkitOverflowScrolling: 'touch', cursor: 'grab', ...dragScrollbarSx }}>
                      <Table size="small" sx={{ '& tbody .MuiFormHelperText-root:not(.Mui-error)': { display: 'none' } }}>
                        <TableHead>
                          <TableRow>
                            <TableCell width={40}>#</TableCell>
                            <TableCell sx={{ minWidth: productCodeColumnWidth }}>Product Code *</TableCell>
                            <TableCell sx={{ minWidth: productNameColumnWidth }}>Product Name</TableCell>
                            <TableCell sx={{ minWidth: 140 }}>HSN/SAC</TableCell>
                            <TableCell sx={{ minWidth: 110 }}>Unit</TableCell>
                            <TableCell sx={{ minWidth: 110 }}>Quantity *</TableCell>
                            <TableCell sx={{ minWidth: 150 }}>Rate (₹) *</TableCell>
                            <TableCell sx={{ minWidth: 100 }}>Discount (%)</TableCell>
                            <TableCell sx={{ minWidth: 120 }}>Tax (%)</TableCell>
                            <TableCell sx={{ minWidth: 110 }}>Amount (₹)</TableCell>
                            <TableCell width={48} />
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {fields.map((field, index) => {
                            const qty = Number(watch(`items.${index}.quantity`)) || 0;
                            const price = Number(watch(`items.${index}.unitPrice`)) || 0;
                            const disc = Number(watch(`items.${index}.discountPercent`)) || 0;
                            const gross = qty * price;
                            const rowAmount = gross - gross * (disc / 100);
                            return (
                              <TableRow key={field.id} sx={{ '& > td': { verticalAlign: 'middle' } }}>
                                <TableCell>{index + 1}</TableCell>
                                <TableCell
                                  sx={hoverExpandColumnSx({
                                    base: productCodeColumnWidth,
                                    value: watch(`items.${index}.productCode`),
                                    max: 420,
                                    field: 'select',
                                  })}
                                >
                                  <ProductCell index={index} methods={methods} options={productCodeOptions} products={products} placeholder="Select product code" multiline />
                                </TableCell>
                                <TableCell
                                  sx={hoverExpandColumnSx({
                                    base: productNameColumnWidth,
                                    value: watch(`items.${index}.productName`),
                                    max: 640,
                                    field: 'select',
                                  })}
                                >
                                  <ProductCell index={index} methods={methods} options={productNameOptions} products={products} placeholder="Select product name" multiline />
                                </TableCell>
                                <TableCell>
                                  <FormTextField name={`items.${index}.hsnCode`} label="" placeholder="HSN/SAC" digitsOnly maxLength={8} />
                                </TableCell>
                                <TableCell>
                                  <FormTextField name={`items.${index}.uom`} label="" placeholder="Unit" />
                                </TableCell>
                                <TableCell>
                                  <FormTextField name={`items.${index}.quantity`} label="" type="number" />
                                </TableCell>
                                <TableCell>
                                  <FormTextField name={`items.${index}.unitPrice`} label="" type="number" />
                                </TableCell>
                                <TableCell>
                                  <FormTextField name={`items.${index}.discountPercent`} label="" type="number" />
                                </TableCell>
                                <TableCell>
                                  <FormSelect name={`items.${index}.taxPercent`} label="" options={taxPercentOptions} />
                                </TableCell>
                                <TableCell sx={{ whiteSpace: 'nowrap' }}>{rowAmount.toFixed(2)}</TableCell>
                                <TableCell>
                                  <IconButton
                                    type="button"
                                    size="small"
                                    color="error"
                                    onClick={() => removeItem(index)}
                                    disabled={fields.length <= 1}
                                    aria-label="remove item"
                                  >
                                    <DeleteIcon fontSize="small" />
                                  </IconButton>
                                </TableCell>
                              </TableRow>
                            );
                          })}
                        </TableBody>
                      </Table>
                    </TableContainer>
                    )}
                  </CardContent>
                </Card>
              </fieldset>

              <Card variant="outlined">
                <CardContent sx={{ p: { xs: 2, sm: 3 } }}>
                  <fieldset disabled={readOnly} style={{ border: 0, padding: 0, margin: 0, minWidth: 0, width: '100%', display: 'block' }}>
                    <Grid container spacing={3}>
                      <Grid item xs={12} md={4}>
                        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1 }}>Order Remarks</Typography>
                        <FormTextField name="remarks" label="" placeholder="Enter any remarks (optional)" multiline rows={6} />
                      </Grid>

                      <Grid item xs={12} md={4}>
                        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1 }}>Terms & Conditions</Typography>
                        <FormTextField name="termsConditions" label="" placeholder="Enter terms and conditions" multiline rows={6} disabled />
                      </Grid>

                      <Grid item xs={12} md={4}>
                        <DocumentTotalsPanel totals={totals} interState={interState} />
                      </Grid>
                    </Grid>
                  </fieldset>

                    <Stack
                      direction={{ xs: 'column', sm: 'row' }}
                      spacing={1.5}
                      justifyContent={{ xs: 'stretch', sm: 'flex-end' }}
                      sx={{ mt: 3 }}
                    >
                      {/* Copy From sits immediately left of Cancel and stays
                          disabled until a Customer is chosen — the dialog it
                          opens lists that customer's quotations, so with no
                          customer there is nothing for it to show. Hidden in
                          view mode, where nothing is being filled in. */}
                      {!readOnly && (
                        quotationValue ? (
                          <Button
                            fullWidth={isMobile}
                            type="button"
                            variant="outlined"
                            color="inherit"
                            startIcon={<CloseIcon />}
                            onClick={clearQuotation}
                            disabled={creating || updating}
                          >
                            Clear Copied Quotation
                          </Button>
                        ) : (
                          <Button
                            fullWidth={isMobile}
                            type="button"
                            variant="outlined"
                            startIcon={<ContentCopyOutlinedIcon />}
                            onClick={() => setCopyFromOpen(true)}
                            disabled={!customerValue || creating || updating}
                          >
                            Copy From
                          </Button>
                        )
                      )}
                      <Button fullWidth={isMobile} type="button" variant="outlined" color="inherit" startIcon={<CloseIcon />} onClick={backToList} disabled={creating || updating}>
                        Cancel
                      </Button>
                      <Button fullWidth={isMobile} type="button" variant="outlined" startIcon={<PrintOutlinedIcon />} onClick={() => window.print()}>
                        Print
                      </Button>
                      {!readOnly && (
                        <>
                          <FormSubmitButton
                            fullWidth={isMobile}
                            variant="outlined"
                            onClick={() => { pendingStatusRef.current = 'Draft'; }}
                            disabled={creating || updating}
                          >
                            Save as Draft
                          </FormSubmitButton>
                          <FormSubmitButton
                            fullWidth={isMobile}
                            // Forcing 'Confirmed' only makes sense on a brand
                            // new order — that is what "Save & Send" means.
                            // On an edit it must NOT force anything: an order
                            // already Partially Delivered or Closed (set by
                            // recomputeSalesOrder from GRNs/challans/invoices
                            // raised against it) would otherwise get silently
                            // downgraded back to Confirmed by any unrelated
                            // edit and save.
                            onClick={() => { pendingStatusRef.current = editingRow ? null : 'Confirmed'; }}
                            disabled={creating || updating}
                          >
                            {editingRow ? 'Update Order' : 'Save & Send Order'}
                          </FormSubmitButton>
                        </>
                      )}
                    </Stack>
                  </CardContent>
                </Card>
              </>
            );
          }}
        </AppForm>
        </RouteMapContextMenu>
      ) : (
        <Card variant="outlined">
          <CardContent sx={{ p: 0 }}>
            <Stack
              direction={{ xs: 'column', sm: 'row' }}
              alignItems={{ xs: 'stretch', sm: 'center' }}
              justifyContent="space-between"
              flexWrap="wrap"
              gap={1.5}
              sx={{ px: { xs: 2, sm: 3 }, pt: 2.5, pb: 1.5 }}
            >
              <Typography variant="subtitle1" fontWeight={700}>Sales Order List</Typography>
              <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.5} flexWrap="wrap" useFlexGap sx={{ width: { xs: '100%', sm: 'auto' } }}>
                <TableSearchFilter table={table} placeholder="Search by order no., customer, ref no..." showFilter={false} />
                <Stack direction="row" spacing={1.5}>
                  <Button size="small" variant="outlined" color="inherit" startIcon={<FilterListIcon />} onClick={() => setShowFilters((v) => !v)} sx={{ whiteSpace: 'nowrap', flexShrink: 0 }}>
                    Filter
                  </Button>
                  <CanAdd>
                    <Button size="small" variant="contained" startIcon={<AddIcon />} onClick={openCreate} sx={{ whiteSpace: 'nowrap', flexShrink: 0 }}>
                      Create Order
                    </Button>
                  </CanAdd>
                </Stack>
              </Stack>
            </Stack>

            <Collapse in={showFilters} unmountOnExit>
            <Box sx={{ px: { xs: 2, sm: 3 }, pb: 2 }}>
              <FormGrid columns={5}>
                <FilterAutocomplete
                  label="Customer"
                  allLabel="All Customers"
                  options={customerOptions}
                  value={customerFilter}
                  onChange={(v) => { setCustomerFilter(v); setPage(0); }}
                />
                <Autocomplete
                  size="small"
                  options={STATUS_FILTERS}
                  value={statusFilter}
                  onChange={(_e, v) => { setStatusFilter(v || 'All Status'); setPage(0); }}
                  disableClearable
                  renderInput={(params) => <TextField {...params} label="Status" InputLabelProps={{ shrink: true }} />}
                />
                <TextField
                  size="small"
                  fullWidth
                  label="Date Range"
                  value={dateRangeLabel}
                  onClick={(e) => setDateAnchor(e.currentTarget)}
                  InputProps={{
                    readOnly: true,
                    startAdornment: <InputAdornment position="start"><EventIcon fontSize="small" /></InputAdornment>,
                    endAdornment: (dateFrom || dateTo) ? (
                      <InputAdornment position="end">
                        <IconButton size="small" onClick={(e) => { e.stopPropagation(); setDateFrom(null); setDateTo(null); setPage(0); }}>
                          <CloseIcon fontSize="small" />
                        </IconButton>
                      </InputAdornment>
                    ) : null,
                  }}
                  InputLabelProps={{ shrink: true }}
                  sx={{ cursor: 'pointer' }}
                />
                <FilterAutocomplete
                  label="Sales Person"
                  allLabel="All Sales Persons"
                  options={salesPersonOptions}
                  value={salesPersonFilter}
                  onChange={(v) => { setSalesPersonFilter(v); setPage(0); }}
                />
                <Autocomplete
                  size="small"
                  options={PAYMENT_STATUS_FILTERS}
                  value={paymentStatusFilter}
                  onChange={(_e, v) => { setPaymentStatusFilter(v || 'All'); setPage(0); }}
                  disableClearable
                  renderInput={(params) => <TextField {...params} label="Payment Status" InputLabelProps={{ shrink: true }} />}
                />
              </FormGrid>

              <Popover
                open={!!dateAnchor}
                anchorEl={dateAnchor}
                onClose={() => setDateAnchor(null)}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
              >
                <Stack direction="row" spacing={2} sx={{ p: 2 }}>
                  <DatePicker label="From" value={dateFrom} onChange={(v) => { setDateFrom(v); setPage(0); }} slotProps={{ textField: { size: 'small' } }} />
                  <DatePicker label="To" value={dateTo} onChange={(v) => { setDateTo(v); setPage(0); }} slotProps={{ textField: { size: 'small' } }} />
                </Stack>
              </Popover>
              <TableFilterPanel table={table} embedded open />
            </Box>
            </Collapse>

            {checkedIds.length > 0 && (
              <Box sx={{ px: { xs: 2, sm: 3 }, pb: 1.5 }}>
                <Button variant="outlined" color="error" size="small" startIcon={<DeleteIcon />} onClick={removeSelected}>
                  Delete Selected ({checkedIds.length})
                </Button>
              </Box>
            )}

            {isMobile ? (
              <Box sx={{ px: 2, pb: 1 }}>
                {!isLoading && pagedRows.map((row) => (
                  <MobileRecordCard
                    key={row.id}
                    title={row.orderNo}
                    statusChip={<Chip size="small" label={row.status} color={STATUS_COLORS[row.status] || 'default'} variant="outlined" />}
                    fields={[
                      { label: 'Customer', value: row.customer || '—' },
                      { label: 'Order Date', value: row.orderDate ? dayjs(row.orderDate).format('DD/MM/YYYY') : '—' },
                      { label: 'Delivery Date', value: row.deliveryDate ? dayjs(row.deliveryDate).format('DD/MM/YYYY') : '—' },
                      { label: 'Amount', value: `₹${Number(row.amount).toFixed(2)}` },
                      { label: 'Payment Status', value: row.paymentStatus || '—' },
                    ]}
                    onEdit={() => handleEdit(row)}
                    onDelete={() => handleDelete(row)}
                  />
                ))}
                {!isLoading && filteredRows.length === 0 && (
                  <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>No orders found</Typography>
                )}
              </Box>
            ) : (
              <ScrollableTableContainer>
                <Table size="small" stickyHeader>
                  <TableHead>
                    <TableRow>
                      <SortableHeaderCell field="id" sort={table.sort} onSort={table.toggleSort} padding="checkbox">
                        <Checkbox
                          size="small"
                          checked={pagedRows.length > 0 && pagedRows.every((r) => checkedIds.includes(r.id))}
                          indeterminate={pagedRows.some((r) => checkedIds.includes(r.id)) && !pagedRows.every((r) => checkedIds.includes(r.id))}
                          onChange={(e) => {
                            const ids = pagedRows.map((r) => r.id);
                            setCheckedIds((prev) => e.target.checked
                              ? Array.from(new Set([...prev, ...ids]))
                              : prev.filter((c) => !ids.includes(c)));
                          }}
                        />
                      </SortableHeaderCell>
                      <TableCell width={40}>#</TableCell>
                      <SortableHeaderCell field="orderNo" sort={table.sort} onSort={table.toggleSort}>Order No.</SortableHeaderCell>
                      <SortableHeaderCell field="orderDate" sort={table.sort} onSort={table.toggleSort}>Order Date</SortableHeaderCell>
                      <SortableHeaderCell field="customer" sort={table.sort} onSort={table.toggleSort}>Customer</SortableHeaderCell>
                      <SortableHeaderCell field="deliveryDate" sort={table.sort} onSort={table.toggleSort}>Delivery Date</SortableHeaderCell>
                      <SortableHeaderCell field="amount" sort={table.sort} onSort={table.toggleSort}>Amount (₹)</SortableHeaderCell>
                      <SortableHeaderCell field="status" sort={table.sort} onSort={table.toggleSort}>Status</SortableHeaderCell>
                      <SortableHeaderCell field="paymentStatus" sort={table.sort} onSort={table.toggleSort}>Payment Status</SortableHeaderCell>
                      <TableCell align="right">Action</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {!isLoading && pagedRows.map((row, i) => (
                      <TableRow key={row.id} hover>
                        <TableCell padding="checkbox">
                          <Checkbox
                            size="small"
                            checked={checkedIds.includes(row.id)}
                            onChange={() => setCheckedIds((prev) => prev.includes(row.id) ? prev.filter((c) => c !== row.id) : [...prev, row.id])}
                          />
                        </TableCell>
                        <TableCell>{page * pageSize + i + 1}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.orderNo}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.orderDate ? dayjs(row.orderDate).format('DD/MM/YYYY') : '—'}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.customer || '—'}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.deliveryDate ? dayjs(row.deliveryDate).format('DD/MM/YYYY') : '—'}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{Number(row.amount).toFixed(2)}</TableCell>
                        <TableCell>
                          <Chip size="small" label={row.status} color={STATUS_COLORS[row.status] || 'default'} variant="outlined" />
                        </TableCell>
                        <TableCell>
                          <Chip size="small" label={row.paymentStatus} color={PAYMENT_STATUS_COLORS[row.paymentStatus] || 'default'} variant="outlined" />
                        </TableCell>
                        <TableCell align="right">
                          <Stack direction="row" spacing={0.5} justifyContent="flex-end">
                            <Tooltip title="View">
                              <IconButton size="small" onClick={() => handleView(row)} aria-label="view">
                                <VisibilityOutlinedIcon fontSize="small" />
                              </IconButton>
                            </Tooltip>
                            <RouteMapButton flow="sales" type="order" docNo={row.orderNo} />
                            <Tooltip title="Duplicate">
                              <IconButton size="small" onClick={() => handleDuplicate(row)} aria-label="duplicate">
                                <ContentCopyOutlinedIcon fontSize="small" />
                              </IconButton>
                            </Tooltip>
                            <Tooltip title="Print">
                              <IconButton size="small" onClick={() => handlePrint(row)} aria-label="print">
                                <PrintOutlinedIcon fontSize="small" />
                              </IconButton>
                            </Tooltip>
                            <IconButton
                              size="small"
                              onClick={(e) => { setRowMenuAnchor(e.currentTarget); setRowMenuTarget(row); }}
                              aria-label="more actions"
                            >
                              <MoreVertIcon fontSize="small" />
                            </IconButton>
                          </Stack>
                        </TableCell>
                      </TableRow>
                    ))}
                    {!isLoading && filteredRows.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={10}>
                          <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>No orders found</Typography>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </ScrollableTableContainer>
            )}

            <Menu anchorEl={rowMenuAnchor} open={!!rowMenuAnchor} onClose={() => setRowMenuAnchor(null)}>
              <CanEdit>
                <MenuItem onClick={() => handleEdit(rowMenuTarget)}>
                  <ListItemIcon><EditIcon fontSize="small" /></ListItemIcon>
                  <ListItemText>Edit</ListItemText>
                </MenuItem>
              </CanEdit>
              <CanDelete>
                <MenuItem onClick={() => handleDelete(rowMenuTarget)}>
                  <ListItemIcon><DeleteIcon fontSize="small" color="error" /></ListItemIcon>
                  <ListItemText>Delete</ListItemText>
                </MenuItem>
              </CanDelete>
            </Menu>

            <EntityListPagination total={filteredRows.length} page={page} onChange={setPage} pageSize={pageSize} onPageSizeChange={(v) => { setPageSize(v); setPage(0); }} />
          </CardContent>
        </Card>
      )}
    </Box>
  );
}

// Both the Product Code and Product Name columns are selects over the same
// underlying items.{index}.productCode field — Product Code lists codes,
// Product Name lists names, and picking either fills the rest of the row
// from the product master. Isolated so the per-row auto-fill effect only
// re-runs for the row whose product actually changed, not every row on every
// keystroke.
function ProductCell({ index, methods, options, products, label = '', placeholder = 'Select product', disabled = false, multiline = false, sx }) {
  const { watch, setValue } = methods;
  const productCodeValue = watch(`items.${index}.productCode`);
  const prevValue = useRef(productCodeValue);

  useEffect(() => {
    if (productCodeValue !== prevValue.current) {
      const found = (products || []).find((p) => p.productCode === productCodeValue);
      if (found) {
        setValue(`items.${index}.productName`, found.productName, { shouldValidate: true });
        setValue(`items.${index}.description`, found.productName, { shouldValidate: true });
        setValue(`items.${index}.hsnCode`, found.hsnCode || '', { shouldValidate: true });
        setValue(`items.${index}.uom`, found.uom || '', { shouldValidate: true });
        setValue(`items.${index}.unitPrice`, found.salesPrice != null ? Number(found.salesPrice) : 0, { shouldValidate: true });
      }
      prevValue.current = productCodeValue;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [productCodeValue]);

  return <FormSelect name={`items.${index}.productCode`} label={label} placeholder={placeholder} options={options} disabled={disabled} multiline={multiline} sx={sx} />;
}
