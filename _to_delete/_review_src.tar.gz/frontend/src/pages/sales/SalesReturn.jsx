import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Box, Typography, Button, Card, CardContent, Stack, Table, TableBody, TableCell,
  TableHead, TableRow, Chip, IconButton, Menu, MenuItem, ListItemIcon, ListItemText, Grid,
  CircularProgress,
} from '@mui/material';
import { useFieldArray } from 'react-hook-form';
import dayjs from 'dayjs';
import AssignmentReturnOutlinedIcon from '@mui/icons-material/AssignmentReturnOutlined';
import AddIcon from '@mui/icons-material/Add';
import CloseIcon from '@mui/icons-material/Close';
import PrintOutlinedIcon from '@mui/icons-material/PrintOutlined';
import UploadFileIcon from '@mui/icons-material/UploadFile';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import EditIcon from '@mui/icons-material/EditOutlined';
import DeleteIcon from '@mui/icons-material/DeleteOutline';
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import Inventory2OutlinedIcon from '@mui/icons-material/Inventory2Outlined';
import AppForm, { FormGrid, FormSubmitButton } from '../../components/form/AppForm';
import FormTextField from '../../components/form/FormTextField';
import FormSelect from '../../components/form/FormSelect';
import FormDatePicker from '../../components/form/FormDatePicker';
import DocumentNoField from '../../components/form/DocumentNoField';
import EntityHeaderCard from '../../components/common/EntityHeaderCard';
import CompanyBadge from '../../components/common/CompanyBadge';
import BatchSerialRestockDialog from '../../components/common/BatchSerialRestockDialog';
import { useWarehouseOptions, warehouseLabel } from '../../lib/useWarehouseOptions';
import { CanAdd, CanEdit, CanDelete } from '../../components/common/PermissionGate';
import EntityListPagination from '../../components/data-display/EntityListPagination';
import MobileRecordCard from '../../components/data-display/MobileRecordCard';
import { useIsMobileListView } from '../../components/data-display/useIsMobileListView';
import { useNotify } from '../../components/feedback/NotificationProvider';
import { useConfirm } from '../../components/feedback/ConfirmationDialog';
import { applyServerErrors } from '../../lib/formErrors';
import { hoverExpandColumnSx, itemColumnBaseWidth } from '../../lib/columnWidth';
import { salesReturnSchema, SALES_RETURN_STATUS_OPTIONS } from '../../lib/validation/salesSchemas';
import { buildDocument, normaliseLine, round2, isInterState } from '../../lib/documentTotals';
import DocumentTotalsPanel from '../../components/form/DocumentTotalsPanel';
import { useGetCompanyDetailsQuery } from '../../features/company/companyDetailsApi';
import { buildTaxPercentOptions } from '../../lib/taxCodeOptions';
import { taxCodeApi } from '../../features/resources';
import { PAYMENT_TERMS_OPTIONS } from '../../lib/validation/partnerSchemas';
import { salesReturnApi, deliveryChallanApi, salesInvoiceApi, salesOrderApi, customerApi, branchApi, productApi } from '../../features/resources';
import useTableFeatures from '../../components/data-display/useTableFeatures';
import TableSearchFilter from '../../components/data-display/TableSearchFilter';
import TableFilterPanel from '../../components/data-display/TableFilterPanel';
import SortableHeaderCell from '../../components/data-display/SortableHeaderCell';
import ScrollableTableContainer from '../../components/data-display/ScrollableTableContainer';
import RouteMapButton from '../../components/common/RouteMapButton';
import RouteMapContextMenu from '../../components/common/RouteMapContextMenu';
import ContentCopyOutlinedIcon from '@mui/icons-material/ContentCopyOutlined';
import CopyFromDocumentDialog from '../../components/common/CopyFromDocumentDialog';

// Columns for the "Find Sales Delivery" dialog opened by Copy From.
const CHALLAN_COPY_COLUMNS = [
  { field: 'challanNo', headerName: 'Delivery No', nowrap: true },
  { field: 'customer', headerName: 'Customer Name' },
  { field: 'deliveryDate', headerName: 'Delivery Date', type: 'date' },
  { field: 'remarks', headerName: 'Comments', type: 'optional' },
];

const PAGE_SIZE = 10;

// Same default wording the other sales documents open with, so a return
// printed alongside them reads consistently.
const DEFAULT_TERMS = [
  '1. Goods once sold will not be taken back.',
  '2. Delivery as per agreed schedule.',
  '3. Payment within the stipulated credit period.',
  '4. Subject to Bangalore jurisdiction.',
].join('\n');

// `returnQuantity`, not `quantity`.
//
// That name is fixed by everything downstream: the zod schema
// (salesReturnItemSchema), the totals engine call below, the server's
// toSalesReturnItem, and the [sales_return_items].[return_quantity] column.
// This form was the one place that spelled it `quantity`, which meant the
// field the user typed into was not the field anything else read — see the
// note on the Return Qty input.
const emptyItem = {
  productCode: '', productName: '', description: '', hsnCode: '', uom: '',
  deliveredQuantity: 0, returnQuantity: 1, unitPrice: 0,
  discountPercent: 0, taxPercent: 0,
  batchAllocations: [], serialAllocations: [],
};

/**
 * Blocks the return save when a Batch/Serial-tracked line's return quantity
 * isn't fully covered by its selected batches/serials — the client-side half
 * of the same rule the server enforces in assertBatchSerialRestockAllocation
 * (utils/businessRules.js). Unlike the issue-side check, this is about
 * putting stock BACK, not drawing it down, but the "selected must equal
 * needed" shape is identical.
 */
function validateBatchSerialAllocation(items, productsByCode) {
  for (let i = 0; i < (items || []).length; i++) {
    const item = items[i];
    const trackingMode = productsByCode[item.productCode]?.manageItemBy;
    if (trackingMode !== 'Batch' && trackingMode !== 'Serial') continue;
    const label = item.productCode || `Row ${i + 1}`;
    const qty = Number(item.returnQuantity) || 0;

    if (trackingMode === 'Batch') {
      const allocated = (item.batchAllocations || []).reduce((sum, b) => sum + (Number(b.quantity) || 0), 0);
      if (Math.abs(allocated - qty) > 0.005) {
        return `${label}: select ${qty} from batches via "Batches - Restock" — currently ${allocated}.`;
      }
    } else {
      const count = (item.serialAllocations || []).length;
      if (count !== qty) {
        return `${label}: select ${qty} serial number(s) via "Serial Numbers - Restock" — currently ${count}.`;
      }
    }
  }
  return null;
}

// Built fresh per "Add" click rather than held in a module constant, so the
// dates are today's whenever the form opens instead of whenever the JS module
// first loaded — the same reason the other transaction pages do this.
function getEmptyValues() {
  const today = new Date();
  return {
    returnNo: '', status: 'Open', challanNo: '', customer: '', customerName: '',
    contactPerson: '', customerRefNo: '', branch: '', warehouse: '',
    reason: '', narration: '',
    documentDate: today, postingDate: today, dueDate: null,
    paymentTerms: '', comments: '',
    placeOfSupply: '', discountPercent: 0,
    termsConditions: DEFAULT_TERMS, attachmentName: '',
    items: [{ ...emptyItem }],
  };
}

// DocumentTotalsPanel reads `discount` and `grandTotal`, which the shared
// engine does not return — every other document derives them in a
// wrapper exactly like this one. Passing buildDocument's raw totals straight
// to the panel is what made it crash on totals.grandTotal.toFixed().
function computeReturnTotals(items, discountPercent, interState) {
  const { totals } = buildDocument(items, discountPercent, {
    quantityField: 'returnQuantity',
    interState,
    roundOff: true,
  });
  return {
    ...totals,
    discount: round2(totals.subtotal - totals.taxableAmount),
    grandTotal: totals.amount,
  };
}

const money = (v) => (Number(v) || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

function rowToFormValues(row) {
  const toDate = (v) => (v ? new Date(v) : null);
  return {
    ...getEmptyValues(),
    ...row,
    documentDate: toDate(row.documentDate),
    postingDate: toDate(row.postingDate),
    dueDate: toDate(row.dueDate),
    items: (row.items?.length ? row.items : [{ ...emptyItem }]).map((i) => ({
      productCode: i.productCode || '',
      productName: i.productName || '',
      description: i.description || '',
      hsnCode: i.hsnCode || '',
      uom: i.uom || '',
      deliveredQuantity: Number(i.deliveredQuantity) || 0,
      returnQuantity: Number(i.returnQuantity) || 0,
      unitPrice: Number(i.unitPrice) || 0,
      discountPercent: Number(i.discountPercent) || 0,
      taxPercent: Number(i.taxPercent) || 0,
      batchAllocations: (i.batchAllocations || []).map((b) => ({ batchNo: b.batchNo, quantity: Number(b.quantity) || 0 })),
      serialAllocations: (i.serialAllocations || []).map((s) => ({ serialNo: s.serialNo })),
    })),
  };
}

/**
 * Sales Return — goods coming back from a customer, raised against a
 * Delivery Challan.
 *
 * Totals, including the CGST/SGST vs IGST split, are computed by the shared
 * document engine and recomputed identically on the server, so the panel can
 * never disagree with what gets stored. The memo posts no stock movement and no receivables adjustment:
 * it records the value of what is coming back only.
 */
export default function SalesReturn({ openDocNo } = {}) {
  const notify = useNotify();
  const confirmDialog = useConfirm();
  const isMobile = useIsMobileListView();

  const { data: rows, isLoading } = salesReturnApi.useList();
  const [create, { isLoading: creating }] = salesReturnApi.useCreate();
  const [update, { isLoading: updating }] = salesReturnApi.useUpdate();
  const [remove] = salesReturnApi.useDelete();
  const { data: challans } = deliveryChallanApi.useList();
  // Needed to know which challans have already been invoiced — see
  // copyableChallans below.
  const { data: invoices } = salesInvoiceApi.useList();
  // The Delivery Challan itself carries no Payment Terms — that lives one
  // level further up, on the Sales Order it was despatched against. Needed
  // to pull it in transitively when a challan is picked (see the challanNo
  // pull-in effect below).
  const { data: salesOrders } = salesOrderApi.useList();
  const { data: customers } = customerApi.useList();
  const { data: branches } = branchApi.useList();
  const { data: taxCodes } = taxCodeApi.useList();
  const { data: products } = productApi.useList();
  const { data: company } = useGetCompanyDetailsQuery();
  const taxPercentOptions = useMemo(() => buildTaxPercentOptions(taxCodes), [taxCodes]);
  // Looked up per row to decide whether the Batch/Serial column applies —
  // Product Master's Manage Item By select is what makes a line ask for it.
  const productsByCode = useMemo(
    () => Object.fromEntries((products || []).map((p) => [p.productCode, p])),
    [products]
  );

  const [view, setView] = useState('list');
  const [editingRow, setEditingRow] = useState(null);
  const [readOnly, setReadOnly] = useState(false);
  const [formKey, setFormKey] = useState(0);
  // Copy From ("Find Sales Delivery") dialog. Held at page level rather than
  // inside AppForm's render prop so remounting the form on formKey change
  // can't leave a dialog orphaned open over a freshly reset form.
  const [copyFromOpen, setCopyFromOpen] = useState(false);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(PAGE_SIZE);
  const [rowMenuAnchor, setRowMenuAnchor] = useState(null);
  const [rowMenuTarget, setRowMenuTarget] = useState(null);
  // { index, mode } for the item row whose "Batches - Restock" /
  // "Serial Numbers - Restock" dialog is open; null when closed.
  const [batchDialog, setBatchDialog] = useState(null);
  // Which of the two save buttons was pressed. A ref, not state: the click
  // handler has to record it before submit reads it, and setting state there
  // would re-render in the middle of the click.
  const pendingStatusRef = useRef(null);

  const { warehouses } = useWarehouseOptions({ currentValue: editingRow?.warehouse });

  // Only challans that have NOT been invoiced can be returned against.
  //
  // Once an invoice exists the goods have been billed, and taking them back by
  // return would leave the invoice standing against stock that has gone —
  // a Sales Credit Memo is the instrument from then on. The backend refuses
  // these outright (assertReturnAllowed in utils/routeMap.js); filtering here
  // means the user never picks an option that is going to be rejected.
  //
  // A cancelled or draft invoice does not lock the challan: neither has been
  // issued, so there is nothing yet to credit instead.
  const invoicedChallanNos = useMemo(() => new Set(
    (invoices || [])
      .filter((i) => !['Draft', 'Cancelled'].includes(i.status))
      .map((i) => i.deliveryChallanNo)
      .filter(Boolean)
  ), [invoices]);

  // Per (challanNo, productCode), how much has already been returned by
  // OTHER sales returns (i.e. not the one currently being edited). Used to
  // cap what THIS return can still take — two returns against the same
  // challan line must share its quantity, not each get the full amount.
  const returnedByChallanProductOther = useMemo(() => {
    const totals = new Map();
    (rows || [])
      .filter((r) => r.status !== 'Cancelled' && r.challanNo && r.returnNo !== editingRow?.returnNo)
      .forEach((r) => {
        (r.items || []).forEach((item) => {
          if (!item.productCode) return;
          const key = `${r.challanNo}::${item.productCode}`;
          totals.set(key, (totals.get(key) || 0) + (Number(item.returnQuantity) || 0));
        });
      });
    return totals;
  }, [rows, editingRow]);

  // What the Copy From dialog is allowed to offer — an already-invoiced challan
  // is excluded for the reason given above (the credit belongs on the invoice,
  // so the backend would reject it anyway).
  //
  // This used to build the options for a challan dropdown; it is now the record
  // list handed to the dialog. The "the challan already on the record being
  // edited stays selectable" case the dropdown needed is gone with it — the
  // field is read-only now, so an existing return's own link is simply
  // displayed and never has to survive a filter to keep showing.
  const copyableChallans = useMemo(
    () => (challans || []).filter((c) => !invoicedChallanNos.has(c.challanNo)),
    [challans, invoicedChallanNos]
  );
  const customerOptions = useMemo(
    () => (customers || []).map((c) => ({ label: c.customerName, value: c.customerName })),
    [customers]
  );
  const branchOptions = useMemo(
    () => (branches || []).map((b) => ({ label: b.branchName, value: b.branchName })),
    [branches]
  );

  const tableColumns = useMemo(() => ([
    { field: 'returnNo', headerName: 'Return No.', filter: 'text' },
    { field: 'challanNo', headerName: 'Challan No.', filter: 'text' },
    { field: 'customer', headerName: 'Customer', filter: 'select' },
    {
      field: 'documentDate',
      headerName: 'Document Date',
      filter: 'dateRange',
      sortValue: (r) => (r.documentDate ? new Date(r.documentDate).getTime() : null),
      searchValue: (r) => (r.documentDate ? dayjs(r.documentDate).format('DD MMM YYYY') : ''),
    },
    { field: 'totalItems', headerName: 'Items', filter: 'numberRange' },
    { field: 'amount', headerName: 'Amount', filter: 'numberRange', sortValue: (r) => Number(r.amount) || 0 },
    { field: 'status', headerName: 'Status', filter: 'select' },
  ]), []);

  const table = useTableFeatures(rows || [], tableColumns, { onChange: setPage });
  const visibleRows = table.rows;
  const pagedRows = useMemo(
    () => visibleRows.slice(page * pageSize, page * pageSize + pageSize),
    [visibleRows, page, pageSize]
  );

  const backToList = () => { setView('list'); setEditingRow(null); setReadOnly(false); setCopyFromOpen(false); };

  const openCreate = () => {
    setEditingRow(null); setReadOnly(false); setFormKey((k) => k + 1); setView('form');
  };
  const handleEdit = (row) => {
    setEditingRow(row); setReadOnly(false); setFormKey((k) => k + 1);
    setView('form'); setRowMenuAnchor(null);
  };
  const handleView = (row) => {
    setEditingRow(row); setReadOnly(true); setFormKey((k) => k + 1);
    setView('form'); setRowMenuAnchor(null);
  };

  // Opened from the Route Map's document preview popup: jump straight into
  // this record's own read-only View, exactly as clicking it in the list
  // would, instead of requiring the user to find and click the row.
  useEffect(() => {
    if (!openDocNo) return;
    if (editingRow && editingRow.returnNo === openDocNo) return;
    const match = (rows || []).find((r) => r.returnNo === openDocNo);
    if (match) handleView(match);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [openDocNo, rows]);

  const handleDelete = async (row) => {
    setRowMenuAnchor(null);
    const ok = await confirmDialog({
      title: 'Delete sales return',
      message: `Are you sure you want to delete "${row.returnNo}"? This cannot be undone.`,
      confirmLabel: 'Delete',
      severity: 'error',
    });
    if (!ok) return;
    try {
      await remove(row.id).unwrap();
      notify.success('Sales return deleted');
    } catch (err) {
      notify.error(err?.data?.message || 'Delete failed');
    }
  };

  const handleSubmit = async (values, methods) => {
    // "Save as Draft" is a shortcut that forces Draft regardless of what the
    // Status field shows. The main Save/Update button does NOT force a
    // status — it used to always set 'Open', silently discarding any other
    // value picked in the Status dropdown (Closed, Cancelled, ...): the
    // record would save, but always as Open, so editing to e.g. Cancelled
    // appeared to "not save" because the list kept showing Open.
    const allocationError = validateBatchSerialAllocation(values.items, productsByCode);
    if (allocationError) {
      notify.error(allocationError);
      return;
    }
    const payload = { ...values, status: pendingStatusRef.current || values.status };
    try {
      if (editingRow) {
        await update({ id: editingRow.id, ...payload }).unwrap();
        notify.success('Sales return updated');
      } else {
        await create(payload).unwrap();
        notify.success('Sales return created');
      }
      backToList();
    } catch (err) {
      notify.error(applyServerErrors(err, methods.setError));
    }
  };

  if (openDocNo && (!editingRow || editingRow.returnNo !== openDocNo)) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', py: 10 }}>
        <CircularProgress size={28} />
      </Box>
    );
  }

  return (
    <Box>
      <EntityHeaderCard
        icon={<AssignmentReturnOutlinedIcon />}
        title="Sales Return"
        subtitle={view === 'form'
          ? 'Record goods coming back from a customer against a delivery challan.'
          : 'Manage goods returned by customers.'}
        rightContent={<CompanyBadge />}
      />

      {view === 'form' ? (
        <RouteMapContextMenu flow="sales" type="return" docNo={editingRow?.returnNo}>
        <AppForm
          key={formKey}
          readOnly={readOnly}
          schema={salesReturnSchema}
          defaultValues={editingRow ? rowToFormValues(editingRow) : getEmptyValues()}
          onSubmit={handleSubmit}
        >
          {(methods) => {
            const { control, watch, setValue } = methods;
            const { fields, append, remove: removeItem, replace: replaceItems } = useFieldArray({ control, name: 'items' });
            const watchedItems = watch('items') || [];

            // Product Code / Product Name are sized to the longest value the
            // column actually holds, instead of a fixed width that left almost
            // no room for text once the field's own padding — and, on a select,
            // its clear and dropdown buttons — were subtracted. Short data still
            // sits tight; anything past the cap is revealed on hover as before.
            const productCodeColumnWidth = itemColumnBaseWidth(
              watchedItems.map((i) => i?.productCode), { kind: 'code', field: 'text' },
            );
            const productNameColumnWidth = itemColumnBaseWidth(
              watchedItems.map((i) => i?.productName), { kind: 'name', field: 'text' },
            );
            const challanNo = watch('challanNo');
            const branch = watch('branch');

            // Once Branch is picked (directly, or via Copy From), the
            // Warehouse dropdown is scoped to that branch's warehouses only —
            // see useWarehouseOptions.js.
            const { options: branchWarehouseOptions } = useWarehouseOptions({ currentValue: editingRow?.warehouse, branch });

            // Copy From pulls the customer block across and replaces the lines
            // with what that challan despatched.
            //
            // This used to run as an effect watching the Challan No. dropdown,
            // guarded by a ref so it fired only on a real change. It is a plain
            // function now, called only from the dialog's Choose button: an
            // effect keyed on a form value also fires when that value is
            // restored on edit or reset, which is what the ref bookkeeping
            // existed to detect. An explicit call has no such ambiguity.
            //
            // The customer is still set from the challan, unlike the sibling
            // sales pages: this form keeps customerName and contactPerson
            // alongside it, so the pull has real work to do here, and the value
            // it writes is the customer the dialog was already filtered by.
            const applyChallan = (challan) => {
              if (!challan) return;
              setValue('challanNo', challan.challanNo || '', { shouldValidate: true });
              setValue('customer', challan.customer || '');
              setValue('customerName', challan.customer || '');
              setValue('branch', challan.branch || '');
              setValue('contactPerson', challan.contactPerson || '');
              setValue('termsConditions', challan.termsConditions || '');
              // The Delivery Challan itself carries no Payment Terms — that
              // lives one level further up, on the Sales Order it was
              // despatched against. Reached transitively via the challan's
              // own orderNo.
              const sourceOrder = (salesOrders || []).find((o) => o.orderNo === challan.orderNo);
              if (sourceOrder) {
                setValue('paymentTerms', sourceOrder.paymentTerms || '');
              }
              // replace(), never setValue('items', ...) — the field array has to
              // remount so each row's inputs pick up the new values.
              //
              // deliveredQuantity on each line is NOT the raw challan quantity —
              // it is what is still left to return after every OTHER sales
              // return against this challan is subtracted
              // (returnedByChallanProductOther, below). Two separate returns
              // against the same 10-unit challan line must not each be allowed
              // up to 10; the second one only has what the first didn't take.
              // A line with nothing left is dropped rather than pulled in at
              // zero, matching the same rule used in Sales Invoice's challan
              // pull-in.
              // `line` is captured BEFORE the filter: base_line names the
              // position of the line on the SOURCE document, so it has to be
              // numbered against the challan's own lines, not against
              // whichever of them survive the remaining-quantity filter.
              const remaining = (challan.items || [])
                .map((i, n) => {
                  // A delivery challan line stores what went out under
                  // `quantity` — DeliveryChallanItem has no `deliveredQuantity`
                  // column. Reading that name gave undefined on every line, so
                  // both the cap and the pre-filled return quantity came
                  // through as 0. (The purchase side reads
                  // GoodsReceivedNoteItem.receivedQuantity, which does exist,
                  // which is why only this page was affected.)
                  const delivered = Number(i.quantity) || 0;
                  const alreadyReturned = returnedByChallanProductOther.get(`${challan.challanNo}::${i.productCode}`) || 0;
                  return { item: i, line: n + 1, qty: round2(delivered - alreadyReturned) };
                })
                .filter(({ qty }) => qty > 0.005);
              replaceItems(
                remaining.length
                  ? remaining.map(({ item: i, line, qty }) => ({
                    productCode: i.productCode || '',
                    productName: i.productName || '',
                    description: i.description || '',
                    hsnCode: i.hsnCode || '',
                    uom: i.uom || '',
                    deliveredQuantity: qty,
                    returnQuantity: qty,
                    unitPrice: Number(i.unitPrice) || 0,
                    discountPercent: Number(i.discountPercent) || 0,
                    taxPercent: Number(i.taxPercent) || 0,
                    // Copy From: a return is raised against the challan.
                    baseType: 'Delivery Challan',
                    baseEntry: challan.id ?? null,
                    baseNo: challan.challanNo || null,
                    baseLine: line,
                  }))
                  : [{ ...emptyItem }]
              );
            };

            // Undo a Copy From: drop the link and the lines that came across
            // with it, rather than leaving a stale despatch's figures sitting
            // in a return that no longer claims to reference it.
            //
            // The customer is deliberately NOT cleared. It is the user's own
            // selection — it is what made Copy From available in the first
            // place, and clearing it would close the dialog off and force a
            // re-pick just to try a different delivery from the same customer.
            const clearChallan = () => {
              setValue('challanNo', '', { shouldValidate: true });
              setValue('contactPerson', '');
              setValue('termsConditions', '');
              setValue('paymentTerms', '');
              replaceItems([{ ...emptyItem }]);
            };

            // Switching Branch invalidates a Warehouse choice that doesn't
            // belong to the new branch. Skipped on the very first render so
            // loading an existing record for edit/view, or a Copy From that
            // sets branch and leaves warehouse untouched, doesn't wipe a value
            // it just loaded.
            const prevBranchRef = useRef(branch);
            useEffect(() => {
              if (prevBranchRef.current === branch) return;
              prevBranchRef.current = branch;
              const allowed = new Set(
                (warehouses || []).filter((w) => !branch || w.branch === branch).map((w) => w.whsCode)
              );
              if (watch('warehouse') && !allowed.has(watch('warehouse'))) setValue('warehouse', '');
              // eslint-disable-next-line react-hooks/exhaustive-deps
            }, [branch]);

            // Totals come from the shared document engine, given the same
            // inputs the server uses, so what the panel shows is what gets
            // saved. interState must be passed through explicitly — defaulting
            // it would show a CGST/SGST split on a document stored as IGST.
            const handleFile = (file) => {
              if (file) setValue('attachmentName', file.name, { shouldValidate: true });
            };

            const interState = isInterState(watch('placeOfSupply'), company?.state);
            const totals = computeReturnTotals(watchedItems, watch('discountPercent'), interState);

            return (
              <>
                <CopyFromDocumentDialog
                  open={copyFromOpen}
                  onClose={() => setCopyFromOpen(false)}
                  onChoose={applyChallan}
                  documents={copyableChallans}
                  party={watch('customer')}
                  partyField="customer"
                  partyLabel="customer"
                  title="Find Sales Delivery"
                  columns={CHALLAN_COPY_COLUMNS}
                  emptyMessage="No uninvoiced deliveries found for"
                />
                <Card variant="outlined" sx={{ mb: 2 }}>
                  <CardContent>
                    <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 2 }}>
                      {readOnly ? 'View Sales Return' : editingRow ? 'Edit Sales Return' : 'Add Sales Return'}
                    </Typography>

                    <FormGrid columns={3}>
                      <DocumentNoField documentCode="SRT" name="returnNo" label="Return No. *" isCreate={!editingRow} />
                      <FormSelect
                        name="status"
                        label="Status *"
                        options={SALES_RETURN_STATUS_OPTIONS.map((v) => ({ label: v, value: v }))}
                      />
                      {/* Filled only by Copy From — never typed. A return's
                          challan reference has to be a despatch that actually
                          exists (the lines carry baseEntry/baseNo back to it,
                          and the remaining-quantity cap is computed from it),
                          so a free-text box could only ever produce a dangling
                          link. Left blank for a return with no despatch behind
                          it, which is now a valid return rather than a schema
                          error. */}
                      <FormTextField
                        name="challanNo"
                        label="Challan No."
                        placeholder="Use Copy From to select a delivery"
                        InputProps={{ readOnly: true }}
                      />

                      <FormSelect name="customer" label="Customer *" placeholder="Select customer" options={customerOptions} />
                      <FormTextField name="customerName" label="Name" placeholder="Customer name" />
                      <FormTextField name="contactPerson" label="Contact Person" placeholder="Enter contact person" />

                      <FormTextField name="customerRefNo" label="Customer Ref No." placeholder="Enter customer ref no." />
                      <FormSelect name="branch" label="Branch *" placeholder="Select branch" options={branchOptions} />
                      <FormSelect
                        name="paymentTerms"
                        label="Payment Terms"
                        placeholder="Select payment terms"
                        options={PAYMENT_TERMS_OPTIONS}
                      />
                      {/* Where the returned goods physically land — see the
                          schema.prisma comment on SalesReturn.warehouse.
                          Scoped to the selected branch — see useWarehouseOptions.js. */}
                      <FormSelect
                        name="warehouse"
                        label="Warehouse *"
                        placeholder={branch ? 'Select warehouse' : 'Select a branch first'}
                        options={branchWarehouseOptions}
                        disabled={!branch}
                      />

                      <FormDatePicker name="documentDate" label="Document Date *" />
                      <FormDatePicker name="postingDate" label="Posting Date" />
                      <FormDatePicker name="dueDate" label="Due Date" />

                      <FormTextField name="reason" label="Reason" placeholder="Reason for the return" />
                      <FormTextField name="narration" label="Narration" placeholder="Enter narration" />
                      <FormTextField name="comments" label="Comments" placeholder="Enter comments" />
                    </FormGrid>
                  </CardContent>
                </Card>

                <Card variant="outlined" sx={{ mb: 2 }}>
                  <CardContent>
                    <Stack direction="row" alignItems="center" justifyContent="space-between" sx={{ mb: 1.5 }}>
                      <Typography variant="subtitle1" fontWeight={700}>Items</Typography>
                      {!readOnly && (
                        <Button size="small" startIcon={<AddIcon />} onClick={() => append({ ...emptyItem })}>
                          Add Row
                        </Button>
                      )}
                    </Stack>

                    <ScrollableTableContainer>
                      <Table size="small">
                        <TableHead>
                          <TableRow>
                            <TableCell width={48}>#</TableCell>
                            <TableCell sx={{ minWidth: productCodeColumnWidth }}>Product Code</TableCell>
                            <TableCell sx={{ minWidth: productNameColumnWidth }}>Product Name</TableCell>
                            <TableCell>UOM</TableCell>
                            <TableCell align="right">Delivered Qty</TableCell>
                            <TableCell align="right">Return Qty</TableCell>
                            <TableCell align="right">Unit Price</TableCell>
                            <TableCell align="right">Disc %</TableCell>
                            <TableCell align="right">Tax %</TableCell>
                            <TableCell>Batch/Serial Restock</TableCell>
                            <TableCell align="right">Amount</TableCell>
                            {!readOnly && <TableCell align="right">Action</TableCell>}
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {fields.map((field, index) => {
                            // Through the shared engine rather than an inline
                            // `qty * price * (1 - disc/100)`: normaliseLine
                            // rounds the gross and the discount the same way
                            // the header totals and the server do, so the row
                            // amounts sum exactly to the subtotal shown below
                            // instead of drifting by a paisa on some lines.
                            const lineAmount = normaliseLine(
                              {
                                returnQuantity: watch(`items.${index}.returnQuantity`),
                                unitPrice: watch(`items.${index}.unitPrice`),
                                discountPercent: watch(`items.${index}.discountPercent`),
                              },
                              { quantityField: 'returnQuantity' }
                            ).amount;
                            return (
                              <TableRow key={field.id}>
                                <TableCell>{index + 1}</TableCell>
                                <TableCell
                                  sx={hoverExpandColumnSx({
                                    base: productCodeColumnWidth,
                                    value: watch(`items.${index}.productCode`),
                                    max: 420,
                                    field: 'text',
                                  })}
                                >
                                  <FormTextField name={`items.${index}.productCode`} label="" placeholder="Product code" multiline />
                                </TableCell>
                                <TableCell
                                  sx={hoverExpandColumnSx({
                                    base: productNameColumnWidth,
                                    value: watch(`items.${index}.productName`),
                                    max: 640,
                                    field: 'text',
                                  })}
                                >
                                  <FormTextField name={`items.${index}.productName`} label="" placeholder="Product name" multiline />
                                </TableCell>
                                <TableCell sx={{ minWidth: 100 }}>
                                  <FormTextField name={`items.${index}.uom`} label="" placeholder="UOM" />
                                </TableCell>
                                <TableCell sx={{ minWidth: 120 }}>
                                  <FormTextField name={`items.${index}.deliveredQuantity`} label="" type="number" disabled />
                                </TableCell>
                                <TableCell sx={{ minWidth: 120 }}>
                                  {/* returnQuantity — the name the schema, the
                                      totals engine and the server all use. It
                                      was `quantity` here, so nothing that
                                      mattered ever saw what was typed. */}
                                  <FormTextField name={`items.${index}.returnQuantity`} label="" type="number" />
                                </TableCell>
                                <TableCell sx={{ minWidth: 130 }}>
                                  <FormTextField name={`items.${index}.unitPrice`} label="" type="number" />
                                </TableCell>
                                <TableCell sx={{ minWidth: 100 }}>
                                  <FormTextField name={`items.${index}.discountPercent`} label="" type="number" />
                                </TableCell>
                                <TableCell sx={{ minWidth: 110 }}>
                                  <FormSelect name={`items.${index}.taxPercent`} label="" options={taxPercentOptions} />
                                </TableCell>
                                <TableCell sx={{ minWidth: 140 }}>
                                  <BatchSerialCell index={index} methods={methods} product={productsByCode[watch(`items.${index}.productCode`)]} quantityField="returnQuantity" onOpen={(mode) => setBatchDialog({ index, mode })} />
                                </TableCell>
                                <TableCell align="right" sx={{ whiteSpace: 'nowrap' }}>
                                  {money(lineAmount)}
                                </TableCell>
                                {!readOnly && (
                                  <TableCell align="right">
                                    <IconButton
                                      size="small"
                                      color="error"
                                      aria-label="remove row"
                                      disabled={fields.length === 1}
                                      onClick={() => removeItem(index)}
                                    >
                                      <DeleteIcon fontSize="small" />
                                    </IconButton>
                                  </TableCell>
                                )}
                              </TableRow>
                            );
                          })}
                        </TableBody>
                      </Table>
                    </ScrollableTableContainer>

                  </CardContent>
                </Card>

                {batchDialog && batchDialog.index < fields.length && (
                  <BatchSerialRestockDialog
                    open
                    onClose={() => setBatchDialog(null)}
                    mode={batchDialog.mode}
                    readOnly={readOnly}
                    docNo={editingRow?.returnNo}
                    itemNumber={watch(`items.${batchDialog.index}.productCode`)}
                    itemDescription={watch(`items.${batchDialog.index}.productName`)}
                    warehouseCode={watch('warehouse')}
                    warehouseName={warehouseLabel((warehouses || []).find((w) => w.whsCode === watch('warehouse')))}
                    totalNeeded={Number(watch(`items.${batchDialog.index}.returnQuantity`)) || 0}
                    productCode={watch(`items.${batchDialog.index}.productCode`)}
                    value={watch(`items.${batchDialog.index}.${batchDialog.mode === 'Batch' ? 'batchAllocations' : 'serialAllocations'}`)}
                    onSave={(rows) => setValue(
                      `items.${batchDialog.index}.${batchDialog.mode === 'Batch' ? 'batchAllocations' : 'serialAllocations'}`,
                      rows,
                      { shouldValidate: true }
                    )}
                  />
                )}

                {/* Terms, attachments and the money panel — the same footer the
                    other sales documents carry, so a return reads and prints
                    consistently beside them. */}
                <Card variant="outlined" sx={{ mb: 2 }}>
                  <CardContent sx={{ p: { xs: 2, sm: 3 } }}>
                    <Grid container spacing={3}>
                      <Grid item xs={12} md={4}>
                        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1 }}>Terms &amp; Conditions</Typography>
                        <FormTextField name="termsConditions" label="" placeholder="Enter terms and conditions" multiline rows={6} />
                      </Grid>

                      <Grid item xs={12} md={4}>
                        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1 }}>Attachments</Typography>
                        <Box
                          onDragOver={(e) => e.preventDefault()}
                          onDrop={(e) => { e.preventDefault(); handleFile(e.dataTransfer.files?.[0]); }}
                          sx={{
                            border: '1px dashed', borderColor: 'divider', borderRadius: 1.5,
                            p: 3, textAlign: 'center', color: 'text.secondary',
                          }}
                        >
                          <UploadFileIcon sx={{ mb: 1 }} />
                          <Typography variant="body2" sx={{ mb: 1 }}>Drag and drop files here</Typography>
                          <Typography variant="body2" sx={{ mb: 1 }}>or</Typography>
                          <Button component="label" variant="outlined" size="small" disabled={readOnly}>
                            Browse Files
                            <input type="file" hidden onChange={(e) => handleFile(e.target.files?.[0])} />
                          </Button>
                          <Typography variant="caption" display="block" sx={{ mt: 1 }}>
                            Supported formats: PDF, JPG, PNG (Max. 5MB)
                          </Typography>
                          {watch('attachmentName') && (
                            <Chip
                              sx={{ mt: 1.5 }}
                              size="small"
                              label={watch('attachmentName')}
                              onDelete={readOnly ? undefined : () => setValue('attachmentName', '')}
                            />
                          )}
                        </Box>
                      </Grid>

                      <Grid item xs={12} md={4}>
                        <DocumentTotalsPanel totals={totals} interState={interState} subtotalLabel="Subtotal" showRoundOff={false} />
                      </Grid>
                    </Grid>

                    <Stack
                      direction={{ xs: 'column', sm: 'row' }}
                      spacing={1.5}
                      justifyContent={{ xs: 'stretch', sm: 'flex-end' }}
                      sx={{ mt: 3 }}
                    >
                      {/* Copy From sits immediately left of Cancel and stays
                          disabled until a Customer is chosen — the dialog it
                          opens lists that customer's deliveries, so with no
                          customer there is nothing for it to show. Hidden in
                          view mode, where nothing is being filled in. */}
                      {!readOnly && (
                        challanNo ? (
                          <Button
                            fullWidth={isMobile}
                            type="button"
                            variant="outlined"
                            color="inherit"
                            startIcon={<CloseIcon />}
                            onClick={clearChallan}
                            disabled={creating || updating}
                          >
                            Clear Copied Challan
                          </Button>
                        ) : (
                          <Button
                            fullWidth={isMobile}
                            type="button"
                            variant="outlined"
                            startIcon={<ContentCopyOutlinedIcon />}
                            onClick={() => setCopyFromOpen(true)}
                            disabled={!watch('customer') || creating || updating}
                          >
                            Copy From
                          </Button>
                        )
                      )}
                      <Button fullWidth={isMobile} type="button" variant="outlined" color={readOnly ? 'error' : 'inherit'} startIcon={<CloseIcon />} onClick={backToList} disabled={creating || updating}>
                        {readOnly ? 'Close' : 'Cancel'}
                      </Button>
                      <Button fullWidth={isMobile} type="button" variant="outlined" startIcon={<PrintOutlinedIcon />} onClick={() => window.print()}>
                        Print
                      </Button>
                      {/* pendingStatusRef, not setValue: the click has to record
                          which button was pressed before submit reads it, and a
                          setValue here would re-render mid-click. */}
                      <FormSubmitButton
                        fullWidth={isMobile}
                        variant="outlined"
                        onClick={() => { pendingStatusRef.current = 'Draft'; }}
                        disabled={creating || updating}
                      >
                        Save as Draft
                      </FormSubmitButton>
                      <FormSubmitButton
                        fullWidth={isMobile}
                        onClick={() => { pendingStatusRef.current = null; }}
                        disabled={creating || updating}
                      >
                        {editingRow ? 'Update Return' : 'Save Return'}
                      </FormSubmitButton>
                    </Stack>
                  </CardContent>
                </Card>

              </>
            );
          }}
        </AppForm>
        </RouteMapContextMenu>
      ) : (
        <Card variant="outlined">
          <CardContent sx={{ p: 0 }}>
            <Stack direction="row" alignItems="center" justifyContent="space-between" flexWrap="wrap" gap={1.5} sx={{ px: 3, pt: 2.5, pb: 1.5 }}>
              <Typography variant="subtitle1" fontWeight={700}>Sales Return List</Typography>
              <Stack direction="row" spacing={1.5} flexWrap="wrap" useFlexGap alignItems="center">
                <TableSearchFilter table={table} placeholder="Search by return no., challan, customer..." />
                <CanAdd>
                  <Button variant="contained" startIcon={<AddIcon />} onClick={openCreate} sx={{ whiteSpace: 'nowrap' }}>
                    Add Return
                  </Button>
                </CanAdd>
              </Stack>
            </Stack>

            <TableFilterPanel table={table} />

            {isMobile ? (
              <Box sx={{ px: 2, pb: 1 }}>
                {!isLoading && pagedRows.map((row) => (
                  <MobileRecordCard
                    key={row.id}
                    title={row.returnNo}
                    statusChip={<Chip size="small" label={row.status} variant="outlined" />}
                    fields={[
                      { label: 'Challan No.', value: row.challanNo },
                      { label: 'Customer', value: row.customer },
                      { label: 'Amount', value: money(row.amount) },
                    ]}
                    onView={() => handleView(row)}
                    onEdit={() => handleEdit(row)}
                    onDelete={() => handleDelete(row)}
                  />
                ))}
                {!isLoading && visibleRows.length === 0 && (
                  <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>
                    {table.isFiltering ? 'No returns match your search' : 'No returns yet'}
                  </Typography>
                )}
              </Box>
            ) : (
              <ScrollableTableContainer>
                <Table size="small" stickyHeader>
                  <TableHead>
                    <TableRow>
                      <TableCell width={48}>#</TableCell>
                      <SortableHeaderCell field="returnNo" sort={table.sort} onSort={table.toggleSort}>Return No.</SortableHeaderCell>
                      <SortableHeaderCell field="challanNo" sort={table.sort} onSort={table.toggleSort}>Challan No.</SortableHeaderCell>
                      <SortableHeaderCell field="customer" sort={table.sort} onSort={table.toggleSort}>Customer</SortableHeaderCell>
                      <SortableHeaderCell field="documentDate" sort={table.sort} onSort={table.toggleSort}>Document Date</SortableHeaderCell>
                      <SortableHeaderCell field="totalItems" sort={table.sort} onSort={table.toggleSort}>Items</SortableHeaderCell>
                      <SortableHeaderCell field="amount" sort={table.sort} onSort={table.toggleSort}>Amount</SortableHeaderCell>
                      <SortableHeaderCell field="status" sort={table.sort} onSort={table.toggleSort}>Status</SortableHeaderCell>
                      <TableCell align="right">Action</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {!isLoading && pagedRows.map((row, i) => (
                      <TableRow key={row.id} hover>
                        <TableCell>{page * pageSize + i + 1}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.returnNo}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.challanNo || '—'}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.customer || '—'}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>
                          {row.documentDate ? dayjs(row.documentDate).format('DD MMM YYYY') : '—'}
                        </TableCell>
                        <TableCell>{row.totalItems}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{money(row.amount)}</TableCell>
                        <TableCell>
                          <Chip size="small" label={row.status} variant="outlined" />
                        </TableCell>
                        <TableCell align="right">
                          <IconButton size="small" onClick={() => handleView(row)} aria-label="view">
                            <VisibilityOutlinedIcon fontSize="small" />
                          </IconButton>
                          <RouteMapButton flow="sales" type="return" docNo={row.returnNo} />
                          <IconButton
                            size="small"
                            aria-label="more actions"
                            onClick={(e) => { setRowMenuAnchor(e.currentTarget); setRowMenuTarget(row); }}
                          >
                            <MoreVertIcon fontSize="small" />
                          </IconButton>
                        </TableCell>
                      </TableRow>
                    ))}
                    {!isLoading && visibleRows.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={9}>
                          <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>
                            {table.isFiltering ? 'No returns match your search' : 'No returns yet'}
                          </Typography>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </ScrollableTableContainer>
            )}

            <Menu anchorEl={rowMenuAnchor} open={!!rowMenuAnchor} onClose={() => setRowMenuAnchor(null)}>
              <CanEdit>
                <MenuItem onClick={() => handleEdit(rowMenuTarget)}>
                  <ListItemIcon><EditIcon fontSize="small" /></ListItemIcon>
                  <ListItemText>Edit</ListItemText>
                </MenuItem>
              </CanEdit>
              <CanDelete>
                <MenuItem onClick={() => handleDelete(rowMenuTarget)}>
                  <ListItemIcon><DeleteIcon fontSize="small" color="error" /></ListItemIcon>
                  <ListItemText>Delete</ListItemText>
                </MenuItem>
              </CanDelete>
            </Menu>

            <EntityListPagination
              total={visibleRows.length}
              page={page}
              onChange={setPage}
              pageSize={pageSize}
              onPageSizeChange={(v) => { setPageSize(v); setPage(0); }}
            />
          </CardContent>
        </Card>
      )}
    </Box>
  );
}

// Shows nothing for a None-tracked (or unrecognised) product — the column
// only means something once Product Master's Manage Item By is Batch or
// Serial for the row's selected product. Otherwise a button that opens the
// matching "... - Restock" dialog, labelled with how much of the line is
// selected so far. Mirrors PurchaseReturn.jsx's BatchSerialCell.
function BatchSerialCell({ index, methods, product, quantityField = 'quantity', onOpen }) {
  const { watch } = methods;
  const trackingMode = product?.manageItemBy;
  if (trackingMode !== 'Batch' && trackingMode !== 'Serial') {
    return <Typography variant="caption" color="text.secondary">—</Typography>;
  }
  const needed = Number(watch(`items.${index}.${quantityField}`)) || 0;
  const batchAllocations = watch(`items.${index}.batchAllocations`) || [];
  const serialAllocations = watch(`items.${index}.serialAllocations`) || [];
  const selected = trackingMode === 'Batch'
    ? batchAllocations.reduce((sum, b) => sum + (Number(b.quantity) || 0), 0)
    : serialAllocations.length;
  const complete = needed > 0 && Math.abs(selected - needed) < 0.005;

  return (
    <Button
      type="button"
      size="small"
      variant="outlined"
      color={complete ? 'success' : 'warning'}
      startIcon={<Inventory2OutlinedIcon fontSize="small" />}
      onClick={() => onOpen(trackingMode)}
      sx={{ whiteSpace: 'nowrap' }}
    >
      {trackingMode}: {selected}/{needed}
    </Button>
  );
}
