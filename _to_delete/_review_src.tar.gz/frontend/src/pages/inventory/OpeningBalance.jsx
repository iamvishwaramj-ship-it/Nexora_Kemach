import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Box, Typography, Button, Card, CardContent, Stack, Table, TableBody, TableCell, TableHead,
  TableRow, Chip, IconButton, Collapse,
} from '@mui/material';
import BalanceIcon from '@mui/icons-material/Balance';
import AddIcon from '@mui/icons-material/Add';
import CloseIcon from '@mui/icons-material/Close';
import EditIcon from '@mui/icons-material/EditOutlined';
import DeleteIcon from '@mui/icons-material/DeleteOutline';
import UploadFileIcon from '@mui/icons-material/UploadFile';
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import AppForm, { FormGrid, FormSubmitButton } from '../../components/form/AppForm';
import FormTextField from '../../components/form/FormTextField';
import FormSelect from '../../components/form/FormSelect';
import EntityHeaderCard from '../../components/common/EntityHeaderCard';
import CompanyBadge from '../../components/common/CompanyBadge';
import EntityListPagination from '../../components/data-display/EntityListPagination';
import MobileRecordCard from '../../components/data-display/MobileRecordCard';
import { useIsMobileListView } from '../../components/data-display/useIsMobileListView';
import { useNotify } from '../../components/feedback/NotificationProvider';
import { applyServerErrors } from '../../lib/formErrors';
import { useConfirm } from '../../components/feedback/ConfirmationDialog';
import { openingBalanceSchema } from '../../lib/validation/partnerSchemas';
import { openingBalanceApi, useImportOpeningBalanceXlsxMutation, branchApi } from '../../features/resources';
import { useWarehouseOptions } from '../../lib/useWarehouseOptions';
import useTableFeatures from '../../components/data-display/useTableFeatures';
import TableSearchFilter from '../../components/data-display/TableSearchFilter';
import SortableHeaderCell from '../../components/data-display/SortableHeaderCell';
import ScrollableTableContainer from '../../components/data-display/ScrollableTableContainer';

import { CanEdit, CanDelete } from '../../components/common/PermissionGate';
import TableFilterPanel from '../../components/data-display/TableFilterPanel';
const STATUS_OPTIONS = [{ label: 'Active', value: 'Active' }, { label: 'Inactive', value: 'Inactive' }];

// `branch` rides along on the form purely to drive the Warehouse dropdown —
// it isn't part of openingBalanceSchema (OpeningBalance has no branch
// column; a warehouse already belongs to exactly one branch via
// WarehouseMaster.branch) and zodResolver strips any key the schema doesn't
// declare before handleSubmit ever sees it, so it never reaches the API.
const emptyValues = {
  itemCode: '', itemName: '', branch: '', warehouse: '', stock: 0, stockValue: 0, status: 'Active',
};

const PAGE_SIZE = 10;

// createdAt is a timestamp (date + time), not just a date, so it gets its
// own formatter rather than reusing a date-only one — this is when the row
// was actually inserted (typed by hand or imported via Excel), always
// server-stamped, never editable.
const formatDateTime = (d) => (d
  ? new Date(d).toLocaleString('en-GB', {
      day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit',
    })
  : '—');

// One row per item per warehouse — mirrors Master Data.xlsx's Current Stock
// sheet (ItemCode, ItemName, Warehouse, Stock, StockValue), which is also
// what `npm run current_stock:seed` loads in bulk. This page is the manual
// CRUD counterpart to that bulk import: create/edit/delete individual rows
// the same way the other master pages do.
export default function OpeningBalance() {
  const notify = useNotify();
  const confirmDialog = useConfirm();
  const isMobile = useIsMobileListView();
  const { data: balances, isLoading } = openingBalanceApi.useList();
  const [create, { isLoading: creating }] = openingBalanceApi.useCreate();
  const [update, { isLoading: updating }] = openingBalanceApi.useUpdate();
  const [remove] = openingBalanceApi.useDelete();
  const [importXlsx, { isLoading: importing }] = useImportOpeningBalanceXlsxMutation();
  const { data: branches } = branchApi.useList();
  const fileInputRef = useRef(null);
  const branchOptions = (branches || []).map((b) => ({ label: b.branchName, value: b.branchName }));

  // Form is hidden by default — only the list shows until "Add Opening
  // Balance" (or an edit action) is triggered, per the standard CRUD page
  // template (Warehouse Master/Location Master).
  const [showForm, setShowForm] = useState(false);
  const [editingRow, setEditingRow] = useState(null);
  const [readOnly, setReadOnly] = useState(false);
  const [formKey, setFormKey] = useState(0);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(PAGE_SIZE);

  // Warehouse is picked from the Warehouse Master rather than typed, so every
  // Opening Balance row resolves to a real warehouse code (the server's FK is
  // the actual backstop; this just keeps the picker honest).
  //
  // This page had the only correct warehouse picker in the application, and its
  // logic is now the shared one every screen uses — see
  // lib/useWarehouseOptions.js. Behaviour is unchanged, including keeping an
  // already-saved row's warehouse selectable after that warehouse has been
  // deactivated, so editing an old record cannot blank the field out.
  // Unfiltered — needed at this level just to derive the Branch field's
  // default value below (a warehouse already belongs to exactly one branch
  // via WarehouseMaster.branch; see the note on the `branch` field further
  // down for why it's derived rather than stored).
  const { warehouses } = useWarehouseOptions({});

  const allRows = balances || [];

  const tableColumns = useMemo(() => ([
    { field: 'itemCode', headerName: 'Item Code', filter: 'text' },
    { field: 'itemName', headerName: 'Item Name', filter: 'text' },
    { field: 'warehouse', headerName: 'Warehouse', filter: 'text' },
    { field: 'stock', headerName: 'Stock', filter: 'numberRange', sortValue: (row) => (row.stock == null ? null : Number(row.stock)) },
    { field: 'stockValue', headerName: 'Stock Value (₹)', filter: 'numberRange', sortValue: (row) => (row.stockValue == null ? null : Number(row.stockValue)) },
    { field: 'status', headerName: 'Status', filter: 'select' },
    { field: 'createdAt', headerName: 'Created At', filter: 'dateRange', sortValue: (row) => (row.createdAt ? new Date(row.createdAt).getTime() : null), searchValue: (row) => formatDateTime(row.createdAt) },
  ]), []);
  const table = useTableFeatures(allRows, tableColumns, { onChange: setPage });
  const rows = table.rows;
  const pagedRows = useMemo(() => rows.slice(page * pageSize, page * pageSize + pageSize), [rows, page, pageSize]);

  useEffect(() => { setPage(0); }, [rows.length]);

  const openCreate = () => {
    setEditingRow(null);
    setReadOnly(false);
    setFormKey((k) => k + 1);
    setShowForm(true);
  };

  const closeForm = () => {
    setShowForm(false);
    setEditingRow(null);
  };

  const handleToggleForm = () => (showForm ? closeForm() : openCreate());

  // Read-only look at a record — same form, every field disabled
  // and the save button removed (see AppForm's readOnly prop).
  const handleView = (row) => {
    setEditingRow(row);
    setReadOnly(true);
    setFormKey((k) => k + 1);
    setShowForm(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleEdit = (row) => {
    setEditingRow(row);
    setReadOnly(false);
    setFormKey((k) => k + 1);
    setShowForm(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = async (row) => {
    const ok = await confirmDialog({
      title: 'Delete opening balance',
      message: `Are you sure you want to delete the opening balance for "${row.itemCode}" at "${row.warehouse}"? This cannot be undone.`,
      confirmLabel: 'Delete',
      severity: 'error',
    });
    if (!ok) return;
    try {
      await remove(row.id).unwrap();
      notify.success('Opening balance deleted');
    } catch (err) {
      notify.error(err?.data?.message || 'Delete failed');
    }
  };

  const handleImportClick = () => fileInputRef.current?.click();

  // The server does all the real validation (header wording, warehouse FK,
  // numeric checks) — this just gets the file there and surfaces the
  // resulting summary. Row-level created_at/updated_at always come from the
  // server clock: the sheet is never allowed to carry a timestamp column
  // through in the first place (see OPENING_BALANCE_IMPORT_FIELDS on the
  // backend), so there's nothing to strip on this side.
  const handleImportFile = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = ''; // allow re-selecting the same file after a failed attempt
    if (!file) return;

    const formData = new FormData();
    formData.append('file', file);

    try {
      const result = await importXlsx(formData).unwrap();
      if (result.skipped > 0) {
        notify.warning(result.message, { duration: 8000 });
        // eslint-disable-next-line no-console
        console.warn('Opening Balance import — skipped rows:', result.errors);
      } else {
        notify.success(result.message);
      }
    } catch (err) {
      notify.error(err?.data?.message || 'Import failed. Check the file and try again.');
    }
  };

  const handleSubmit = async (values, formMethods) => {
    // branch only exists on the form to scope the Warehouse dropdown —
    // OpeningBalance itself has no branch column, so it's dropped here
    // rather than sent to an API that would reject an unknown field.
    const { branch: _branch, ...payload } = values;
    try {
      if (editingRow) {
        await update({ id: editingRow.id, ...payload }).unwrap();
        notify.success('Opening balance updated');
      } else {
        await create(payload).unwrap();
        notify.success('Opening balance added');
      }
      closeForm();
    } catch (err) {
      notify.error(applyServerErrors(err, formMethods.setError));
    }
  };

  return (
    <Box>
      <EntityHeaderCard
        icon={<BalanceIcon />}
        title="Opening Balance"
        subtitle="Manage per-item, per-warehouse opening stock. Add, update or remove entries."
        rightContent={<CompanyBadge />}
      />

      <Stack direction="row" justifyContent="flex-end" spacing={1.5} sx={{ mb: 2 }}>
        <input
          ref={fileInputRef}
          type="file"
          accept=".xlsx,.xls"
          hidden
          onChange={handleImportFile}
        />
        <Button
          variant="outlined"
          color="inherit"
          startIcon={<UploadFileIcon />}
          onClick={handleImportClick}
          disabled={importing}
        >
          {importing ? 'Importing...' : 'Import from Excel'}
        </Button>
        <Button
          variant="contained"
          startIcon={showForm ? <CloseIcon /> : <AddIcon />}
          onClick={handleToggleForm}
        >
          {showForm ? 'Close' : 'Add Opening Balance'}
        </Button>
      </Stack>

      <Collapse in={showForm} unmountOnExit>
        <Card variant="outlined" sx={{ mb: 2 }}>
          <CardContent sx={{ p: 3 }}>
            <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 2 }}>
              {readOnly ? 'View Opening Balance' : editingRow ? 'Edit Opening Balance' : 'New Opening Balance'}
            </Typography>

            <AppForm readOnly={readOnly}
              key={formKey}
              schema={openingBalanceSchema}
              defaultValues={editingRow
                ? {
                    ...emptyValues,
                    ...editingRow,
                    // Derived, not stored — see the note on emptyValues above.
                    branch: (warehouses || []).find((w) => w.whsCode === editingRow.warehouse)?.branch || '',
                  }
                : emptyValues}
              onSubmit={handleSubmit}
            >
              {(methods) => {
                const { watch, setValue } = methods;
                const branch = watch('branch');
                const { options: warehouseOptions } = useWarehouseOptions({ currentValue: editingRow?.warehouse, branch });

                // Switching Branch clears Warehouse if it no longer belongs —
                // same rule every other branch-scoped warehouse picker in the
                // app now follows. Skipped on the very first render so
                // opening an existing row for edit/view doesn't wipe the
                // value just derived into defaultValues above.
                const prevBranchRef = useRef(branch);
                useEffect(() => {
                  if (prevBranchRef.current === branch) return;
                  prevBranchRef.current = branch;
                  const allowed = new Set(
                    (warehouses || []).filter((w) => !branch || w.branch === branch).map((w) => w.whsCode)
                  );
                  if (watch('warehouse') && !allowed.has(watch('warehouse'))) setValue('warehouse', '');
                  // eslint-disable-next-line react-hooks/exhaustive-deps
                }, [branch]);

                return (
                  <>
                    <FormGrid columns={3}>
                      <FormTextField name="itemCode" label="Item Code *" placeholder="Enter item code" />
                      <FormTextField name="itemName" label="Item Name *" placeholder="Enter item name" />
                      <FormSelect name="branch" label="Branch *" placeholder="Select branch" options={branchOptions} />
                      <FormSelect
                        name="warehouse"
                        label="Warehouse *"
                        placeholder={branch ? 'Select warehouse' : 'Select a branch first'}
                        options={warehouseOptions}
                        disabled={!branch}
                      />

                      <FormTextField name="stock" label="Stock *" type="number" placeholder="0" />
                      <FormTextField name="stockValue" label="Stock Value (₹) *" type="number" placeholder="0.00" />
                      <FormSelect name="status" label="Status *" options={STATUS_OPTIONS} />
                    </FormGrid>

                    <Stack direction="row" spacing={1.5} justifyContent="flex-end" sx={{ mt: 3 }}>
                      <Button variant="outlined" color={readOnly ? 'error' : 'inherit'} onClick={closeForm} disabled={creating || updating}>
                        {readOnly ? 'Close' : 'Clear'}
                      </Button>
                      <FormSubmitButton disabled={creating || updating}>
                        {readOnly ? 'View' : editingRow ? 'Update Opening Balance' : 'Save Opening Balance'}
                      </FormSubmitButton>
                    </Stack>
                  </>
                );
              }}
            </AppForm>
          </CardContent>
        </Card>
      </Collapse>

      <Card variant="outlined">
        <CardContent sx={{ p: 0 }}>
          <Stack direction="row" alignItems="center" justifyContent="space-between" flexWrap="wrap" gap={1.5} sx={{ px: 3, pt: 2.5, pb: 1.5 }}>
            <Typography variant="subtitle1" fontWeight={700}>Opening Balance List</Typography>
            <TableSearchFilter table={table} placeholder="Search by item code, name, warehouse..." width={260} />
          </Stack>

          <TableFilterPanel table={table} />

          {isMobile ? (
            <Box sx={{ px: 2, pb: 1 }}>
              {!isLoading && pagedRows.map((row) => (
                <MobileRecordCard
                  key={row.id}
                  title={row.itemName}
                  statusChip={<Chip size="small" label={row.status} color={row.status === 'Active' ? 'success' : 'default'} variant="outlined" />}
                  fields={[
                    { label: 'Item Code', value: row.itemCode },
                    { label: 'Warehouse', value: row.warehouse || '—' },
                    { label: 'Stock', value: Number(row.stock ?? 0).toFixed(2) },
                    { label: 'Stock Value', value: `₹${Number(row.stockValue ?? 0).toFixed(2)}` },
                    { label: 'Created At', value: formatDateTime(row.createdAt) },
                  ]}
                  onView={() => handleView(row)}
                  onEdit={() => handleEdit(row)}
                  onDelete={() => handleDelete(row)}
                />
              ))}
              {!isLoading && rows.length === 0 && (
                <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>{table.isFiltering ? 'No opening balances match your search' : 'No opening balances yet'}</Typography>
              )}
            </Box>
          ) : (
            <ScrollableTableContainer>
              <Table size="small" stickyHeader>
                <TableHead>
                  <TableRow>
                    <TableCell width={48}>#</TableCell>
                    <SortableHeaderCell field="itemCode" sort={table.sort} onSort={table.toggleSort}>Item Code</SortableHeaderCell>
                    <SortableHeaderCell field="itemName" sort={table.sort} onSort={table.toggleSort}>Item Name</SortableHeaderCell>
                    <SortableHeaderCell field="warehouse" sort={table.sort} onSort={table.toggleSort}>Warehouse</SortableHeaderCell>
                    <SortableHeaderCell field="stock" sort={table.sort} onSort={table.toggleSort}>Stock</SortableHeaderCell>
                    <SortableHeaderCell field="stockValue" sort={table.sort} onSort={table.toggleSort}>Stock Value (₹)</SortableHeaderCell>
                    <SortableHeaderCell field="status" sort={table.sort} onSort={table.toggleSort}>Status</SortableHeaderCell>
                    <SortableHeaderCell field="createdAt" sort={table.sort} onSort={table.toggleSort}>Created At</SortableHeaderCell>
                    <TableCell align="right">Action</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {!isLoading && pagedRows.map((row, i) => (
                    <TableRow key={row.id} hover>
                      <TableCell>{page * pageSize + i + 1}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.itemCode}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.itemName}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.warehouse || '—'}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{Number(row.stock ?? 0).toFixed(2)}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{Number(row.stockValue ?? 0).toFixed(2)}</TableCell>
                      <TableCell>
                        <Chip size="small" label={row.status} color={row.status === 'Active' ? 'success' : 'default'} variant="outlined" />
                      </TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{formatDateTime(row.createdAt)}</TableCell>
                      <TableCell align="right">
                        <Stack direction="row" spacing={0.5} justifyContent="flex-end">
                          <IconButton size="small" onClick={() => handleView(row)} aria-label="view">
                            <VisibilityOutlinedIcon fontSize="small" />
                          </IconButton>
                          <CanEdit>
                            <IconButton size="small" color="primary" onClick={() => handleEdit(row)} aria-label="edit">
                              <EditIcon fontSize="small" />
                            </IconButton>
                          </CanEdit>
                          <CanDelete>
                            <IconButton size="small" color="error" onClick={() => handleDelete(row)} aria-label="delete">
                              <DeleteIcon fontSize="small" />
                            </IconButton>
                          </CanDelete>
                        </Stack>
                      </TableCell>
                    </TableRow>
                  ))}
                  {!isLoading && rows.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={9}>
                        <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>{table.isFiltering ? 'No opening balances match your search' : 'No opening balances yet'}</Typography>
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </ScrollableTableContainer>
          )}

          <EntityListPagination total={rows.length} page={page} onChange={setPage} pageSize={pageSize} onPageSizeChange={(v) => { setPageSize(v); setPage(0); }} />
        </CardContent>
      </Card>
    </Box>
  );
}
