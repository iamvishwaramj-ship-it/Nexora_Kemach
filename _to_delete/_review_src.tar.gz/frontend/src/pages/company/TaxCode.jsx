import React, { useEffect, useMemo, useState } from 'react';
import {
  Box, Typography, Button, Card, CardContent, Stack, Table, TableBody, TableCell, TableHead,
  TableRow, Chip, IconButton, Dialog, DialogTitle, DialogContent, DialogActions,
} from '@mui/material';
import PercentIcon from '@mui/icons-material/Percent';
import AddIcon from '@mui/icons-material/Add';
import CloseIcon from '@mui/icons-material/Close';
import EditIcon from '@mui/icons-material/EditOutlined';
import DeleteIcon from '@mui/icons-material/DeleteOutline';
import RestartAltIcon from '@mui/icons-material/RestartAlt';
import SearchIcon from '@mui/icons-material/Search';
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import { z } from 'zod';
import AppForm, { FormGrid, FormSubmitButton } from '../../components/form/AppForm';
import { useUnsavedChangesGuard, FormDirtyTracker } from '../../components/form/useUnsavedChangesGuard';
import FormTextField from '../../components/form/FormTextField';
import FormSelect from '../../components/form/FormSelect';
import EntityHeaderCard from '../../components/common/EntityHeaderCard';import EntityListPagination from '../../components/data-display/EntityListPagination';
import MobileRecordCard from '../../components/data-display/MobileRecordCard';
import { useIsMobileListView } from '../../components/data-display/useIsMobileListView';
import useDragScroll from '../../components/data-display/useDragScroll';
import { useNotify } from '../../components/feedback/NotificationProvider';
import { applyServerErrors } from '../../lib/formErrors';
import { useConfirm } from '../../components/feedback/ConfirmationDialog';
import { requiredString, optionalString, nonNegativeNumber, statusEnum } from '../../lib/validation/common';
import { taxCodeApi } from '../../features/resources';
import { useResetTaxCodesMutation } from '../../features/company/taxCodeExtraApi';
import useTableFeatures from '../../components/data-display/useTableFeatures';
import TableSearchFilter from '../../components/data-display/TableSearchFilter';
import SortableHeaderCell from '../../components/data-display/SortableHeaderCell';
import ScrollableTableContainer from '../../components/data-display/ScrollableTableContainer';
import DocumentNoField from '../../components/form/DocumentNoField';

import { CanAdd, CanEdit, CanDelete } from '../../components/common/PermissionGate';
import TableFilterPanel from '../../components/data-display/TableFilterPanel';
// Local schema — the shared taxCodeSchema treats taxType as optional, but
// this page's design marks it required, so extend it here rather than
// changing required-ness for every other consumer of taxCodeSchema.
const taxCodeDetailsSchema = z.object({
  taxCode: requiredString('Tax code'),
  taxName: requiredString('Tax name'),
  taxType: requiredString('Tax type'),
  taxRate: nonNegativeNumber('Rate', 100),
  description: optionalString(),
  status: statusEnum(),
});

const emptyValues = { taxCode: '', taxName: '', taxType: '', taxRate: '', description: '', status: 'Active' };

// "GST 12%" and "GST12%" read as the same tax code to a person even though
// they're different strings byte-for-byte — collapse whitespace and case
// before comparing so a re-typed duplicate with different spacing is still
// caught client-side before it ever reaches the server. Mirrors the same
// normalisation the backend applies in routes/company.js (findDuplicateTaxCode).
const normaliseTaxLabel = (v) => String(v ?? '').replace(/\s+/g, '').toLowerCase();

function findDuplicateTaxCode(values, existingRows, ignoreId) {
  const normCode = normaliseTaxLabel(values.taxCode);
  const normName = normaliseTaxLabel(values.taxName);
  return existingRows.find((r) => {
    if (ignoreId != null && r.id === ignoreId) return false;
    return (normCode && normaliseTaxLabel(r.taxCode) === normCode)
        || (normName && normaliseTaxLabel(r.taxName) === normName);
  });
}

const TAX_TYPE_OPTIONS = [
  { label: 'GST', value: 'GST' },
  { label: 'IGST', value: 'IGST' },
  { label: 'CGST', value: 'CGST' },
  { label: 'SGST', value: 'SGST' },
  { label: 'Other', value: 'Other' },
];

const PAGE_SIZE = 10;

export default function TaxCode() {
  const notify = useNotify();
  const confirmDialog = useConfirm();
  const isMobile = useIsMobileListView();
  const { data: taxCodes, isLoading } = taxCodeApi.useList();
  const [create, { isLoading: creating }] = taxCodeApi.useCreate();
  const [update, { isLoading: updating }] = taxCodeApi.useUpdate();
  const [remove] = taxCodeApi.useDelete();
  const [resetTaxCodes, { isLoading: resetting }] = useResetTaxCodesMutation();

  // The form lives in a modal — the page itself is the list, and the Add
  // button (or an edit action) opens the dialog over it. Same shape as the
  // Branch Details page / shared MasterCrudPage template.
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingRow, setEditingRow] = useState(null);
  const [readOnly, setReadOnly] = useState(false);
  const [formKey, setFormKey] = useState(0);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(PAGE_SIZE);

  const [search, setSearch] = useState('');
  const allRows = taxCodes || [];
  const baseTableRows = useMemo(() => {
    const q = '';
    if (!q) return allRows;
    return allRows.filter((r) => [r.taxCode, r.taxName, r.taxType].some((v) => String(v || '').toLowerCase().includes(q)));
  }, [allRows]);

  // Column definitions drive the global search, the sort icons and the filter
  // popover — see components/data-display/useTableFeatures.js.
  const tableColumns = useMemo(() => ([
    { field: 'taxCode', headerName: 'Tax Code', filter: 'text' },
    { field: 'taxName', headerName: 'Tax Name', filter: 'text' },
    { field: 'taxType', headerName: 'Tax Type', filter: 'text' },
    { field: 'taxRate', headerName: 'Rate (%)', filter: 'numberRange', sortValue: (row) => (row.taxRate == null || row.taxRate === '' ? null : Number(row.taxRate)) },
    { field: 'description', headerName: 'Description', filter: 'text' },
    { field: 'status', headerName: 'Status', filter: 'select' },
  ]), []);
  const table = useTableFeatures(baseTableRows, tableColumns, { onChange: setPage });
  const rows = table.rows;
  const pagedRows = useMemo(() => rows.slice(page * pageSize, page * pageSize + pageSize), [rows, page, pageSize]);

  useEffect(() => { setPage(0); }, [search]);

  const openCreate = () => {
    setEditingRow(null);
    setReadOnly(false);
    setFormKey((k) => k + 1);
    setDialogOpen(true);
  };

  const closeForm = () => {
    setDialogOpen(false);
    setEditingRow(null);
  };

  // Closing a half-filled form asks before throwing the work away.
  // requestClose is what Cancel / the X / Esc go through; forceClose is the
  // save path, which has nothing to lose. See useUnsavedChangesGuard.jsx.
  const { requestClose, forceClose, setDirty, dialogCloseProps } = useUnsavedChangesGuard(closeForm);

  // Read-only look at a record — same form, every field disabled
  // and the save button removed (see AppForm's readOnly prop).
  const handleView = (row) => {
    setEditingRow(row);
    setReadOnly(true);
    setFormKey((k) => k + 1);
    setDialogOpen(true);
  };

  const handleEdit = (row) => {
    setEditingRow(row);
    setReadOnly(false);
    setFormKey((k) => k + 1);
    setDialogOpen(true);
  };

  const handleDelete = async (row) => {
    const ok = await confirmDialog({
      title: 'Delete tax code',
      message: `Are you sure you want to delete "${row.taxCode}"? This cannot be undone.`,
      confirmLabel: 'Delete',
      severity: 'error',
    });
    if (!ok) return;
    try {
      await remove(row.id).unwrap();
      notify.success('Tax code deleted');
    } catch (err) {
      notify.error(err?.data?.message || 'Delete failed');
    }
  };

  // Captured from AppForm's render prop once its RHF instance exists (see
  // the `key={formKey}` AppForm below) — lets handleSubmit attach a
  // duplicate-tax-code error to the exact field it belongs to, the same
  // pattern DocumentNumberingForm.jsx uses for its own server-side errors.
  const setErrorRef = React.useRef(() => {});

  const handleSubmit = async (values, formMethods) => {
    // Client-side check first: catches a duplicate immediately, without a
    // round trip, using the same "ignore spacing/case" comparison as the
    // server (findDuplicateTaxCode in routes/company.js) — "GST 12%" already
    // in the list blocks "GST12%" from saving as if it were new.
    const clientDupe = findDuplicateTaxCode(values, allRows, editingRow?.id ?? null);
    if (clientDupe) {
      const field = normaliseTaxLabel(clientDupe.taxCode) === normaliseTaxLabel(values.taxCode) ? 'taxCode' : 'taxName';
      const message = `"${clientDupe.taxCode} — ${clientDupe.taxName}" already covers this — differing only by spacing/case does not make it a new tax code`;
      setErrorRef.current(field, { type: 'duplicate', message });
      notify.error(message);
      return;
    }

    try {
      if (editingRow) {
        await update({ id: editingRow.id, ...values }).unwrap();
        notify.success('Tax code updated');
      } else {
        await create(values).unwrap();
        notify.success('Tax code added');
      }
      forceClose();
    } catch (err) {
      notify.error(applyServerErrors(err, formMethods.setError));
      // Field-tagged errors from the server's own duplicate check (badRequest
      // in routes/company.js) — covers the race where two people add the
      // same tax code between this page's load and this save.
      const fieldErrors = err?.data?.errors;
      if (Array.isArray(fieldErrors)) {
        for (const fe of fieldErrors) {
          if (fe.field) setErrorRef.current(fe.field, { type: 'server', message: fe.message });
        }
      }
    }
  };

  const handleReset = async () => {
    const ok = await confirmDialog({
      title: 'Reset to default',
      message: 'This restores the standard GST tax code set (GST5, GST12, GST18, GST28, IGST18, CGST9, SGST9). Continue?',
      confirmLabel: 'Reset',
      severity: 'warning',
    });
    if (!ok) return;
    try {
      await resetTaxCodes().unwrap();
      table.resetAll();
      setPage(0);
      notify.success('Tax codes reset to defaults');
    } catch (err) {
      notify.error(err?.data?.message || 'Reset failed');
    }
  };

  return (
    <Box>
      <EntityHeaderCard
        icon={<PercentIcon />}
        title="Tax Code"
        subtitle="Create and manage tax codes for your business."
        rightContent={
          <CanAdd>
            <Button variant="contained" startIcon={<AddIcon />} onClick={openCreate}>
              Add Tax Code
            </Button>
          </CanAdd>
        }
      />

      <Dialog
        open={dialogOpen}
        {...dialogCloseProps}
        maxWidth="md"
        fullWidth
        sx={{
          // AppForm wraps its children in a <form>, which lands between the
          // dialog's Paper and DialogContent and breaks the flex chain Paper
          // relies on to make DialogContent scroll. Without this the field
          // grid is clipped on a short viewport instead of scrolling, and the
          // action buttons go with it.
          '& .MuiDialog-paper > form': {
            display: 'flex',
            flexDirection: 'column',
            minHeight: 0,
            overflow: 'hidden',
          },
        }}
      >
        <DialogTitle
          component="div"
          sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 1, pr: 1 }}
        >
          <Typography variant="subtitle1" fontWeight={700}>
            {readOnly ? 'View Tax Code' : editingRow ? 'Edit Tax Code' : 'New Tax Code'}
          </Typography>
          <IconButton
            onClick={requestClose}
            size="small"
            aria-label="close"
            // Red only while viewing — on an Add/Edit dialog this same button sits
            // beside a live Save, where red would read as destructive.
            sx={readOnly ? {
              border: '1px solid',
              borderColor: 'error.main',
              color: 'error.main',
              '&:hover': { borderColor: 'error.dark', color: 'error.dark' },
            } : undefined}
          >
            <CloseIcon fontSize="small" />
          </IconButton>
        </DialogTitle>

        <AppForm readOnly={readOnly}
          key={formKey}
          schema={taxCodeDetailsSchema}
          defaultValues={editingRow ? { ...emptyValues, ...editingRow } : emptyValues}
          onSubmit={handleSubmit}
        >
          {({ setError }) => {
            setErrorRef.current = setError;
            return (
            <>
              {/* Watches for the first real user edit so the close handlers
                  above know whether there is anything to lose. */}
              <FormDirtyTracker onDirtyChange={setDirty} />
              <DialogContent dividers>
                <FormGrid columns={3}>
                  {/* Auto-generated from the perpetual TAX numbering series (hidden from
                      the Document Numbering page — see hiddenFromNumberingUI in
                      documentNumberService.js). The field is filled and locked on
                      create, and left untouched on edit so an existing record's code
                      is never rewritten. */}
                  <DocumentNoField documentCode="TAX" name="taxCode" label="Tax Code *" isCreate={!editingRow} />
                  <FormTextField name="taxName" label="Tax Name *" placeholder="Enter tax name (e.g. GST 5%)" />
                  <FormSelect name="taxType" label="Tax Type *" placeholder="Select tax type" options={TAX_TYPE_OPTIONS} />

                  <FormTextField name="taxRate" label="Rate (%) *" type="number" placeholder="Enter rate (e.g. 5.00)" />
                  <FormTextField name="description" label="Description" placeholder="Enter description (optional)" />
                  <FormSelect
                    name="status"
                    label="Status *"
                    options={[{ label: 'Active', value: 'Active' }, { label: 'Inactive', value: 'Inactive' }]}
                  />
                </FormGrid>
              </DialogContent>

              <DialogActions sx={{ px: 3, py: 2 }}>
                <FormSubmitButton disabled={creating || updating}>
                  {readOnly ? 'View' : editingRow ? 'Update Tax Code' : 'Save Tax Code'}
                </FormSubmitButton>
                <Button variant={readOnly ? 'outlined' : 'text'} color={readOnly ? 'error' : 'inherit'} onClick={requestClose} disabled={creating || updating}>
                  {readOnly ? 'Close' : 'Cancel'}
                </Button>
              </DialogActions>
            </>
            );
          }}
        </AppForm>
      </Dialog>

      <Card variant="outlined">
        <CardContent sx={{ p: 0 }}>
          <Stack direction="row" alignItems="center" justifyContent="space-between" flexWrap="wrap" gap={1.5} sx={{ px: 3, pt: 2.5, pb: 1.5 }}>
            <Typography variant="subtitle1" fontWeight={700}>Tax Code List</Typography>
            <Stack direction="row" spacing={1.5} alignItems="center">
              <TableSearchFilter table={table} placeholder="Search tax codes..." width={220} />
              <Button variant="outlined" startIcon={<RestartAltIcon />} onClick={handleReset} disabled={resetting}>
                Reset to Default
              </Button>
            </Stack>

            <TableFilterPanel table={table} />
          </Stack>

          {isMobile ? (
            <Box sx={{ px: 2, pb: 1 }}>
              {!isLoading && pagedRows.map((row) => (
                <MobileRecordCard
                  key={row.id}
                  title={`${row.taxCode} — ${row.taxName}`}
                  statusChip={<Chip size="small" label={row.status} color={row.status === 'Active' ? 'success' : 'default'} variant="outlined" />}
                  fields={[
                    { label: 'Tax Type', value: row.taxType || '—' },
                    { label: 'Rate (%)', value: row.taxRate != null ? Number(row.taxRate).toFixed(2) : '—' },
                    { label: 'Description', value: row.description || '—' },
                  ]}
                  onView={() => handleView(row)}
                  onEdit={() => handleEdit(row)}
                  onDelete={() => handleDelete(row)}
                />
              ))}
              {!isLoading && rows.length === 0 && (
                <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>{table.isFiltering ? 'No tax codes match your search' : 'No tax codes yet'}</Typography>
              )}
            </Box>
          ) : (
            <ScrollableTableContainer>
              <Table size="small" stickyHeader>
                <TableHead>
                  <TableRow>
                    <TableCell width={48}>#</TableCell>
                    <SortableHeaderCell field="taxCode" sort={table.sort} onSort={table.toggleSort}>Tax Code</SortableHeaderCell>
                    <SortableHeaderCell field="taxName" sort={table.sort} onSort={table.toggleSort}>Tax Name</SortableHeaderCell>
                    <SortableHeaderCell field="taxType" sort={table.sort} onSort={table.toggleSort}>Tax Type</SortableHeaderCell>
                    <SortableHeaderCell field="taxRate" sort={table.sort} onSort={table.toggleSort}>Rate (%)</SortableHeaderCell>
                    <SortableHeaderCell field="description" sort={table.sort} onSort={table.toggleSort}>Description</SortableHeaderCell>
                    <SortableHeaderCell field="status" sort={table.sort} onSort={table.toggleSort}>Status</SortableHeaderCell>
                    <TableCell align="right">Action</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {!isLoading && pagedRows.map((row, i) => (
                    <TableRow key={row.id} hover>
                      <TableCell>{page * pageSize + i + 1}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.taxCode}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.taxName}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.taxType || '—'}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.taxRate != null ? Number(row.taxRate).toFixed(2) : '—'}</TableCell>
                      <TableCell sx={{ maxWidth: 280 }}>{row.description || '—'}</TableCell>
                      <TableCell>
                        <Chip size="small" label={row.status} color={row.status === 'Active' ? 'success' : 'default'} variant="outlined" />
                      </TableCell>
                      <TableCell align="right">
                        <Stack direction="row" spacing={0.5} justifyContent="flex-end">
                          <IconButton size="small" onClick={() => handleView(row)} aria-label="view">
                            <VisibilityOutlinedIcon fontSize="small" />
                          </IconButton>
                          <CanEdit>
                            <IconButton size="small" color="primary" onClick={() => handleEdit(row)} aria-label="edit">
                              <EditIcon fontSize="small" />
                            </IconButton>
                          </CanEdit>
                          <CanDelete>
                            <IconButton size="small" color="error" onClick={() => handleDelete(row)} aria-label="delete">
                              <DeleteIcon fontSize="small" />
                            </IconButton>
                          </CanDelete>
                        </Stack>
                      </TableCell>
                    </TableRow>
                  ))}
                  {!isLoading && rows.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={8}>
                        <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>{table.isFiltering ? 'No tax codes match your search' : 'No tax codes yet'}</Typography>
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </ScrollableTableContainer>
          )}

          <EntityListPagination total={rows.length} page={page} onChange={setPage} pageSize={pageSize} onPageSizeChange={(v) => { setPageSize(v); setPage(0); }} />
        </CardContent>
      </Card>
    </Box>
  );
}
