import React, { useEffect, useMemo, useState } from 'react';
import {
  Box, Typography, Button, Card, CardContent, Stack, Table, TableBody, TableCell, TableHead,
  TableRow, Chip, IconButton, Dialog, DialogTitle, DialogContent, DialogActions,
} from '@mui/material';
import PeopleAltIcon from '@mui/icons-material/PeopleAlt';
import AddIcon from '@mui/icons-material/Add';
import CloseIcon from '@mui/icons-material/Close';
import EditIcon from '@mui/icons-material/EditOutlined';
import DeleteIcon from '@mui/icons-material/DeleteOutline';
import RefreshIcon from '@mui/icons-material/Refresh';
import SearchIcon from '@mui/icons-material/Search';
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import { z } from 'zod';
import AppForm, { FormGrid, FormSubmitButton } from '../../components/form/AppForm';
import { useUnsavedChangesGuard, FormDirtyTracker } from '../../components/form/useUnsavedChangesGuard';
import FormTextField from '../../components/form/FormTextField';
import FormSelect from '../../components/form/FormSelect';
import FormDatePicker from '../../components/form/FormDatePicker';
import EntityHeaderCard from '../../components/common/EntityHeaderCard';import EntityListPagination from '../../components/data-display/EntityListPagination';
import MobileRecordCard from '../../components/data-display/MobileRecordCard';
import { useIsMobileListView } from '../../components/data-display/useIsMobileListView';
import useDragScroll from '../../components/data-display/useDragScroll';
import { useNotify } from '../../components/feedback/NotificationProvider';
import { applyServerErrors } from '../../lib/formErrors';
import { useConfirm } from '../../components/feedback/ConfirmationDialog';
import { requiredString, optionalString, optionalEmail, mobileNumber, statusEnum, optionalDate } from '../../lib/validation/common';
import { salesEmployeeApi } from '../../features/resources';
import useTableFeatures from '../../components/data-display/useTableFeatures';
import TableSearchFilter from '../../components/data-display/TableSearchFilter';
import SortableHeaderCell from '../../components/data-display/SortableHeaderCell';
import ScrollableTableContainer from '../../components/data-display/ScrollableTableContainer';
import DocumentNoField from '../../components/form/DocumentNoField';

import { CanAdd, CanEdit, CanDelete } from '../../components/common/PermissionGate';
import TableFilterPanel from '../../components/data-display/TableFilterPanel';
// Local schema — the shared salesEmployeeSchema makes phone optional and
// date of joining required; this page's design is the opposite (Phone
// Number required, Date of Joining optional), so override both here rather
// than changing every other consumer of salesEmployeeSchema.
const salesEmployeeDetailsSchema = z.object({
  employeeCode: requiredString('Employee code'),
  employeeName: requiredString('Employee name'),
  email: optionalEmail(),
  phoneNumber: mobileNumber('Phone number'),
  designation: optionalString(),
  department: optionalString(),
  reportingManager: optionalString(),
  dateOfJoining: optionalDate('Date of joining'),
  address: optionalString(),
  status: statusEnum(),
});

const emptyValues = {
  employeeCode: '', employeeName: '', email: '', phoneNumber: '', designation: '',
  department: '', reportingManager: '', dateOfJoining: null, address: '', status: 'Active',
};

const DEPARTMENT_OPTIONS = [
  { label: 'Sales', value: 'Sales' },
  { label: 'Marketing', value: 'Marketing' },
  { label: 'Finance', value: 'Finance' },
  { label: 'Operations', value: 'Operations' },
  { label: 'HR', value: 'HR' },
  { label: 'IT', value: 'IT' },
  { label: 'Support', value: 'Support' },
  { label: 'Admin', value: 'Admin' },
];

const PAGE_SIZE = 10;

const formatDate = (d) => (d ? new Date(d).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '—');

export default function SalesEmployee() {
  const notify = useNotify();
  const confirmDialog = useConfirm();
  const isMobile = useIsMobileListView();
  const { data: employees, isLoading, isFetching, refetch } = salesEmployeeApi.useList();
  const [create, { isLoading: creating }] = salesEmployeeApi.useCreate();
  const [update, { isLoading: updating }] = salesEmployeeApi.useUpdate();
  const [remove] = salesEmployeeApi.useDelete();

  // The form lives in a modal — the page itself is the list, and the Add
  // button (or an edit action) opens the dialog over it. Same shape as the
  // Branch Details page / shared MasterCrudPage template.
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingRow, setEditingRow] = useState(null);
  const [readOnly, setReadOnly] = useState(false);
  const [formKey, setFormKey] = useState(0);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(PAGE_SIZE);

  const [search, setSearch] = useState('');
  const allRows = employees || [];
  const baseTableRows = useMemo(() => {
    const q = '';
    if (!q) return allRows;
    return allRows.filter((r) => [r.employeeCode, r.employeeName, r.designation, r.email].some((v) => String(v || '').toLowerCase().includes(q)));
  }, [allRows]);

  // Column definitions drive the global search, the sort icons and the filter
  // popover — see components/data-display/useTableFeatures.js.
  const tableColumns = useMemo(() => ([
    { field: 'employeeCode', headerName: 'Employee Code', filter: 'text' },
    { field: 'employeeName', headerName: 'Employee Name', filter: 'text' },
    { field: 'designation', headerName: 'Designation', filter: 'text' },
    { field: 'department', headerName: 'Department', filter: 'text' },
    { field: 'phoneNumber', headerName: 'Phone Number', filter: 'text' },
    { field: 'email', headerName: 'Email', filter: 'text' },
    { field: 'dateOfJoining', headerName: 'Date of Joining', filter: 'dateRange', sortValue: (row) => (row.dateOfJoining ? new Date(row.dateOfJoining).getTime() : null), searchValue: (row) => formatDate(row.dateOfJoining) },
    { field: 'status', headerName: 'Status', filter: 'select' },
  ]), []);
  const table = useTableFeatures(baseTableRows, tableColumns, { onChange: setPage });
  const rows = table.rows;
  const pagedRows = useMemo(() => rows.slice(page * pageSize, page * pageSize + pageSize), [rows, page, pageSize]);

  useEffect(() => { setPage(0); }, [search]);

  // Reporting Manager is populated from existing employees — real data,
  // not a static guess — excluding whoever is currently being edited
  // (an employee can't report to themself).
  const managerOptions = useMemo(
    () => rows
      .filter((r) => r.id !== editingRow?.id)
      .map((r) => ({ label: r.employeeName, value: r.employeeName })),
    [rows, editingRow]
  );

  const openCreate = () => {
    setEditingRow(null);
    setReadOnly(false);
    setFormKey((k) => k + 1);
    setDialogOpen(true);
  };

  const closeForm = () => {
    setDialogOpen(false);
    setEditingRow(null);
  };

  // Closing a half-filled form asks before throwing the work away.
  // requestClose is what Cancel / the X / Esc go through; forceClose is the
  // save path, which has nothing to lose. See useUnsavedChangesGuard.jsx.
  const { requestClose, forceClose, setDirty, dialogCloseProps } = useUnsavedChangesGuard(closeForm);

  // Read-only look at a record — same form, every field disabled
  // and the save button removed (see AppForm's readOnly prop).
  const handleView = (row) => {
    setEditingRow(row);
    setReadOnly(true);
    setFormKey((k) => k + 1);
    setDialogOpen(true);
  };

  const handleEdit = (row) => {
    setEditingRow(row);
    setReadOnly(false);
    setFormKey((k) => k + 1);
    setDialogOpen(true);
  };

  const handleDelete = async (row) => {
    const ok = await confirmDialog({
      title: 'Delete sales employee',
      message: `Are you sure you want to delete "${row.employeeName}"? This cannot be undone.`,
      confirmLabel: 'Delete',
      severity: 'error',
    });
    if (!ok) return;
    try {
      await remove(row.id).unwrap();
      notify.success('Sales employee deleted');
    } catch (err) {
      notify.error(err?.data?.message || 'Delete failed');
    }
  };

  const handleSubmit = async (values, formMethods) => {
    try {
      if (editingRow) {
        await update({ id: editingRow.id, ...values }).unwrap();
        notify.success('Sales employee updated');
      } else {
        await create(values).unwrap();
        notify.success('Sales employee added');
      }
      forceClose();
    } catch (err) {
      notify.error(applyServerErrors(err, formMethods.setError));
    }
  };

  return (
    <Box>
      <EntityHeaderCard
        icon={<PeopleAltIcon />}
        title="Sales Employee"
        subtitle="Manage your sales employees. Add, update or remove employees."
        rightContent={
          <CanAdd>
            <Button variant="contained" startIcon={<AddIcon />} onClick={openCreate}>
              Add Sales Employee
            </Button>
          </CanAdd>
        }
      />

      <Dialog
        open={dialogOpen}
        {...dialogCloseProps}
        maxWidth="lg"
        fullWidth
        sx={{
          // AppForm wraps its children in a <form>, which lands between the
          // dialog's Paper and DialogContent and breaks the flex chain Paper
          // relies on to make DialogContent scroll. Without this the field
          // grid is clipped on a short viewport instead of scrolling, and the
          // action buttons go with it.
          '& .MuiDialog-paper > form': {
            display: 'flex',
            flexDirection: 'column',
            minHeight: 0,
            overflow: 'hidden',
          },
        }}
      >
        <DialogTitle
          component="div"
          sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 1, pr: 1 }}
        >
          <Typography variant="subtitle1" fontWeight={700}>
            {readOnly ? 'View Sales Employee' : editingRow ? 'Edit Sales Employee' : 'New Sales Employee'}
          </Typography>
          <IconButton
            onClick={requestClose}
            size="small"
            aria-label="close"
            // Red only while viewing — on an Add/Edit dialog this same button sits
            // beside a live Save, where red would read as destructive.
            sx={readOnly ? {
              border: '1px solid',
              borderColor: 'error.main',
              color: 'error.main',
              '&:hover': { borderColor: 'error.dark', color: 'error.dark' },
            } : undefined}
          >
            <CloseIcon fontSize="small" />
          </IconButton>
        </DialogTitle>

        <AppForm readOnly={readOnly}
          key={formKey}
          schema={salesEmployeeDetailsSchema}
          defaultValues={editingRow ? { ...emptyValues, ...editingRow } : emptyValues}
          onSubmit={handleSubmit}
        >
          {() => (
            <>
              {/* Watches for the first real user edit so the close handlers
                  above know whether there is anything to lose. */}
              <FormDirtyTracker onDirtyChange={setDirty} />
              <DialogContent dividers>
                <FormGrid columns={4}>
                  {/* Auto-generated from the perpetual EMP numbering series (hidden from
                      the Document Numbering page — see hiddenFromNumberingUI in
                      documentNumberService.js). The field is filled and locked on
                      create, and left untouched on edit so an existing record's code
                      is never rewritten. */}
                  <DocumentNoField documentCode="EMP" name="employeeCode" label="Employee Code *" isCreate={!editingRow} />
                  <FormTextField name="employeeName" label="Employee Name *" placeholder="Enter employee name" />
                  <FormTextField name="email" label="Email" placeholder="Enter email address" />
                  <FormTextField name="phoneNumber" label="Phone Number *" placeholder="Enter phone number" digitsOnly maxLength={10} />

                  <FormTextField name="designation" label="Designation" placeholder="Enter designation" />
                  <FormSelect name="department" label="Department" placeholder="Select department" options={DEPARTMENT_OPTIONS} />
                  <FormSelect name="reportingManager" label="Reporting Manager" placeholder="Select reporting manager" options={managerOptions} />
                  <FormDatePicker name="dateOfJoining" label="Date of Joining" />

                  <FormTextField name="address" label="Address" placeholder="Enter address" />
                  <FormSelect
                    name="status"
                    label="Status *"
                    options={[{ label: 'Active', value: 'Active' }, { label: 'Inactive', value: 'Inactive' }]}
                  />
                </FormGrid>
              </DialogContent>

              <DialogActions sx={{ px: 3, py: 2 }}>
                <FormSubmitButton disabled={creating || updating}>
                  {readOnly ? 'View' : editingRow ? 'Update Employee' : 'Save Employee'}
                </FormSubmitButton>
                <Button variant={readOnly ? 'outlined' : 'text'} color={readOnly ? 'error' : 'inherit'} onClick={requestClose} disabled={creating || updating}>
                  {readOnly ? 'Close' : 'Cancel'}
                </Button>
              </DialogActions>
            </>
          )}
        </AppForm>
      </Dialog>

      <Card variant="outlined">
        <CardContent sx={{ p: 0 }}>
          <Stack direction="row" alignItems="center" justifyContent="space-between" sx={{ px: 3, pt: 2.5, pb: 1.5 }}>
            <Typography variant="subtitle1" fontWeight={700}>Sales Employee List</Typography>
            <Stack direction="row" spacing={1.5} alignItems="center">
              <TableSearchFilter table={table} placeholder="Search employees..." width={220} />
              <Button variant="outlined" startIcon={<RefreshIcon />} onClick={() => refetch()} disabled={isFetching}>
                Refresh
              </Button>
            </Stack>

            <TableFilterPanel table={table} />
          </Stack>

          {isMobile ? (
            <Box sx={{ px: 2, pb: 1 }}>
              {!isLoading && pagedRows.map((row) => (
                <MobileRecordCard
                  key={row.id}
                  title={row.employeeName}
                  statusChip={<Chip size="small" label={row.status} color={row.status === 'Active' ? 'success' : 'default'} variant="outlined" />}
                  fields={[
                    { label: 'Employee Code', value: row.employeeCode },
                    { label: 'Designation', value: row.designation || '—' },
                    { label: 'Department', value: row.department || '—' },
                    { label: 'Phone Number', value: row.phoneNumber || '—' },
                    { label: 'Email', value: row.email || '—' },
                    { label: 'Date of Joining', value: formatDate(row.dateOfJoining) },
                  ]}
                  onView={() => handleView(row)}
                  onEdit={() => handleEdit(row)}
                  onDelete={() => handleDelete(row)}
                />
              ))}
              {!isLoading && rows.length === 0 && (
                <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>{table.isFiltering ? 'No sales employees match your search' : 'No sales employees yet'}</Typography>
              )}
            </Box>
          ) : (
            <ScrollableTableContainer>
              <Table size="small" stickyHeader>
                <TableHead>
                  <TableRow>
                    <TableCell width={48}>#</TableCell>
                    <SortableHeaderCell field="employeeCode" sort={table.sort} onSort={table.toggleSort}>Employee Code</SortableHeaderCell>
                    <SortableHeaderCell field="employeeName" sort={table.sort} onSort={table.toggleSort}>Employee Name</SortableHeaderCell>
                    <SortableHeaderCell field="designation" sort={table.sort} onSort={table.toggleSort}>Designation</SortableHeaderCell>
                    <SortableHeaderCell field="department" sort={table.sort} onSort={table.toggleSort}>Department</SortableHeaderCell>
                    <SortableHeaderCell field="phoneNumber" sort={table.sort} onSort={table.toggleSort}>Phone Number</SortableHeaderCell>
                    <SortableHeaderCell field="email" sort={table.sort} onSort={table.toggleSort}>Email</SortableHeaderCell>
                    <SortableHeaderCell field="dateOfJoining" sort={table.sort} onSort={table.toggleSort}>Date of Joining</SortableHeaderCell>
                    <SortableHeaderCell field="status" sort={table.sort} onSort={table.toggleSort}>Status</SortableHeaderCell>
                    <TableCell align="right">Action</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {!isLoading && pagedRows.map((row, i) => (
                    <TableRow key={row.id} hover>
                      <TableCell>{page * pageSize + i + 1}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.employeeCode}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.employeeName}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.designation || '—'}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.department || '—'}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.phoneNumber || '—'}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.email || '—'}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{formatDate(row.dateOfJoining)}</TableCell>
                      <TableCell>
                        <Chip size="small" label={row.status} color={row.status === 'Active' ? 'success' : 'default'} variant="outlined" />
                      </TableCell>
                      <TableCell align="right">
                        <Stack direction="row" spacing={0.5} justifyContent="flex-end">
                          <IconButton size="small" onClick={() => handleView(row)} aria-label="view">
                            <VisibilityOutlinedIcon fontSize="small" />
                          </IconButton>
                          <CanEdit>
                            <IconButton size="small" color="primary" onClick={() => handleEdit(row)} aria-label="edit">
                              <EditIcon fontSize="small" />
                            </IconButton>
                          </CanEdit>
                          <CanDelete>
                            <IconButton size="small" color="error" onClick={() => handleDelete(row)} aria-label="delete">
                              <DeleteIcon fontSize="small" />
                            </IconButton>
                          </CanDelete>
                        </Stack>
                      </TableCell>
                    </TableRow>
                  ))}
                  {!isLoading && rows.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={10}>
                        <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>{table.isFiltering ? 'No sales employees match your search' : 'No sales employees yet'}</Typography>
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </ScrollableTableContainer>
          )}

          <EntityListPagination total={rows.length} page={page} onChange={setPage} pageSize={pageSize} onPageSizeChange={(v) => { setPageSize(v); setPage(0); }} />
        </CardContent>
      </Card>
    </Box>
  );
}
