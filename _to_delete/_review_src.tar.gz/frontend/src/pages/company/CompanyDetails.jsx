import React, { useState } from 'react';
import { Box, Button, Card, CardContent, Stack, Grid } from '@mui/material';
import ApartmentIcon from '@mui/icons-material/Apartment';
import EditIcon from '@mui/icons-material/EditOutlined';
import CloseIcon from '@mui/icons-material/Close';
import { useTranslation } from 'react-i18next';
import AppForm, { FormGrid, FormSubmitButton } from '../../components/form/AppForm';
import FormTextField from '../../components/form/FormTextField';
import FormSelect from '../../components/form/FormSelect';
import Spinner from '../../components/ui/Spinner';
import EntityHeaderCard from '../../components/common/EntityHeaderCard';
import { useNotify } from '../../components/feedback/NotificationProvider';
import { applyServerErrors } from '../../lib/formErrors';
import { companyDetailsSchema } from '../../lib/validation/companySchemas';
import { useGetCompanyDetailsQuery, useUpdateCompanyDetailsMutation } from '../../features/company/companyDetailsApi';
import { countries, getStateOptions, getCityOptions } from '../../lib/constants/locations';
import CompanyInfoField from './components/CompanyInfoField';

export default function CompanyDetails() {
  const { t } = useTranslation();
  const notify = useNotify();
  const { data, isLoading } = useGetCompanyDetailsQuery();
  const [updateDetails, { isLoading: saving }] = useUpdateCompanyDetailsMutation();
  const [editing, setEditing] = useState(false);

  if (isLoading) return <Spinner label={t('common.loading')} />;

  const handleSubmit = async (values, formMethods) => {
    try {
      await updateDetails(values).unwrap();
      notify.success('Company details saved');
      setEditing(false);
    } catch (err) {
      notify.error(applyServerErrors(err, formMethods.setError));
    }
  };

  const viewFields = [
    { name: 'companyName', label: 'Company Name' },
    { name: 'legalName', label: 'Legal Name' },
    { name: 'registrationNumber', label: 'Registration Number' },
    { name: 'pan', label: 'PAN Number' },
    { name: 'gstin', label: 'GST Number' },
    { name: 'email', label: 'Email' },
    { name: 'phone', label: 'Phone Number' },
    { name: 'website', label: 'Website' },
    { name: 'country', label: 'Country' },
    { name: 'state', label: 'State' },
    { name: 'city', label: 'City' },
    { name: 'pincode', label: 'Pincode' },
  ];

  return (
    <Box>
      <EntityHeaderCard
        icon={<ApartmentIcon />}
        title="Company Details"
        subtitle="View and update your company information."
        rightContent={!editing && (
          <Button variant="outlined" startIcon={<EditIcon />} onClick={() => setEditing(true)}>
            Edit
          </Button>
        )}
      />

      <Card variant="outlined">
        <CardContent sx={{ p: 3 }}>
          {!editing ? (
            <Grid container spacing={2.5}>
              {viewFields.map((f) => (
                <Grid item xs={12} sm={6} md={3} key={f.name}>
                  <CompanyInfoField label={f.label} value={data?.[f.name]} />
                </Grid>
              ))}
              <Grid item xs={12}>
                <CompanyInfoField label="Address" value={data?.address} minHeight={48} />
              </Grid>
            </Grid>
          ) : (
            <AppForm schema={companyDetailsSchema} defaultValues={data || { currency: 'INR' }} onSubmit={handleSubmit}>
              {({ watch }) => {
                const selectedCountry = watch('country');
                const selectedState = watch('state');
                return (
                  <>
                    <FormGrid columns={4}>
                      <FormTextField name="companyName" label="Company Name" />
                      <FormTextField name="legalName" label="Legal Name" />
                      <FormTextField name="registrationNumber" label="Registration Number" />
                      <FormTextField name="tinNumber" label="TIN Number" />
                      <FormTextField name="gstin" label="GSTIN" maxLength={15} inputProps={{ style: { textTransform: 'uppercase' } }} />
                      <FormTextField name="pan" label="PAN" maxLength={10} inputProps={{ style: { textTransform: 'uppercase' } }} />
                      <FormTextField name="currency" label="Currency" />
                      <FormTextField name="phone" label="Phone" digitsOnly maxLength={10} />
                      <FormTextField name="email" label="Email" />
                      <FormTextField name="website" label="Website" />
                      <FormSelect name="country" label="Country" options={countries} />
                      <FormSelect name="state" label="State" options={getStateOptions(selectedCountry)} />
                      <FormSelect name="city" label="City" options={getCityOptions(selectedCountry, selectedState)} />
                      <FormTextField name="pincode" label="Pincode" digitsOnly maxLength={6} />
                    </FormGrid>
                    <FormGrid columns={1}>
                      <FormTextField name="address" label="Address" multiline rows={2} />
                    </FormGrid>
                    <Stack direction="row" spacing={1.5} sx={{ mt: 3 }}>
                      <FormSubmitButton disabled={saving}>{t('common.save')}</FormSubmitButton>
                      <Button variant="outlined" color="inherit" startIcon={<CloseIcon />} onClick={() => setEditing(false)} disabled={saving}>
                        Cancel
                      </Button>
                    </Stack>
                  </>
                );
              }}
            </AppForm>
          )}
        </CardContent>
      </Card>
    </Box>
  );
}
