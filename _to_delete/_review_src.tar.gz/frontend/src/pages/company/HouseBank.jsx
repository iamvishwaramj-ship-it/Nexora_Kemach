import React, { useEffect, useMemo, useState } from 'react';
import {
  Box, Typography, Button, Card, CardContent, Stack, Table, TableBody, TableCell, TableHead,
  TableRow, Chip, IconButton, Dialog, DialogTitle, DialogContent, DialogActions,
} from '@mui/material';
import AccountBalanceIcon from '@mui/icons-material/AccountBalance';
import AddIcon from '@mui/icons-material/Add';
import CloseIcon from '@mui/icons-material/Close';
import EditIcon from '@mui/icons-material/EditOutlined';
import DeleteIcon from '@mui/icons-material/DeleteOutline';
import RefreshIcon from '@mui/icons-material/Refresh';
import SearchIcon from '@mui/icons-material/Search';
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import { z } from 'zod';
import AppForm, { FormGrid, FormSubmitButton } from '../../components/form/AppForm';
import { useUnsavedChangesGuard, FormDirtyTracker } from '../../components/form/useUnsavedChangesGuard';
import FormTextField from '../../components/form/FormTextField';
import FormSelect from '../../components/form/FormSelect';
import FormDatePicker from '../../components/form/FormDatePicker';
import EntityHeaderCard from '../../components/common/EntityHeaderCard';import EntityListPagination from '../../components/data-display/EntityListPagination';
import MobileRecordCard from '../../components/data-display/MobileRecordCard';
import { useIsMobileListView } from '../../components/data-display/useIsMobileListView';
import useDragScroll from '../../components/data-display/useDragScroll';
import { useNotify } from '../../components/feedback/NotificationProvider';
import { applyServerErrors } from '../../lib/formErrors';
import { useConfirm } from '../../components/feedback/ConfirmationDialog';
import { requiredString, optionalString, statusEnum, optionalDate } from '../../lib/validation/common';
import { houseBankApi, bankNameApi } from '../../features/resources';
import useTableFeatures from '../../components/data-display/useTableFeatures';
import TableSearchFilter from '../../components/data-display/TableSearchFilter';
import SortableHeaderCell from '../../components/data-display/SortableHeaderCell';
import ScrollableTableContainer from '../../components/data-display/ScrollableTableContainer';

import { CanAdd, CanEdit, CanDelete } from '../../components/common/PermissionGate';
import TableFilterPanel from '../../components/data-display/TableFilterPanel';
// Local schema — the shared houseBankSchema requires accountName, opening
// balance and opening date; this page's design marks those optional (no
// asterisk), so relax them here rather than changing every other consumer
// of houseBankSchema.
const houseBankDetailsSchema = z.object({
  bankName: requiredString('Bank name'),
  accountNumber: requiredString('Account number'),
  accountName: requiredString('Account name'),
  ifscCode: optionalString(),
  bankAddress: optionalString(),
  branchName: optionalString(),
  accountType: requiredString('Account type'),
  currency: requiredString('Currency'),
  openingBalance: z.preprocess(
    (v) => (v === '' || v == null ? undefined : Number(v)),
    z.number().min(0, 'Opening balance cannot be negative').optional()
  ),
  openingDate: optionalDate('Opening date'),
  description: optionalString(),
  status: statusEnum(),
});

const emptyValues = {
  bankName: '', accountNumber: '', accountName: '', ifscCode: '', bankAddress: '', branchName: '',
  accountType: '', currency: 'INR', openingBalance: '', openingDate: null, description: '', status: 'Active',
};

const ACCOUNT_TYPE_OPTIONS = [
  { label: 'Current Account', value: 'Current Account' },
  { label: 'Savings Account', value: 'Savings Account' },
  { label: 'Cash Credit', value: 'Cash Credit' },
  { label: 'Overdraft', value: 'Overdraft' },
];

const CURRENCY_OPTIONS = [
  { label: 'INR', value: 'INR' },
  { label: 'USD', value: 'USD' },
  { label: 'EUR', value: 'EUR' },
  { label: 'GBP', value: 'GBP' },
  { label: 'AED', value: 'AED' },
];

const PAGE_SIZE = 10;

const currency = (v) => (v == null ? '—' : Number(v).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }));
const formatDate = (d) => (d ? new Date(d).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '—');

export default function HouseBank() {
  const notify = useNotify();
  const confirmDialog = useConfirm();
  const isMobile = useIsMobileListView();
  const { data: houseBanks, isLoading, isFetching, refetch } = houseBankApi.useList();
  const { data: bankNames } = bankNameApi.useList();
  const [create, { isLoading: creating }] = houseBankApi.useCreate();
  const [update, { isLoading: updating }] = houseBankApi.useUpdate();
  const [remove] = houseBankApi.useDelete();

  const bankNameOptions = (bankNames || []).map((b) => ({ label: b.bankName, value: b.bankName }));

  // The form lives in a modal — the page itself is the list, and the Add
  // button (or an edit action) opens the dialog over it. Same shape as the
  // Branch Details page / shared MasterCrudPage template.
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingRow, setEditingRow] = useState(null);
  const [readOnly, setReadOnly] = useState(false);
  const [formKey, setFormKey] = useState(0);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(PAGE_SIZE);

  const [search, setSearch] = useState('');
  const allRows = houseBanks || [];
  const baseTableRows = useMemo(() => {
    const q = '';
    if (!q) return allRows;
    return allRows.filter((r) => [r.bankName, r.accountNumber, r.accountName, r.branchName].some((v) => String(v || '').toLowerCase().includes(q)));
  }, [allRows]);

  // Column definitions drive the global search, the sort icons and the filter
  // popover — see components/data-display/useTableFeatures.js.
  const tableColumns = useMemo(() => ([
    { field: 'bankName', headerName: 'Bank Name', filter: 'text' },
    { field: 'accountNumber', headerName: 'Account Number', filter: 'text' },
    { field: 'accountName', headerName: 'Account Name', filter: 'text' },
    { field: 'ifscCode', headerName: 'IFSC Code', filter: 'text' },
    { field: 'accountType', headerName: 'Account Type', filter: 'text' },
    { field: 'currency', headerName: 'Currency', filter: 'text' },
    { field: 'openingBalance', headerName: 'Opening Balance', filter: 'numberRange', sortValue: (row) => (row.openingBalance == null || row.openingBalance === '' ? null : Number(row.openingBalance)) },
    { field: 'openingDate', headerName: 'Opening Date', filter: 'dateRange', sortValue: (row) => (row.openingDate ? new Date(row.openingDate).getTime() : null), searchValue: (row) => formatDate(row.openingDate) },
    { field: 'status', headerName: 'Status', filter: 'select' },
  ]), []);
  const table = useTableFeatures(baseTableRows, tableColumns, { onChange: setPage });
  const rows = table.rows;
  const pagedRows = useMemo(() => rows.slice(page * pageSize, page * pageSize + pageSize), [rows, page, pageSize]);

  useEffect(() => { setPage(0); }, [search]);

  const openCreate = () => {
    setEditingRow(null);
    setReadOnly(false);
    setFormKey((k) => k + 1);
    setDialogOpen(true);
  };

  const closeForm = () => {
    setDialogOpen(false);
    setEditingRow(null);
  };

  // Closing a half-filled form asks before throwing the work away.
  // requestClose is what Cancel / the X / Esc go through; forceClose is the
  // save path, which has nothing to lose. See useUnsavedChangesGuard.jsx.
  const { requestClose, forceClose, setDirty, dialogCloseProps } = useUnsavedChangesGuard(closeForm);

  // Read-only look at a record — same form, every field disabled
  // and the save button removed (see AppForm's readOnly prop).
  const handleView = (row) => {
    setEditingRow(row);
    setReadOnly(true);
    setFormKey((k) => k + 1);
    setDialogOpen(true);
  };

  const handleEdit = (row) => {
    setEditingRow(row);
    setReadOnly(false);
    setFormKey((k) => k + 1);
    setDialogOpen(true);
  };

  const handleDelete = async (row) => {
    const ok = await confirmDialog({
      title: 'Delete house bank',
      message: `Are you sure you want to delete "${row.bankName}"? This cannot be undone.`,
      confirmLabel: 'Delete',
      severity: 'error',
    });
    if (!ok) return;
    try {
      await remove(row.id).unwrap();
      notify.success('House bank deleted');
    } catch (err) {
      notify.error(err?.data?.message || 'Delete failed');
    }
  };

  const handleSubmit = async (values, formMethods) => {
    try {
      if (editingRow) {
        await update({ id: editingRow.id, ...values }).unwrap();
        notify.success('House bank updated');
      } else {
        await create(values).unwrap();
        notify.success('House bank added');
      }
      forceClose();
    } catch (err) {
      notify.error(applyServerErrors(err, formMethods.setError));
    }
  };

  return (
    <Box>
      <EntityHeaderCard
        icon={<AccountBalanceIcon />}
        title="House Bank"
        subtitle="Manage your house bank accounts."
        rightContent={
          <CanAdd>
            <Button variant="contained" startIcon={<AddIcon />} onClick={openCreate}>
              Add House Bank
            </Button>
          </CanAdd>
        }
      />

      <Dialog
        open={dialogOpen}
        {...dialogCloseProps}
        maxWidth="lg"
        fullWidth
        sx={{
          // AppForm wraps its children in a <form>, which lands between the
          // dialog's Paper and DialogContent and breaks the flex chain Paper
          // relies on to make DialogContent scroll. Without this the field
          // grid is clipped on a short viewport instead of scrolling, and the
          // action buttons go with it.
          '& .MuiDialog-paper > form': {
            display: 'flex',
            flexDirection: 'column',
            minHeight: 0,
            overflow: 'hidden',
          },
        }}
      >
        <DialogTitle
          component="div"
          sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 1, pr: 1 }}
        >
          <Typography variant="subtitle1" fontWeight={700}>
            {readOnly ? 'View House Bank' : editingRow ? 'Edit House Bank' : 'New House Bank'}
          </Typography>
          <IconButton
            onClick={requestClose}
            size="small"
            aria-label="close"
            // Red only while viewing — on an Add/Edit dialog this same button sits
            // beside a live Save, where red would read as destructive.
            sx={readOnly ? {
              border: '1px solid',
              borderColor: 'error.main',
              color: 'error.main',
              '&:hover': { borderColor: 'error.dark', color: 'error.dark' },
            } : undefined}
          >
            <CloseIcon fontSize="small" />
          </IconButton>
        </DialogTitle>

        <AppForm readOnly={readOnly}
          key={formKey}
          schema={houseBankDetailsSchema}
          defaultValues={editingRow ? { ...emptyValues, ...editingRow } : emptyValues}
          onSubmit={handleSubmit}
        >
          {() => (
            <>
              {/* Watches for the first real user edit so the close handlers
                  above know whether there is anything to lose. */}
              <FormDirtyTracker onDirtyChange={setDirty} />
              <DialogContent dividers>
                <FormGrid columns={4}>
                  <FormSelect name="bankName" label="Bank Name *" placeholder="Select bank name" options={bankNameOptions} />
                  <FormTextField name="accountNumber" label="Account Number *" placeholder="Enter account number" />
                  <FormTextField name="accountName" label="Account Name *" placeholder="Enter account name" />
                  <FormTextField name="ifscCode" label="IFSC Code" placeholder="Enter IFSC code" />

                  <FormTextField name="bankAddress" label="Bank Address" placeholder="Enter bank address" />
                  <FormTextField name="branchName" label="Branch Name" placeholder="Enter branch name" />
                  <FormSelect name="accountType" label="Account Type *" placeholder="Select account type" options={ACCOUNT_TYPE_OPTIONS} />
                  <FormSelect name="currency" label="Currency *" placeholder="Select currency" options={CURRENCY_OPTIONS} />

                  <FormTextField name="openingBalance" label="Opening Balance" type="number" placeholder="Enter opening balance" />
                  <FormDatePicker name="openingDate" label="Opening Balance Date" />
                  <FormTextField name="description" label="Description" placeholder="Enter description (optional)" />
                  <FormSelect
                    name="status"
                    label="Status *"
                    options={[{ label: 'Active', value: 'Active' }, { label: 'Inactive', value: 'Inactive' }]}
                  />
                </FormGrid>
              </DialogContent>

              <DialogActions sx={{ px: 3, py: 2 }}>
                <FormSubmitButton disabled={creating || updating}>
                  {readOnly ? 'View' : editingRow ? 'Update House Bank' : 'Save House Bank'}
                </FormSubmitButton>
                <Button variant={readOnly ? 'outlined' : 'text'} color={readOnly ? 'error' : 'inherit'} onClick={requestClose} disabled={creating || updating}>
                  {readOnly ? 'Close' : 'Cancel'}
                </Button>
              </DialogActions>
            </>
          )}
        </AppForm>
      </Dialog>

      <Card variant="outlined">
        <CardContent sx={{ p: 0 }}>
          <Stack direction="row" alignItems="center" justifyContent="space-between" sx={{ px: 3, pt: 2.5, pb: 1.5 }}>
            <Typography variant="subtitle1" fontWeight={700}>House Bank List</Typography>
            <Stack direction="row" spacing={1.5} alignItems="center">
              <TableSearchFilter table={table} placeholder="Search house banks..." width={220} />
              <Button variant="outlined" startIcon={<RefreshIcon />} onClick={() => refetch()} disabled={isFetching}>
                Refresh
              </Button>
            </Stack>

            <TableFilterPanel table={table} />
          </Stack>

          {isMobile ? (
            <Box sx={{ px: 2, pb: 1 }}>
              {!isLoading && pagedRows.map((row) => (
                <MobileRecordCard
                  key={row.id}
                  title={row.bankName}
                  statusChip={<Chip size="small" label={row.status} color={row.status === 'Active' ? 'success' : 'default'} variant="outlined" />}
                  fields={[
                    { label: 'Account Number', value: row.accountNumber },
                    { label: 'Account Name', value: row.accountName || '—' },
                    { label: 'IFSC Code', value: row.ifscCode || '—' },
                    { label: 'Account Type', value: row.accountType || '—' },
                    { label: 'Currency', value: row.currency || '—' },
                    { label: 'Opening Balance', value: currency(row.openingBalance) },
                    { label: 'Opening Date', value: formatDate(row.openingDate) },
                  ]}
                  onView={() => handleView(row)}
                  onEdit={() => handleEdit(row)}
                  onDelete={() => handleDelete(row)}
                />
              ))}
              {!isLoading && rows.length === 0 && (
                <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>{table.isFiltering ? 'No house banks match your search' : 'No house banks yet'}</Typography>
              )}
            </Box>
          ) : (
            <ScrollableTableContainer>
              <Table size="small" stickyHeader>
                <TableHead>
                  <TableRow>
                    <TableCell width={48}>#</TableCell>
                    <SortableHeaderCell field="bankName" sort={table.sort} onSort={table.toggleSort}>Bank Name</SortableHeaderCell>
                    <SortableHeaderCell field="accountNumber" sort={table.sort} onSort={table.toggleSort}>Account Number</SortableHeaderCell>
                    <SortableHeaderCell field="accountName" sort={table.sort} onSort={table.toggleSort}>Account Name</SortableHeaderCell>
                    <SortableHeaderCell field="ifscCode" sort={table.sort} onSort={table.toggleSort}>IFSC Code</SortableHeaderCell>
                    <SortableHeaderCell field="accountType" sort={table.sort} onSort={table.toggleSort}>Account Type</SortableHeaderCell>
                    <SortableHeaderCell field="currency" sort={table.sort} onSort={table.toggleSort}>Currency</SortableHeaderCell>
                    <SortableHeaderCell field="openingBalance" sort={table.sort} onSort={table.toggleSort}>Opening Balance</SortableHeaderCell>
                    <SortableHeaderCell field="openingDate" sort={table.sort} onSort={table.toggleSort}>Opening Date</SortableHeaderCell>
                    <SortableHeaderCell field="status" sort={table.sort} onSort={table.toggleSort}>Status</SortableHeaderCell>
                    <TableCell align="right">Action</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {!isLoading && pagedRows.map((row, i) => (
                    <TableRow key={row.id} hover>
                      <TableCell>{page * pageSize + i + 1}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.bankName}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.accountNumber}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.accountName || '—'}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.ifscCode || '—'}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.accountType || '—'}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.currency || '—'}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{currency(row.openingBalance)}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{formatDate(row.openingDate)}</TableCell>
                      <TableCell>
                        <Chip size="small" label={row.status} color={row.status === 'Active' ? 'success' : 'default'} variant="outlined" />
                      </TableCell>
                      <TableCell align="right">
                        <Stack direction="row" spacing={0.5} justifyContent="flex-end">
                          <IconButton size="small" onClick={() => handleView(row)} aria-label="view">
                            <VisibilityOutlinedIcon fontSize="small" />
                          </IconButton>
                          <CanEdit>
                            <IconButton size="small" color="primary" onClick={() => handleEdit(row)} aria-label="edit">
                              <EditIcon fontSize="small" />
                            </IconButton>
                          </CanEdit>
                          <CanDelete>
                            <IconButton size="small" color="error" onClick={() => handleDelete(row)} aria-label="delete">
                              <DeleteIcon fontSize="small" />
                            </IconButton>
                          </CanDelete>
                        </Stack>
                      </TableCell>
                    </TableRow>
                  ))}
                  {!isLoading && rows.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={11}>
                        <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>{table.isFiltering ? 'No house banks match your search' : 'No house banks yet'}</Typography>
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </ScrollableTableContainer>
          )}

          <EntityListPagination total={rows.length} page={page} onChange={setPage} pageSize={pageSize} onPageSizeChange={(v) => { setPageSize(v); setPage(0); }} />
        </CardContent>
      </Card>
    </Box>
  );
}
