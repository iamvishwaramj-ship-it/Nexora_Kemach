import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import {
  Box, Typography, Button, Card, CardContent, Stack, Table, TableBody, TableCell, TableHead,
  TableRow, Chip, IconButton, Menu, MenuItem, ListItemIcon, ListItemText, Grid, Collapse,
  Tabs, Tab, Dialog, DialogTitle, DialogContent, DialogActions,
} from '@mui/material';
import { useFieldArray } from 'react-hook-form';
import ContactMailOutlinedIcon from '@mui/icons-material/ContactMailOutlined';
import AddIcon from '@mui/icons-material/Add';
import CloseIcon from '@mui/icons-material/Close';
import SaveIcon from '@mui/icons-material/SaveOutlined';
import FilterListIcon from '@mui/icons-material/FilterList';
import EditIcon from '@mui/icons-material/EditOutlined';
import DeleteIcon from '@mui/icons-material/DeleteOutline';
import CheckIcon from '@mui/icons-material/Check';
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import AppForm, { FormGrid, FormSubmitButton } from '../../components/form/AppForm';
import FormTextField from '../../components/form/FormTextField';
import FormSelect from '../../components/form/FormSelect';
import { FormCheckbox } from '../../components/form/FormCheckbox';
import EntityHeaderCard from '../../components/common/EntityHeaderCard';
import CompanyBadge from '../../components/common/CompanyBadge';
import EntityListPagination from '../../components/data-display/EntityListPagination';
import MobileRecordCard from '../../components/data-display/MobileRecordCard';
import { useIsMobileListView } from '../../components/data-display/useIsMobileListView';
import { useNotify } from '../../components/feedback/NotificationProvider';
import { applyServerErrors } from '../../lib/formErrors';
import { useConfirm } from '../../components/feedback/ConfirmationDialog';
import {
  businessPartnerSchema, PARTNER_TYPE_OPTIONS, PARTNER_GROUP_OPTIONS, BP_CURRENCY_OPTIONS,
  PARTNER_CODE_MODE_OPTIONS, SHIPPING_TYPE_OPTIONS, INDUSTRY_OPTIONS, BUSINESS_PARTNER_TYPE_OPTIONS,
  EMAIL_GROUP_OPTIONS, GENDER_OPTIONS, PAYMENT_METHOD_OPTIONS, PAYMENT_PRIORITY_OPTIONS, PAYMENT_TERMS_OPTIONS,
  GST_TYPE_OPTIONS,
} from '../../lib/validation/partnerSchemas';
import {
  businessPartnerApi, salesEmployeeApi, chartOfAccountApi, houseBankApi, usePeekBusinessPartnerCodeMutation,
} from '../../features/resources';
import { countries, getStateOptions, getCityOptions } from '../../lib/constants/locations';
import useTableFeatures from '../../components/data-display/useTableFeatures';
import TableSearchFilter from '../../components/data-display/TableSearchFilter';
import SortableHeaderCell from '../../components/data-display/SortableHeaderCell';
import ScrollableTableContainer from '../../components/data-display/ScrollableTableContainer';

import { CanAdd, CanEdit, CanDelete } from '../../components/common/PermissionGate';
import TableFilterPanel from '../../components/data-display/TableFilterPanel';

// Label-left field layout, copied from pages/product/ProductMaster.jsx's own
// LabeledField (per "refer the product master add page for the label and
// input field... apply the alignment as same as in the product master add
// page" — kept page-local exactly as ProductMaster's own copy is, rather than
// factored into a shared component, since it's a one-page layout choice, not
// a house style change for the whole app).
const FIELD_LABEL_WIDTH = 190;
const FIELD_LABEL_GAP = 3.5;
const FIELD_ROW_SPACING = 0;
const FIELD_MAX_WIDTH = 500;
const FIELD_LABEL_OFFSET = 0;
const FIELD_INPUT_SX = {
  '& .MuiInputBase-input': { paddingTop: '5px', paddingBottom: '5px', fontSize: '0.8125rem' },
  '& .MuiInputBase-root': { minHeight: 34 },
  '& .MuiFormHelperText-root': { margin: 0, minHeight: '0.9em', lineHeight: 1.2, fontSize: '0.6875rem' },
};

function FieldLabel({ children }) {
  const text = String(children || '');
  const required = text.trim().endsWith('*');
  const base = required ? text.trim().replace(/\*$/, '').trimEnd() : text;
  return (
    <Typography
      variant="body2"
      sx={{
        width: { xs: '100%', sm: FIELD_LABEL_WIDTH },
        flexShrink: 0,
        fontWeight: 600,
        color: 'text.primary',
        pt: FIELD_LABEL_OFFSET,
      }}
    >
      {base}
      {required && <Typography component="span" color="error.main">&nbsp;*</Typography>}
    </Typography>
  );
}

function LabeledField({ label, children, align = 'flex-start' }) {
  return (
    <Box sx={{ display: 'flex', flexDirection: { xs: 'column', sm: 'row' }, alignItems: { xs: 'stretch', sm: align }, gap: { xs: 0.5, sm: FIELD_LABEL_GAP } }}>
      <FieldLabel>{label}</FieldLabel>
      <Box
        sx={{
          flex: 1, minWidth: 0, maxWidth: { sm: FIELD_MAX_WIDTH }, ...FIELD_INPUT_SX,
          ...(align === 'center' ? { display: 'flex', alignItems: 'center', minHeight: 34 } : null),
        }}
      >
        {children}
      </Box>
    </Box>
  );
}

const emptyValues = {
  codeMode: 'auto-customer',
  partnerCode: '', partnerName: '', foreignName: '', groupName: '', currency: 'All',
  accountBalance: 0, partnerType: '', status: 'Active',
  telephone: '', mobile: '', email: '', website: '',
  shippingType: '', industry: '', businessPartnerType: '', contactPerson: '', salesPerson: '',
  remarks: '',
  contacts: [], billingAddresses: [], shippingAddresses: [],
  paymentTerms: '', creditDays: 0, creditLimit: 0,
  paymentMethod: '', paymentPriority: '', blockPayment: false, houseBank: '', bankAccountNo: '',
  controlAccount: '',
};

const PAGE_SIZE = 10;
const STATUS_FILTERS = ['All', 'Active', 'Inactive'];
const TAB_LABELS = ['General', 'Contact Person', 'Addresses', 'Payment Terms', 'Payment Run', 'Accounting', 'Remarks', 'Attachments'];

const emptyContactValues = {
  contactId: '', title: '', firstName: '', lastName: '', position: '', address: '',
  telephone: '', mobile: '', email: '', emailGroup: '', password: '',
  birthCountry: '', birthCity: '', dateOfBirth: '', gender: '', profession: '', remarks: '',
  isDefault: false,
};

// Add/Edit Contact Person — a small standalone dialog (plain useState, not a
// nested RHF form) whose Save hands a plain object back to the caller, which
// appends/updates it into the parent form's `contacts` field array. Mirrors
// the content of the "Add Contact Person" reference mockup.
function ContactPersonDialog({ open, initialValue, onClose, onSave }) {
  const [values, setValues] = useState(emptyContactValues);
  useEffect(() => {
    if (open) setValues({ ...emptyContactValues, ...(initialValue || {}) });
  }, [open, initialValue]);

  const set = (field) => (e) => setValues((v) => ({ ...v, [field]: e.target.value }));
  const canSave = String(values.firstName || '').trim().length > 0;

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle component="div" sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 1, pr: 1 }}>
        <Typography variant="subtitle1" fontWeight={700}>
          {initialValue ? 'Edit Contact Person' : 'Add Contact Person'}
        </Typography>
        <IconButton onClick={onClose} size="small" aria-label="close"><CloseIcon fontSize="small" /></IconButton>
      </DialogTitle>
      <DialogContent dividers>
        <Grid container spacing={2} sx={{ mt: 0.25 }}>
          {[
            { name: 'contactId', label: 'Contact ID' },
            { name: 'title', label: 'Title' },
            { name: 'firstName', label: 'First Name *' },
            { name: 'lastName', label: 'Last Name' },
            { name: 'position', label: 'Position' },
            { name: 'address', label: 'Address' },
            { name: 'telephone', label: 'Telephone' },
            { name: 'mobile', label: 'Mobile' },
            { name: 'email', label: 'Email' },
          ].map((f) => (
            <Grid item xs={12} sm={6} key={f.name}>
              <FormTextFieldStandalone label={f.label} value={values[f.name]} onChange={set(f.name)} placeholder={f.label.replace(' *', '')} />
            </Grid>
          ))}
          <Grid item xs={12} sm={6}>
            <SelectStandalone label="Email Group" value={values.emailGroup} onChange={set('emailGroup')} options={EMAIL_GROUP_OPTIONS} />
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormTextFieldStandalone label="Password" value={values.password} onChange={set('password')} type="password" placeholder="Password" />
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormTextFieldStandalone label="Birth Country" value={values.birthCountry} onChange={set('birthCountry')} placeholder="Birth Country" />
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormTextFieldStandalone label="Birth City" value={values.birthCity} onChange={set('birthCity')} placeholder="Birth City" />
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormTextFieldStandalone label="Date of Birth" value={values.dateOfBirth} onChange={set('dateOfBirth')} type="date" />
          </Grid>
          <Grid item xs={12} sm={6}>
            <SelectStandalone label="Gender" value={values.gender} onChange={set('gender')} options={GENDER_OPTIONS} />
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormTextFieldStandalone label="Profession" value={values.profession} onChange={set('profession')} placeholder="Profession" />
          </Grid>
          <Grid item xs={12}>
            <FormTextFieldStandalone label="Remarks" value={values.remarks} onChange={set('remarks')} placeholder="Remarks" multiline rows={2} />
          </Grid>
        </Grid>
      </DialogContent>
      <DialogActions sx={{ px: 3, py: 2 }}>
        <Button variant="outlined" color="inherit" onClick={onClose}>Cancel</Button>
        <Button variant="contained" startIcon={<SaveIcon />} disabled={!canSave} onClick={() => onSave(values)}>Save</Button>
      </DialogActions>
    </Dialog>
  );
}

const emptyAddressValues = {
  addressName: '', street: '', streetNo: '', buildingFloorRoom: '', block: '',
  country: 'India', state: '', city: '', zipCode: '', taxOffice: '', gstType: '', gstNumber: '',
  isDefault: false,
};

// Basic client-side GSTIN shape check for the Save-button guard below —
// mirrors the gstin() regex in lib/validation/common.js. The real
// validation (and the error message shown after Save) still runs through
// the zod schema on submit; this is only so an obviously-malformed GST
// number can't even be handed off to it.
const GSTIN_PATTERN = /^\d{2}[A-Z]{5}\d{4}[A-Z]\d[A-Z][A-Z0-9]$/;

// Add/Edit Address — used for both the Billing Address and Shipping Address
// sections of the Addresses tab; `title` distinguishes which is open. Field
// set/order (Address Name, Street, Street No, Building/Floor/Room, Block,
// Country, State, City, Zip Code, Tax Office, GST Type, GST Number) and the
// Country -> State -> City cascade mirror Branch's own address block.
function AddressDialog({ open, title, initialValue, onClose, onSave }) {
  const [values, setValues] = useState(emptyAddressValues);
  useEffect(() => {
    if (open) setValues({ ...emptyAddressValues, ...(initialValue || {}) });
  }, [open, initialValue]);

  const set = (field) => (e) => setValues((v) => ({ ...v, [field]: e.target.value }));
  const setCountry = (e) => setValues((v) => ({ ...v, country: e.target.value, state: '', city: '' }));
  const setState = (e) => setValues((v) => ({ ...v, state: e.target.value, city: '' }));

  const gstValue = String(values.gstNumber || '').trim().toUpperCase();
  const canSave = String(values.addressName || '').trim().length > 0
    && (!gstValue || GSTIN_PATTERN.test(gstValue));

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle component="div" sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 1, pr: 1 }}>
        <Typography variant="subtitle1" fontWeight={700}>{title}</Typography>
        <IconButton onClick={onClose} size="small" aria-label="close"><CloseIcon fontSize="small" /></IconButton>
      </DialogTitle>
      <DialogContent dividers>
        <Grid container spacing={2} sx={{ mt: 0.25 }}>
          <Grid item xs={12} sm={6}>
            <FormTextFieldStandalone label="Address Name *" value={values.addressName} onChange={set('addressName')} placeholder="Enter address name" />
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormTextFieldStandalone label="Street" value={values.street} onChange={set('street')} placeholder="Enter street" />
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormTextFieldStandalone label="Street No" value={values.streetNo} onChange={set('streetNo')} placeholder="Enter street number" />
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormTextFieldStandalone label="Building/Floor/Room" value={values.buildingFloorRoom} onChange={set('buildingFloorRoom')} placeholder="Enter building, floor or room" />
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormTextFieldStandalone label="Block" value={values.block} onChange={set('block')} placeholder="Enter block" />
          </Grid>
          <Grid item xs={12} sm={6}>
            <SelectStandalone label="Country" value={values.country} onChange={setCountry} options={countries} />
          </Grid>
          <Grid item xs={12} sm={6}>
            <SelectStandalone label="State" value={values.state} onChange={setState} options={getStateOptions(values.country)} />
          </Grid>
          <Grid item xs={12} sm={6}>
            <SelectStandalone label="City" value={values.city} onChange={set('city')} options={getCityOptions(values.country, values.state)} />
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormTextFieldStandalone label="Zip Code" value={values.zipCode} onChange={set('zipCode')} placeholder="Enter zip code" />
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormTextFieldStandalone label="Tax Office" value={values.taxOffice} onChange={set('taxOffice')} placeholder="Enter tax office" />
          </Grid>
          <Grid item xs={12} sm={6}>
            <SelectStandalone label="GST Type" value={values.gstType} onChange={set('gstType')} options={GST_TYPE_OPTIONS} />
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormTextFieldStandalone
              label="GST Number"
              value={values.gstNumber}
              onChange={(e) => setValues((v) => ({ ...v, gstNumber: e.target.value.toUpperCase() }))}
              placeholder="e.g. 22AAAAA0000A1Z5"
            />
            {gstValue && !GSTIN_PATTERN.test(gstValue) && (
              <Typography variant="caption" color="error.main" sx={{ display: 'block', mt: 0.5 }}>
                Enter a valid 15-character GST number
              </Typography>
            )}
          </Grid>
          <Grid item xs={12}>
            <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 14 }}>
              <input
                type="checkbox"
                checked={!!values.isDefault}
                onChange={(e) => setValues((v) => ({ ...v, isDefault: e.target.checked }))}
              />
              Set as default
            </label>
          </Grid>
        </Grid>
      </DialogContent>
      <DialogActions sx={{ px: 3, py: 2 }}>
        <Button variant="outlined" color="inherit" onClick={onClose}>Cancel</Button>
        <Button variant="contained" startIcon={<SaveIcon />} disabled={!canSave} onClick={() => onSave(values)}>Save</Button>
      </DialogActions>
    </Dialog>
  );
}

// Plain (non-RHF) text field for the two dialogs above — they manage their
// own local state rather than a nested react-hook-form instance, so they use
// bare MUI-styled inputs instead of the RHF-bound FormTextField.
function FormTextFieldStandalone({ label, value, onChange, placeholder, multiline, rows, type }) {
  return (
    <Box>
      <Typography variant="caption" fontWeight={600} sx={{ display: 'block', mb: 0.5 }}>{label}</Typography>
      <input
        type={type || 'text'}
        value={value ?? ''}
        onChange={onChange}
        placeholder={placeholder}
        rows={multiline ? (rows || 3) : undefined}
        {...(multiline ? { as: 'textarea' } : {})}
        style={{
          width: '100%', boxSizing: 'border-box', padding: '10.5px 14px', fontSize: 14,
          border: '1px solid rgba(0,0,0,0.23)', borderRadius: 8, fontFamily: 'inherit',
          resize: multiline ? 'vertical' : undefined,
        }}
      />
    </Box>
  );
}

function SelectStandalone({ label, value, onChange, options = [] }) {
  return (
    <Box>
      <Typography variant="caption" fontWeight={600} sx={{ display: 'block', mb: 0.5 }}>{label}</Typography>
      <select
        value={value || ''}
        onChange={onChange}
        style={{
          width: '100%', boxSizing: 'border-box', padding: '10.5px 14px', fontSize: 14,
          border: '1px solid rgba(0,0,0,0.23)', borderRadius: 8, fontFamily: 'inherit', background: 'transparent',
        }}
      >
        <option value="">Select</option>
        {options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
    </Box>
  );
}

// Contact Person / Address child grids — a small table plus Add/Edit/Delete,
// backed by useFieldArray on the surrounding AppForm so the rows travel with
// the rest of the record on submit. Shared between the Contact Person tab and
// each of the two Addresses sections.
function ChildRowsTable({ rows, columns, onAdd, onEdit, onRemove, addLabel, emptyLabel, readOnly }) {
  return (
    <Box>
      <Stack direction="row" alignItems="center" justifyContent="space-between" sx={{ mb: 1.5 }}>
        <Typography variant="subtitle2" fontWeight={700}>{addLabel.replace('Add ', '')}s</Typography>
        {!readOnly && (
          <Button variant="contained" size="small" startIcon={<AddIcon />} onClick={onAdd}>{addLabel}</Button>
        )}
      </Stack>
      <ScrollableTableContainer>
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell width={48}>#</TableCell>
              {columns.map((c) => <TableCell key={c.field}>{c.headerName}</TableCell>)}
              <TableCell width={70}>Default</TableCell>
              {!readOnly && <TableCell align="right" width={90}>Action</TableCell>}
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.length === 0 && (
              <TableRow>
                <TableCell colSpan={columns.length + (readOnly ? 2 : 3)}>
                  <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 2 }}>{emptyLabel}</Typography>
                </TableCell>
              </TableRow>
            )}
            {rows.map((row, i) => (
              <TableRow key={row.id || i} hover>
                <TableCell>{i + 1}</TableCell>
                {columns.map((c) => <TableCell key={c.field}>{row[c.field] || '—'}</TableCell>)}
                <TableCell>{row.isDefault ? <Chip size="small" label="Default" color="primary" variant="outlined" /> : '—'}</TableCell>
                {!readOnly && (
                  <TableCell align="right">
                    <Stack direction="row" spacing={0.5} justifyContent="flex-end">
                      <IconButton size="small" color="primary" onClick={() => onEdit(i)} aria-label="edit"><EditIcon fontSize="small" /></IconButton>
                      <IconButton size="small" color="error" onClick={() => onRemove(i)} aria-label="delete"><DeleteIcon fontSize="small" /></IconButton>
                    </Stack>
                  </TableCell>
                )}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </ScrollableTableContainer>
    </Box>
  );
}

export default function BusinessPartner() {
  const location = useLocation();
  const navigate = useNavigate();
  const notify = useNotify();
  const confirmDialog = useConfirm();
  const isMobile = useIsMobileListView();
  const { data: partners, isLoading } = businessPartnerApi.useList();
  const { data: salesEmployees } = salesEmployeeApi.useList();
  const { data: accounts } = chartOfAccountApi.useList();
  const { data: houseBanks } = houseBankApi.useList();
  const [create, { isLoading: creating }] = businessPartnerApi.useCreate();
  const [update, { isLoading: updating }] = businessPartnerApi.useUpdate();
  const [remove] = businessPartnerApi.useDelete();
  const [peekCode] = usePeekBusinessPartnerCodeMutation();

  const salesPersonOptions = (salesEmployees || []).map((e) => ({ label: e.employeeName, value: e.employeeName }));
  const houseBankOptions = (houseBanks || []).map((b) => ({ label: `${b.bankName} — ${b.accountName || ''}`.trim(), value: b.bankName }));
  // Accounting — Control Account. Only accounts flagged "Control Account"
  // (isControlAccount) in Chart of Accounts show up here, same as Customer/
  // Supplier's own Accounts Receivable picker — plus only real posting
  // accounts (not Title rows) that are Active.
  const accountOptions = (accounts || [])
    .filter((a) => a.accountNature === 'A' && a.status === 'A' && a.isControlAccount)
    .map((a) => ({ label: `${a.accountCode} — ${a.accountName}`, value: a.accountCode }));
  const accountByCode = useMemo(() => new Map((accounts || []).map((a) => [a.accountCode, a])), [accounts]);

  const [showForm, setShowForm] = useState(false);
  const [editingRow, setEditingRow] = useState(null);
  const [readOnly, setReadOnly] = useState(false);
  const [formKey, setFormKey] = useState(0);
  const [tab, setTab] = useState(0);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [filterAnchor, setFilterAnchor] = useState(null);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(PAGE_SIZE);

  const rows = partners || [];

  const baseTableRows = useMemo(() => {
    const q = '';
    return rows.filter((r) => {
      const matchesSearch = !q || [r.partnerCode, r.partnerName, r.email, r.mobile].some((v) => String(v || '').toLowerCase().includes(q));
      const matchesStatus = statusFilter === 'All' || r.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [rows, statusFilter]);

  const tableColumns = useMemo(() => ([
    { field: 'partnerCode', headerName: 'Code', filter: 'text' },
    { field: 'partnerName', headerName: 'Name', filter: 'text' },
    { field: 'partnerType', headerName: 'Partner Type', filter: 'select' },
    { field: 'groupName', headerName: 'Group', filter: 'select' },
    { field: 'mobile', headerName: 'Mobile', filter: 'text' },
    { field: 'status', headerName: 'Status', filter: 'select' },
  ]), []);
  const table = useTableFeatures(baseTableRows, tableColumns, { onChange: setPage });
  const filteredRows = table.rows;

  const pagedRows = useMemo(
    () => filteredRows.slice(page * pageSize, page * pageSize + pageSize),
    [filteredRows, page, pageSize]
  );

  const openCreate = () => {
    setEditingRow(null);
    setReadOnly(false);
    setTab(0);
    setFormKey((k) => k + 1);
    setShowForm(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const closeForm = () => {
    setShowForm(false);
    setEditingRow(null);
  };

  useEffect(() => {
    if (location.state?.openAdd) {
      openCreate();
      navigate(location.pathname, { replace: true, state: null });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.state]);

  const handleView = (row) => {
    setEditingRow(row);
    setReadOnly(true);
    setTab(0);
    setFormKey((k) => k + 1);
    setShowForm(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleEdit = (row) => {
    setEditingRow(row);
    setReadOnly(false);
    setTab(0);
    setFormKey((k) => k + 1);
    setShowForm(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = async (row) => {
    const ok = await confirmDialog({
      title: 'Delete business partner',
      message: `Are you sure you want to delete "${row.partnerName}"? This cannot be undone.`,
      confirmLabel: 'Delete',
      severity: 'error',
    });
    if (!ok) return;
    try {
      await remove(row.id).unwrap();
      notify.success('Business partner deleted');
    } catch (err) {
      notify.error(err?.data?.message || 'Delete failed');
    }
  };

  const handleSubmit = async (values, formMethods) => {
    try {
      if (editingRow) {
        await update({ id: editingRow.id, ...values }).unwrap();
        notify.success('Business partner updated');
      } else {
        await create(values).unwrap();
        notify.success('Business partner added');
      }
      closeForm();
    } catch (err) {
      notify.error(applyServerErrors(err, formMethods.setError));
    }
  };

  // Splits the row's flat `addresses` (addressType: 'Billing' | 'Shipping')
  // into the two arrays the form works with.
  const rowToFormValues = (row) => ({
    ...emptyValues,
    ...row,
    contacts: row.contacts || [],
    billingAddresses: (row.addresses || []).filter((a) => a.addressType === 'Billing'),
    shippingAddresses: (row.addresses || []).filter((a) => a.addressType === 'Shipping'),
  });

  return (
    <Box>
      <EntityHeaderCard
        icon={<ContactMailOutlinedIcon />}
        title="Business Partner"
        subtitle={showForm ? 'Create a new business partner.' : 'Manage customers, suppliers and leads in one place.'}
        rightContent={<CompanyBadge />}
      />

      <Collapse in={showForm} unmountOnExit>
        <Box sx={{ mb: 2 }}>
          <AppForm readOnly={readOnly}
            key={formKey}
            schema={businessPartnerSchema}
            defaultValues={editingRow ? rowToFormValues(editingRow) : emptyValues}
            onSubmit={handleSubmit}
          >
            {(methods) => {
              const contactsArray = useFieldArray({ control: methods.control, name: 'contacts' });
              const billingArray = useFieldArray({ control: methods.control, name: 'billingAddresses' });
              const shippingArray = useFieldArray({ control: methods.control, name: 'shippingAddresses' });

              const [contactDialog, setContactDialog] = useState(null); // { index } | { index: null } | null
              const [billingDialog, setBillingDialog] = useState(null);
              const [shippingDialog, setShippingDialog] = useState(null);

              // Picking a Control Account auto-fills Account Balance from
              // that account's own opening balance — same pattern
              // CustomerMaster uses for Accounts Receivable.
              const controlAccountValue = methods.watch('controlAccount');
              const prevControlAccount = useRef(editingRow ? editingRow.controlAccount : null);
              useEffect(() => {
                if (controlAccountValue !== prevControlAccount.current) {
                  const account = accountByCode.get(controlAccountValue);
                  if (account) {
                    methods.setValue('accountBalance', account.openingBalance != null ? Number(account.openingBalance) : 0, { shouldValidate: true });
                  }
                  prevControlAccount.current = controlAccountValue;
                }
                // eslint-disable-next-line react-hooks/exhaustive-deps
              }, [controlAccountValue]);

              // Code * — three modes (per the reference screenshots): Manual
              // (typed freely), Auto - Customer (C00001, C00002, ...) and
              // Auto - Supplier (S00001, S00002, ...). Switching modes on the
              // Add form clears the code and, for the two Auto modes, peeks
              // the next code for that prefix from the backend. Only runs on
              // create — an existing record's code is fixed and shown locked.
              const codeModeValue = methods.watch('codeMode');
              const prevCodeMode = useRef(null);
              useEffect(() => {
                if (editingRow) return;
                if (codeModeValue === prevCodeMode.current) return;
                prevCodeMode.current = codeModeValue;
                if (codeModeValue === 'auto-customer' || codeModeValue === 'auto-supplier') {
                  const prefix = codeModeValue === 'auto-customer' ? 'C' : 'S';
                  methods.setValue('partnerCode', '', { shouldValidate: true });
                  peekCode({ prefix }).unwrap()
                    .then((res) => methods.setValue('partnerCode', res?.code || '', { shouldValidate: true }))
                    .catch(() => notify.error('Could not generate code'));
                } else if (codeModeValue === 'manual') {
                  methods.setValue('partnerCode', '', { shouldValidate: true });
                }
                // eslint-disable-next-line react-hooks/exhaustive-deps
              }, [codeModeValue]);

              // Customer/Vendor (next to Code) drives the Accounting tab's
              // Control Account label — Accounts Receivable for a Customer,
              // Accounts Payable for a Vendor — same account field either way.
              const partnerTypeValue = methods.watch('partnerType');
              const controlAccountLabel = partnerTypeValue === 'Customer'
                ? 'Accounts Receivable'
                : partnerTypeValue === 'Vendor'
                  ? 'Accounts Payable'
                  : 'Control Account';

              return (
              <>
                <Card variant="outlined" sx={{ mb: 2 }}>
                  <CardContent sx={{ p: 3 }}>
                    <Stack direction="row" alignItems="center" justifyContent="space-between" flexWrap="wrap" gap={1.5} sx={{ mb: 2 }}>
                      <Typography variant="subtitle1" fontWeight={700}>
                        {readOnly ? 'View Business Partner' : editingRow ? 'Edit Business Partner' : 'Add Business Partner'}
                      </Typography>
                      <Button variant="outlined" color="inherit" startIcon={<CloseIcon />} onClick={closeForm}>
                        Close
                      </Button>
                    </Stack>

                    <FormGrid columns={2} singleColumnOnMobile spacing={FIELD_ROW_SPACING}>
                      <LabeledField label="Code *">
                        {editingRow ? (
                          <FormTextField name="partnerCode" label="" placeholder="Code" disabled />
                        ) : (
                          <Stack direction="row" spacing={1}>
                            <Box sx={{ width: 176, flexShrink: 0 }}>
                              <FormSelect name="codeMode" label="" options={PARTNER_CODE_MODE_OPTIONS} />
                            </Box>
                            <Box sx={{ flex: 1, minWidth: 0 }}>
                              <FormTextField
                                name="partnerCode"
                                label=""
                                placeholder="Code"
                                disabled={codeModeValue !== 'manual'}
                              />
                            </Box>
                          </Stack>
                        )}
                      </LabeledField>
                      <LabeledField label="Name *">
                        <FormTextField name="partnerName" label="" placeholder="Enter name" />
                      </LabeledField>

                      <LabeledField label="Type *">
                        <FormSelect name="partnerType" label="" placeholder="Select type" options={PARTNER_TYPE_OPTIONS} />
                      </LabeledField>
                      <LabeledField label="Foreign Name">
                        <FormTextField name="foreignName" label="" placeholder="Enter foreign name" />
                      </LabeledField>

                      <LabeledField label="Group *">
                        <FormSelect name="groupName" label="" placeholder="Select group" options={PARTNER_GROUP_OPTIONS} />
                      </LabeledField>
                      <LabeledField label="Currency *">
                        <FormSelect name="currency" label="" placeholder="Select currency" options={BP_CURRENCY_OPTIONS} />
                      </LabeledField>

                      <LabeledField label="Account Balance (₹)">
                        <FormTextField name="accountBalance" label="" type="number" placeholder="0.00" />
                      </LabeledField>
                    </FormGrid>

                    <Tabs
                      value={tab}
                      onChange={(_e, v) => setTab(v)}
                      variant="scrollable"
                      scrollButtons="auto"
                      sx={{ mt: 2, borderBottom: 1, borderColor: 'divider' }}
                    >
                      {TAB_LABELS.map((label) => <Tab key={label} label={label} />)}
                    </Tabs>

                    <Box sx={{ pt: 3 }}>
                      {tab === 0 && (
                        <FormGrid columns={2} singleColumnOnMobile spacing={FIELD_ROW_SPACING}>
                          <LabeledField label="Telephone">
                            <FormTextField name="telephone" label="" placeholder="Enter telephone" />
                          </LabeledField>
                          <LabeledField label="Mobile">
                            <FormTextField name="mobile" label="" placeholder="Enter mobile" digitsOnly maxLength={10} />
                          </LabeledField>

                          <LabeledField label="Email">
                            <FormTextField name="email" label="" placeholder="Enter email" />
                          </LabeledField>

                          <LabeledField label="Website">
                            <FormTextField name="website" label="" placeholder="Enter website" />
                          </LabeledField>
                          <LabeledField label="Shipping type">
                            <FormSelect name="shippingType" label="" placeholder="Select shipping type" options={SHIPPING_TYPE_OPTIONS} />
                          </LabeledField>

                          <LabeledField label="Industry">
                            <FormSelect name="industry" label="" placeholder="Select industry" options={INDUSTRY_OPTIONS} />
                          </LabeledField>
                          <LabeledField label="Business Partner Type">
                            <FormSelect name="businessPartnerType" label="" placeholder="Select type" options={BUSINESS_PARTNER_TYPE_OPTIONS} />
                          </LabeledField>

                          <LabeledField label="Contact Person">
                            <FormTextField name="contactPerson" label="" placeholder="Enter contact person" />
                          </LabeledField>
                          <LabeledField label="Sales Employee">
                            <FormSelect name="salesPerson" label="" placeholder="Select sales employee" options={salesPersonOptions} />
                          </LabeledField>

                          <LabeledField label="Status *">
                            <FormSelect
                              name="status"
                              label=""
                              options={[{ label: 'Active', value: 'Active' }, { label: 'Inactive', value: 'Inactive' }]}
                            />
                          </LabeledField>
                        </FormGrid>
                      )}
                      {tab === 0 && (
                        <Grid container spacing={2} sx={{ mt: 0.5 }}>
                          <Grid item xs={12}>
                            <LabeledField label="Remarks">
                              <FormTextField name="remarks" label="" placeholder="Enter remarks" multiline rows={2} />
                            </LabeledField>
                          </Grid>
                        </Grid>
                      )}

                      {tab === 1 && (
                        <>
                          <ChildRowsTable
                            rows={contactsArray.fields}
                            columns={[
                              { field: 'contactId', headerName: 'Contact Id' },
                              { field: 'firstName', headerName: 'First Name' },
                              { field: 'lastName', headerName: 'Last Name' },
                              { field: 'email', headerName: 'Email' },
                            ]}
                            addLabel="Add Contact Person"
                            emptyLabel="No contact persons added"
                            readOnly={readOnly}
                            onAdd={() => setContactDialog({ index: null })}
                            onEdit={(i) => setContactDialog({ index: i })}
                            onRemove={(i) => contactsArray.remove(i)}
                          />
                          <ContactPersonDialog
                            open={!!contactDialog}
                            initialValue={contactDialog && contactDialog.index != null ? contactsArray.fields[contactDialog.index] : null}
                            onClose={() => setContactDialog(null)}
                            onSave={(values) => {
                              if (contactDialog.index != null) contactsArray.update(contactDialog.index, values);
                              else contactsArray.append(values);
                              setContactDialog(null);
                            }}
                          />
                        </>
                      )}

                      {tab === 2 && (
                        <Stack spacing={4}>
                          <Box>
                            <ChildRowsTable
                              rows={billingArray.fields}
                              columns={[
                                { field: 'addressName', headerName: 'Address Name' },
                                { field: 'city', headerName: 'City' },
                                { field: 'gstNumber', headerName: 'GST Number' },
                              ]}
                              addLabel="Add Billing Address"
                              emptyLabel="No billing addresses added"
                              readOnly={readOnly}
                              onAdd={() => setBillingDialog({ index: null })}
                              onEdit={(i) => setBillingDialog({ index: i })}
                              onRemove={(i) => billingArray.remove(i)}
                            />
                            <AddressDialog
                              open={!!billingDialog}
                              title={billingDialog && billingDialog.index != null ? 'Edit Billing Address' : 'Add Billing Address'}
                              initialValue={billingDialog && billingDialog.index != null ? billingArray.fields[billingDialog.index] : null}
                              onClose={() => setBillingDialog(null)}
                              onSave={(values) => {
                                if (billingDialog.index != null) billingArray.update(billingDialog.index, values);
                                else billingArray.append(values);
                                setBillingDialog(null);
                              }}
                            />
                          </Box>
                          <Box>
                            <ChildRowsTable
                              rows={shippingArray.fields}
                              columns={[
                                { field: 'addressName', headerName: 'Address Name' },
                                { field: 'city', headerName: 'City' },
                                { field: 'gstNumber', headerName: 'GST Number' },
                              ]}
                              addLabel="Add Shipping Address"
                              emptyLabel="No shipping addresses added"
                              readOnly={readOnly}
                              onAdd={() => setShippingDialog({ index: null })}
                              onEdit={(i) => setShippingDialog({ index: i })}
                              onRemove={(i) => shippingArray.remove(i)}
                            />
                            <AddressDialog
                              open={!!shippingDialog}
                              title={shippingDialog && shippingDialog.index != null ? 'Edit Shipping Address' : 'Add Shipping Address'}
                              initialValue={shippingDialog && shippingDialog.index != null ? shippingArray.fields[shippingDialog.index] : null}
                              onClose={() => setShippingDialog(null)}
                              onSave={(values) => {
                                if (shippingDialog.index != null) shippingArray.update(shippingDialog.index, values);
                                else shippingArray.append(values);
                                setShippingDialog(null);
                              }}
                            />
                          </Box>
                        </Stack>
                      )}

                      {tab === 3 && (
                        <FormGrid columns={2} singleColumnOnMobile spacing={FIELD_ROW_SPACING}>
                          <LabeledField label="Payment Terms">
                            <FormSelect name="paymentTerms" label="" placeholder="Select payment terms" options={PAYMENT_TERMS_OPTIONS} />
                          </LabeledField>
                          <LabeledField label="Credit Days">
                            <FormTextField name="creditDays" label="" type="number" placeholder="0" />
                          </LabeledField>

                          <LabeledField label="Credit Limit (₹)">
                            <FormTextField name="creditLimit" label="" type="number" placeholder="0.00" />
                          </LabeledField>
                        </FormGrid>
                      )}

                      {tab === 4 && (
                        <FormGrid columns={2} singleColumnOnMobile spacing={FIELD_ROW_SPACING}>
                          <LabeledField label="Payment Method">
                            <FormSelect name="paymentMethod" label="" placeholder="Select payment method" options={PAYMENT_METHOD_OPTIONS} />
                          </LabeledField>
                          <LabeledField label="Priority">
                            <FormSelect name="paymentPriority" label="" placeholder="Select priority" options={PAYMENT_PRIORITY_OPTIONS} />
                          </LabeledField>

                          <LabeledField label="House Bank">
                            <FormSelect name="houseBank" label="" placeholder="Select house bank" options={houseBankOptions} />
                          </LabeledField>
                          <LabeledField label="Bank Account No">
                            <FormTextField name="bankAccountNo" label="" placeholder="Enter account number" />
                          </LabeledField>

                          <LabeledField label="Block Payment" align="center">
                            <FormCheckbox name="blockPayment" label="" />
                          </LabeledField>
                        </FormGrid>
                      )}

                      {tab === 5 && (
                        <FormGrid columns={2} singleColumnOnMobile spacing={FIELD_ROW_SPACING}>
                          <LabeledField label={controlAccountLabel}>
                            <FormSelect name="controlAccount" label="" placeholder="Select account" options={accountOptions} />
                          </LabeledField>
                        </FormGrid>
                      )}

                      {tab === 6 && (
                        <Grid container spacing={2}>
                          <Grid item xs={12}>
                            <LabeledField label="Remarks">
                              <FormTextField name="remarks" label="" placeholder="Enter remarks" multiline rows={6} />
                            </LabeledField>
                          </Grid>
                        </Grid>
                      )}

                      {tab === 7 && (
                        <Typography variant="body2" color="text.secondary">
                          File attachments are not supported yet — this tab is reserved for a future upload feature.
                        </Typography>
                      )}
                    </Box>

                    <Stack direction="row" spacing={1.5} justifyContent="flex-end" sx={{ mt: 3 }}>
                      <Button variant="outlined" color={readOnly ? 'error' : 'inherit'} startIcon={<CloseIcon />} onClick={closeForm} disabled={creating || updating}>
                        {readOnly ? 'Close' : 'Cancel'}
                      </Button>
                      <FormSubmitButton startIcon={<SaveIcon />} disabled={creating || updating}>
                        {readOnly ? 'View' : editingRow ? 'Update Business Partner' : 'Save Business Partner'}
                      </FormSubmitButton>
                    </Stack>
                  </CardContent>
                </Card>
              </>
              );
            }}
          </AppForm>
        </Box>
      </Collapse>

      <Card variant="outlined">
        <CardContent sx={{ p: 0 }}>
          <Stack direction="row" alignItems="center" justifyContent="space-between" flexWrap="wrap" gap={1.5} sx={{ px: 3, pt: 2.5, pb: 1.5 }}>
            <Typography variant="subtitle1" fontWeight={700}>Business Partner List</Typography>
            <Stack direction="row" spacing={1.5} flexWrap="wrap" useFlexGap>
              <TableSearchFilter table={table} placeholder="Search by code, name, email or mobile..." width={260} />
              <Button
                variant="outlined"
                color="inherit"
                startIcon={<FilterListIcon />}
                onClick={(e) => setFilterAnchor(e.currentTarget)}
              >
                Filter{statusFilter !== 'All' ? `: ${statusFilter}` : ''}
              </Button>
              <Menu anchorEl={filterAnchor} open={!!filterAnchor} onClose={() => setFilterAnchor(null)}>
                {STATUS_FILTERS.map((s) => (
                  <MenuItem key={s} selected={statusFilter === s} onClick={() => { setStatusFilter(s); setPage(0); setFilterAnchor(null); }}>
                    {statusFilter === s && <ListItemIcon><CheckIcon fontSize="small" /></ListItemIcon>}
                    <ListItemText inset={statusFilter !== s}>{s}</ListItemText>
                  </MenuItem>
                ))}
              </Menu>
              <CanAdd>
                <Button variant="contained" startIcon={<AddIcon />} onClick={openCreate}>
                  Add Business Partner
                </Button>
              </CanAdd>
            </Stack>

            <TableFilterPanel table={table} />
          </Stack>

          {isMobile ? (
            <Box sx={{ px: 2, pb: 1 }}>
              {!isLoading && pagedRows.map((row) => (
                <MobileRecordCard
                  key={row.id}
                  title={row.partnerName}
                  statusChip={<Chip size="small" label={row.status} color={row.status === 'Active' ? 'success' : 'default'} variant="outlined" />}
                  fields={[
                    { label: 'Code', value: row.partnerCode },
                    { label: 'Partner Type', value: row.partnerType || '—' },
                    { label: 'Group', value: row.groupName || '—' },
                    { label: 'Mobile', value: row.mobile || '—' },
                  ]}
                  onView={() => handleView(row)}
                  onEdit={() => handleEdit(row)}
                  onDelete={() => handleDelete(row)}
                />
              ))}
              {!isLoading && filteredRows.length === 0 && (
                <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>No business partners found</Typography>
              )}
            </Box>
          ) : (
            <ScrollableTableContainer>
              <Table size="small" stickyHeader>
                <TableHead>
                  <TableRow>
                    <TableCell width={48}>#</TableCell>
                    <SortableHeaderCell field="partnerCode" sort={table.sort} onSort={table.toggleSort}>Code</SortableHeaderCell>
                    <SortableHeaderCell field="partnerName" sort={table.sort} onSort={table.toggleSort}>Name</SortableHeaderCell>
                    <SortableHeaderCell field="partnerType" sort={table.sort} onSort={table.toggleSort}>Partner Type</SortableHeaderCell>
                    <SortableHeaderCell field="groupName" sort={table.sort} onSort={table.toggleSort}>Group</SortableHeaderCell>
                    <SortableHeaderCell field="mobile" sort={table.sort} onSort={table.toggleSort}>Mobile</SortableHeaderCell>
                    <SortableHeaderCell field="status" sort={table.sort} onSort={table.toggleSort}>Status</SortableHeaderCell>
                    <TableCell align="right">Action</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {!isLoading && pagedRows.map((row, i) => (
                    <TableRow key={row.id} hover>
                      <TableCell>{page * pageSize + i + 1}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.partnerCode}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.partnerName}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.partnerType || '—'}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.groupName || '—'}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.mobile || '—'}</TableCell>
                      <TableCell>
                        <Chip size="small" label={row.status} color={row.status === 'Active' ? 'success' : 'default'} variant="outlined" />
                      </TableCell>
                      <TableCell align="right">
                        <Stack direction="row" spacing={0.5} justifyContent="flex-end">
                          <IconButton size="small" onClick={() => handleView(row)} aria-label="view">
                            <VisibilityOutlinedIcon fontSize="small" />
                          </IconButton>
                          <CanEdit>
                            <IconButton size="small" color="primary" onClick={() => handleEdit(row)} aria-label="edit">
                              <EditIcon fontSize="small" />
                            </IconButton>
                          </CanEdit>
                          <CanDelete>
                            <IconButton size="small" color="error" onClick={() => handleDelete(row)} aria-label="delete">
                              <DeleteIcon fontSize="small" />
                            </IconButton>
                          </CanDelete>
                        </Stack>
                      </TableCell>
                    </TableRow>
                  ))}
                  {!isLoading && filteredRows.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={8}>
                        <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>No business partners found</Typography>
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </ScrollableTableContainer>
          )}

          <EntityListPagination total={filteredRows.length} page={page} onChange={setPage} pageSize={pageSize} onPageSizeChange={(v) => { setPageSize(v); setPage(0); }} />
        </CardContent>
      </Card>
    </Box>
  );
}
