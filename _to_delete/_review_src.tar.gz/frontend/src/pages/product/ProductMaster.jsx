import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Box, Typography, Button, Card, CardContent, Stack, Table, TableBody, TableCell, TableHead,
  TableRow, Chip, IconButton, Menu, MenuItem, ListItemIcon, ListItemText, Tabs, Tab, Grid,
  Divider, Collapse,
} from '@mui/material';
import Inventory2OutlinedIcon from '@mui/icons-material/Inventory2Outlined';
import AddIcon from '@mui/icons-material/Add';
import CloseIcon from '@mui/icons-material/Close';
import SearchIcon from '@mui/icons-material/Search';
import FilterListIcon from '@mui/icons-material/FilterList';
import EditIcon from '@mui/icons-material/EditOutlined';
import DeleteIcon from '@mui/icons-material/DeleteOutline';
import CheckIcon from '@mui/icons-material/Check';
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import { z } from 'zod';
import AppForm, { FormGrid, FormSubmitButton } from '../../components/form/AppForm';
import FormTextField from '../../components/form/FormTextField';
import FormSelect from '../../components/form/FormSelect';
import { FormCheckbox } from '../../components/form/FormCheckbox';
import EntityHeaderCard from '../../components/common/EntityHeaderCard';
import CompanyBadge from '../../components/common/CompanyBadge';
import EntityListPagination from '../../components/data-display/EntityListPagination';
import MobileRecordCard from '../../components/data-display/MobileRecordCard';
import { useIsMobileListView } from '../../components/data-display/useIsMobileListView';
import useDragScroll from '../../components/data-display/useDragScroll';
import { useNotify } from '../../components/feedback/NotificationProvider';
import { applyServerErrors } from '../../lib/formErrors';
import { useConfirm } from '../../components/feedback/ConfirmationDialog';
import { productBaseSchema, refineProductUsageFlags, refineItemCategoryRequired } from '../../lib/validation/productSchemas';
import ProductUsageFlags from './ProductUsageFlags';
import {
  productApi, productGroupApi, productSubGroupApi, brandApi, uomApi, supplierApi,
  useGetProductCurrentStockQuery, useGetProductUsageQuery,
} from '../../features/resources';
import useTableFeatures from '../../components/data-display/useTableFeatures';
import TableSearchFilter from '../../components/data-display/TableSearchFilter';
import SortableHeaderCell from '../../components/data-display/SortableHeaderCell';
import ScrollableTableContainer from '../../components/data-display/ScrollableTableContainer';
import DocumentNoField from '../../components/form/DocumentNoField';
import ProductInventoryTab from './ProductInventoryTab';

import { CanAdd, CanEdit, CanDelete } from '../../components/common/PermissionGate';
import TableFilterPanel from '../../components/data-display/TableFilterPanel';

// Label-left field layout for the Product Master form only (per the "Edit
// Items / Material" reference template) — a plain label sits to the left of
// a plain box, two such pairs per row, instead of this app's usual MUI
// floating-label style (label riding inside the box, shrinking onto the
// border on focus). Every other form in the app is untouched; this wrapper
// just clears whichever FormTextField/FormSelect it wraps down to no
// internal label, so the label text shown here is the only one that renders.
//

// Every knob for this layout's sizing lives here as one constant each, so
// the gap, the input's width and the input's height can each be tuned in one
// place without hunting through the JSX below:
//   - FIELD_LABEL_WIDTH   how wide the label column is
//   - FIELD_LABEL_GAP     the horizontal gap between a label and its input
//   - FIELD_ROW_SPACING   the gap between rows/columns of label+input pairs
//   - FIELD_MAX_WIDTH     caps how wide the input box itself grows
//   - FIELD_LABEL_OFFSET  nudges the label down/up to line up with the input
//   - FIELD_INPUT_SX      the input's own height (padding) and font size —
//                          also where the helper-text row under every field
//                          is shrunk, since that reserved line (for
//                          validation messages) was the biggest contributor
//                          to the visible top/bottom gap around each field
const FIELD_LABEL_WIDTH = 190;
const FIELD_LABEL_GAP = 3.5;
const FIELD_ROW_SPACING = 0;
const FIELD_MAX_WIDTH = 500;
const FIELD_LABEL_OFFSET = 0;
const FIELD_INPUT_SX = {
  '& .MuiInputBase-input': { paddingTop: '5px', paddingBottom: '5px', fontSize: '0.8125rem' },
  '& .MuiInputBase-root': { minHeight: 34 },
  // Every FormTextField/FormSelect always renders a helper-text line below
  // the box (blank when there's no error) so error messages don't shift the
  // layout when they appear — that reserved line is what made each row look
  // like it had a large top/bottom gap even with FIELD_ROW_SPACING at 0.
  '& .MuiFormHelperText-root': { margin: 0, minHeight: '0.9em', lineHeight: 1.2, fontSize: '0.6875rem' },
};

function FieldLabel({ children }) {
  const text = String(children || '');
  const required = text.trim().endsWith('*');
  const base = required ? text.trim().replace(/\*$/, '').trimEnd() : text;
  return (
    <Typography
      variant="body2"
      sx={{
        // FIXED width, not minWidth — a minWidth lets a long label (e.g.
        // "Brand & Manufacturer") grow past it, which pushed that row's own
        // input further right than every shorter-labelled row above and
        // below it. A fixed width can't grow, so every input's left edge
        // lines up regardless of its label's length; a label too long for
        // the column wraps onto a second line instead of stealing space
        // from the input next to it.
        width: { xs: '100%', sm: FIELD_LABEL_WIDTH },
        flexShrink: 0,
        fontWeight: 600,
        color: 'text.primary',
        pt: FIELD_LABEL_OFFSET,
      }}
    >
      {base}
      {required && <Typography component="span" color="error.main">&nbsp;*</Typography>}
    </Typography>
  );
}

// `align` lets a caller centre the label against its content instead of
// pinning it to the top — every plain text/select field wants top alignment
// (so a multi-line box's label sits by its first line), but a checkbox row
// like "Item Listed In" has no first line to align to, and top-aligning it
// left the label sitting above the checkboxes instead of level with them.
function LabeledField({ label, children, align = 'flex-start' }) {
  return (
    <Box sx={{ display: 'flex', flexDirection: { xs: 'column', sm: 'row' }, alignItems: { xs: 'stretch', sm: align }, gap: { xs: 0.5, sm: FIELD_LABEL_GAP } }}>
      <FieldLabel>{label}</FieldLabel>
      <Box
        sx={{
          flex: 1, minWidth: 0, maxWidth: { sm: FIELD_MAX_WIDTH }, ...FIELD_INPUT_SX,
          ...(align === 'center' ? { display: 'flex', alignItems: 'center', minHeight: 34 } : null),
        }}
      >
        {children}
      </Box>
    </Box>
  );
}
// Local schema — the list's "Active" state is exposed as a checkbox rather
// than the shared Active/Inactive select, so swap the shared `status` enum
// for a boolean `active` field here and translate it back on submit.
// Built from the UNREFINED object and refined afterwards: `.superRefine()`
// returns a ZodEffects, which has no `.omit()`/`.extend()`, so the
// at-least-one-flow rule has to be applied after this reshaping rather than
// inherited through it. See refineProductUsageFlags.
const productDetailsSchema = productBaseSchema
  .omit({ status: true })
  .extend({ active: z.boolean().optional() })
  .superRefine(refineProductUsageFlags)
  .superRefine(refineItemCategoryRequired);

const emptyValues = {
  productCode: '', productName: '', barcode: '', productGroup: '', productSubGroup: '', brand: '',
  productType: '',
  // A new product is offered in every flow until someone says otherwise —
  // the same default the database applies, so a product created and saved
  // without touching these behaves exactly as products did before the flags
  // existed.
  salesItem: true, purchaseItem: true, inventoryItem: true,
  uom: '', salesUom: '', hsnCode: '', excisable: false, gst: false,
  chapterId: '', taxCategory: '',
  calculationMethod: 'None',
  manageItemBy: 'None',
  glAccountsBy: 'Warehouse',
  costPrice: 0, openingStock: 0, reorderLevel: 0,
  expiryApplicable: false, defaultSupplier: '', defaultLocation: '', rackNo: '',
  description: '', remarks: '', active: true,

  // --- General tab (header) — see migration 20260823150000_add_product_tab_fields ---
  foreignName: '', manufacturer: '', msdc: '', additionalIdentifier: '', shippingType: '',
  costCenterCode: '', costCenterName: '', manageMethod: '', priceList: '', unitPrice: 0,
  assetItem: false,

  // --- Purchase tab ---
  mfrCatalogNo: '', purchasingUomName: '', itemsPerPurchaseUnit: 0,
  purchasePackagingUomName: '', quantityPerPurchasePackage: 0, customsGroup: '',

  // --- Sales tab ---
  itemsPerSalesUnit: 0, salesPackagingUomName: '', quantityPerSalesPackage: 0,

  // --- Shared physical attributes ---
  taxGroup: '', productLength: 0, width: 0, height: 0, volume: 0, weight: 0,

  // --- Inventory tab ---
  manageInventoryByWarehouse: false, inventoryLevelRequired: 0, minimumLevel: 0,
  maximumLevel: 0, inventoryUomName: '',
};

const PRODUCT_TYPE_OPTIONS = [
  { label: 'Raw Material', value: 'Raw Material' },
  { label: 'Semi-Finished Goods', value: 'Semi-Finished Goods' },
  { label: 'Finished Goods', value: 'Finished Goods' },
  { label: 'Trading Goods', value: 'Trading Goods' },
  { label: 'Service', value: 'Service' },
  { label: 'Consumable', value: 'Consumable' },
  { label: 'Other', value: 'Other' },
];

// Inventory costing method. Picking FIFO or Moving Average makes each of this
// product's stock movements store its unit cost under that method in the
// stock journal's FIFO / MAV columns — a background record only, not shown
// anywhere in the app. 'None' stores neither. No other calculation in the
// application is affected by this choice.
const CALCULATION_METHOD_OPTIONS = [
  { label: 'None', value: 'None' },
  { label: 'FIFO', value: 'FIFO' },
  { label: 'Moving Average', value: 'Moving Average' },
];

// How this product's stock is tracked at the unit level. Display/
// classification only — no stock movement, valuation or inventory
// calculation currently branches on it.
const MANAGE_ITEM_BY_OPTIONS = [
  { label: 'None', value: 'None' },
  { label: 'Batch', value: 'Batch' },
  { label: 'Serial', value: 'Serial' },
];

// When this product's batch/serial numbers get assigned — display/
// classification only, same as MANAGE_ITEM_BY_OPTIONS above; nothing in the
// batch/serial allocation flow currently branches on it.
const MANAGE_METHOD_OPTIONS = [
  { label: 'On Every Transaction', value: 'On Every Transaction' },
  { label: 'On Release Only', value: 'On Release Only' },
];

// GST Tax Category — display/classification only on this form, shown next to
// the conditional HSN field while GST is ticked.
const TAX_CATEGORY_OPTIONS = [
  { label: 'Regular', value: 'Regular' },
  { label: 'Nil Rated', value: 'Nil Rated' },
  { label: 'Exempt', value: 'Exempt' },
];

// Which level's Accounting-tab G/L account mappings this product posts
// through — WarehouseMaster's own Accounting tab, or the product's
// ProductGroup's Accounting tab (see PRODUCT_GROUP_ACCOUNT_MAP in
// ProductGroup.jsx). Warehouse is the default, matching every product
// saved before this field existed.
const GL_ACCOUNTS_BY_OPTIONS = [
  { label: 'Warehouse', value: 'Warehouse' },
  { label: 'Product Group', value: 'Product Group' },
];

const PAGE_SIZE = 10;
const STATUS_FILTERS = ['All', 'Active', 'Inactive'];

export default function ProductMaster() {
  const notify = useNotify();
  const confirmDialog = useConfirm();
  const isMobile = useIsMobileListView();
  const { data: products, isLoading } = productApi.useList();
  const { data: currentStockByCode } = useGetProductCurrentStockQuery();
  const [create, { isLoading: creating }] = productApi.useCreate();
  const [update, { isLoading: updating }] = productApi.useUpdate();
  const [remove] = productApi.useDelete();

  const { data: productGroups } = productGroupApi.useList();
  const { data: productSubGroups } = productSubGroupApi.useList();
  const { data: brands } = brandApi.useList();
  const { data: uoms } = uomApi.useList();
  const { data: suppliers } = supplierApi.useList();

  const productGroupOptions = (productGroups || []).map((g) => ({ label: g.groupName, value: g.groupName }));
  const brandOptions = (brands || []).map((b) => ({ label: b.brandName, value: b.brandName }));
  const uomOptions = (uoms || []).map((u) => ({ label: u.uomName, value: u.uomName }));
  const supplierOptions = (suppliers || []).map((s) => ({ label: s.supplierName, value: s.supplierName }));

  // Form is hidden by default -- it expands in a Collapse ABOVE the list
  // (which stays visible) when "Add Product" or an edit action is
  // triggered, per the inline form template (Payment Entry/Deposit Entry),
  // instead of swapping the whole page out for a separate form view.
  const [showForm, setShowForm] = useState(false);
  const [editingRow, setEditingRow] = useState(null);
  const [readOnly, setReadOnly] = useState(false);
  // Which of the three flow flags are pinned by documents already using this
  // product, so those checkboxes render locked. Skipped while creating — a
  // product that does not exist yet is used nowhere, so nothing can be locked.
  const { data: productUsage } = useGetProductUsageQuery(editingRow?.productCode, {
    skip: !editingRow?.productCode,
  });
  const [formKey, setFormKey] = useState(0);
  const [tab, setTab] = useState(0);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [filterAnchor, setFilterAnchor] = useState(null);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(PAGE_SIZE);

  // "Stock" in the list shows live current stock (opening stock plus every
  // posted Stock Receipt/Issue/Adjustment), not just the static opening-stock
  // field entered on the product record. Falls back to openingStock while
  // the current-stock lookup is still loading.
  const rows = (products || []).map((p) => ({
    ...p,
    currentStock: currentStockByCode?.[p.productCode] ?? p.openingStock,
  }));

  const baseTableRows = useMemo(() => {
    const q = '';
    return rows.filter((r) => {
      const matchesSearch = !q || [r.productCode, r.productName, r.productGroup, r.brand]
        .some((v) => String(v || '').toLowerCase().includes(q));
      const matchesStatus = statusFilter === 'All' || r.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [rows, statusFilter]);

  // Column definitions drive the global search, the sort icons and the filter
  // popover — see components/data-display/useTableFeatures.js.
  const tableColumns = useMemo(() => ([
    { field: 'productCode', headerName: 'Product Code', filter: 'text' },
    { field: 'productName', headerName: 'Product Name', filter: 'text' },
    { field: 'productGroup', headerName: 'Group', filter: 'text' },
    { field: 'brand', headerName: 'Brand', filter: 'text' },
    { field: 'currentStock', headerName: 'Stock', filter: 'numberRange', sortValue: (row) => (row.currentStock == null || row.currentStock === '' ? null : Number(row.currentStock)) },
    { field: 'status', headerName: 'Status', filter: 'select' },
  ]), []);
  const table = useTableFeatures(baseTableRows, tableColumns, { onChange: setPage });
  const filteredRows = table.rows;

  const pagedRows = useMemo(
    () => filteredRows.slice(page * pageSize, page * pageSize + pageSize),
    [filteredRows, page, pageSize]
  );

  const openCreate = () => {
    setEditingRow(null);
    setReadOnly(false);
    setFormKey((k) => k + 1);
    setTab(0);
    setShowForm(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const closeForm = () => {
    setShowForm(false);
    setEditingRow(null);
  };

  // Read-only look at a record — same form, every field disabled
  // and the save button removed (see AppForm's readOnly prop).
  const handleView = (row) => {
    setEditingRow(row);
    setReadOnly(true);
    setFormKey((k) => k + 1);
    setTab(0);
    setShowForm(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleEdit = (row) => {
    setEditingRow(row);
    setReadOnly(false);
    setFormKey((k) => k + 1);
    setTab(0);
    setShowForm(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = async (row) => {
    const ok = await confirmDialog({
      title: 'Delete product',
      message: `Are you sure you want to delete "${row.productName}"? This cannot be undone.`,
      confirmLabel: 'Delete',
      severity: 'error',
    });
    if (!ok) return;
    try {
      await remove(row.id).unwrap();
      notify.success('Product deleted');
    } catch (err) {
      notify.error(err?.data?.message || 'Delete failed');
    }
  };

  const handleSubmit = async (values, formMethods) => {
    const { active, ...rest } = values;
    const payload = { ...rest, status: active ? 'Active' : 'Inactive' };
    try {
      if (editingRow) {
        await update({ id: editingRow.id, ...payload }).unwrap();
        notify.success('Product updated');
      } else {
        await create(payload).unwrap();
        notify.success('Product added');
      }
      closeForm();
    } catch (err) {
      notify.error(applyServerErrors(err, formMethods.setError));
    }
  };

  return (
    <Box>
      <EntityHeaderCard
        icon={<Inventory2OutlinedIcon />}
        title="Product Master"
        subtitle="Create and manage products."
        rightContent={<CompanyBadge />}
      />

      <Collapse in={showForm} unmountOnExit>
        <Box sx={{ mb: 2 }}>
          <Card variant="outlined">
            <CardContent sx={{ p: 3 }}>
              <Stack direction="row" alignItems="center" justifyContent="space-between" flexWrap="wrap" gap={1.5} sx={{ mb: 1 }}>
                <Typography variant="subtitle1" fontWeight={700}>
                  {readOnly ? 'View Product' : editingRow ? 'Edit Product' : 'Create Product'}
                </Typography>
                <Button variant="outlined" color="inherit" startIcon={<CloseIcon />} onClick={closeForm}>
                  Close
                </Button>
              </Stack>

              <AppForm readOnly={readOnly}
                key={formKey}
                schema={productDetailsSchema}
                defaultValues={editingRow ? {
                  ...emptyValues,
                  ...editingRow,
                  costPrice: editingRow.costPrice != null ? Number(editingRow.costPrice) : 0,
                  openingStock: editingRow.openingStock != null ? Number(editingRow.openingStock) : 0,
                  reorderLevel: editingRow.reorderLevel != null ? Number(editingRow.reorderLevel) : 0,
                  unitPrice: editingRow.unitPrice != null ? Number(editingRow.unitPrice) : 0,
                  itemsPerPurchaseUnit: editingRow.itemsPerPurchaseUnit != null ? Number(editingRow.itemsPerPurchaseUnit) : 0,
                  quantityPerPurchasePackage: editingRow.quantityPerPurchasePackage != null ? Number(editingRow.quantityPerPurchasePackage) : 0,
                  itemsPerSalesUnit: editingRow.itemsPerSalesUnit != null ? Number(editingRow.itemsPerSalesUnit) : 0,
                  quantityPerSalesPackage: editingRow.quantityPerSalesPackage != null ? Number(editingRow.quantityPerSalesPackage) : 0,
                  productLength: editingRow.productLength != null ? Number(editingRow.productLength) : 0,
                  width: editingRow.width != null ? Number(editingRow.width) : 0,
                  height: editingRow.height != null ? Number(editingRow.height) : 0,
                  volume: editingRow.volume != null ? Number(editingRow.volume) : 0,
                  weight: editingRow.weight != null ? Number(editingRow.weight) : 0,
                  inventoryLevelRequired: editingRow.inventoryLevelRequired != null ? Number(editingRow.inventoryLevelRequired) : 0,
                  minimumLevel: editingRow.minimumLevel != null ? Number(editingRow.minimumLevel) : 0,
                  maximumLevel: editingRow.maximumLevel != null ? Number(editingRow.maximumLevel) : 0,
                  assetItem: !!editingRow.assetItem,
                  manageInventoryByWarehouse: !!editingRow.manageInventoryByWarehouse,
                  excisable: !!editingRow.excisable,
                  gst: !!editingRow.gst,
                  // Products saved before this field existed come back null;
                  // show them as 'None' so the select isn't blank.
                  calculationMethod: editingRow.calculationMethod || 'None',
                  manageItemBy: editingRow.manageItemBy || 'None',
                  glAccountsBy: editingRow.glAccountsBy || 'Warehouse',
                  // `!== false` rather than a plain truthiness test: a product
                  // saved before these columns existed comes back with them
                  // undefined, and the column default is true, so an absent
                  // value must read as ticked — not as a product that belongs
                  // to no flow at all.
                  salesItem: editingRow.salesItem !== false,
                  purchaseItem: editingRow.purchaseItem !== false,
                  inventoryItem: editingRow.inventoryItem !== false,
                  active: editingRow.status === 'Active',
                } : emptyValues}
                onSubmit={handleSubmit}
              >
                {(methods) => {
                  const groupValue = methods.watch('productGroup');
                  const subGroupOptions = (productSubGroups || [])
                    .filter((s) => !groupValue || !s.groupName || s.groupName === groupValue)
                    .map((s) => ({ label: s.subGroupName, value: s.subGroupName }));

                  // Auto-fill the UOM from the selected Product Group's own
                  // default UOM (still editable afterwards) whenever the
                  // group selection actually changes — including on an
                  // existing product, so re-grouping a product re-derives its
                  // UOM rather than leaving behind whatever the old group set.
                  // A group with no UOM configured leaves the field alone.
                  const prevGroupValue = useRef(editingRow ? editingRow.productGroup : null);
                  useEffect(() => {
                    if (groupValue !== prevGroupValue.current) {
                      const group = (productGroups || []).find((g) => g.groupName === groupValue);
                      if (group && group.uom) methods.setValue('uom', group.uom, { shouldValidate: true });
                      prevGroupValue.current = groupValue;
                    }
                    // eslint-disable-next-line react-hooks/exhaustive-deps
                  }, [groupValue]);

                  // Item Category — Excisable / GST are mutually exclusive:
                  // ticking one unchecks the other, rather than letting both
                  // sit ticked at once. Two one-way effects rather than a
                  // single shared handler because FormCheckbox owns its own
                  // Controller/onChange (see components/form/FormCheckbox.jsx)
                  // — there's no hook to intercept a click on before it
                  // writes, only a value to react to after it does.
                  const excisableValue = methods.watch('excisable');
                  const gstValue = methods.watch('gst');
                  useEffect(() => {
                    if (excisableValue) methods.setValue('gst', false, { shouldValidate: true });
                    // eslint-disable-next-line react-hooks/exhaustive-deps
                  }, [excisableValue]);
                  useEffect(() => {
                    if (gstValue) methods.setValue('excisable', false, { shouldValidate: true });
                    // eslint-disable-next-line react-hooks/exhaustive-deps
                  }, [gstValue]);

                  // Volume — the one live calculation on this form: length *
                  // width * height, recomputed whenever any of the three
                  // changes, on both Purchase and Sales tabs since they share
                  // the same three fields. Read-only on the field itself (see
                  // the Volume LabeledField below) so nobody's typed value is
                  // silently overwritten by a stale product's dimensions.
                  const lengthValue = Number(methods.watch('productLength')) || 0;
                  const widthValue = Number(methods.watch('width')) || 0;
                  const heightValue = Number(methods.watch('height')) || 0;
                  useEffect(() => {
                    const computed = lengthValue && widthValue && heightValue
                      ? Math.round(lengthValue * widthValue * heightValue * 1000000) / 1000000
                      : 0;
                    methods.setValue('volume', computed, { shouldValidate: true });
                    // eslint-disable-next-line react-hooks/exhaustive-deps
                  }, [lengthValue, widthValue, heightValue]);

                  return (
                    <>
                      {/* Persistent header — visible on every tab, matching the
                          reference template's "Item No / Description / Item
                          Group / UoM Group / Price List / Unit Price / Item
                          Listed In" band that sits above its tab strip. */}
                      <FormGrid columns={2} singleColumnOnMobile spacing={FIELD_ROW_SPACING}>
                        {/* Auto-generated from the perpetual PRD numbering series (hidden
                            from the Document Numbering page — see hiddenFromNumberingUI
                            in documentNumberService.js). The field is filled and locked
                            on create, and left untouched on edit so an existing record's
                            code is never rewritten. */}
                        <LabeledField label="Item No *">
                          <DocumentNoField documentCode="PRD" name="productCode" label="" isCreate={!editingRow} />
                        </LabeledField>
                        <LabeledField label="Description *">
                          <FormTextField name="productName" label="" placeholder="Enter product name" />
                        </LabeledField>

                        <LabeledField label="Foreign Name">
                          <FormTextField name="foreignName" label="" placeholder="Foreign name" />
                        </LabeledField>
                        <LabeledField label="Item Group *">
                          <FormSelect name="productGroup" label="" placeholder="Select group" options={productGroupOptions} />
                        </LabeledField>

                        <LabeledField label="UoM Group *">
                          <FormSelect name="uom" label="" placeholder="Select unit" options={uomOptions} />
                        </LabeledField>
                        <LabeledField label="Price List">
                          <FormTextField name="priceList" label="" placeholder="Select price list" />
                        </LabeledField>

                        <LabeledField label="Unit Price">
                          <FormTextField name="unitPrice" label="" type="number" placeholder="0.00" />
                        </LabeledField>
                        
                        <LabeledField label="Item Listed In *" align="center">
                          <ProductUsageFlags usage={productUsage} />
                        </LabeledField>
                        
                      </FormGrid>

                      {/* "Item Listed In" — which flows this product may be
                          used in. Sales/Purchase/Inventory drive real picker
                          behaviour elsewhere in the app (see
                          lib/productUsage.js) and can be locked by existing
                          usage. */}
                      <Divider sx={{ mt: 2, mb: 1.5 }} />
                      

                      <Tabs value={tab} onChange={(_e, v) => setTab(v)} sx={{ mt: 2, mb: 2, borderBottom: 1, borderColor: 'divider' }}>
                        <Tab label="General" />
                        <Tab label="Purchase" />
                        <Tab label="Sales" />
                        {/* Where this product's stock sits, per warehouse. Only
                            meaningful once the product exists — its movements are
                            tracked against a product code that is issued on save — so
                            on create the tab is present but explains itself rather
                            than showing an empty grid. */}
                        <Tab label="Inventory" />
                      </Tabs>

                      {tab === 0 && (
                        <>
                          <FormGrid columns={2} singleColumnOnMobile spacing={FIELD_ROW_SPACING}>
                            <LabeledField label="Barcode">
                              <FormTextField name="barcode" label="" placeholder="Enter barcode" />
                            </LabeledField>
                            <LabeledField label="Product Sub-Group">
                              <FormSelect name="productSubGroup" label="" placeholder="Select sub-group" options={subGroupOptions} />
                            </LabeledField>

                            <LabeledField label="Brand & Manufacturer">
                              <FormSelect name="brand" label="" placeholder="Select brand" options={brandOptions} />
                            </LabeledField>
                            <LabeledField label="Product Type">
                              <FormSelect name="productType" label="" placeholder="Select type" options={PRODUCT_TYPE_OPTIONS} />
                            </LabeledField>

                            <LabeledField label="Additional Identifier">
                              <FormTextField name="additionalIdentifier" label="" placeholder="additional_identifier" />
                            </LabeledField>

                            <LabeledField label="Manage Item By">
                              <FormSelect name="manageItemBy" label="" placeholder="Select option" options={MANAGE_ITEM_BY_OPTIONS} />
                            </LabeledField>
                            <LabeledField label="Shipping Type">
                              <FormTextField name="shippingType" label="" placeholder="Enter shipping type" />
                            </LabeledField>
                            <LabeledField label="Manage Method">
                              <FormSelect name="manageMethod" label="" placeholder="Select option" options={MANAGE_METHOD_OPTIONS} />
                            </LabeledField>
                            
                            <LabeledField label="Item Category *" align="center">
                            <Stack direction="row" spacing={3}>
                              <FormCheckbox name="excisable" label="Excisable" />
                              <FormCheckbox name="gst" label="GST" />
                            </Stack>
                          </LabeledField>
                          </FormGrid>

                          {/* Conditional Item Category detail fields — Chapter ID
                              only while Excisable is ticked; HSN and Tax Category
                              only while GST is ticked. Item Category itself sits in
                              the RIGHT column of the grid above, so each of these is
                              placed as an empty left-column spacer + a right-column
                              field, row by row — that's what actually stacks them
                              straight under Item Category instead of under Barcode
                              on the left (a plain 2-column FormGrid always starts a
                              fresh row at the left column, which is what put HSN /
                              Tax Category on the wrong side before). */}
                          {(excisableValue || gstValue) && (
                            <Grid container spacing={FIELD_ROW_SPACING}>
                              {excisableValue && (
                                <>
                                  <Grid item xs={12} sm={6} md={6} />
                                  <Grid item xs={12} sm={6} md={6}>
                                    <LabeledField label="Chapter ID">
                                      <FormTextField name="chapterId" label="" placeholder="Enter chapter ID" />
                                    </LabeledField>
                                  </Grid>
                                </>
                              )}
                              {gstValue && (
                                <>
                                  <Grid item xs={12} sm={6} md={6} />
                                  <Grid item xs={12} sm={6} md={6}>
                                    <LabeledField label="HSN">
                                      <FormTextField name="hsnCode" label="" placeholder="Enter HSN / SAC code" digitsOnly maxLength={8} />
                                    </LabeledField>
                                  </Grid>
                                  <Grid item xs={12} sm={6} md={6} />
                                  <Grid item xs={12} sm={6} md={6}>
                                    <LabeledField label="Tax Category">
                                      <FormSelect name="taxCategory" label="" placeholder="Select category" options={TAX_CATEGORY_OPTIONS} />
                                    </LabeledField>
                                  </Grid>
                                </>
                              )}
                            </Grid>
                          )}
                            

                            
                           

                          {/* Item Category tax treatment — Excisable and GST
                              are mutually exclusive (see the excisableValue/
                              gstValue effects above): ticking one always
                              unchecks the other, so a product can never be
                              flagged both at once. */}

                          <Grid container spacing={2} sx={{ mt: 0.5 }}>
                            <Grid item xs={12} md={6}>
                              <LabeledField label="Remarks">
                                <FormTextField name="remarks" label="" placeholder="Enter remarks" multiline rows={3} />
                              </LabeledField>
                            </Grid>
                          </Grid>
                        </>
                      )}

                      {tab === 1 && (
                        <FormGrid columns={2} singleColumnOnMobile spacing={FIELD_ROW_SPACING}>
                          <LabeledField label="Preferred Vendor">
                            <FormSelect name="defaultSupplier" label="" placeholder="Select supplier" options={supplierOptions} />
                          </LabeledField>
                          <LabeledField label="Mfr Catalog No.">
                            <FormTextField name="mfrCatalogNo" label="" placeholder="Catalog No" />
                          </LabeledField>

                          <LabeledField label="Purchasing UoM Name">
                            <FormSelect name="purchasingUomName" label="" placeholder="Select unit" options={uomOptions} />
                          </LabeledField>
                          <LabeledField label="Items per Purchase Unit">
                            <FormTextField name="itemsPerPurchaseUnit" label="" type="number" placeholder="Items per purchase unit" />
                          </LabeledField>

                          <LabeledField label="Packaging UoM Name">
                            <FormTextField name="purchasePackagingUomName" label="" placeholder="p_pakcaging_uom_name" />
                          </LabeledField>
                          <LabeledField label="Quantity per Package">
                            <FormTextField name="quantityPerPurchasePackage" label="" type="number" placeholder="Quantity per package" />
                          </LabeledField>

                          <LabeledField label="Customs Group">
                            <FormTextField name="customsGroup" label="" placeholder="Enter customs group" />
                          </LabeledField>
                          <LabeledField label="Tax Group">
                            <FormTextField name="taxGroup" label="" placeholder="Enter tax group" />
                          </LabeledField>

                          <LabeledField label="Cost Price (Purchase Price) *">
                            <FormTextField name="costPrice" label="" type="number" placeholder="0.00" />
                          </LabeledField>
                          <LabeledField label="Manage Item By">
                            <FormSelect name="manageItemBy" label="" placeholder="Select option" options={MANAGE_ITEM_BY_OPTIONS} />
                          </LabeledField>

                          <LabeledField label="Valuation Method">
                            <FormSelect name="calculationMethod" label="" placeholder="Select method" options={CALCULATION_METHOD_OPTIONS} />
                          </LabeledField>
                          <LabeledField label="Set G/L Accounts By">
                            <FormSelect
                              name="glAccountsBy"
                              label=""
                              placeholder="Select level"
                              options={GL_ACCOUNTS_BY_OPTIONS}
                            />
                          </LabeledField>

                          <LabeledField label="Length">
                            <FormTextField name="productLength" label="" type="number" placeholder="p_length" />
                          </LabeledField>
                          <LabeledField label="Width">
                            <FormTextField name="width" label="" type="number" placeholder="p_width" />
                          </LabeledField>

                          <LabeledField label="Height">
                            <FormTextField name="height" label="" type="number" placeholder="p_height" />
                          </LabeledField>
                          {/* Read-only: computed as Length × Width × Height —
                              see the volume effect above, which recomputes it
                              live whenever any of the three changes. */}
                          <LabeledField label="Volume">
                            <FormTextField name="volume" label="" type="number" placeholder="Volume" disabled />
                          </LabeledField>

                          <LabeledField label="Weight">
                            <FormTextField name="weight" label="" type="number" placeholder="Weight" />
                          </LabeledField>
                        </FormGrid>
                      )}

                      {tab === 2 && (
                        <FormGrid columns={2} singleColumnOnMobile spacing={FIELD_ROW_SPACING}>
                          <LabeledField label="Tax Group">
                            <FormTextField name="taxGroup" label="" placeholder="Enter tax group" />
                          </LabeledField>
                          <LabeledField label="Sales UoM Name">
                            <FormSelect name="salesUom" label="" placeholder="Select sales unit" options={uomOptions} />
                          </LabeledField>

                          <LabeledField label="Items per Sales Unit">
                            <FormTextField name="itemsPerSalesUnit" label="" type="number" placeholder="Items per Sales Unit" />
                          </LabeledField>
                          <LabeledField label="Packaging UoM Name">
                            <FormTextField name="salesPackagingUomName" label="" placeholder="Packaging UoM Name" />
                          </LabeledField>

                          <LabeledField label="Quantity per Package">
                            <FormTextField name="quantityPerSalesPackage" label="" type="number" placeholder="Quantity per Package" />
                          </LabeledField>
                          <LabeledField label="Width">
                            <FormTextField name="width" label="" type="number" placeholder="Width" />
                          </LabeledField>
                          <LabeledField label="Height">
                            <FormTextField name="height" label="" type="number" placeholder="Height" />
                          </LabeledField>

                          {/* Shared with the Purchase tab — see the volume
                              effect above. */}
                          <LabeledField label="Volume">
                            <FormTextField name="volume" label="" type="number" placeholder="Volume" disabled />
                          </LabeledField>
                          <LabeledField label="Weight">
                            <FormTextField name="weight" label="" type="number" placeholder="Weight" />
                          </LabeledField>
                        </FormGrid>
                      )}

                      {tab === 3 && (
                        <>
                          <FormGrid columns={2} singleColumnOnMobile spacing={FIELD_ROW_SPACING}>
                            <LabeledField label="Set G/L Accounts By *">
                              <FormSelect
                                name="glAccountsBy"
                                label=""
                                placeholder="Select level"
                                options={GL_ACCOUNTS_BY_OPTIONS}
                              />
                            </LabeledField>
                            
                            <LabeledField label="UoM Name">
                              <FormSelect name="inventoryUomName" label="" placeholder="Select unit" options={uomOptions} />
                            </LabeledField>
                     <LabeledField label="Valuation Method">
                              <FormSelect name="calculationMethod" label="" placeholder="Select method" options={CALCULATION_METHOD_OPTIONS} />
                            </LabeledField>
                            <LabeledField label="Minimum">
                              <FormTextField name="minimumLevel" label="" type="number" placeholder="Minimum" />
                            </LabeledField>
                              <LabeledField label="Weight">
                              <FormTextField name="weight" label="" type="number" placeholder="Weight" />
                            </LabeledField>
                            <LabeledField label="Maximum">
                              <FormTextField name="maximumLevel" label="" type="number" placeholder="Maximum" />
                            </LabeledField>

                      
       
                          </FormGrid>

                          {/* Per-warehouse stock — only meaningful once the
                              product exists, see the Tab label comment above. */}
                          <Divider sx={{ mt: 2, mb: 1.5 }} />
                          <ProductInventoryTab
                            productCode={editingRow?.productCode}
                            disabled={!editingRow}
                          />
                        </>
                      )}

                      <Divider sx={{ my: 3 }} />

                      <Stack direction="row" alignItems="center" justifyContent="space-between" flexWrap="wrap" gap={1.5}>
                        <FormCheckbox name="active" label="Active" />
                        <Stack direction="row" spacing={1.5}>
                          <Button variant="outlined" color="inherit" onClick={() => methods.reset(emptyValues)} disabled={creating || updating}>
                            Reset
                          </Button>
                          <FormSubmitButton disabled={creating || updating}>
                            {readOnly ? 'View' : editingRow ? 'Update Product' : 'Save Product'}
                          </FormSubmitButton>
                        </Stack>
                      </Stack>
                    </>
                  );
                }}
              </AppForm>
            </CardContent>
          </Card>
        </Box>
      </Collapse>

      <Card variant="outlined">
        <CardContent sx={{ p: 0 }}>
          <Stack direction="row" alignItems="center" justifyContent="space-between" flexWrap="wrap" gap={1.5} sx={{ px: 3, pt: 2.5, pb: 1.5 }}>
            <Typography variant="subtitle1" fontWeight={700}>Product List</Typography>
            <Stack direction="row" spacing={1.5} flexWrap="wrap" useFlexGap>
              <TableSearchFilter table={table} placeholder="Search products..." width={220} />
              <Button
                variant="outlined"
                color="inherit"
                startIcon={<FilterListIcon />}
                onClick={(e) => setFilterAnchor(e.currentTarget)}
              >
                Filter{statusFilter !== 'All' ? `: ${statusFilter}` : ''}
              </Button>
              <Menu anchorEl={filterAnchor} open={!!filterAnchor} onClose={() => setFilterAnchor(null)}>
                {STATUS_FILTERS.map((s) => (
                  <MenuItem key={s} selected={statusFilter === s} onClick={() => { setStatusFilter(s); setPage(0); setFilterAnchor(null); }}>
                    {statusFilter === s && <ListItemIcon><CheckIcon fontSize="small" /></ListItemIcon>}
                    <ListItemText inset={statusFilter !== s}>{s}</ListItemText>
                  </MenuItem>
                ))}
              </Menu>
              <CanAdd>
                <Button variant="contained" startIcon={<AddIcon />} onClick={openCreate}>
                  Add Product
                </Button>
              </CanAdd>
            </Stack>

            <TableFilterPanel table={table} />
          </Stack>

          {isMobile ? (
            <Box sx={{ px: 2, pb: 1 }}>
              {!isLoading && pagedRows.map((row) => (
                <MobileRecordCard
                  key={row.id}
                  title={row.productName}
                  statusChip={<Chip size="small" label={row.status} color={row.status === 'Active' ? 'success' : 'default'} variant="outlined" />}
                  fields={[
                    { label: 'Product Code', value: row.productCode },
                    { label: 'Group', value: row.productGroup || '—' },
                    { label: 'Brand', value: row.brand || '—' },
                    { label: 'Stock', value: row.currentStock != null ? Number(row.currentStock) : '—' },
                  ]}
                  onView={() => handleView(row)}
                  onEdit={() => handleEdit(row)}
                  onDelete={() => handleDelete(row)}
                />
              ))}
              {!isLoading && filteredRows.length === 0 && (
                <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>No products found</Typography>
              )}
            </Box>
          ) : (
            <ScrollableTableContainer>
              <Table size="small" stickyHeader>
                <TableHead>
                  <TableRow>
                    <TableCell width={48}>#</TableCell>
                    <SortableHeaderCell field="productCode" sort={table.sort} onSort={table.toggleSort}>Product Code</SortableHeaderCell>
                    <SortableHeaderCell field="productName" sort={table.sort} onSort={table.toggleSort}>Product Name</SortableHeaderCell>
                    <SortableHeaderCell field="productGroup" sort={table.sort} onSort={table.toggleSort}>Group</SortableHeaderCell>
                    <SortableHeaderCell field="brand" sort={table.sort} onSort={table.toggleSort}>Brand</SortableHeaderCell>
                    <SortableHeaderCell field="currentStock" sort={table.sort} onSort={table.toggleSort}>Stock</SortableHeaderCell>
                    <SortableHeaderCell field="status" sort={table.sort} onSort={table.toggleSort}>Status</SortableHeaderCell>
                    <TableCell align="right">Action</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {!isLoading && pagedRows.map((row, i) => (
                    <TableRow key={row.id} hover>
                      <TableCell>{page * pageSize + i + 1}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.productCode}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.productName}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.productGroup || '—'}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.brand || '—'}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.currentStock != null ? Number(row.currentStock) : '—'}</TableCell>
                      <TableCell>
                        <Chip size="small" label={row.status} color={row.status === 'Active' ? 'success' : 'default'} variant="outlined" />
                      </TableCell>
                      <TableCell align="right">
                        <Stack direction="row" spacing={0.5} justifyContent="flex-end">
                          <IconButton size="small" onClick={() => handleView(row)} aria-label="view">
                            <VisibilityOutlinedIcon fontSize="small" />
                          </IconButton>
                          <CanEdit>
                            <IconButton size="small" color="primary" onClick={() => handleEdit(row)} aria-label="edit">
                              <EditIcon fontSize="small" />
                            </IconButton>
                          </CanEdit>
                          <CanDelete>
                            <IconButton size="small" color="error" onClick={() => handleDelete(row)} aria-label="delete">
                              <DeleteIcon fontSize="small" />
                            </IconButton>
                          </CanDelete>
                        </Stack>
                      </TableCell>
                    </TableRow>
                  ))}
                  {!isLoading && filteredRows.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={8}>
                        <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>No products found</Typography>
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </ScrollableTableContainer>
          )}

          <EntityListPagination total={filteredRows.length} page={page} onChange={setPage} pageSize={pageSize} onPageSizeChange={(v) => { setPageSize(v); setPage(0); }} />
        </CardContent>
      </Card>
    </Box>
  );
}
