import React, { useMemo, useState } from 'react';
import {
  Box, Typography, Button, Card, CardContent, Stack, TextField, InputAdornment, Table,
  TableBody, TableCell, TableContainer, TableHead, TableRow, Chip, IconButton, Menu, MenuItem,
  ListItemIcon, ListItemText, Collapse, Checkbox,
} from '@mui/material';
import ArticleOutlinedIcon from '@mui/icons-material/ArticleOutlined';
import AddIcon from '@mui/icons-material/Add';
import CloseIcon from '@mui/icons-material/Close';
import SearchIcon from '@mui/icons-material/Search';
import FilterListIcon from '@mui/icons-material/FilterList';
import EditIcon from '@mui/icons-material/EditOutlined';
import DeleteIcon from '@mui/icons-material/DeleteOutline';
import CheckIcon from '@mui/icons-material/Check';
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import AppForm, { FormGrid, FormSubmitButton } from '../../components/form/AppForm';
import FormTextField from '../../components/form/FormTextField';
import FormSelect from '../../components/form/FormSelect';
import EntityHeaderCard from '../../components/common/EntityHeaderCard';
import CompanyBadge from '../../components/common/CompanyBadge';
import EntityListPagination from '../../components/data-display/EntityListPagination';
import MobileRecordCard from '../../components/data-display/MobileRecordCard';
import { useIsMobileListView } from '../../components/data-display/useIsMobileListView';
import useDragScroll from '../../components/data-display/useDragScroll';
import { useNotify } from '../../components/feedback/NotificationProvider';
import { applyServerErrors } from '../../lib/formErrors';
import { useConfirm } from '../../components/feedback/ConfirmationDialog';
import { productCatalogSchema } from '../../lib/validation/productSchemas';
import { productCatalogApi, productApi } from '../../features/resources';
import useTableFeatures from '../../components/data-display/useTableFeatures';
import TableSearchFilter from '../../components/data-display/TableSearchFilter';
import SortableHeaderCell from '../../components/data-display/SortableHeaderCell';
import ScrollableTableContainer from '../../components/data-display/ScrollableTableContainer';
import DocumentNoField from '../../components/form/DocumentNoField';

import { CanAdd, CanEdit, CanDelete } from '../../components/common/PermissionGate';
import TableFilterPanel from '../../components/data-display/TableFilterPanel';
const emptyValues = { catalogCode: '', catalogName: '', description: '', status: 'Active' };

const PAGE_SIZE = 10;
const STATUS_FILTERS = ['All', 'Active', 'Inactive'];

function toItem(product) {
  return {
    productCode: product.productCode,
    productName: product.productName,
    productGroup: product.productGroup || '',
    brand: product.brand || '',
    uom: product.uom || '',
    mrp: product.salesPrice != null ? Number(product.salesPrice) : 0,
  };
}

export default function ProductCatalog() {
  const notify = useNotify();
  const confirmDialog = useConfirm();
  const isMobile = useIsMobileListView();
  const { data: catalogs, isLoading } = productCatalogApi.useList();
  const { data: products } = productApi.useList();
  const [create, { isLoading: creating }] = productCatalogApi.useCreate();
  const [update, { isLoading: updating }] = productCatalogApi.useUpdate();
  const [remove] = productCatalogApi.useDelete();

  // View toggles between the catalog list and the full-page Create/Edit
  // form — same page, no dialog/popup, per the standard CRUD page template.
  const [view, setView] = useState('list');
  const [editingRow, setEditingRow] = useState(null);
  const [readOnly, setReadOnly] = useState(false);
  const [formKey, setFormKey] = useState(0);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [filterAnchor, setFilterAnchor] = useState(null);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(PAGE_SIZE);

  // Mapped-products state lives outside the AppForm/zod-validated fields —
  // it's a picker-driven list, not a set of typed inputs.
  const [items, setItems] = useState([]);
  const [checkedCodes, setCheckedCodes] = useState([]);
  const [showPicker, setShowPicker] = useState(false);
  const [pickerChecked, setPickerChecked] = useState([]);

  const rows = catalogs || [];

  const baseTableRows = useMemo(() => {
    const q = '';
    return rows.filter((r) => {
      const matchesSearch = !q || [r.catalogCode, r.catalogName, r.description]
        .some((v) => String(v || '').toLowerCase().includes(q));
      const matchesStatus = statusFilter === 'All' || r.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [rows, statusFilter]);

  // Column definitions drive the global search, the sort icons and the filter
  // popover — see components/data-display/useTableFeatures.js.
  const tableColumns = useMemo(() => ([
    { field: 'catalogCode', headerName: 'Catalog Code', filter: 'text' },
    { field: 'catalogName', headerName: 'Catalog Name', filter: 'text' },
    { field: 'description', headerName: 'Description', filter: 'text' },
    { field: 'items', headerName: 'Products', filter: 'text' },
    { field: 'status', headerName: 'Status', filter: 'select' },
  ]), []);
  const table = useTableFeatures(baseTableRows, tableColumns, { onChange: setPage });
  const filteredRows = table.rows;

  const pagedRows = useMemo(
    () => filteredRows.slice(page * pageSize, page * pageSize + pageSize),
    [filteredRows, page, pageSize]
  );

  const availableProducts = useMemo(() => {
    const mappedCodes = new Set(items.map((i) => i.productCode));
    // Text search is handled by useTableFeatures; this only excludes
    // products already mapped into the catalog.
    return (products || []).filter((p) => !mappedCodes.has(p.productCode));
  }, [products, items]);

  // Both catalog tables — the "add products" picker and the mapped-items
  // list — get search, sorting and column filters of their own.
  const productColumns = useMemo(() => ([
    { field: 'productCode', headerName: 'Product Code', filter: 'text' },
    { field: 'productName', headerName: 'Product Name', filter: 'text' },
    { field: 'productGroup', headerName: 'Product Group', filter: 'select' },
    { field: 'brand', headerName: 'Brand', filter: 'select' },
    { field: 'uom', headerName: 'Unit', filter: 'select' },
    { field: 'mrp', headerName: 'MRP (₹)', filter: 'numberRange', sortValue: (r) => Number(r.mrp) || 0 },
  ]), []);
  const pickerTable = useTableFeatures(availableProducts, productColumns);
  const itemsTable = useTableFeatures(items, productColumns);

  const openCreate = () => {
    setEditingRow(null);
    setReadOnly(false);
    setItems([]);
    setCheckedCodes([]);
    setShowPicker(false);
    setFormKey((k) => k + 1);
    setView('form');
  };

  const backToList = () => {
    setView('list');
    setEditingRow(null);
    setShowPicker(false);
    setPickerChecked([]);
  };

  // Read-only look at a record — same form, every field disabled
  // and the save button removed (see AppForm's readOnly prop).
  const handleView = (row) => {
    setEditingRow(row);
    setReadOnly(true);
    setItems((row.items || []).map((i) => ({
      productCode: i.productCode, productName: i.productName, productGroup: i.productGroup || '',
      brand: i.brand || '', uom: i.uom || '', mrp: i.mrp != null ? Number(i.mrp) : 0,
    })));
    setCheckedCodes([]);
    setShowPicker(false);
    setFormKey((k) => k + 1);
    setView('form');
  };

  const handleEdit = (row) => {
    setEditingRow(row);
    setReadOnly(false);
    setItems((row.items || []).map((i) => ({
      productCode: i.productCode, productName: i.productName, productGroup: i.productGroup || '',
      brand: i.brand || '', uom: i.uom || '', mrp: i.mrp != null ? Number(i.mrp) : 0,
    })));
    setCheckedCodes([]);
    setShowPicker(false);
    setFormKey((k) => k + 1);
    setView('form');
  };

  const handleDelete = async (row) => {
    const ok = await confirmDialog({
      title: 'Delete catalog',
      message: `Are you sure you want to delete "${row.catalogName}"? This cannot be undone.`,
      confirmLabel: 'Delete',
      severity: 'error',
    });
    if (!ok) return;
    try {
      await remove(row.id).unwrap();
      notify.success('Catalog deleted');
    } catch (err) {
      notify.error(err?.data?.message || 'Delete failed');
    }
  };

  const handleAddSelected = () => {
    const toAdd = availableProducts.filter((p) => pickerChecked.includes(p.productCode)).map(toItem);
    setItems((prev) => [...prev, ...toAdd]);
    setPickerChecked([]);
    setShowPicker(false);
  };

  const togglePickerChecked = (code) => {
    setPickerChecked((prev) => (prev.includes(code) ? prev.filter((c) => c !== code) : [...prev, code]));
  };

  const toggleRowChecked = (code) => {
    setCheckedCodes((prev) => (prev.includes(code) ? prev.filter((c) => c !== code) : [...prev, code]));
  };

  const removeItem = (productCode) => {
    setItems((prev) => prev.filter((i) => i.productCode !== productCode));
    setCheckedCodes((prev) => prev.filter((c) => c !== productCode));
  };

  const removeSelected = () => {
    setItems((prev) => prev.filter((i) => !checkedCodes.includes(i.productCode)));
    setCheckedCodes([]);
  };

  const handleSubmit = async (values, formMethods) => {
    const payload = { ...values, items };
    try {
      if (editingRow) {
        await update({ id: editingRow.id, ...payload }).unwrap();
        notify.success('Catalog updated');
      } else {
        await create(payload).unwrap();
        notify.success('Catalog added');
      }
      backToList();
    } catch (err) {
      notify.error(applyServerErrors(err, formMethods.setError));
    }
  };

  const allChecked = items.length > 0 && checkedCodes.length === items.length;
  const someChecked = checkedCodes.length > 0 && !allChecked;

  return (
    <Box>
      <EntityHeaderCard
        icon={<ArticleOutlinedIcon />}
        title={view === 'form' ? 'Create / Edit Product Catalog' : 'Product Catalog'}
        subtitle={view === 'form' ? 'Create a new product catalog and map multiple products.' : 'Create and manage product catalogs.'}
        rightContent={<CompanyBadge />}
      />

      {view === 'form' ? (
        <AppForm readOnly={readOnly}
          key={formKey}
          schema={productCatalogSchema}
          defaultValues={editingRow ? { ...emptyValues, ...editingRow } : emptyValues}
          onSubmit={handleSubmit}
        >
          {() => (
            <>
              <Card variant="outlined" sx={{ mb: 2 }}>
                <CardContent sx={{ p: 3 }}>
                  <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 2 }}>
                    Catalog Information
                  </Typography>
                  <FormGrid columns={4}>
                    {/* Auto-generated from the perpetual CAT numbering series (hidden from
                        the Document Numbering page — see hiddenFromNumberingUI in
                        documentNumberService.js). The field is filled and locked on
                        create, and left untouched on edit so an existing record's code
                        is never rewritten. */}
                    <DocumentNoField documentCode="CAT" name="catalogCode" label="Catalog Code *" isCreate={!editingRow} />
                    <FormTextField name="catalogName" label="Catalog Name *" placeholder="Enter catalog name" />
                    <FormTextField name="description" label="Description" placeholder="Enter description (optional)" />
                    <FormSelect
                      name="status"
                      label="Status"
                      options={[{ label: 'Active', value: 'Active' }, { label: 'Inactive', value: 'Inactive' }]}
                    />
                  </FormGrid>
                </CardContent>
              </Card>

              <Card variant="outlined">
                <CardContent sx={{ p: 0 }}>
                  <Stack direction="row" alignItems="flex-start" justifyContent="space-between" flexWrap="wrap" gap={1.5} sx={{ px: 3, pt: 2.5, pb: 1.5 }}>
                    <Box>
                      <Typography variant="subtitle1" fontWeight={700}>Mapped Products</Typography>
                      <Typography variant="body2" color="text.secondary">Add multiple products to this catalog.</Typography>
                    </Box>
                    <Stack direction="row" spacing={1.5} flexWrap="wrap" useFlexGap>
                      {checkedCodes.length > 0 && (
                        <Button variant="outlined" color="error" startIcon={<DeleteIcon />} onClick={removeSelected}>
                          Remove Selected ({checkedCodes.length})
                        </Button>
                      )}
                      <Button
                        variant="outlined"
                        color="inherit"
                        startIcon={<FilterListIcon />}
                        onClick={(e) => setFilterAnchor(e.currentTarget)}
                      >
                        Filter
                      </Button>
                      <Menu anchorEl={filterAnchor} open={!!filterAnchor} onClose={() => setFilterAnchor(null)}>
                        <MenuItem onClick={() => setFilterAnchor(null)}>All Products</MenuItem>
                      </Menu>
                      <Button
                        variant="contained"
                        startIcon={showPicker ? <CloseIcon /> : <AddIcon />}
                        onClick={() => setShowPicker((v) => !v)}
                      >
                        {showPicker ? 'Close' : 'Add Products'}
                      </Button>
                    </Stack>
                  </Stack>

                  <Collapse in={showPicker} unmountOnExit>
                    <Box sx={{ px: 3, pb: 2 }}>
                      <Card variant="outlined" sx={{ bgcolor: 'action.hover' }}>
                        <CardContent>
                          <Stack direction="row" alignItems="center" justifyContent="space-between" flexWrap="wrap" gap={1.5} sx={{ mb: 1.5 }}>
                            <TableSearchFilter table={pickerTable} placeholder="Search products to add..." width={240} />
                            <Button
                              variant="contained"
                              size="small"
                              disabled={pickerChecked.length === 0}
                              onClick={handleAddSelected}
                            >
                              Add Selected ({pickerChecked.length})
                            </Button>
                          </Stack>

                          <TableFilterPanel table={pickerTable} />
                          <ScrollableTableContainer maxHeight="min(45vh, 320px)">
                            <Table size="small" stickyHeader>
                              <TableHead>
                                <TableRow>
                                  <TableCell padding="checkbox" />
                                  <SortableHeaderCell field="productCode" sort={pickerTable.sort} onSort={pickerTable.toggleSort}>Product Code</SortableHeaderCell>
                                  <SortableHeaderCell field="productName" sort={pickerTable.sort} onSort={pickerTable.toggleSort}>Product Name</SortableHeaderCell>
                                  <SortableHeaderCell field="productGroup" sort={pickerTable.sort} onSort={pickerTable.toggleSort}>Product Group</SortableHeaderCell>
                                  <SortableHeaderCell field="brand" sort={pickerTable.sort} onSort={pickerTable.toggleSort}>Brand</SortableHeaderCell>
                                  <SortableHeaderCell field="mrp" sort={pickerTable.sort} onSort={pickerTable.toggleSort}>MRP (₹)</SortableHeaderCell>
                                </TableRow>
                              </TableHead>
                              <TableBody>
                                {pickerTable.rows.map((p) => (
                                  <TableRow
                                    key={p.productCode}
                                    hover
                                    onClick={() => togglePickerChecked(p.productCode)}
                                    sx={{ cursor: 'pointer' }}
                                  >
                                    <TableCell padding="checkbox">
                                      <Checkbox
                                        size="small"
                                        checked={pickerChecked.includes(p.productCode)}
                                        onClick={(e) => e.stopPropagation()}
                                        onChange={() => togglePickerChecked(p.productCode)}
                                      />
                                    </TableCell>
                                    <TableCell sx={{ whiteSpace: 'nowrap' }}>{p.productCode}</TableCell>
                                    <TableCell sx={{ whiteSpace: 'nowrap' }}>{p.productName}</TableCell>
                                    <TableCell sx={{ whiteSpace: 'nowrap' }}>{p.productGroup || '—'}</TableCell>
                                    <TableCell sx={{ whiteSpace: 'nowrap' }}>{p.brand || '—'}</TableCell>
                                    <TableCell sx={{ whiteSpace: 'nowrap' }}>{p.salesPrice != null ? Number(p.salesPrice).toFixed(2) : '—'}</TableCell>
                                  </TableRow>
                                ))}
                                {availableProducts.length === 0 && (
                                  <TableRow>
                                    <TableCell colSpan={6}>
                                      <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 2 }}>
                                        No matching products
                                      </Typography>
                                    </TableCell>
                                  </TableRow>
                                )}
                              </TableBody>
                            </Table>
                          </ScrollableTableContainer>
                        </CardContent>
                      </Card>
                    </Box>
                  </Collapse>

                  {isMobile ? (
                    <Box sx={{ px: 2, pb: 1 }}>
                      {items.map((item) => (
                        <MobileRecordCard
                          key={item.productCode}
                          title={item.productName}
                          fields={[
                            { label: 'Product Code', value: item.productCode },
                            { label: 'Group', value: item.productGroup || '—' },
                            { label: 'Brand', value: item.brand || '—' },
                            { label: 'Unit', value: item.uom || '—' },
                            { label: 'MRP (₹)', value: Number(item.mrp).toFixed(2) },
                          ]}
                          onDelete={() => removeItem(item.productCode)}
                        />
                      ))}
                      {items.length === 0 && (
                        <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>No products mapped yet</Typography>
                      )}
                    </Box>
                  ) : (
                    <>
                    <Stack direction="row" justifyContent="flex-end" sx={{ px: 1, pb: 1 }}>
                      <TableSearchFilter table={itemsTable} placeholder="Search mapped products..." width={220} />
                    </Stack>

                    <TableFilterPanel table={itemsTable} />
                    <ScrollableTableContainer maxHeight="min(55vh, 420px)">
                      <Table size="small" stickyHeader>
                        <TableHead>
                          <TableRow>
                            <TableCell padding="checkbox">
                              <Checkbox
                                size="small"
                                indeterminate={someChecked}
                                checked={allChecked}
                                onChange={(e) => setCheckedCodes(e.target.checked ? items.map((i) => i.productCode) : [])}
                              />
                            </TableCell>
                            <TableCell width={48}>#</TableCell>
                            <SortableHeaderCell field="productCode" sort={itemsTable.sort} onSort={itemsTable.toggleSort}>Product Code</SortableHeaderCell>
                            <SortableHeaderCell field="productName" sort={itemsTable.sort} onSort={itemsTable.toggleSort}>Product Name</SortableHeaderCell>
                            <SortableHeaderCell field="productGroup" sort={itemsTable.sort} onSort={itemsTable.toggleSort}>Product Group</SortableHeaderCell>
                            <SortableHeaderCell field="brand" sort={itemsTable.sort} onSort={itemsTable.toggleSort}>Brand</SortableHeaderCell>
                            <SortableHeaderCell field="uom" sort={itemsTable.sort} onSort={itemsTable.toggleSort}>Unit</SortableHeaderCell>
                            <SortableHeaderCell field="mrp" sort={itemsTable.sort} onSort={itemsTable.toggleSort}>MRP (₹)</SortableHeaderCell>
                            <TableCell align="right">Action</TableCell>
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {itemsTable.rows.map((item, i) => (
                            <TableRow key={item.productCode} hover>
                              <TableCell padding="checkbox">
                                <Checkbox
                                  size="small"
                                  checked={checkedCodes.includes(item.productCode)}
                                  onChange={() => toggleRowChecked(item.productCode)}
                                />
                              </TableCell>
                              <TableCell>{i + 1}</TableCell>
                              <TableCell sx={{ whiteSpace: 'nowrap' }}>{item.productCode}</TableCell>
                              <TableCell sx={{ whiteSpace: 'nowrap' }}>{item.productName}</TableCell>
                              <TableCell sx={{ whiteSpace: 'nowrap' }}>{item.productGroup || '—'}</TableCell>
                              <TableCell sx={{ whiteSpace: 'nowrap' }}>{item.brand || '—'}</TableCell>
                              <TableCell sx={{ whiteSpace: 'nowrap' }}>{item.uom || '—'}</TableCell>
                              <TableCell sx={{ whiteSpace: 'nowrap' }}>{Number(item.mrp).toFixed(2)}</TableCell>
                              <TableCell align="right">
                                <CanDelete>
                                  <IconButton size="small" color="error" onClick={() => removeItem(item.productCode)} aria-label="delete">
                                    <DeleteIcon fontSize="small" />
                                  </IconButton>
                                </CanDelete>
                              </TableCell>
                            </TableRow>
                          ))}
                          {itemsTable.rows.length === 0 && (
                            <TableRow>
                              <TableCell colSpan={9}>
                                <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>No products mapped yet</Typography>
                              </TableCell>
                            </TableRow>
                          )}
                        </TableBody>
                      </Table>
                    </ScrollableTableContainer>
                    </>
                  )}

                  <Stack direction="row" alignItems="center" justifyContent="space-between" flexWrap="wrap" gap={1.5} sx={{ px: 3, py: 2 }}>
                    <Typography variant="body2" color="text.secondary">
                      {itemsTable.rows.length > 0 ? `Showing 1 to ${itemsTable.rows.length} of ${items.length} products` : 'No products mapped yet'}
                    </Typography>
                    <Chip label={`Total Products: ${items.length}`} variant="outlined" />
                  </Stack>
                </CardContent>
              </Card>

              <Stack direction="row" spacing={1.5} justifyContent="flex-end" sx={{ mt: 2 }}>
                <Button variant="outlined" color={readOnly ? 'error' : 'inherit'} onClick={backToList} disabled={creating || updating}>
                  {readOnly ? 'Close' : 'Cancel'}
                </Button>
                <FormSubmitButton disabled={creating || updating}>
                  {readOnly ? 'View' : editingRow ? 'Update Catalog' : 'Save Catalog'}
                </FormSubmitButton>
              </Stack>
            </>
          )}
        </AppForm>
      ) : (
        <Card variant="outlined">
          <CardContent sx={{ p: 0 }}>
            <Stack direction="row" alignItems="center" justifyContent="space-between" flexWrap="wrap" gap={1.5} sx={{ px: 3, pt: 2.5, pb: 1.5 }}>
              <Typography variant="subtitle1" fontWeight={700}>Product Catalog List</Typography>
              <Stack direction="row" spacing={1.5} flexWrap="wrap" useFlexGap>
                <TableSearchFilter table={table} placeholder="Search catalogs..." width={220} />
                <Button
                  variant="outlined"
                  color="inherit"
                  startIcon={<FilterListIcon />}
                  onClick={(e) => setFilterAnchor(e.currentTarget)}
                >
                  Filter{statusFilter !== 'All' ? `: ${statusFilter}` : ''}
                </Button>
                <Menu anchorEl={filterAnchor} open={!!filterAnchor} onClose={() => setFilterAnchor(null)}>
                  {STATUS_FILTERS.map((s) => (
                    <MenuItem key={s} selected={statusFilter === s} onClick={() => { setStatusFilter(s); setPage(0); setFilterAnchor(null); }}>
                      {statusFilter === s && <ListItemIcon><CheckIcon fontSize="small" /></ListItemIcon>}
                      <ListItemText inset={statusFilter !== s}>{s}</ListItemText>
                    </MenuItem>
                  ))}
                </Menu>
                <CanAdd>
                  <Button variant="contained" startIcon={<AddIcon />} onClick={openCreate}>
                    Add Catalog
                  </Button>
                </CanAdd>
              </Stack>

              <TableFilterPanel table={table} />
            </Stack>

            {isMobile ? (
              <Box sx={{ px: 2, pb: 1 }}>
                {!isLoading && pagedRows.map((row) => (
                  <MobileRecordCard
                    key={row.id}
                    title={row.catalogName}
                    statusChip={<Chip size="small" label={row.status} color={row.status === 'Active' ? 'success' : 'default'} variant="outlined" />}
                    fields={[
                      { label: 'Catalog Code', value: row.catalogCode },
                      { label: 'Products', value: (row.items || []).length },
                      { label: 'Description', value: row.description || '—' },
                    ]}
                    onView={() => handleView(row)}
                    onEdit={() => handleEdit(row)}
                    onDelete={() => handleDelete(row)}
                  />
                ))}
                {!isLoading && filteredRows.length === 0 && (
                  <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>No catalogs found</Typography>
                )}
              </Box>
            ) : (
              <ScrollableTableContainer>
                <Table size="small" stickyHeader>
                  <TableHead>
                    <TableRow>
                      <TableCell width={48}>#</TableCell>
                      <SortableHeaderCell field="catalogCode" sort={table.sort} onSort={table.toggleSort}>Catalog Code</SortableHeaderCell>
                      <SortableHeaderCell field="catalogName" sort={table.sort} onSort={table.toggleSort}>Catalog Name</SortableHeaderCell>
                      <SortableHeaderCell field="description" sort={table.sort} onSort={table.toggleSort}>Description</SortableHeaderCell>
                      <SortableHeaderCell field="items" sort={table.sort} onSort={table.toggleSort}>Products</SortableHeaderCell>
                      <SortableHeaderCell field="status" sort={table.sort} onSort={table.toggleSort}>Status</SortableHeaderCell>
                      <TableCell align="right">Action</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {!isLoading && pagedRows.map((row, i) => (
                      <TableRow key={row.id} hover>
                        <TableCell>{page * pageSize + i + 1}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.catalogCode}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.catalogName}</TableCell>
                        <TableCell sx={{ maxWidth: 320 }}>{row.description || '—'}</TableCell>
                        <TableCell>{(row.items || []).length}</TableCell>
                        <TableCell>
                          <Chip size="small" label={row.status} color={row.status === 'Active' ? 'success' : 'default'} variant="outlined" />
                        </TableCell>
                        <TableCell align="right">
                          <Stack direction="row" spacing={0.5} justifyContent="flex-end">
                            <IconButton size="small" onClick={() => handleView(row)} aria-label="view">
                              <VisibilityOutlinedIcon fontSize="small" />
                            </IconButton>
                            <CanEdit>
                              <IconButton size="small" color="primary" onClick={() => handleEdit(row)} aria-label="edit">
                                <EditIcon fontSize="small" />
                              </IconButton>
                            </CanEdit>
                            <CanDelete>
                              <IconButton size="small" color="error" onClick={() => handleDelete(row)} aria-label="delete">
                                <DeleteIcon fontSize="small" />
                              </IconButton>
                            </CanDelete>
                          </Stack>
                        </TableCell>
                      </TableRow>
                    ))}
                    {!isLoading && filteredRows.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={7}>
                          <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>No catalogs found</Typography>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </ScrollableTableContainer>
            )}

            <EntityListPagination total={filteredRows.length} page={page} onChange={setPage} pageSize={pageSize} onPageSizeChange={(v) => { setPageSize(v); setPage(0); }} />
          </CardContent>
        </Card>
      )}
    </Box>
  );
}
