import React, { useMemo, useState } from 'react';
import {
  Box, Typography, Button, Card, CardContent, Stack, TextField, Table, TableBody, TableCell,
  TableHead, TableRow, Chip, IconButton, Menu, MenuItem, ListItemIcon, ListItemText, Collapse,
  Checkbox, SvgIcon,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import PrintOutlinedIcon from '@mui/icons-material/PrintOutlined';
import SearchIcon from '@mui/icons-material/Search';
import FilterListIcon from '@mui/icons-material/FilterList';
import EditIcon from '@mui/icons-material/EditOutlined';
import DeleteIcon from '@mui/icons-material/DeleteOutline';
import CheckIcon from '@mui/icons-material/Check';
import BarcodeSvg from '../../components/common/BarcodeSvg';
import EntityHeaderCard from '../../components/common/EntityHeaderCard';
import CompanyBadge from '../../components/common/CompanyBadge';
import EntityListPagination from '../../components/data-display/EntityListPagination';
import MobileRecordCard from '../../components/data-display/MobileRecordCard';
import { useIsMobileListView } from '../../components/data-display/useIsMobileListView';
import useDragScroll from '../../components/data-display/useDragScroll';
import { useNotify } from '../../components/feedback/NotificationProvider';
import { useConfirm } from '../../components/feedback/ConfirmationDialog';
import { productApi } from '../../features/resources';
import useTableFeatures from '../../components/data-display/useTableFeatures';
import TableSearchFilter from '../../components/data-display/TableSearchFilter';
import SortableHeaderCell from '../../components/data-display/SortableHeaderCell';
import ScrollableTableContainer from '../../components/data-display/ScrollableTableContainer';

import { CanEdit, CanDelete } from '../../components/common/PermissionGate';
import TableFilterPanel from '../../components/data-display/TableFilterPanel';
// No stock MUI icon renders as a barcode glyph — a small custom one keeps
// the header consistent with every other page's circular icon treatment.
function BarcodeGlyphIcon(props) {
  const bars = [2, 1, 2, 1, 1, 2, 1, 3, 1, 2, 1, 1, 2];
  let x = 3;
  return (
    <SvgIcon {...props} viewBox="0 0 24 24">
      {bars.map((w, i) => {
        const rect = <rect key={i} x={x} y={4} width={w * 0.6} height={16} fill="currentColor" />;
        x += w * 0.6 + 0.7;
        return rect;
      })}
    </SvgIcon>
  );
}

const PAGE_SIZE = 10;
const STATUS_FILTERS = ['All', 'Active', 'Inactive'];

export default function Barcode() {
  const notify = useNotify();
  const confirmDialog = useConfirm();
  const isMobile = useIsMobileListView();
  const { data: products, isLoading } = productApi.useList();
  const [update] = productApi.useUpdate();

  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [filterAnchor, setFilterAnchor] = useState(null);
  const [genMenuAnchor, setGenMenuAnchor] = useState(null);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(PAGE_SIZE);
  const [checkedCodes, setCheckedCodes] = useState([]);
  const [editingRow, setEditingRow] = useState(null);
  const [editValue, setEditValue] = useState('');
  const [busy, setBusy] = useState(false);

  const rows = products || [];

  const baseTableRows = useMemo(() => {
    const q = '';
    return rows.filter((r) => {
      const matchesSearch = !q || [r.productCode, r.productName].some((v) => String(v || '').toLowerCase().includes(q));
      const matchesStatus = statusFilter === 'All' || r.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [rows, statusFilter]);

  // Column definitions drive the global search, the sort icons and the filter
  // popover — see components/data-display/useTableFeatures.js.
  const tableColumns = useMemo(() => ([
    { field: 'productCode', headerName: 'Product Code', filter: 'text' },
    { field: 'productName', headerName: 'Product Name', filter: 'text' },
    { field: 'barcode', headerName: 'Barcode (Product Code)', filter: 'text' },
    { field: 'status', headerName: 'Status', filter: 'select' },
  ]), []);
  const table = useTableFeatures(baseTableRows, tableColumns, { onChange: setPage });
  const filteredRows = table.rows;

  const pagedRows = useMemo(
    () => filteredRows.slice(page * pageSize, page * pageSize + pageSize),
    [filteredRows, page, pageSize]
  );

  const allChecked = pagedRows.length > 0 && pagedRows.every((r) => checkedCodes.includes(r.productCode));
  const someChecked = pagedRows.some((r) => checkedCodes.includes(r.productCode)) && !allChecked;

  const toggleRowChecked = (code) => {
    setCheckedCodes((prev) => (prev.includes(code) ? prev.filter((c) => c !== code) : [...prev, code]));
  };

  const closeEditor = () => {
    setEditingRow(null);
    setEditValue('');
  };

  const handleEdit = (row) => {
    setEditingRow(row);
    setEditValue(row.barcode || row.productCode || '');
  };

  const handleSaveBarcode = async () => {
    if (!editingRow) return;
    setBusy(true);
    try {
      await update({ id: editingRow.id, barcode: editValue.trim() }).unwrap();
      notify.success('Barcode saved');
      closeEditor();
    } catch (err) {
      notify.error(err?.data?.message || 'Save failed');
    } finally {
      setBusy(false);
    }
  };

  const handleDelete = async (row) => {
    const ok = await confirmDialog({
      title: 'Remove barcode',
      message: `Remove the barcode for "${row.productName}"? The product record itself will not be deleted.`,
      confirmLabel: 'Remove',
      severity: 'error',
    });
    if (!ok) return;
    try {
      await update({ id: row.id, barcode: null }).unwrap();
      notify.success('Barcode removed');
    } catch (err) {
      notify.error(err?.data?.message || 'Remove failed');
    }
  };

  const handleGenerate = async (mode) => {
    setGenMenuAnchor(null);
    const targets = mode === 'selected'
      ? rows.filter((r) => checkedCodes.includes(r.productCode) && !r.barcode)
      : rows.filter((r) => !r.barcode);
    if (targets.length === 0) {
      notify.info(mode === 'selected' ? 'Selected products already have barcodes' : 'Every product already has a barcode');
      return;
    }
    setBusy(true);
    try {
      await Promise.all(targets.map((r) => update({ id: r.id, barcode: r.productCode }).unwrap()));
      notify.success(`Generated ${targets.length} barcode${targets.length > 1 ? 's' : ''}`);
    } catch (err) {
      notify.error(err?.data?.message || 'Generate failed');
    } finally {
      setBusy(false);
    }
  };

  const printRows = useMemo(() => {
    const source = checkedCodes.length > 0 ? rows.filter((r) => checkedCodes.includes(r.productCode)) : filteredRows;
    return source.filter((r) => r.barcode);
  }, [rows, filteredRows, checkedCodes]);

  const handlePrint = () => {
    if (printRows.length === 0) {
      notify.info('No generated barcodes to print — generate barcodes first');
      return;
    }
    window.print();
  };

  return (
    <Box>
      <style>{`
        .barcode-print-area { display: none; }
        @media print {
          body * { visibility: hidden; }
          .barcode-print-area, .barcode-print-area * { visibility: visible; }
          .barcode-print-area {
            display: block; position: absolute; top: 0; left: 0; width: 100%;
            padding: 16px; box-sizing: border-box;
          }
        }
      `}</style>

      <EntityHeaderCard
        icon={<BarcodeGlyphIcon />}
        title="Barcode"
        subtitle="Generate and manage product barcodes."
        rightContent={<CompanyBadge />}
      />

      <Card variant="outlined">
        <CardContent sx={{ p: 0 }}>
          <Stack direction="row" alignItems="center" justifyContent="space-between" flexWrap="wrap" gap={1.5} sx={{ px: 3, pt: 2.5, pb: 1.5 }}>
            <Typography variant="subtitle1" fontWeight={700}>Barcode List</Typography>
            <Stack direction="row" spacing={1.5} flexWrap="wrap" useFlexGap>
              <TableSearchFilter table={table} placeholder="Search by product code or name..." width={260} />
              <Button
                variant="outlined"
                color="inherit"
                startIcon={<FilterListIcon />}
                onClick={(e) => setFilterAnchor(e.currentTarget)}
              >
                Filter{statusFilter !== 'All' ? `: ${statusFilter}` : ''}
              </Button>
              <Menu anchorEl={filterAnchor} open={!!filterAnchor} onClose={() => setFilterAnchor(null)}>
                {STATUS_FILTERS.map((s) => (
                  <MenuItem key={s} selected={statusFilter === s} onClick={() => { setStatusFilter(s); setPage(0); setFilterAnchor(null); }}>
                    {statusFilter === s && <ListItemIcon><CheckIcon fontSize="small" /></ListItemIcon>}
                    <ListItemText inset={statusFilter !== s}>{s}</ListItemText>
                  </MenuItem>
                ))}
              </Menu>
              <Button
                variant="contained"
                startIcon={<AddIcon />}
                endIcon={<ArrowDropDownIcon />}
                onClick={(e) => setGenMenuAnchor(e.currentTarget)}
                disabled={busy}
              >
                Generate Barcode
              </Button>
              <Menu anchorEl={genMenuAnchor} open={!!genMenuAnchor} onClose={() => setGenMenuAnchor(null)}>
                <MenuItem onClick={() => handleGenerate('selected')} disabled={checkedCodes.length === 0}>
                  Generate for Selected ({checkedCodes.length})
                </MenuItem>
                <MenuItem onClick={() => handleGenerate('missing')}>
                  Generate for All Missing
                </MenuItem>
              </Menu>
              <Button variant="outlined" color="inherit" startIcon={<PrintOutlinedIcon />} onClick={handlePrint}>
                Print Barcodes
              </Button>
            </Stack>

            <TableFilterPanel table={table} />
          </Stack>

          <Collapse in={!!editingRow} unmountOnExit>
            {editingRow && (
              <Box sx={{ px: 3, pb: 2 }}>
                <Card variant="outlined" sx={{ bgcolor: 'action.hover' }}>
                  <CardContent>
                    <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1.5 }}>
                      Edit Barcode — {editingRow.productName}
                    </Typography>
                    <Stack direction="row" spacing={1.5} alignItems="center" flexWrap="wrap" useFlexGap>
                      <TextField
                        size="small"
                        label="Barcode Value"
                        value={editValue}
                        onChange={(e) => setEditValue(e.target.value)}
                        sx={{ minWidth: 240 }}
                      />
                      <Button variant="outlined" color="inherit" onClick={closeEditor} disabled={busy}>Cancel</Button>
                      <Button variant="contained" onClick={handleSaveBarcode} disabled={busy || !editValue.trim()}>Save</Button>
                    </Stack>
                  </CardContent>
                </Card>
              </Box>
            )}
          </Collapse>

          {isMobile ? (
            <Box sx={{ px: 2, pb: 1 }}>
              {!isLoading && pagedRows.map((row) => (
                <MobileRecordCard
                  key={row.id}
                  title={row.productName}
                  statusChip={<Chip size="small" label={row.status} color={row.status === 'Active' ? 'success' : 'default'} variant="outlined" />}
                  fields={[
                    { label: 'Product Code', value: row.productCode },
                    { label: 'Barcode', value: row.barcode ? <BarcodeSvg value={row.barcode} height={32} /> : 'Not generated' },
                  ]}
                  onEdit={() => handleEdit(row)}
                  onDelete={() => handleDelete(row)}
                />
              ))}
              {!isLoading && filteredRows.length === 0 && (
                <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>No products found</Typography>
              )}
            </Box>
          ) : (
            <ScrollableTableContainer>
              <Table size="small" stickyHeader>
                <TableHead>
                  <TableRow>
                    <SortableHeaderCell field="productCode" sort={table.sort} onSort={table.toggleSort} padding="checkbox">
                      <Checkbox
                        size="small"
                        indeterminate={someChecked}
                        checked={allChecked}
                        onChange={(e) => {
                          const codes = pagedRows.map((r) => r.productCode);
                          setCheckedCodes((prev) => e.target.checked
                            ? Array.from(new Set([...prev, ...codes]))
                            : prev.filter((c) => !codes.includes(c)));
                        }}
                      />
                    </SortableHeaderCell>
                    <TableCell width={48}>#</TableCell>
                    <TableCell>Product Code</TableCell>
                    <SortableHeaderCell field="productName" sort={table.sort} onSort={table.toggleSort}>Product Name</SortableHeaderCell>
                    <SortableHeaderCell field="barcode" sort={table.sort} onSort={table.toggleSort}>Barcode (Product Code)</SortableHeaderCell>
                    <SortableHeaderCell field="status" sort={table.sort} onSort={table.toggleSort}>Status</SortableHeaderCell>
                    <TableCell align="right">Action</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {!isLoading && pagedRows.map((row, i) => (
                    <TableRow key={row.id} hover>
                      <TableCell padding="checkbox">
                        <Checkbox size="small" checked={checkedCodes.includes(row.productCode)} onChange={() => toggleRowChecked(row.productCode)} />
                      </TableCell>
                      <TableCell>{page * pageSize + i + 1}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.productCode}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.productName}</TableCell>
                      <TableCell>
                        {row.barcode ? (
                          <BarcodeSvg value={row.barcode} height={34} />
                        ) : (
                          <Typography variant="body2" color="text.secondary">Not generated</Typography>
                        )}
                      </TableCell>
                      <TableCell>
                        <Chip size="small" label={row.status} color={row.status === 'Active' ? 'success' : 'default'} variant="outlined" />
                      </TableCell>
                      <TableCell align="right">
                        <Stack direction="row" spacing={0.5} justifyContent="flex-end">
                          <CanEdit>
                            <IconButton size="small" color="primary" onClick={() => handleEdit(row)} aria-label="edit">
                              <EditIcon fontSize="small" />
                            </IconButton>
                          </CanEdit>
                          <CanDelete>
                            <IconButton size="small" color="error" onClick={() => handleDelete(row)} aria-label="delete" disabled={!row.barcode}>
                              <DeleteIcon fontSize="small" />
                            </IconButton>
                          </CanDelete>
                        </Stack>
                      </TableCell>
                    </TableRow>
                  ))}
                  {!isLoading && filteredRows.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={7}>
                        <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>No products found</Typography>
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </ScrollableTableContainer>
          )}

          <EntityListPagination total={filteredRows.length} page={page} onChange={setPage} pageSize={pageSize} onPageSizeChange={(v) => { setPageSize(v); setPage(0); }} />
        </CardContent>
      </Card>

      <Box className="barcode-print-area">
        <Typography variant="h6" fontWeight={700} sx={{ mb: 2 }}>Product Barcodes</Typography>
        <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 2 }}>
          {printRows.map((row) => (
            <Box key={row.id} sx={{ border: '1px solid #ccc', borderRadius: 1, p: 1.5, textAlign: 'center' }}>
              <Typography variant="caption" display="block" sx={{ mb: 0.5 }}>{row.productName}</Typography>
              <BarcodeSvg value={row.barcode} height={45} />
            </Box>
          ))}
        </Box>
      </Box>
    </Box>
  );
}
