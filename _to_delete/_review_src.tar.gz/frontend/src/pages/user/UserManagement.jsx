import React, { useMemo, useState } from 'react';
import {
  Box, Typography, Button, Card, CardContent, Stack, Table, TableBody, TableCell, TableHead,
  TableRow, Chip, IconButton, Dialog, DialogTitle, DialogContent, DialogActions, Tooltip,
} from '@mui/material';
import ManageAccountsIcon from '@mui/icons-material/ManageAccounts';
import AddIcon from '@mui/icons-material/Add';
import CloseIcon from '@mui/icons-material/Close';
import EditIcon from '@mui/icons-material/EditOutlined';
import DeleteIcon from '@mui/icons-material/DeleteOutline';
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import { useSelector } from 'react-redux';
import { z } from 'zod';
import AppForm, { FormGrid, FormSubmitButton } from '../../components/form/AppForm';
import { useUnsavedChangesGuard, FormDirtyTracker } from '../../components/form/useUnsavedChangesGuard';
import FormTextField from '../../components/form/FormTextField';
import FormSelect from '../../components/form/FormSelect';
import EntityHeaderCard from '../../components/common/EntityHeaderCard';
import PermissionMatrix, { buildPermissionRows } from '../../components/common/PermissionMatrix';
import EntityListPagination from '../../components/data-display/EntityListPagination';
import MobileRecordCard from '../../components/data-display/MobileRecordCard';
import { useIsMobileListView } from '../../components/data-display/useIsMobileListView';
import { useNotify } from '../../components/feedback/NotificationProvider';
import { applyServerErrors } from '../../lib/formErrors';
import { useConfirm } from '../../components/feedback/ConfirmationDialog';
import { requiredString, email as emailField, statusEnum } from '../../lib/validation/common';
import { appUserApi } from '../../features/resources';
import { selectCurrentUser } from '../../store/authSlice';
import useTableFeatures from '../../components/data-display/useTableFeatures';
import TableSearchFilter from '../../components/data-display/TableSearchFilter';
import SortableHeaderCell from '../../components/data-display/SortableHeaderCell';
import ScrollableTableContainer from '../../components/data-display/ScrollableTableContainer';
import TableFilterPanel from '../../components/data-display/TableFilterPanel';

// role stays a plain string (matches the existing AppUser.role column), but
// 'admin' specifically must be preserved verbatim — it's the exact string
// backend/src/middleware/auth.js and crudRouter's deleteRoles compare
// against everywhere else in the app that gates an action to admins. The
// other three are just labels; nothing currently branches on them.
const ROLE_OPTIONS = [
  { label: 'Admin', value: 'admin' },
  { label: 'Manager', value: 'manager' },
  { label: 'Staff', value: 'staff' },
  { label: 'User', value: 'user' },
];

const permissionRowSchema = z.object({
  menuKey: z.string(),
  canView: z.boolean(),
  canAdd: z.boolean(),
  canEdit: z.boolean(),
  canDelete: z.boolean(),
});

// Same rule the reference design shows in red at the top of the grid, and
// the same rule the server re-checks on save (see routes/users.js) — a
// client-side schema is never trusted as the only gate.
const permissionsSchema = z
  .array(permissionRowSchema)
  .refine((rows) => rows.some((r) => r.canView || r.canAdd || r.canEdit || r.canDelete), {
    message: 'Grant at least one section permission.',
  });

const passwordRule = (v) => !v || (v.length >= 8 && /[A-Z]/.test(v) && /[0-9]/.test(v));
const passwordMessage = 'Password must be at least 8 characters and contain an uppercase letter and a number';

const baseUserShape = {
  name: requiredString('Name'),
  email: emailField('Email'),
  role: requiredString('Role'),
  status: statusEnum(),
  permissions: permissionsSchema,
};

// Password + confirmation are required on create...
const createUserSchema = z
  .object({
    ...baseUserShape,
    password: z.string().min(1, 'Password is required').refine(passwordRule, passwordMessage),
    confirmPassword: z.string().min(1, 'Confirm your password'),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: 'Passwords do not match',
    path: ['confirmPassword'],
  });

// ...but optional on edit — a blank password leaves the account's existing
// one untouched (see routes/users.js's PUT handler), so re-saving someone's
// role or permissions never forces a password reset as a side effect.
const editUserSchema = z
  .object({
    ...baseUserShape,
    password: z.string().refine(passwordRule, passwordMessage),
    confirmPassword: z.string(),
  })
  .refine((data) => !data.password || data.password === data.confirmPassword, {
    message: 'Passwords do not match',
    path: ['confirmPassword'],
  });

function getEmptyValues() {
  return {
    name: '', email: '', password: '', confirmPassword: '', role: 'staff', status: 'Active',
    permissions: buildPermissionRows(),
  };
}

const PAGE_SIZE = 10;

export default function UserManagement() {
  const notify = useNotify();
  const confirmDialog = useConfirm();
  const isMobile = useIsMobileListView();
  const currentUser = useSelector(selectCurrentUser);
  const { data: users, isLoading } = appUserApi.useList();
  const [create, { isLoading: creating }] = appUserApi.useCreate();
  const [update, { isLoading: updating }] = appUserApi.useUpdate();
  const [remove] = appUserApi.useDelete();

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingRow, setEditingRow] = useState(null);
  const [readOnly, setReadOnly] = useState(false);
  const [formKey, setFormKey] = useState(0);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(PAGE_SIZE);

  const allRows = users || [];

  const tableColumns = useMemo(() => ([
    { field: 'name', headerName: 'Name', filter: 'text' },
    { field: 'email', headerName: 'Email', filter: 'text' },
    { field: 'role', headerName: 'Role', filter: 'select' },
    { field: 'status', headerName: 'Status', filter: 'select' },
    // Not searchable/sortable by anything meaningful — just a quick "how
    // much access does this person actually have" glance in the list.
    {
      field: 'permissionCount',
      headerName: 'Permissions',
      filter: 'numberRange',
      value: (r) => (r.permissions || []).filter((p) => p.canView || p.canAdd || p.canEdit || p.canDelete).length,
    },
  ]), []);
  const table = useTableFeatures(allRows, tableColumns, { onChange: setPage });
  const rows = table.rows;
  const pagedRows = useMemo(() => rows.slice(page * pageSize, page * pageSize + pageSize), [rows, page, pageSize]);

  const openCreate = () => {
    setEditingRow(null);
    setReadOnly(false);
    setFormKey((k) => k + 1);
    setDialogOpen(true);
  };

  const closeForm = () => {
    setDialogOpen(false);
    setEditingRow(null);
  };

  const { requestClose, forceClose, setDirty, dialogCloseProps } = useUnsavedChangesGuard(closeForm);

  // Read-only look at a record — same form, every field disabled
  // and the save button removed (see AppForm's readOnly prop).
  const handleView = (row) => {
    setEditingRow(row);
    setReadOnly(true);
    setFormKey((k) => k + 1);
    setDialogOpen(true);
  };

  const handleEdit = (row) => {
    setEditingRow(row);
    setReadOnly(false);
    setFormKey((k) => k + 1);
    setDialogOpen(true);
  };

  const handleDelete = async (row) => {
    const ok = await confirmDialog({
      title: 'Delete user',
      message: `Are you sure you want to delete "${row.name}"? This cannot be undone.`,
      confirmLabel: 'Delete',
      severity: 'error',
    });
    if (!ok) return;
    try {
      await remove(row.id).unwrap();
      notify.success('User deleted');
    } catch (err) {
      notify.error(err?.data?.message || 'Delete failed');
    }
  };

  const handleSubmit = async (values, formMethods) => {
    const { confirmPassword, ...rest } = values;
    const payload = { ...rest };
    // Editing without touching the password field must not send an empty
    // string through — routes/users.js treats "no password key" and "blank
    // password" the same way (leave the hash alone), but there is no reason
    // to send the field at all when there is nothing in it.
    if (!payload.password) delete payload.password;
    try {
      if (editingRow) {
        await update({ id: editingRow.id, ...payload }).unwrap();
        notify.success('User updated');
      } else {
        await create(payload).unwrap();
        notify.success('User added');
      }
      forceClose();
    } catch (err) {
      notify.error(applyServerErrors(err, formMethods.setError));
    }
  };

  return (
    <Box>
      <EntityHeaderCard
        icon={<ManageAccountsIcon />}
        title="User Management"
        subtitle="Add users and grant menu-based View / Add / Edit / Delete permissions."
        rightContent={
          <Button variant="contained" startIcon={<AddIcon />} onClick={openCreate}>
            Add User
          </Button>
        }
      />

      <Dialog
        open={dialogOpen}
        {...dialogCloseProps}
        maxWidth="lg"
        fullWidth
        sx={{
          '& .MuiDialog-paper > form': {
            display: 'flex',
            flexDirection: 'column',
            minHeight: 0,
            overflow: 'hidden',
          },
        }}
      >
        <DialogTitle
          component="div"
          sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 1, pr: 1 }}
        >
          <Typography variant="subtitle1" fontWeight={700}>
            {readOnly ? 'View User' : editingRow ? 'Edit User' : 'New User'}
          </Typography>
          <IconButton
            onClick={requestClose}
            size="small"
            aria-label="close"
            // Red only while viewing — on an Add/Edit dialog this same button sits
            // beside a live Save, where red would read as destructive.
            sx={readOnly ? {
              border: '1px solid',
              borderColor: 'error.main',
              color: 'error.main',
              '&:hover': { borderColor: 'error.dark', color: 'error.dark' },
            } : undefined}
          >
            <CloseIcon fontSize="small" />
          </IconButton>
        </DialogTitle>

        <AppForm readOnly={readOnly}
          key={formKey}
          schema={editingRow ? editUserSchema : createUserSchema}
          defaultValues={editingRow
            ? { ...getEmptyValues(), ...editingRow, password: '', confirmPassword: '', permissions: buildPermissionRows(editingRow.permissions) }
            : getEmptyValues()}
          onSubmit={handleSubmit}
        >
          {() => (
            <>
              <FormDirtyTracker onDirtyChange={setDirty} />
              <DialogContent dividers>
                <FormGrid columns={3}>
                  <FormTextField name="name" label="Name *" placeholder="Enter full name" />
                  <FormTextField name="email" label="Email *" placeholder="Enter email address" />
                  <FormSelect name="role" label="Role *" options={ROLE_OPTIONS} />

                  <FormTextField
                    name="password"
                    label={readOnly ? 'View' : editingRow ? 'New Password' : 'Password *'}
                    type="password"
                    placeholder={readOnly ? 'View' : editingRow ? 'Leave blank to keep current password' : 'Enter password'}
                  />
                  <FormTextField
                    name="confirmPassword"
                    label={readOnly ? 'View' : editingRow ? 'Confirm New Password' : 'Confirm Password *'}
                    type="password"
                    placeholder="Re-enter password"
                  />
                  <FormSelect
                    name="status"
                    label="Status *"
                    options={[{ label: 'Active', value: 'Active' }, { label: 'Inactive', value: 'Inactive' }]}
                  />
                </FormGrid>

                <Typography variant="subtitle2" fontWeight={700} sx={{ mt: 3, mb: 1 }}>
                  Section Permissions
                </Typography>
                <PermissionMatrix name="permissions" />
              </DialogContent>

              <DialogActions sx={{ px: 3, py: 2 }}>
                <FormSubmitButton disabled={creating || updating}>
                  {readOnly ? 'View' : editingRow ? 'Update User' : 'Save User'}
                </FormSubmitButton>
                <Button variant={readOnly ? 'outlined' : 'text'} color={readOnly ? 'error' : 'inherit'} onClick={requestClose} disabled={creating || updating}>
                  {readOnly ? 'Close' : 'Cancel'}
                </Button>
              </DialogActions>
            </>
          )}
        </AppForm>
      </Dialog>

      <Card variant="outlined">
        <CardContent sx={{ p: 0 }}>
          <Stack direction="row" alignItems="center" justifyContent="space-between" flexWrap="wrap" gap={1.5} sx={{ px: 3, pt: 2.5, pb: 1.5 }}>
            <Typography variant="subtitle1" fontWeight={700}>User List</Typography>
            <TableSearchFilter table={table} placeholder="Search users..." width={220} />
          </Stack>

          <TableFilterPanel table={table} />

          {isMobile ? (
            <Box sx={{ px: 2, pb: 1 }}>
              {!isLoading && pagedRows.map((row) => {
                const isSelf = currentUser?.id === row.id;
                return (
                  <MobileRecordCard
                    key={row.id}
                    title={row.name}
                    statusChip={<Chip size="small" label={row.status} color={row.status === 'Active' ? 'success' : 'default'} variant="outlined" />}
                    fields={[
                      { label: 'Email', value: row.email },
                      { label: 'Role', value: row.role },
                      { label: 'Permissions', value: `${(row.permissions || []).filter((p) => p.canView || p.canAdd || p.canEdit || p.canDelete).length} sections` },
                    ]}
                    onView={() => handleView(row)}
                    onEdit={() => handleEdit(row)}
                    onDelete={isSelf ? undefined : () => handleDelete(row)}
                  />
                );
              })}
              {!isLoading && rows.length === 0 && (
                <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>{table.isFiltering ? 'No users match your search' : 'No users yet'}</Typography>
              )}
            </Box>
          ) : (
            <ScrollableTableContainer>
              <Table size="small" stickyHeader>
                <TableHead>
                  <TableRow>
                    <TableCell width={48}>#</TableCell>
                    <SortableHeaderCell field="name" sort={table.sort} onSort={table.toggleSort}>Name</SortableHeaderCell>
                    <SortableHeaderCell field="email" sort={table.sort} onSort={table.toggleSort}>Email</SortableHeaderCell>
                    <SortableHeaderCell field="role" sort={table.sort} onSort={table.toggleSort}>Role</SortableHeaderCell>
                    <SortableHeaderCell field="status" sort={table.sort} onSort={table.toggleSort}>Status</SortableHeaderCell>
                    <TableCell>Permissions</TableCell>
                    <TableCell align="right">Action</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {!isLoading && pagedRows.map((row, i) => {
                    const isSelf = currentUser?.id === row.id;
                    const grantedCount = (row.permissions || []).filter((p) => p.canView || p.canAdd || p.canEdit || p.canDelete).length;
                    return (
                      <TableRow key={row.id} hover>
                        <TableCell>{page * pageSize + i + 1}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.name}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.email}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap', textTransform: 'capitalize' }}>{row.role}</TableCell>
                        <TableCell>
                          <Chip size="small" label={row.status} color={row.status === 'Active' ? 'success' : 'default'} variant="outlined" />
                        </TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{grantedCount} section{grantedCount === 1 ? '' : 's'}</TableCell>
                        <TableCell align="right">
                          <Stack direction="row" spacing={0.5} justifyContent="flex-end">
                            <IconButton size="small" onClick={() => handleView(row)} aria-label="view">
                              <VisibilityOutlinedIcon fontSize="small" />
                            </IconButton>
                            <IconButton size="small" color="primary" onClick={() => handleEdit(row)} aria-label="edit">
                              <EditIcon fontSize="small" />
                            </IconButton>
                            {isSelf ? (
                              <Tooltip title="You cannot delete your own account">
                                <span>
                                  <IconButton size="small" color="error" disabled aria-label="delete">
                                    <DeleteIcon fontSize="small" />
                                  </IconButton>
                                </span>
                              </Tooltip>
                            ) : (
                              <IconButton size="small" color="error" onClick={() => handleDelete(row)} aria-label="delete">
                                <DeleteIcon fontSize="small" />
                              </IconButton>
                            )}
                          </Stack>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                  {!isLoading && rows.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={7}>
                        <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>{table.isFiltering ? 'No users match your search' : 'No users yet'}</Typography>
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </ScrollableTableContainer>
          )}

          <EntityListPagination total={rows.length} page={page} onChange={setPage} pageSize={pageSize} onPageSizeChange={(v) => { setPageSize(v); setPage(0); }} />
        </CardContent>
      </Card>
    </Box>
  );
}
