// Single source of truth for the sidebar, breadcrumbs, global search, and the
// card-grid sub-menu pages. Every route entry below MUST correspond to a real
// route in router/AppRouter.jsx. Add a nav entry whenever you add a page.
//
// Shape: { key, labelKey, path, icon, children? }
// - Top-level items with children render as a sidebar link to `path`, which
//   shows a card grid of the children (design-system.md sidebar rule).
// - Leaf items (no children) are the actual pages.

export const navConfig = [
  {
    key: 'dashboard',
    labelKey: 'nav.dashboard',
    path: '/dashboard',
    icon: 'Dashboard',
  },
  {
    key: 'company',
    labelKey: 'nav.company',
    path: '/company',
    icon: 'Business',
    children: [
      { key: 'company-details', labelKey: 'Company Details', path: '/company/details', icon: 'Domain' },
      { key: 'branch', labelKey: 'Branch', path: '/company/branch', icon: 'AccountTree' },
      { key: 'financial-year', labelKey: 'Financial Year', path: '/company/financial-year', icon: 'DateRange' },
      { key: 'document-numbering', labelKey: 'Document Numbering', path: '/company/document-numbering', icon: 'Numbers' },
      { key: 'tax-code', labelKey: 'Tax Code', path: '/company/tax-code', icon: 'Percent' },
      { key: 'bank-details', labelKey: 'Bank Details', path: '/company/bank-details', icon: 'AccountBalance' },
      { key: 'house-bank', labelKey: 'House Bank', path: '/company/house-bank', icon: 'AccountBalanceWallet' },
      { key: 'sales-employee', labelKey: 'Sales Employee', path: '/company/sales-employee', icon: 'Badge' },
      { key: 'approval-flow', labelKey: 'Approval Flow', path: '/company/approval-flow', icon: 'Rule' },
      { key: 'location-master', labelKey: 'Location Master', path: '/company/location', icon: 'Place' },
      { key: 'warehouse-master', labelKey: 'Warehouse Master', path: '/company/warehouse', icon: 'Warehouse' },
    ],
  },
  {
    key: 'accounting',
    labelKey: 'nav.accounting',
    path: '/accounting',
    icon: 'Calculate',
    children: [
      { key: 'account-group', labelKey: 'Account Group', path: '/accounting/account-group', icon: 'AccountTreeOutlined' },
      { key: 'account-type', labelKey: 'Account Type', path: '/accounting/account-type', icon: 'Category' },
      { key: 'chart-of-accounts', labelKey: 'Chart Of Accounts', path: '/accounting/chart-of-accounts', icon: 'MenuBook' },
      { key: 'gl-account-determination', labelKey: 'G/L Account Determination', path: '/accounting/gl-account-determination', icon: 'Rule' },
      { key: 'journal-entry', labelKey: 'Journal Entry', path: '/accounting/journal-entry', icon: 'Book' },
    ],
  },
  {
    key: 'product',
    labelKey: 'nav.product',
    path: '/product',
    icon: 'Inventory2',
    children: [
      { key: 'product-group', labelKey: 'Product Group', path: '/product/group', icon: 'Category' },
      { key: 'product-sub-group', labelKey: 'Product Sub-Group', path: '/product/sub-group', icon: 'Layers' },
      { key: 'brand', labelKey: 'Brand', path: '/product/brand', icon: 'BrandingWatermark' },
      { key: 'uom', labelKey: 'Unit of Measure', path: '/product/uom', icon: 'Straighten' },
      { key: 'product-master', labelKey: 'Product Master', path: '/product/master', icon: 'Inventory' },
      { key: 'product-catalog', labelKey: 'Product Catalog', path: '/product/catalog', icon: 'MenuBook' },
      { key: 'barcode', labelKey: 'Barcode', path: '/product/barcode', icon: 'QrCode' },
      { key: 'purchase-price', labelKey: 'Purchase Price', path: '/product/purchase-price', icon: 'PriceChange' },
      { key: 'sales-price', labelKey: 'Sales Price', path: '/product/sales-price', icon: 'Sell' },
      { key: 'customer-discount', labelKey: 'Customer Discount', path: '/product/customer-discount', icon: 'Discount' },
    ],
  },
  {
    key: 'partner',
    labelKey: 'nav.partner',
    path: '/partner',
    icon: 'Groups',
    children: [
      { key: 'business-partner', labelKey: 'Business Partner', path: '/partner/business-partner', icon: 'ContactMail' },
      { key: 'customer-master', labelKey: 'Customer Master', path: '/partner/customer', icon: 'Person' },
      { key: 'supplier-master', labelKey: 'Supplier Master', path: '/partner/supplier', icon: 'LocalShipping' },
      { key: 'transport-master', labelKey: 'Transport Master', path: '/partner/transport', icon: 'DirectionsCar' },
    ],
  },
  {
    key: 'purchase',
    labelKey: 'nav.purchase',
    path: '/purchase',
    icon: 'ShoppingCart',
    children: [
      { key: 'purchase-quotation', labelKey: 'Purchase Quotation', path: '/purchase/quotation', icon: 'RequestQuote' },
      { key: 'purchase-order', labelKey: 'Purchase Order', path: '/purchase/order', icon: 'Assignment' },
      { key: 'purchase-grn', labelKey: 'Purchase GRN', path: '/purchase/grn', icon: 'Inventory' },
      { key: 'purchase-return', labelKey: 'Purchase Return', path: '/purchase/return', icon: 'AssignmentReturn' },
      { key: 'purchase-invoice', labelKey: 'Purchase Invoice', path: '/purchase/invoice', icon: 'Receipt' },
      { key: 'purchase-credit-memo', labelKey: 'Purchase Credit Memo', path: '/purchase/credit-memo', icon: 'ReceiptLong' },
    ],
  },
  {
    key: 'sales',
    labelKey: 'nav.sales',
    path: '/sales',
    icon: 'PointOfSale',
    children: [
      { key: 'enquiry', labelKey: 'Enquiry', path: '/sales/enquiry', icon: 'ContactMail' },
      { key: 'follow-up', labelKey: 'Follow-up', path: '/sales/follow-up', icon: 'EventRepeat' },
      { key: 'sales-quotation', labelKey: 'Sales Quotation', path: '/sales/quotation', icon: 'RequestQuote' },
      { key: 'sales-order', labelKey: 'Sales Order', path: '/sales/order', icon: 'Assignment' },
      { key: 'delivery-challan', labelKey: 'Delivery Challan', path: '/sales/delivery-challan', icon: 'LocalShipping' },
      { key: 'sales-return', labelKey: 'Sales Return', path: '/sales/return', icon: 'AssignmentReturn' },
      { key: 'sales-invoice', labelKey: 'Sales Invoice', path: '/sales/invoice', icon: 'Receipt' },
      { key: 'sales-credit-memo', labelKey: 'Sales Credit Memo', path: '/sales/credit-memo', icon: 'ReceiptLong' },
      
    ],
  },
  {
    key: 'inventory',
    labelKey: 'nav.inventory',
    path: '/inventory',
    icon: 'Warehouse',
    children: [
      { key: 'stock-receipt', labelKey: 'Stock Receipt', path: '/inventory/stock-receipt', icon: 'MoveToInbox' },
      { key: 'stock-issue', labelKey: 'Stock Issue', path: '/inventory/stock-issue', icon: 'Outbox' },
      { key: 'stock-adjustment', labelKey: 'Stock Adjustment', path: '/inventory/stock-adjustment', icon: 'Tune' },
      { key: 'stock-transfer', labelKey: 'Stock Transfer', path: '/inventory/stock-transfer', icon: 'SwapHoriz' },
      { key: 'opening-balance', labelKey: 'Opening Balance', path: '/inventory/opening-balance', icon: 'Balance' },
    ],
  },
  {
    key: 'receivables',
    labelKey: 'nav.receivables',
    path: '/receivables',
    icon: 'TrendingUp',
    children: [
      { key: 'customer-outstanding', labelKey: 'Customer Outstanding', path: '/receivables/outstanding', icon: 'AccountBalance' },
      { key: 'collection-entry', labelKey: 'Collection Entry', path: '/receivables/collection', icon: 'Payments' },
    ],
  },
  {
    key: 'payables',
    labelKey: 'nav.payables',
    path: '/payables',
    icon: 'TrendingDown',
    children: [
      { key: 'supplier-outstanding', labelKey: 'Supplier Outstanding', path: '/payables/outstanding', icon: 'AccountBalance' },
      { key: 'payment-entry', labelKey: 'Payment Entry', path: '/payables/payment', icon: 'Payments' },
    ],
  },
  {
    key: 'banking',
    labelKey: 'nav.banking',
    path: '/banking',
    icon: 'AccountBalance',
    children: [
      { key: 'deposit-entry', labelKey: 'Deposit Entry', path: '/banking/deposit', icon: 'Savings' },
      { key: 'bank-reconciliation', labelKey: 'Bank Reconciliation', path: '/banking/reconciliation', icon: 'Balance' },
      { key: 'cheque-print', labelKey: 'Cheque Print', path: '/banking/cheque-print', icon: 'Print' },
      { key: 'payment-receipt', labelKey: 'Payment Receipt', path: '/banking/payment-receipt', icon: 'ReceiptLong' },
      { key: 'payment-voucher', labelKey: 'Payment Voucher', path: '/banking/payment-voucher', icon: 'Payments' },
    ],
  },
  {
    key: 'reports',
    labelKey: 'nav.reports',
    path: '/reports',
    icon: 'Assessment',
    children: [
      {
        key: 'reports-sales',
        labelKey: 'Sales',
        path: '/reports/sales',
        icon: 'PointOfSale',
        children: [
          { key: 'reports-sales-enquiry-register', labelKey: 'Enquiry Register', path: '/reports/sales/enquiry-register', icon: 'ListAlt' },
          { key: 'reports-sales-enquiry-analysis', labelKey: 'Enquiry Analysis', path: '/reports/sales/enquiry-analysis', icon: 'Analytics' },
          { key: 'reports-sales-order-register', labelKey: 'Sales Order Register', path: '/reports/sales/order-register', icon: 'Assignment' },
          { key: 'reports-sales-invoice-register', labelKey: 'Sales Invoice Register', path: '/reports/sales/invoice-register', icon: 'Receipt' },
          { key: 'reports-sales-customer-wise', labelKey: 'Customer-wise Sales', path: '/reports/sales/customer-wise', icon: 'PersonSearch' },
          { key: 'reports-sales-product-wise', labelKey: 'Product-wise Sales', path: '/reports/sales/product-wise', icon: 'BarChart' },
          { key: 'reports-sales-salesman-wise', labelKey: 'Salesman-wise Sales', path: '/reports/sales/salesman-wise', icon: 'Leaderboard' },
          { key: 'reports-sales-pending-order', labelKey: 'Pending Sales Order', path: '/reports/sales/pending-order', icon: 'HourglassBottom' },
          { key: 'reports-sales-profitability', labelKey: 'Profitability Analysis', path: '/reports/sales/profitability', icon: 'TrendingUp' },
        ],
      },
      {
        key: 'reports-purchase',
        labelKey: 'Purchase',
        path: '/reports/purchase',
        icon: 'ShoppingCart',
        children: [
          { key: 'reports-purchase-order-register', labelKey: 'Purchase Order Register', path: '/reports/purchase/order-register', icon: 'Assignment' },
          { key: 'reports-purchase-invoice-register', labelKey: 'Purchase Invoice Register', path: '/reports/purchase/invoice-register', icon: 'Receipt' },
          { key: 'reports-purchase-pending-order', labelKey: 'Pending Purchase Order', path: '/reports/purchase/pending-order', icon: 'HourglassBottom' },
          { key: 'reports-purchase-price-comparison', labelKey: 'Price Comparison', path: '/reports/purchase/price-comparison', icon: 'CompareArrows' },
          { key: 'reports-purchase-price-history', labelKey: 'Price History', path: '/reports/purchase/price-history', icon: 'History' },
        ],
      },
      {
        key: 'reports-inventory',
        labelKey: 'Inventory',
        path: '/reports/inventory',
        icon: 'Warehouse',
        children: [
          { key: 'reports-inventory-stock-summary', labelKey: 'Stock Summary', path: '/reports/inventory/stock-summary', icon: 'Inventory' },
          { key: 'reports-inventory-stock-valuation', labelKey: 'Stock Valuation', path: '/reports/inventory/stock-valuation', icon: 'PriceCheck' },
          { key: 'reports-inventory-low-stock', labelKey: 'Low Stock Report', path: '/reports/inventory/low-stock', icon: 'WarningAmber' },
          { key: 'reports-inventory-slow-moving', labelKey: 'Slow Moving Stock', path: '/reports/inventory/slow-moving', icon: 'Speed' },
          { key: 'reports-inventory-dead-stock', labelKey: 'Dead Stock', path: '/reports/inventory/dead-stock', icon: 'Block' },
          { key: 'reports-inventory-reorder-level', labelKey: 'Reorder Level', path: '/reports/inventory/reorder-level', icon: 'Replay' },
        ],
      },
      {
        key: 'reports-receivable',
        labelKey: 'Receivable',
        path: '/reports/receivable',
        icon: 'TrendingUp',
        children: [
          { key: 'reports-receivable-customer-outstanding', labelKey: 'Customer Outstanding', path: '/reports/receivable/customer-outstanding', icon: 'AccountBalance' },
          { key: 'reports-receivable-collection-register', labelKey: 'Collection Register', path: '/reports/receivable/collection-register', icon: 'Payments' },
        ],
      },
      {
        key: 'reports-payable',
        labelKey: 'Payable',
        path: '/reports/payable',
        icon: 'TrendingDown',
        children: [
          { key: 'reports-payable-supplier-outstanding', labelKey: 'Supplier Outstanding', path: '/reports/payable/supplier-outstanding', icon: 'AccountBalance' },
          { key: 'reports-payable-payment-register', labelKey: 'Payment Register', path: '/reports/payable/payment-register', icon: 'Payments' },
        ],
      },
      {
        key: 'reports-cash-bank',
        labelKey: 'Cash / Bank Position',
        path: '/reports/cash-bank',
        icon: 'AccountBalance',
        children: [
          { key: 'reports-cash-bank-cash-book', labelKey: 'Cash Book', path: '/reports/cash-bank/cash-book', icon: 'Book' },
          { key: 'reports-cash-bank-day-book', labelKey: 'Day Book', path: '/reports/cash-bank/day-book', icon: 'Today' },
          { key: 'reports-cash-bank-bank-book', labelKey: 'Bank Book', path: '/reports/cash-bank/bank-book', icon: 'AccountBalanceWallet' },
          { key: 'reports-cash-bank-deposit-register', labelKey: 'Deposit Register', path: '/reports/cash-bank/deposit-register', icon: 'Savings' },
        ],
      },
    ],
  },
  {
    key: 'user',
    labelKey: 'nav.user',
    path: '/user',
    icon: 'ManageAccounts',
  },
  {
    key: 'settings',
    labelKey: 'nav.settings',
    path: '/settings',
    icon: 'Settings',
  },
];

// Flat list of every leaf page — used for the global search and breadcrumb lookup.
export function flattenNav(tree = navConfig, trail = []) {
  return tree.flatMap((node) => {
    const currentTrail = [...trail, node];
    if (node.children?.length) {
      return [
        { ...node, trail: currentTrail, isParent: true },
        ...flattenNav(node.children, currentTrail),
      ];
    }
    return [{ ...node, trail: currentTrail, isParent: false }];
  });
}

export const flatNav = flattenNav();

export function findNavByPath(path) {
  return flatNav.find((n) => n.path === path);
}
