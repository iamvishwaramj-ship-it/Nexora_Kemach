import React, { Suspense, lazy } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { selectCurrentUser } from '../store/authSlice';
import MainLayout from '../components/layout/MainLayout';
import AuthLayout from '../layouts/AuthLayout';
import Spinner from '../components/ui/Spinner';
import SubMenuIndexPage from '../pages/common/SubMenuIndexPage';
import ReportPlaceholder from '../pages/reports/ReportPlaceholder';
import { getNavIcon } from './iconMap';

// Reports — real pages (backend-wired), as opposed to the ReportPlaceholder
// shells used for reports not yet built.
const EnquiryRegister = lazy(() => import('../pages/reports/sales/EnquiryRegister'));
const EnquiryAnalysis = lazy(() => import('../pages/reports/sales/EnquiryAnalysis'));
const SalesOrderRegister = lazy(() => import('../pages/reports/sales/SalesOrderRegister'));
const SalesInvoiceRegister = lazy(() => import('../pages/reports/sales/SalesInvoiceRegister'));
const CustomerWiseSales = lazy(() => import('../pages/reports/sales/CustomerWiseSales'));
const ProductWiseSales = lazy(() => import('../pages/reports/sales/ProductWiseSales'));
const SalesmanWiseSales = lazy(() => import('../pages/reports/sales/SalesmanWiseSales'));
const PendingSalesOrder = lazy(() => import('../pages/reports/sales/PendingSalesOrder'));
const ProfitabilityAnalysis = lazy(() => import('../pages/reports/sales/ProfitabilityAnalysis'));
const PurchaseOrderRegister = lazy(() => import('../pages/reports/purchase/PurchaseOrderRegister'));
const PurchaseInvoiceRegister = lazy(() => import('../pages/reports/purchase/PurchaseInvoiceRegister'));
const PendingPurchaseOrder = lazy(() => import('../pages/reports/purchase/PendingPurchaseOrder'));
const PriceComparison = lazy(() => import('../pages/reports/purchase/PriceComparison'));
const PurchasePriceHistory = lazy(() => import('../pages/reports/purchase/PurchasePriceHistory'));
const StockSummary = lazy(() => import('../pages/reports/inventory/StockSummary'));
const StockValuation = lazy(() => import('../pages/reports/inventory/StockValuation'));
const LowStockReport = lazy(() => import('../pages/reports/inventory/LowStockReport'));
const SlowMovingStock = lazy(() => import('../pages/reports/inventory/SlowMovingStock'));
const DeadStock = lazy(() => import('../pages/reports/inventory/DeadStock'));
const ReorderLevel = lazy(() => import('../pages/reports/inventory/ReorderLevel'));
const CollectionRegister = lazy(() => import('../pages/reports/receivable/CollectionRegister'));
const PaymentRegister = lazy(() => import('../pages/reports/payable/PaymentRegister'));
const CashBook = lazy(() => import('../pages/reports/cashbank/CashBook'));
const DayBook = lazy(() => import('../pages/reports/cashbank/DayBook'));
const BankBook = lazy(() => import('../pages/reports/cashbank/BankBook'));
const DepositRegister = lazy(() => import('../pages/reports/cashbank/DepositRegister'));

// Small helper so each report route can reference the same icon name used
// in navConfig.js, instead of importing a duplicate MUI icon per route.
const ReportIcon = ({ name }) => {
  const Icon = getNavIcon(name);
  return <Icon />;
};

// Auth
const Login = lazy(() => import('../pages/auth/Login'));

// Dashboard
const Dashboard = lazy(() => import('../pages/dashboard/Dashboard'));

// Company Setup
const CompanyDetails = lazy(() => import('../pages/company/CompanyDetails'));
const Branch = lazy(() => import('../pages/company/Branch'));
const FinancialYear = lazy(() => import('../pages/company/FinancialYear'));
const DocumentNumbering = lazy(() => import('../pages/company/DocumentNumbering'));
const TaxCode = lazy(() => import('../pages/company/TaxCode'));
const BankDetails = lazy(() => import('../pages/company/BankDetails'));
const HouseBank = lazy(() => import('../pages/company/HouseBank'));
const SalesEmployee = lazy(() => import('../pages/company/SalesEmployee'));
const ApprovalFlow = lazy(() => import('../pages/company/ApprovalFlow'));
const WarehouseMaster = lazy(() => import('../pages/company/WarehouseMaster'));
const LocationMaster = lazy(() => import('../pages/company/LocationMaster'));

// Accounting
const AccountGroup = lazy(() => import('../pages/accounting/AccountGroup'));
const AccountType = lazy(() => import('../pages/accounting/AccountType'));
const ChartOfAccounts = lazy(() => import('../pages/accounting/ChartOfAccounts'));
const GLAccountDetermination = lazy(() => import('../pages/accounting/GLAccountDetermination'));
const GLAccountDeterminationForm = lazy(() => import('../pages/accounting/GLAccountDeterminationForm'));
const JournalEntry = lazy(() => import('../pages/accounting/JournalEntry'));

// Product Setup
const ProductGroup = lazy(() => import('../pages/product/ProductGroup'));
const ProductSubGroup = lazy(() => import('../pages/product/ProductSubGroup'));
const Brand = lazy(() => import('../pages/product/Brand'));
const UnitOfMeasure = lazy(() => import('../pages/product/UnitOfMeasure'));
const ProductMaster = lazy(() => import('../pages/product/ProductMaster'));
const ProductCatalog = lazy(() => import('../pages/product/ProductCatalog'));
const Barcode = lazy(() => import('../pages/product/Barcode'));
const PurchasePrice = lazy(() => import('../pages/product/PurchasePrice'));
const SalesPrice = lazy(() => import('../pages/product/SalesPrice'));
const CustomerDiscount = lazy(() => import('../pages/product/CustomerDiscount'));

// Business Partner
const BusinessPartner = lazy(() => import('../pages/businessPartner/BusinessPartner'));
const CustomerMaster = lazy(() => import('../pages/businessPartner/CustomerMaster'));
const SupplierMaster = lazy(() => import('../pages/businessPartner/SupplierMaster'));
const TransportMaster = lazy(() => import('../pages/businessPartner/TransportMaster'));

// Purchase
const PurchaseQuotation = lazy(() => import('../pages/purchase/PurchaseQuotation'));
const PurchaseOrder = lazy(() => import('../pages/purchase/PurchaseOrder'));
const PurchaseGRN = lazy(() => import('../pages/purchase/PurchaseGRN'));
const PurchaseInvoice = lazy(() => import('../pages/purchase/PurchaseInvoice'));
const PurchaseReturn = lazy(() => import('../pages/purchase/PurchaseReturn'));
const PurchaseCreditMemo = lazy(() => import('../pages/purchase/PurchaseCreditMemo'));

// Sales
const SalesQuotation = lazy(() => import('../pages/sales/SalesQuotation'));
const SalesOrder = lazy(() => import('../pages/sales/SalesOrder'));
const DeliveryChallan = lazy(() => import('../pages/sales/DeliveryChallan'));
const SalesInvoice = lazy(() => import('../pages/sales/SalesInvoice'));
const SalesCreditMemo = lazy(() => import('../pages/sales/SalesCreditMemo'));
const SalesReturn = lazy(() => import('../pages/sales/SalesReturn'));
const Enquiry = lazy(() => import('../pages/sales/Enquiry'));
const FollowUp = lazy(() => import('../pages/sales/FollowUp'));

// Inventory
const StockReceipt = lazy(() => import('../pages/inventory/StockReceipt'));
const StockIssue = lazy(() => import('../pages/inventory/StockIssue'));
const StockAdjustment = lazy(() => import('../pages/inventory/StockAdjustment'));
const StockTransfer = lazy(() => import('../pages/inventory/StockTransfer'));
const OpeningBalance = lazy(() => import('../pages/inventory/OpeningBalance'));

// Receivables
const CustomerOutstanding = lazy(() => import('../pages/receivables/CustomerOutstanding'));
// Simplified Customer Outstanding view used only on the Receivables menu —
// the Reports > Customer Outstanding route above keeps using the full
// CustomerOutstanding component untouched.
const CustomerOutstandingList = lazy(() => import('../pages/receivables/CustomerOutstandingList'));
const CollectionEntry = lazy(() => import('../pages/receivables/CollectionEntry'));

// Payables
const SupplierOutstanding = lazy(() => import('../pages/payables/SupplierOutstanding'));
// Simplified Supplier Outstanding view used only on the Payables menu — the
// Reports > Supplier Outstanding route below keeps using the full
// SupplierOutstanding component untouched.
const SupplierOutstandingList = lazy(() => import('../pages/payables/SupplierOutstandingList'));
const PaymentEntry = lazy(() => import('../pages/payables/PaymentEntry'));

// Banking
const DepositEntry = lazy(() => import('../pages/banking/DepositEntry'));
const BankReconciliation = lazy(() => import('../pages/banking/BankReconciliation'));
const ChequePrint = lazy(() => import('../pages/banking/ChequePrint'));
const PaymentReceipt = lazy(() => import('../pages/banking/PaymentReceipt'));
const PaymentVoucher = lazy(() => import('../pages/banking/PaymentVoucher'));

// User Management
const UserManagement = lazy(() => import('../pages/user/UserManagement'));

// Settings & Profile
const Settings = lazy(() => import('../pages/settings/Settings'));
const Profile = lazy(() => import('../pages/profile/Profile'));

const ProtectedRoute = ({ children }) => {
  const user = useSelector(selectCurrentUser);
  return user ? children : <Navigate to="/login" replace />;
};

export default function AppRouter() {
  const user = useSelector(selectCurrentUser);

  return (
    <Suspense fallback={<Spinner fullScreen />}>
      <Routes>
        <Route element={<AuthLayout />}>
          <Route path="/login" element={user ? <Navigate to="/dashboard" replace /> : <Login />} />
        </Route>

        <Route path="/" element={<ProtectedRoute><MainLayout /></ProtectedRoute>}>
          <Route index element={<Navigate to="/dashboard" replace />} />
          <Route path="dashboard" element={<Dashboard />} />

          {/* Company Setup */}
          <Route path="company">
            <Route index element={<SubMenuIndexPage navKey="company" />} />
            <Route path="details" element={<CompanyDetails />} />
            <Route path="branch" element={<Branch />} />
            <Route path="financial-year" element={<FinancialYear />} />
            <Route path="document-numbering" element={<DocumentNumbering />} />
            <Route path="tax-code" element={<TaxCode />} />
            <Route path="bank-details" element={<BankDetails />} />
            <Route path="house-bank" element={<HouseBank />} />
            <Route path="sales-employee" element={<SalesEmployee />} />
            <Route path="approval-flow" element={<ApprovalFlow />} />
            <Route path="location" element={<LocationMaster />} />
            <Route path="location/create" element={<LocationMaster />} />
            <Route path="warehouse" element={<WarehouseMaster />} />
            <Route path="warehouse/create" element={<WarehouseMaster />} />
          </Route>

          {/* Accounting */}
          <Route path="accounting">
            <Route index element={<SubMenuIndexPage navKey="accounting" />} />
            <Route path="account-group" element={<AccountGroup />} />
            <Route path="account-type" element={<AccountType />} />
            <Route path="chart-of-accounts" element={<ChartOfAccounts />} />
            <Route path="gl-account-determination" element={<GLAccountDetermination />} />
            <Route path="gl-account-determination/new" element={<GLAccountDeterminationForm />} />
            <Route path="gl-account-determination/:id/edit" element={<GLAccountDeterminationForm />} />
            <Route path="journal-entry" element={<JournalEntry />} />
            <Route path="journal-entry/create" element={<JournalEntry />} />
          </Route>

          {/* Product Setup */}
          <Route path="product">
            <Route index element={<SubMenuIndexPage navKey="product" />} />
            <Route path="group" element={<ProductGroup />} />
            <Route path="sub-group" element={<ProductSubGroup />} />
            <Route path="brand" element={<Brand />} />
            <Route path="uom" element={<UnitOfMeasure />} />
            <Route path="master" element={<ProductMaster />} />
            <Route path="master/create" element={<ProductMaster />} />
            <Route path="catalog" element={<ProductCatalog />} />
            <Route path="barcode" element={<Barcode />} />
            <Route path="purchase-price" element={<PurchasePrice />} />
            <Route path="sales-price" element={<SalesPrice />} />
            <Route path="customer-discount" element={<CustomerDiscount />} />
          </Route>

          {/* Business Partner */}
          <Route path="partner">
            <Route index element={<SubMenuIndexPage navKey="partner" />} />
            <Route path="business-partner" element={<BusinessPartner />} />
            <Route path="business-partner/create" element={<BusinessPartner />} />
            <Route path="customer" element={<CustomerMaster />} />
            <Route path="customer/create" element={<CustomerMaster />} />
            <Route path="supplier" element={<SupplierMaster />} />
            <Route path="supplier/create" element={<SupplierMaster />} />
            <Route path="transport" element={<TransportMaster />} />
            <Route path="transport/create" element={<TransportMaster />} />
          </Route>

          {/* Purchase */}
          <Route path="purchase">
            <Route index element={<SubMenuIndexPage navKey="purchase" />} />
            <Route path="quotation" element={<PurchaseQuotation />} />
            <Route path="quotation/create" element={<PurchaseQuotation />} />
            <Route path="order" element={<PurchaseOrder />} />
            <Route path="order/create" element={<PurchaseOrder />} />
            <Route path="grn" element={<PurchaseGRN />} />
            <Route path="grn/create" element={<PurchaseGRN />} />
            <Route path="invoice" element={<PurchaseInvoice />} />
            <Route path="invoice/create" element={<PurchaseInvoice />} />
            <Route path="return" element={<PurchaseReturn />} />
            <Route path="return/create" element={<PurchaseReturn />} />
            <Route path="credit-memo" element={<PurchaseCreditMemo />} />
            <Route path="credit-memo/create" element={<PurchaseCreditMemo />} />
          </Route>

          {/* Sales */}
          <Route path="sales">
            <Route index element={<SubMenuIndexPage navKey="sales" />} />
            <Route path="quotation" element={<SalesQuotation />} />
            <Route path="quotation/create" element={<SalesQuotation />} />
            <Route path="order" element={<SalesOrder />} />
            <Route path="order/create" element={<SalesOrder />} />
            <Route path="delivery-challan" element={<DeliveryChallan />} />
            <Route path="delivery-challan/create" element={<DeliveryChallan />} />
            <Route path="invoice" element={<SalesInvoice />} />
            <Route path="invoice/create" element={<SalesInvoice />} />
            <Route path="credit-memo" element={<SalesCreditMemo />} />
            <Route path="credit-memo/create" element={<SalesCreditMemo />} />
            <Route path="return" element={<SalesReturn />} />
            <Route path="return/create" element={<SalesReturn />} />
            <Route path="enquiry" element={<Enquiry />} />
            <Route path="follow-up" element={<FollowUp />} />
          </Route>

          {/* Inventory */}
          <Route path="inventory">
            <Route index element={<SubMenuIndexPage navKey="inventory" />} />
            <Route path="stock-receipt" element={<StockReceipt />} />
            <Route path="stock-receipt/create" element={<StockReceipt />} />
            <Route path="stock-issue" element={<StockIssue />} />
            <Route path="stock-issue/create" element={<StockIssue />} />
            <Route path="stock-adjustment" element={<StockAdjustment />} />
            <Route path="stock-adjustment/create" element={<StockAdjustment />} />
            <Route path="stock-transfer" element={<StockTransfer />} />
            <Route path="stock-transfer/create" element={<StockTransfer />} />
            <Route path="opening-balance" element={<OpeningBalance />} />
            <Route path="opening-balance/create" element={<OpeningBalance />} />
          </Route>

          {/* Receivables */}
          <Route path="receivables">
            <Route index element={<SubMenuIndexPage navKey="receivables" />} />
            <Route path="outstanding" element={<CustomerOutstandingList />} />
            <Route path="collection" element={<CollectionEntry />} />
            <Route path="collection/create" element={<CollectionEntry />} />
          </Route>

          {/* Payables */}
          <Route path="payables">
            <Route index element={<SubMenuIndexPage navKey="payables" />} />
            <Route path="outstanding" element={<SupplierOutstandingList />} />
            <Route path="payment" element={<PaymentEntry />} />
            <Route path="payment/create" element={<PaymentEntry />} />
          </Route>

          {/* Banking */}
          <Route path="banking">
            <Route index element={<SubMenuIndexPage navKey="banking" />} />
            <Route path="deposit" element={<DepositEntry />} />
            <Route path="deposit/create" element={<DepositEntry />} />
            <Route path="reconciliation" element={<BankReconciliation />} />
            <Route path="cheque-print" element={<ChequePrint />} />
            <Route path="payment-receipt" element={<PaymentReceipt />} />
            <Route path="payment-receipt/create" element={<PaymentReceipt />} />
            <Route path="payment-voucher" element={<PaymentVoucher />} />
            <Route path="payment-voucher/create" element={<PaymentVoucher />} />
          </Route>

          {/* Reports */}
          <Route path="reports">
            <Route index element={<SubMenuIndexPage navKey="reports" />} />

            <Route path="sales">
              <Route index element={<SubMenuIndexPage navKey="reports-sales" />} />
              <Route path="enquiry-register" element={<EnquiryRegister />} />
              <Route path="enquiry-analysis" element={<EnquiryAnalysis />} />
              <Route path="order-register" element={<SalesOrderRegister />} />
              <Route path="invoice-register" element={<SalesInvoiceRegister />} />
              <Route path="customer-wise" element={<CustomerWiseSales />} />
              <Route path="product-wise" element={<ProductWiseSales />} />
              <Route path="salesman-wise" element={<SalesmanWiseSales />} />
              <Route path="pending-order" element={<PendingSalesOrder />} />
              <Route path="profitability" element={<ProfitabilityAnalysis />} />
            </Route>

            <Route path="purchase">
              <Route index element={<SubMenuIndexPage navKey="reports-purchase" />} />
              <Route path="order-register" element={<PurchaseOrderRegister />} />
              <Route path="invoice-register" element={<PurchaseInvoiceRegister />} />
              <Route path="pending-order" element={<PendingPurchaseOrder />} />
              <Route path="price-comparison" element={<PriceComparison />} />
              <Route path="price-history" element={<PurchasePriceHistory />} />
            </Route>

            <Route path="inventory">
              <Route index element={<SubMenuIndexPage navKey="reports-inventory" />} />
              <Route path="stock-summary" element={<StockSummary />} />
              <Route path="stock-valuation" element={<StockValuation />} />
              <Route path="low-stock" element={<LowStockReport />} />
              <Route path="slow-moving" element={<SlowMovingStock />} />
              <Route path="dead-stock" element={<DeadStock />} />
              <Route path="reorder-level" element={<ReorderLevel />} />
            </Route>

            <Route path="receivable">
              <Route index element={<SubMenuIndexPage navKey="reports-receivable" />} />
              <Route path="customer-outstanding" element={<CustomerOutstanding />} />
              <Route path="collection-register" element={<CollectionRegister />} />
            </Route>

            <Route path="payable">
              <Route index element={<SubMenuIndexPage navKey="reports-payable" />} />
              <Route path="supplier-outstanding" element={<SupplierOutstanding />} />
              <Route path="payment-register" element={<PaymentRegister />} />
            </Route>

            <Route path="cash-bank">
              <Route index element={<SubMenuIndexPage navKey="reports-cash-bank" />} />
              <Route path="cash-book" element={<CashBook />} />
              <Route path="day-book" element={<DayBook />} />
              <Route path="bank-book" element={<BankBook />} />
              <Route path="deposit-register" element={<DepositRegister />} />
            </Route>
          </Route>

          {/* User Management */}
          <Route path="user" element={<UserManagement />} />

          {/* Settings & Profile */}
          <Route path="settings" element={<Settings />} />
          <Route path="settings/profile" element={<Profile />} />
          <Route path="profile" element={<Profile />} />
        </Route>

        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </Suspense>
  );
}
