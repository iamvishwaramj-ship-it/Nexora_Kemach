import { baseApi } from '../../store/baseApi';

// Bespoke read-only aggregate endpoint for the Reports > Inventory >
// Stock Valuation page. Query params drive the filter bar; the response
// contains one row per product (on-hand qty, unit cost, stock value, last
// purchase price/date, warehouse), precomputed stat totals, and four
// chart series. `branch` and `valuationMethod` are accepted for filter-bar
// parity but are no-ops on the backend — see the route comment in
// resources.js.
export const stockValuationReportApi = baseApi.injectEndpoints({
  endpoints: (builder) => ({
    getStockValuationReport: builder.query({
      query: ({ branch, warehouse, productGroup, product, valuationMethod, asOnDate } = {}) => ({
        url: '/inventory/stock-valuation/report',
        params: {
          ...(branch ? { branch } : {}),
          ...(warehouse ? { warehouse } : {}),
          ...(productGroup ? { productGroup } : {}),
          ...(product ? { product } : {}),
          ...(valuationMethod ? { valuationMethod } : {}),
          ...(asOnDate ? { asOnDate } : {}),
        },
      }),
      transformResponse: (r) => r.data,
      providesTags: [{ type: 'Product', id: 'STOCK_VALUATION_REPORT' }],
    }),
  }),
});

export const { useGetStockValuationReportQuery, useLazyGetStockValuationReportQuery } = stockValuationReportApi;
