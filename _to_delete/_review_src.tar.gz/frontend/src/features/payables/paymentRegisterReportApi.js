import { baseApi } from '../../store/baseApi';

// Bespoke read-only aggregate endpoint for the Reports > Payable >
// Payment Register page. `fromDate`/`toDate` are resolved on the page from
// the "Period Range" preset (MTD/WTD/QTD/YTD/Custom Range) before being
// sent — the backend just filters a plain date range. `branch`,
// `paymentMethod`, `referenceType`, `currency`, `showCancelledPayments`, and
// `showUnreconciledPayments` are accepted for filter-bar parity but are
// no-ops on the backend — see the route comment in resources.js.
export const paymentRegisterReportApi = baseApi.injectEndpoints({
  endpoints: (builder) => ({
    getPaymentRegisterReport: builder.query({
      query: ({
        branch, fromDate, toDate, supplierGroup, supplier, paymentMode, paymentMethod, include,
        currency, referenceType, showCancelledPayments, showUnreconciledPayments,
      } = {}) => ({
        url: '/payables/payment-register/report',
        params: {
          ...(branch ? { branch } : {}),
          ...(fromDate ? { fromDate } : {}),
          ...(toDate ? { toDate } : {}),
          ...(supplierGroup ? { supplierGroup } : {}),
          ...(supplier ? { supplier } : {}),
          ...(paymentMode ? { paymentMode } : {}),
          ...(paymentMethod ? { paymentMethod } : {}),
          ...(include ? { include } : {}),
          ...(currency ? { currency } : {}),
          ...(referenceType ? { referenceType } : {}),
          ...(showCancelledPayments ? { showCancelledPayments } : {}),
          ...(showUnreconciledPayments ? { showUnreconciledPayments } : {}),
        },
      }),
      transformResponse: (r) => r.data,
      providesTags: [{ type: 'SupplierPayment', id: 'REGISTER_REPORT' }],
    }),
  }),
});

export const { useGetPaymentRegisterReportQuery, useLazyGetPaymentRegisterReportQuery } = paymentRegisterReportApi;
