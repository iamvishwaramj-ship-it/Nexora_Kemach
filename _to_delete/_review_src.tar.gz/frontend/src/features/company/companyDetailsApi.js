import { baseApi } from '../../store/baseApi';

export const companyDetailsApi = baseApi.injectEndpoints({
  endpoints: (builder) => ({
    getCompanyDetails: builder.query({
      query: () => '/company/details',
      transformResponse: (r) => r.data,
      providesTags: ['Company'],
    }),
    updateCompanyDetails: builder.mutation({
      query: (body) => ({ url: '/company/details', method: 'PUT', body }),
      transformResponse: (r) => r.data,
      invalidatesTags: ['Company'],
    }),

    // --- Document Numbering Series ------------------------------------------
    // The list is scoped by financial year (series are per-FY), so the query
    // arg is an object of filters rather than nothing. RTK Query caches each
    // filter combination separately, which is what we want when the user
    // flips the FY selector back and forth.
    listDocumentNumbering: builder.query({
      query: (params = {}) => ({ url: '/company/document-numbers', params }),
      transformResponse: (r) => r.data,
      providesTags: ['DocumentNumbering'],
    }),
    getDocumentNumbering: builder.query({
      query: (id) => `/company/document-numbers/${id}`,
      transformResponse: (r) => r.data,
      providesTags: ['DocumentNumbering'],
    }),
    // Document types, separators and length options for the Add/Edit form.
    // Pass financialYearId to have each document flagged with whether it
    // already has a series in that year (so we can grey it out).
    getDocumentNumberingCatalog: builder.query({
      query: (params = {}) => ({ url: '/company/document-numbers/catalog', params }),
      transformResponse: (r) => r.data,
      providesTags: ['DocumentNumbering'],
    }),
    // Every series for one document type in one FY — backs the "Existing
    // Series for ..." table on the Add/Edit form. Also returns a `suggestion`
    // block (next free name and a non-overlapping start point) so the form can
    // pre-fill a valid new series instead of making the user work out where
    // the previous block ended.
    listSeriesForDocument: builder.query({
      query: ({ documentCode, ...params }) => ({
        url: `/company/document-numbers/by-document/${documentCode}`,
        params,
      }),
      transformResponse: (r) => r.data,
      providesTags: ['DocumentNumbering'],
    }),
    // Promote a series to be the one its document type allocates from.
    // Separate from the plain update because it has to demote the incumbent
    // in the same transaction.
    setDefaultDocumentSeries: builder.mutation({
      query: (id) => ({ url: `/company/document-numbers/${id}/set-default`, method: 'POST' }),
      transformResponse: (r) => r.data,
      invalidatesTags: ['DocumentNumbering'],
    }),
    createDocumentNumbering: builder.mutation({
      query: (body) => ({ url: '/company/document-numbers', method: 'POST', body }),
      transformResponse: (r) => r.data,
      invalidatesTags: ['DocumentNumbering'],
    }),
    updateDocumentNumbering: builder.mutation({
      query: ({ id, ...body }) => ({ url: `/company/document-numbers/${id}`, method: 'PUT', body }),
      transformResponse: (r) => r.data,
      invalidatesTags: ['DocumentNumbering'],
    }),
    deleteDocumentNumbering: builder.mutation({
      query: (id) => ({ url: `/company/document-numbers/${id}`, method: 'DELETE' }),
      invalidatesTags: ['DocumentNumbering'],
    }),
    resetDocumentNumbering: builder.mutation({
      query: (body = {}) => ({ url: '/company/document-numbers/reset', method: 'POST', body }),
      transformResponse: (r) => r.data,
      invalidatesTags: ['DocumentNumbering'],
    }),
    // Copies the current year's series into the target FY, honouring each
    // series' Reset Every FY flag. Idempotent.
    rolloverDocumentNumbering: builder.mutation({
      query: (body) => ({ url: '/company/document-numbers/rollover', method: 'POST', body }),
      transformResponse: (r) => r.data,
      invalidatesTags: ['DocumentNumbering'],
    }),
    // Server-side preview. The form renders its own preview locally for
    // instant feedback; this exists so transaction screens and any future
    // caller get the number formatted by the same code that will issue it.
    previewDocumentNumber: builder.mutation({
      query: (body) => ({ url: '/company/document-numbers/preview', method: 'POST', body }),
      transformResponse: (r) => r.data,
    }),
    // Non-consuming: what the next number *would* be. Safe on form open.
    peekDocumentNumber: builder.mutation({
      query: (body) => ({ url: '/company/document-numbers/peek', method: 'POST', body }),
      transformResponse: (r) => r.data,
    }),
    // Consuming: burns the number. Only call this when actually saving a
    // document, and treat a 409 as a hard stop.
    allocateDocumentNumber: builder.mutation({
      query: (body) => ({ url: '/company/document-numbers/next', method: 'POST', body }),
      transformResponse: (r) => r.data,
      invalidatesTags: ['DocumentNumbering'],
    }),
  }),
});

export const {
  useGetCompanyDetailsQuery, useUpdateCompanyDetailsMutation,
  useListDocumentNumberingQuery, useGetDocumentNumberingQuery,
  useGetDocumentNumberingCatalogQuery,
  useListSeriesForDocumentQuery, useSetDefaultDocumentSeriesMutation,
  useCreateDocumentNumberingMutation, useUpdateDocumentNumberingMutation,
  useDeleteDocumentNumberingMutation, useResetDocumentNumberingMutation,
  useRolloverDocumentNumberingMutation,
  usePreviewDocumentNumberMutation, usePeekDocumentNumberMutation,
  useAllocateDocumentNumberMutation,
} = companyDetailsApi;
