import { baseApi } from '../../store/baseApi';

// Extra tax-code endpoint that doesn't fit the generic CRUD shape
// (createCrudApi in lib/createCrudApi.js — see features/resources.js's
// `taxCodeApi` for list/create/update/delete). Injected onto the same
// baseApi with the same 'TaxCode' tag so resetting invalidates the
// generic list query too.
export const taxCodeExtraApi = baseApi.injectEndpoints({
  endpoints: (builder) => ({
    resetTaxCodes: builder.mutation({
      query: () => ({ url: '/company/tax-codes/reset', method: 'POST' }),
      transformResponse: (r) => r.data,
      invalidatesTags: [{ type: 'TaxCode', id: 'LIST' }],
    }),
  }),
});

export const { useResetTaxCodesMutation } = taxCodeExtraApi;
