import { createSlice } from '@reduxjs/toolkit';

// Chrome-style tab system: every page a user opens gets its own closeable tab.
// maxTabs defaults to 10, user-adjustable 1-10. When the max is hit, opening a
// new tab should prompt the user (handled by the TabBar component via
// pendingTab), not silently evict the oldest tab.
const STORAGE_KEY = 'nexora_tabs';

function loadInitial() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null');
    // dirtyPaths is deliberately never persisted/restored -- unsaved form
    // state doesn't survive a page reload anyway (keep-alive is in-memory
    // only), so a stale "dirty" flag from a previous session would just
    // block closing a tab that's actually clean.
    if (saved) return { tabs: [], activeTabPath: null, maxTabs: 10, ...saved, pendingTab: null, dirtyPaths: {} };
  } catch {
    /* ignore */
  }
  return { tabs: [], activeTabPath: null, maxTabs: 10, pendingTab: null, dirtyPaths: {} };
}

function persist(state) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify({ tabs: state.tabs, activeTabPath: state.activeTabPath, maxTabs: state.maxTabs }));
}

const tabsSlice = createSlice({
  name: 'tabs',
  initialState: loadInitial(),
  reducers: {
    openTab(state, action) {
      const { path, title, closable = true } = action.payload;
      const existing = state.tabs.find((t) => t.path === path);
      if (existing) {
        // Re-pin on every open in case an older, pre-pinned-Dashboard session
        // was persisted to localStorage with closable still true.
        if (closable === false) existing.closable = false;
        // Keep the tab's label in sync with the current nav config -- a menu
        // rename (e.g. "Business Partner" -> "Partner Management") should
        // take effect on the next visit, not stay stuck at whatever title
        // was persisted to localStorage the first time this path was opened.
        if (title && existing.title !== title) existing.title = title;
        state.activeTabPath = path;
        persist(state);
        return;
      }
      if (state.tabs.length >= state.maxTabs) {
        state.pendingTab = { path, title, closable };
        return;
      }
      state.tabs.push({ path, title, closable });
      state.activeTabPath = path;
      persist(state);
    },
    confirmOpenPendingTab(state) {
      if (!state.pendingTab) return;
      // Evict the oldest closable tab to make room, per user confirmation
      const idx = state.tabs.findIndex((t) => t.closable);
      if (idx !== -1) state.tabs.splice(idx, 1);
      state.tabs.push(state.pendingTab);
      state.activeTabPath = state.pendingTab.path;
      state.pendingTab = null;
      persist(state);
    },
    cancelPendingTab(state) {
      state.pendingTab = null;
    },
    closeTab(state, action) {
      const path = action.payload;
      const idx = state.tabs.findIndex((t) => t.path === path);
      if (idx === -1) return;
      if (state.tabs[idx].closable === false) return; // e.g. Dashboard -- always pinned, never removable
      state.tabs.splice(idx, 1);
      delete state.dirtyPaths[path];
      if (state.activeTabPath === path) {
        const fallback = state.tabs[idx] || state.tabs[idx - 1];
        state.activeTabPath = fallback ? fallback.path : null;
      }
      persist(state);
    },
    closeAllTabs(state) {
      // Pinned tabs (Dashboard) survive "close all" -- it's static, not just
      // closeable-one-at-a-time.
      const closing = state.tabs.filter((t) => t.closable !== false).map((t) => t.path);
      state.tabs = state.tabs.filter((t) => t.closable === false);
      closing.forEach((p) => delete state.dirtyPaths[p]);
      state.activeTabPath = state.tabs[0]?.path || null;
      persist(state);
    },
    setActiveTab(state, action) {
      state.activeTabPath = action.payload;
      persist(state);
    },
    setMaxTabs(state, action) {
      state.maxTabs = Math.min(10, Math.max(1, action.payload));
      persist(state);
    },
    // Not persisted to localStorage -- purely in-memory, mirrors whether the
    // tab's form currently has unsaved edits (RHF's formState.isDirty).
    setTabDirty(state, action) {
      const { path, dirty } = action.payload;
      if (dirty) state.dirtyPaths[path] = true;
      else delete state.dirtyPaths[path];
    },
  },
});

export const {
  openTab, confirmOpenPendingTab, cancelPendingTab,
  closeTab, closeAllTabs, setActiveTab, setMaxTabs, setTabDirty,
} = tabsSlice.actions;
export default tabsSlice.reducer;
