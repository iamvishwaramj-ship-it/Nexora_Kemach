import { createSlice } from '@reduxjs/toolkit';
import { DEFAULT_SIDEBAR_FONT, DEFAULT_BODY_FONT } from '../theme/fonts';
import { DEFAULT_COLOR_SCHEME } from '../theme/colorSchemes';

// Default theme color: maroon (DEFAULT_COLOR_SCHEME, defined next to the
// schemes themselves). Alt colors: orange, blue, green, red, purple.
// Also supports two-color combos (primary/accent pairs).
// sidebarFont / bodyFont let the sidebar navigation and the main
// dashboard/body content use independent professional fonts (Settings page).
// sidebarBold/Italic/Underline and bodyBold/Italic/Underline are independent
// style toggles layered on top of those fonts, also set from Settings.
const STORAGE_KEY = 'nexora_theme';

const DEFAULTS = {
  colorScheme: DEFAULT_COLOR_SCHEME,
  mode: 'light',
  sidebarFont: DEFAULT_SIDEBAR_FONT,
  bodyFont: DEFAULT_BODY_FONT,
  sidebarBold: false,
  sidebarItalic: false,
  sidebarUnderline: false,
  bodyBold: false,
  bodyItalic: false,
  bodyUnderline: false,
};

function loadInitial() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null');
    if (saved) {
      return { ...DEFAULTS, ...saved };
    }
  } catch {
    /* ignore */
  }
  return { ...DEFAULTS };
}

const initialState = loadInitial();

const themeSlice = createSlice({
  name: 'theme',
  initialState,
  reducers: {
    setColorScheme(state, action) {
      state.colorScheme = action.payload;
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    },
    setMode(state, action) {
      state.mode = action.payload;
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    },
    toggleMode(state) {
      state.mode = state.mode === 'light' ? 'dark' : 'light';
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    },
    setSidebarFont(state, action) {
      state.sidebarFont = action.payload;
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    },
    setBodyFont(state, action) {
      state.bodyFont = action.payload;
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    },
    setSidebarBold(state, action) {
      state.sidebarBold = action.payload;
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    },
    setSidebarItalic(state, action) {
      state.sidebarItalic = action.payload;
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    },
    setSidebarUnderline(state, action) {
      state.sidebarUnderline = action.payload;
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    },
    setBodyBold(state, action) {
      state.bodyBold = action.payload;
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    },
    setBodyItalic(state, action) {
      state.bodyItalic = action.payload;
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    },
    setBodyUnderline(state, action) {
      state.bodyUnderline = action.payload;
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    },
  },
});

export const {
  setColorScheme,
  setMode,
  toggleMode,
  setSidebarFont,
  setBodyFont,
  setSidebarBold,
  setSidebarItalic,
  setSidebarUnderline,
  setBodyBold,
  setBodyItalic,
  setBodyUnderline,
} = themeSlice.actions;
export default themeSlice.reducer;
