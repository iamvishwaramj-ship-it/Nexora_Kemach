const router = require('express').Router();
const { body } = require('express-validator');
const auth = require('../middleware/auth');
const controller = require('../controllers/authController');

router.post(
  '/login',
  [
    body('email').isEmail().withMessage('Enter a valid email address'),
    body('password').notEmpty().withMessage('Password is required'),
  ],
  controller.login
);

router.post('/refresh', controller.refresh);
router.post('/logout', controller.logout);
router.get('/me', auth(), controller.me);

router.post(
  '/reset-password',
  auth(),
  [
    body('currentPassword').notEmpty().withMessage('Current password is required'),
    body('newPassword')
      .isLength({ min: 8 })
      .withMessage('New password must be at least 8 characters')
      .matches(/[A-Z]/).withMessage('New password must contain an uppercase letter')
      .matches(/[0-9]/).withMessage('New password must contain a number'),
  ],
  controller.resetPassword
);

module.exports = router;
