// Consolidated REST resource mounting for every simple master/transaction
// resource in the app. Each one shares the same list/get/create/update/delete
// shape (see utils/crudFactory.js), so they're generated here instead of
// 30 near-identical route files.
const router = require('express').Router();
const multer = require('multer');
const prisma = require('../prisma/client');
const auth = require('../middleware/auth');
const asyncHandler = require('../utils/asyncHandler');
const crudRouter = require('../utils/crudRouter');
const { validateHeaders, readWorkbookRows } = require('../utils/xlsxImport');
const {
  TRANS_TYPES,
  postStockEntries,
  receiptLines,
  issueLines,
  adjustmentLines,
  grnLines,
  challanLines,
  transferOutLines,
  transferInLines,
  purchaseReturnLines,
  purchaseCreditMemoLines,
  salesReturnLines,
  salesCreditMemoLines,
  purchaseInvoiceLines,
  salesInvoiceLines,
} = require('../utils/stockTable');
const {
  getStockMovements,
  getStockMovementByProductCode,
  getInwardOutwardByProductCode,
  getCurrentStockForMany,
  getCurrentStockByWarehouseForMany,
} = require('../utils/stockLedger');
const { normaliseLine, computeTotals, isInterState, round2 } = require('../utils/documentTotals');
const { createOpenItemLedger } = require('../utils/openItemLedger');
const { validateChartOfAccount, guardChartOfAccountDelete } = require('../utils/chartOfAccountRules');
const { validateAccountGroup, guardAccountGroupDelete } = require('../utils/accountGroupRules');
const { getProductInventory } = require('../utils/productInventory');
const { resolveDocumentNumber } = require('../utils/documentNumber');
const {
  JOURNAL_SOURCE_TYPES,
  JOURNAL_STATUS,
  syncJournalEntry,
  reverseJournalEntry,
  repostJournalEntry,
} = require('../utils/glPosting');
const {
  recomputeSalesOrder,
  recomputePurchaseOrder,
  recomputeEnquiryStatus,
  recomputeSalesQuotationStatus,
  recomputePurchaseQuotationStatus,
  recomputeDeliveryChallanStatus,
  recomputeGrnStatus,
  assertNoOverDelivery,
  assertNoOverConsumption,
} = require('../utils/documentFlow');
const {
  buildRouteMap,
  isChallanInvoiced,
  isGrnInvoiced,
  assertReturnAllowed,
  assertCreditMemoAllowed,
} = require('../utils/routeMap');
const {
  assertWithinCreditLimit,
  assertNotReferenced,
  cascadeRename,
  assertMasterExists,
  getProductUsage,
  validateProductUsageFlags,
  validateItemCategoryRequired,
  assertProductUsageUnchanged,
  assertBatchSerialAllocation,
  assertUniqueBatchesAndSerials,
  assertBatchSerialIssueAllocation,
  assertBatchSerialAvailability,
  restoreBatchSerialIssueEffects,
  applyBatchSerialIssueEffects,
  assertBatchSerialRestockAllocation,
  assertBatchSerialRestockAvailability,
  restoreBatchSerialRestockEffects,
  applyBatchSerialRestockEffects,
  assertBatchSerialRelocateAllocation,
  assertWholeBatchRelocation,
  assertRelocateWarehouseMatches,
  restoreBatchSerialRelocateEffects,
  applyBatchSerialRelocateEffects,
} = require('../utils/businessRules');



// ---------------------------------------------------------------------------
// Document totals
// ---------------------------------------------------------------------------
// Every sales/purchase document computes its header the same way, through
// utils/documentTotals.js. Before that module existed each route carried its
// own inline copy of the arithmetic, and the copies had drifted: GRN and
// Delivery Challan hard-coded 9% + 9% GST regardless of what the goods
// attract, nothing was rounded to paise so stored headers did not add up, and
// inter-state supply could not be represented at all. The helpers below are
// the only thing routes call now.

// The company's registered state, which the place of supply is compared
// against to decide CGST/SGST vs IGST. Cached briefly because it is read on
// every document save but changes approximately never; the TTL means an edit
// in Company Details takes effect without a restart.
let homeStateCache = { value: null, readAt: 0 };
const HOME_STATE_TTL_MS = 60_000;

async function getHomeState(client) {
  const now = Date.now();
  if (homeStateCache.value !== null && now - homeStateCache.readAt < HOME_STATE_TTL_MS) {
    return homeStateCache.value;
  }
  const company = await client.companyDetails.findFirst({ select: { state: true } });
  homeStateCache = { value: company?.state || '', readAt: now };
  return homeStateCache.value;
}

/**
 * Decide the tax treatment for a document being saved.
 *
 * Returns true when the supply is inter-state and the whole tax must be
 * charged as IGST. When either the place of supply or the company's own state
 * is blank we deliberately fall back to intra-state (CGST/SGST) — that is the
 * behaviour every existing record was saved with, so an unconfigured company
 * keeps working exactly as before rather than silently restating its tax.
 */
async function resolveTaxTreatment(client, placeOfSupply) {
  if (!placeOfSupply) return false;
  return isInterState(placeOfSupply, await getHomeState(client));
}

/**
 * The SAP-style "Copy From" reference carried by every sales and purchase
 * line: which document, and which line of it, this line was copied from.
 *
 * Read here rather than in each document's own mapper because all twelve
 * line tables carry the identical four columns — see the
 * 20260820120000_add_base_document_fields migration. Doing it once is also
 * what stops the set drifting apart as documents are added.
 *
 * Every field is independently nullable and nothing is inferred: a line typed
 * in by hand has no base document, and inventing one would assert a history
 * that never happened. baseEntry/baseLine are coerced through Number and
 * dropped unless they come out as real integers, so a malformed client value
 * lands as NULL instead of poisoning the column.
 */
function baseFields(item) {
  const int = (v) => {
    if (v === '' || v == null) return null;
    const n = Number(v);
    return Number.isInteger(n) ? n : null;
  };
  return {
    baseType: item.baseType || null,
    baseEntry: int(item.baseEntry),
    baseNo: item.baseNo || null,
    baseLine: int(item.baseLine),
  };
}

/**
 * Map one raw request line onto the columns its line table actually has.
 *
 * The quantity/price/discount/tax/amount side comes from normaliseLine so
 * every document rounds identically; `passthrough` covers the descriptive
 * columns and `extras` the handful of per-document ones (batch numbers, PO
 * quantities). Nothing outside these lists reaches the database, so a client
 * cannot inject a column by adding it to the JSON.
 *
 * The four base_* columns are applied to every line table alike, so they are
 * added here rather than repeated in each caller's `extras`.
 */
function mapLine(item, {
  quantityField = 'quantity',
  passthrough = ['productCode', 'productName', 'description', 'hsnCode', 'uom'],
  extras = null,
} = {}) {
  const line = normaliseLine(item, { quantityField });
  const row = {};
  for (const key of passthrough) row[key] = item[key] || null;
  row[quantityField] = line.quantity;
  row.unitPrice = line.unitPrice;
  row.discountPercent = line.discountPercent;
  row.taxPercent = line.taxPercent;
  row.amount = line.amount;
  Object.assign(row, baseFields(item));
  if (extras) Object.assign(row, extras(item, line));
  return row;
}

/**
 * Reduce the engine's result to exactly the header columns that exist on
 * these models. `totalTax` is a working figure, not a stored one — spreading
 * it into Prisma's `data` would throw "Unknown argument totalTax".
 */
function headerTotals(totals, extra = {}) {
  return {
    subtotal: totals.subtotal,
    taxableAmount: totals.taxableAmount,
    cgstAmount: totals.cgstAmount,
    sgstAmount: totals.sgstAmount,
    igstAmount: totals.igstAmount,
    roundOff: totals.roundOff,
    amount: totals.amount,
    ...extra,
  };
}

/**
 * Strip fields a client must never be able to set on a header.
 *
 * Routes spread the request body straight into Prisma's `data`, so without
 * this a caller could post `{ "id": 1 }` and repoint a record's primary key,
 * or forge createdAt/updatedAt on an audited row. Computed money columns are
 * removed too: they are recalculated server-side immediately afterwards, and
 * accepting them from the wire is what lets a tampered client save an invoice
 * whose total does not match its lines.
 */
// Statuses that mean a document is not real revenue/spend yet, or has been
// withdrawn. Every analytics report filters on this.
//
// None of the sales or purchase reports filtered on status at all: a draft
// invoice someone was still typing, and a cancelled one, both counted as
// revenue. Sales figures, gross profit, salesman commissions and the
// dashboard were all overstated by whatever happened to be sitting in draft.
const UNREALISED_DOCUMENT_STATUSES = ['Draft', 'Cancelled'];
const REALISED_ONLY = { status: { notIn: UNREALISED_DOCUMENT_STATUSES } };

/**
 * Stamp each line with the product's cost price at the moment of the posting.
 *
 * Gross margin used to be valued against the product master's *present* cost
 * price, so changing a cost silently restated every historic margin the
 * business had already reported. Capturing it on the line freezes the figure
 * the way SAP's moving-average cost posting does.
 */
async function stampCostPrices(tx, itemData) {
  const codes = [...new Set(itemData.map((i) => i.productCode).filter(Boolean))];
  if (!codes.length) return itemData;

  const products = await tx.product.findMany({
    where: { productCode: { in: codes } },
    select: { productCode: true, costPrice: true },
  });
  const costByCode = new Map(products.map((p) => [p.productCode, Number(p.costPrice) || 0]));

  return itemData.map((i) => ({ ...i, costPrice: costByCode.get(i.productCode) || 0 }));
}

const PROTECTED_HEADER_FIELDS = [
  'id', 'createdAt', 'updatedAt', 'created_at', 'updated_at',
  'subtotal', 'taxableAmount', 'cgstAmount', 'sgstAmount', 'igstAmount',
  'roundOff', 'amount', 'totalItems', 'totalAppliedAmount',
];

/**
 * @param {object} header  the request body minus its line-item array
 * @param {object} options
 *   allow: string[]  — fields to keep despite being in the protected list.
 *     Needed because `amount` is a computed total on every document except
 *     Cheque, where it is the face value the user types on the cheque. Without
 *     this exemption the cheque would save with no amount at all, and the bank
 *     reconciliation entry raised from it would be for nothing.
 *   alsoBlock: string[] — additional fields to strip.
 */
function sanitizeHeader(header, { allow = [], alsoBlock = [] } = {}) {
  const blocked = new Set([...PROTECTED_HEADER_FIELDS, ...alsoBlock]);
  for (const field of allow) blocked.delete(field);

  const clean = {};
  for (const [key, value] of Object.entries(header || {})) {
    if (blocked.has(key)) continue;
    if (value === undefined) continue;
    clean[key] = value;
  }
  return clean;
}

/**
 * CRUD guards for the three masters every transaction refers to by name.
 *
 * Because customers, suppliers and products are linked to transactions by a
 * plain string with no foreign key, the database cannot refuse a delete that
 * orphans history the way it would for a real relation, and a rename silently
 * detaches a record from everything it ever did. These guards supply both
 * behaviours: refuse the delete, and carry the rename across.
 *
 * `identityField` is the column transactions actually store — the product code
 * for products, the display name for parties.
 */
function masterGuard(kind, identityField) {
  return {
    onDelete: async ({ id, delegate }) =>
      prisma.$transaction(async (tx) => {
        const existing = await delegate.findUnique({ where: { id } });
        if (!existing) {
          const err = new Error('Record not found');
          err.status = 404;
          throw err;
        }
        await assertNotReferenced(tx, kind, existing[identityField]);
        await delegate.delete({ where: { id } });
      }),

    onUpdate: async ({ id, data, delegate }) =>
      prisma.$transaction(async (tx) => {
        const existing = await delegate.findUnique({ where: { id } });
        const nextIdentity = data[identityField];
        const updated = await delegate.update({ where: { id }, data });

        if (existing && nextIdentity && existing[identityField] !== nextIdentity) {
          await cascadeRename(tx, kind, existing[identityField], nextIdentity);
        }
        return updated;
      }),
  };
}

/**
 * Product Master's guard: everything masterGuard does, plus the rule that a
 * flow flag already backed by documents cannot be turned off.
 *
 * Its own function rather than an option on masterGuard because the rule is
 * specific to this one master — no other record has flags that history pins —
 * and because the check has to happen inside the same transaction as the
 * update, before the write, so a save that would contradict existing
 * documents never lands at all.
 */
function productGuard() {
  const base = masterGuard('product', 'productCode');
  return {
    onDelete: base.onDelete,
    onUpdate: async ({ id, data, delegate }) =>
      prisma.$transaction(async (tx) => {
        const existing = await delegate.findUnique({ where: { id } });
        if (!existing) {
          const err = new Error('Record not found');
          err.status = 404;
          throw err;
        }

        // Checked against the STORED code, not whatever the payload carries:
        // the documents reference the product by the code it had when they
        // were written, and a rename in this same request has not cascaded yet.
        await assertProductUsageUnchanged(tx, existing.productCode, data);

        const nextIdentity = data.productCode;
        const updated = await delegate.update({ where: { id }, data });

        if (nextIdentity && existing.productCode !== nextIdentity) {
          await cascadeRename(tx, 'product', existing.productCode, nextIdentity);
        }
        return updated;
      }),
  };
}

// Accounting
// Master codes are auto-generated from perpetual numbering series — see
// DOCUMENT_CATALOG in services/documentNumberService.js. They carry no
// financial year: a code identifies a record for as long as it exists, so
// the counter must never reset with the year.
// `validate` derives GroupLevel from the parent chain, inherits GroupType from
// the drawer, keeps IsPostingAllowed meaning "is a leaf", and refuses cycles
// or a 6th level. See utils/accountGroupRules.js.
router.use('/account-groups', crudRouter(prisma.accountGroup, {
  searchFields: ['groupCode', 'groupName', 'groupType'],
  autoNumber: { documentCode: 'AG', field: 'groupCode', delegate: 'accountGroup' },
  validate: validateAccountGroup,
  guard: { onDelete: guardAccountGroupDelete },
}));
router.use('/account-types', crudRouter(prisma.accountType, {
  searchFields: ['typeCode', 'typeName'],
  autoNumber: { documentCode: 'ATY', field: 'typeCode', delegate: 'accountType' },
}));
// accountType is now a relation (AccountTypeID), not a scalar column, so it's
// dropped from searchFields — the generic { contains } search can't reach
// through a relation.
//
// `validate` enforces the SAP-style level hierarchy — Titles only as parents,
// parent in the same drawer, no cycles, and a 5-level cap — and rewrites
// AccountLevel with the server-derived depth so the column can't be spoofed by
// the client. See utils/chartOfAccountRules.js for the full rule list.
router.use('/chart-of-accounts', crudRouter(prisma.chartOfAccount, {
  searchFields: ['accountCode', 'accountName'],
  autoNumber: { documentCode: 'COA', field: 'accountCode', delegate: 'chartOfAccount' },
  validate: validateChartOfAccount,
  guard: { onDelete: guardChartOfAccountDelete },
}));
// One row per Financial Year, not a coded master — no autoNumber/searchFields.
// The page loads the whole list and finds the row for the selected period
// client-side, the same way FinancialYear's own picker works elsewhere.
router.use('/gl-account-determinations', crudRouter(prisma.glAccountDetermination, {}));

// Journal Entry (Accounting > Journal Entry) -- a master/detail resource
// (JournalEntry has many JournalEntryLine rows), hand-rolled like
// PaymentVoucher/PaymentReceipt/BankDeposit rather than the generic
// crudRouter: the header's totalDebit/totalCredit are server-recomputed from
// the lines on every save, never trusted from the client, and every save
// enforces the one rule the whole feature exists to guarantee -- a journal
// entry that does not balance (total debit == total credit) is rejected
// outright rather than saved lopsided.
/**
 * Drop the accounting document behind a business document that is about to be
 * deleted.
 *
 * Runs BEFORE the delete rather than inside it: the journal entry is keyed on
 * the document NUMBER, and by the time the row is gone there is no way left
 * to look that number up. Reads through the plain client rather than a
 * transaction for the same reason -- it is a lookup, not part of the delete's
 * atomicity, and a journal entry removed for a delete that then fails is
 * regenerated by the next save of that document.
 */
async function removeJournalEntryForDocument(client, sourceType, delegate, field, id) {
  if (!Number.isInteger(id) || id <= 0) return;
  const doc = await client[delegate].findUnique({ where: { id }, select: { [field]: true } });
  if (!doc?.[field]) return;
  await reverseJournalEntry(client, sourceType, doc[field]);
}

/**
 * Reload a source document, with its lines, for a parked entry being retried.
 * The shape each posting schema expects is the same one its route hands to
 * syncJournalEntry: the header, with `items`.
 */
const JOURNAL_SOURCE_LOADERS = {
  [JOURNAL_SOURCE_TYPES.PURCHASE_GRN]: (tx, no) => tx.goodsReceivedNote.findFirst({ where: { grnNo: no }, include: { items: true } }),
  [JOURNAL_SOURCE_TYPES.PURCHASE_INVOICE]: (tx, no) => tx.purchaseInvoice.findFirst({ where: { invoiceNo: no }, include: { items: true } }),
  [JOURNAL_SOURCE_TYPES.PURCHASE_RETURN]: (tx, no) => tx.purchaseReturn.findFirst({ where: { returnNo: no }, include: { items: true } }),
  [JOURNAL_SOURCE_TYPES.PURCHASE_CREDIT_MEMO]: (tx, no) => tx.purchaseCreditMemo.findFirst({ where: { creditNo: no }, include: { items: true } }),
  [JOURNAL_SOURCE_TYPES.DELIVERY_CHALLAN]: (tx, no) => tx.deliveryChallan.findFirst({ where: { challanNo: no }, include: { items: true } }),
  [JOURNAL_SOURCE_TYPES.SALES_INVOICE]: (tx, no) => tx.salesInvoice.findFirst({ where: { invoiceNo: no }, include: { items: true } }),
  [JOURNAL_SOURCE_TYPES.SALES_RETURN]: (tx, no) => tx.salesReturn.findFirst({ where: { returnNo: no }, include: { items: true } }),
  [JOURNAL_SOURCE_TYPES.SALES_CREDIT_MEMO]: (tx, no) => tx.salesCreditMemo.findFirst({ where: { creditNo: no }, include: { items: true } }),
  [JOURNAL_SOURCE_TYPES.STOCK_ISSUE]: (tx, no) => tx.stockIssue.findFirst({ where: { issueNo: no }, include: { items: true } }),
  [JOURNAL_SOURCE_TYPES.STOCK_RETURN]: (tx, no) => tx.stockReceipt.findFirst({ where: { receiptNo: no }, include: { items: true } }),
  [JOURNAL_SOURCE_TYPES.STOCK_TRANSFER]: (tx, no) => tx.stockTransfer.findFirst({ where: { transferNo: no }, include: { items: true } }),
  [JOURNAL_SOURCE_TYPES.PAYMENT_RECEIPT]: (tx, no) => tx.paymentReceipt.findFirst({ where: { paymentReceiptNo: no } }),
  [JOURNAL_SOURCE_TYPES.PAYMENT_VOUCHER]: (tx, no) => tx.paymentVoucher.findFirst({ where: { paymentVoucherNo: no } }),
};

function loadJournalSourceDocument(tx, sourceType, sourceDocNo) {
  const loader = JOURNAL_SOURCE_LOADERS[sourceType];
  if (!loader) return null;
  return loader(tx, sourceDocNo);
}

const journalEntryInclude = { lines: { orderBy: { id: 'asc' } } };

function toJournalEntryLineData(line, index) {
  const debit = round2(Number(line.debit) || 0);
  const credit = round2(Number(line.credit) || 0);
  return {
    lineNo: index + 1,
    accountCode: line.accountCode || '',
    accountName: line.accountName || null,
    description: line.description || null,
    costCenter: line.costCenter || null,
    debit,
    credit,
  };
}

/**
 * Every rule that makes a set of journal-entry lines a valid double-entry
 * posting. Thrown errors carry status 400 so they surface as a plain
 * validation message rather than a 500.
 *
 *   - at least two lines (a single-sided posting isn't a journal entry)
 *   - every line names an account
 *   - every line carries a debit XOR a credit, never both, never neither --
 *     a line with both is not "net" anything meaningful, and a line with
 *     neither is just a blank row that slipped through
 *   - total debit == total credit, to the paisa (0.005 tolerance for
 *     floating-point rounding, same tolerance documentFlow.js uses)
 */
function assertJournalEntryBalanced(lines) {
  if (!Array.isArray(lines) || lines.length < 2) {
    const err = new Error('A journal entry needs at least two lines');
    err.status = 400;
    throw err;
  }

  let totalDebit = 0;
  let totalCredit = 0;

  lines.forEach((line, index) => {
    if (!line.accountCode) {
      const err = new Error(`Line ${index + 1}: select a G/L account`);
      err.status = 400;
      throw err;
    }
    const debit = Number(line.debit) || 0;
    const credit = Number(line.credit) || 0;
    if (debit > 0 && credit > 0) {
      const err = new Error(`Line ${index + 1}: enter either a debit or a credit, not both`);
      err.status = 400;
      throw err;
    }
    if (debit <= 0 && credit <= 0) {
      const err = new Error(`Line ${index + 1}: enter a debit or a credit amount`);
      err.status = 400;
      throw err;
    }
    totalDebit = round2(totalDebit + debit);
    totalCredit = round2(totalCredit + credit);
  });

  if (Math.abs(totalDebit - totalCredit) > 0.005) {
    const err = new Error(
      `Journal entry is not balanced — total debit ₹${totalDebit.toFixed(2)} does not equal total credit ₹${totalCredit.toFixed(2)}`
    );
    err.status = 400;
    throw err;
  }

  return { totalDebit, totalCredit };
}

router.get('/journal-entries', auth(), asyncHandler(async (req, res) => {
  const { q } = req.query;
  const where = q
    ? {
        OR: [
          { journalEntryNo: { contains: q } },
          { referenceNo: { contains: q } },
          { remarks: { contains: q } },
        ],
      }
    : undefined;
  const rows = await prisma.journalEntry.findMany({ where, include: journalEntryInclude, orderBy: { id: 'desc' } });
  res.json({ success: true, data: rows });
}));

router.get('/journal-entries/:id', auth(), asyncHandler(async (req, res) => {
  const row = await prisma.journalEntry.findUnique({ where: { id: Number(req.params.id) }, include: journalEntryInclude });
  if (!row) return res.status(404).json({ success: false, message: 'Record not found' });
  res.json({ success: true, data: row });
}));

/**
 * Refuse to let a hand-edit reach a system-generated entry.
 *
 * An entry produced by glPosting.js is the accounting behind a document, and
 * the document is the authority for it. Editing it directly would put the
 * ledger and the document it claims to represent permanently out of step,
 * with nothing on either screen to reveal it — which is exactly the failure
 * an audit trail exists to prevent. Corrections go through the document:
 * change the invoice and its entry is rebuilt from what it now says.
 */
async function assertJournalEntryIsManual(id, action) {
  const existing = await prisma.journalEntry.findUnique({ where: { id } });
  if (!existing) {
    const err = new Error('Record not found');
    err.status = 404;
    throw err;
  }
  if (existing.sourceType) {
    const err = new Error(
      `This journal entry was generated automatically from ${existing.sourceType} ${existing.sourceDocNo} and cannot be ${action} directly. Change that document instead — its journal entry is rebuilt from it on every save.`
    );
    err.status = 400;
    throw err;
  }
  return existing;
}

router.post('/journal-entries', auth(), asyncHandler(async (req, res) => {
  const { lines = [], ...rawHeader } = req.body;
  // totalDebit/totalCredit are always server-computed from the lines below —
  // never trust what the client sent for them.
  //
  // transactionType, sourceType and sourceDocNo are blocked outright: a
  // hand-typed entry is a MANUAL entry, and letting a client name it 'Sales
  // Invoice' would put a row in the ledger that claims to be the accounting
  // behind a document it has no connection to. Only glPosting.js sets those.
  const header = sanitizeHeader(rawHeader, {
    alsoBlock: ['totalDebit', 'totalCredit', 'transactionType', 'sourceType', 'sourceDocNo', 'glError'],
  });
  const lineData = lines.map(toJournalEntryLineData);
  const { totalDebit, totalCredit } = assertJournalEntryBalanced(lineData);

  const row = await prisma.$transaction(async (tx) => {
    // journalEntryNo comes from the configured JE numbering series rather
    // than free text — see resolveDocumentNumber above.
    const { documentNumber, syncManual } = await resolveDocumentNumber('JE', header.journalEntryNo, tx);
    const created = await tx.journalEntry.create({
      data: {
        ...header,
        journalEntryNo: documentNumber,
        transactionType: JOURNAL_SOURCE_TYPES.MANUAL,
        sourceType: null,
        sourceDocNo: null,
        totalDebit,
        totalCredit,
        lines: { create: lineData },
      },
      include: journalEntryInclude,
    });
    if (syncManual) await syncManual();
    return created;
  });
  res.status(201).json({ success: true, data: row });
}));

router.put('/journal-entries/:id', auth(), asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  await assertJournalEntryIsManual(id, 'edited');

  const { lines = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader, {
    alsoBlock: ['totalDebit', 'totalCredit', 'journalEntryNo', 'transactionType', 'sourceType', 'sourceDocNo', 'glError'],
  });
  const lineData = lines.map(toJournalEntryLineData);
  const { totalDebit, totalCredit } = assertJournalEntryBalanced(lineData);

  // Replace the line set wholesale on every save — simpler and safer than
  // diffing which rows were added/removed/edited client-side, same as
  // PaymentVoucher/PaymentReceipt/BankDeposit above.
  const row = await prisma.$transaction(async (tx) => {
    await tx.journalEntryLine.deleteMany({ where: { journalEntryId: id } });
    const updated = await tx.journalEntry.update({
      where: { id },
      data: { ...header, transactionType: JOURNAL_SOURCE_TYPES.MANUAL, totalDebit, totalCredit, lines: { create: lineData } },
      include: journalEntryInclude,
    });
    return updated;
  });
  res.json({ success: true, data: row });
}));

/**
 * Post a parked entry, once the account determination it was waiting on has
 * been configured.
 *
 * This is the other half of the decision not to block documents on missing
 * configuration: an entry parked as 'Pending G/L' is a visible, listed debt
 * against the books, and this is how it gets settled. The source document is
 * re-read rather than replayed from anything cached on the parked row, since
 * it may well have been edited in the meantime.
 */
router.post('/journal-entries/:id/post-to-gl', auth(), asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  const row = await prisma.$transaction(async (tx) =>
    repostJournalEntry(tx, id, loadJournalSourceDocument)
  );
  res.json({ success: true, data: row });
}));

router.delete('/journal-entries/:id', auth(['admin']), asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  await assertJournalEntryIsManual(id, 'deleted');
  // JournalEntryLine.journalEntry has onDelete: Cascade, so lines go with it.
  await prisma.journalEntry.delete({ where: { id } });
  res.json({ success: true, message: 'Deleted successfully' });
}));

// Product Setup
// Master codes are auto-generated from perpetual numbering series — see
// DOCUMENT_CATALOG in services/documentNumberService.js. They carry no
// financial year: a code identifies a record for as long as it exists, so
// the counter must never reset with the year.
router.use('/product-groups', crudRouter(prisma.productGroup, {
  searchFields: ['groupCode', 'groupName'],
  autoNumber: { documentCode: 'PG', field: 'groupCode', delegate: 'productGroup' },
}));
router.use('/product-sub-groups', crudRouter(prisma.productSubGroup, {
  searchFields: ['subGroupCode', 'subGroupName'],
  autoNumber: { documentCode: 'PSG', field: 'subGroupCode', delegate: 'productSubGroup' },
}));
router.use('/brands', crudRouter(prisma.brand, {
  searchFields: ['brandCode', 'brandName'],
  autoNumber: { documentCode: 'BRD', field: 'brandCode', delegate: 'brand' },
}));
router.use('/uoms', crudRouter(prisma.uom, {
  searchFields: ['uomCode', 'uomName'],
  autoNumber: { documentCode: 'UOM', field: 'uomCode', delegate: 'uom' },
}));

// Registered before the generic /products crudRouter below so this exact
// path wins the match instead of being swallowed by crudRouter's GET /:id.
// Returns { [productCode]: liveCurrentStock } — openingStock plus every
// posted Stock Receipt/Issue/Adjustment movement for that product — so
// Product Master's list/mobile views can show real stock instead of the
// static opening-stock field.
router.get('/products/current-stock', auth(), asyncHandler(async (req, res) => {
  const [products, movement] = await Promise.all([
    prisma.product.findMany({ select: { productCode: true, openingStock: true } }),
    getStockMovementByProductCode(),
  ]);
  const data = Object.fromEntries(
    products.map((p) => [p.productCode, Number(p.openingStock || 0) + (movement.get(p.productCode) || 0)])
  );
  res.json({ success: true, data });
}));

// Product Master > Inventory tab — the per-warehouse position for one product.
//
// Registered before the generic '/products' crudRouter for the same reason as
// '/products/current-stock' above. A two-segment path would not collide with
// crudRouter's GET '/:id' in any case, but keeping every bespoke product route
// together above the generic one means the ordering rule holds however many
// are added later.
//
// Quantities and valuations are derived on every read; nothing is stored. See
// utils/productInventory.js for why, and for the two figures this schema
// genuinely cannot attribute per warehouse. (Min/Max levels used to be the
// one persisted exception, saved through a PUT on this same path — removed
// along with their table; see migration
// 20260823210000_drop_product_warehouse_levels. The tab is read-only now.)
router.get('/products/:productCode/inventory', auth(), asyncHandler(async (req, res) => {
  const data = await getProductInventory(req.params.productCode);
  res.json({ success: true, data });
}));

// Stock Summary report — bespoke aggregation endpoint for the Reports >
// Inventory > Stock Summary page. Registered before the generic
// '/products' crudRouter below, same reasoning as '/products/current-stock'
// above. Opening Stock is Product.openingStock itself (this schema has no
// per-warehouse opening balance — only movements are warehouse-tagged), so
// when a Warehouse filter is applied, Inward/Outward/Closing scope to that
// warehouse correctly but Opening Stock stays company-wide; this is a real
// limitation of the data model, not a bug, and mirrors how
// getStockMovementByProductCode()/current-stock works everywhere else.
// Only "Posted" documents move stock, same convention as current-stock.
// "Branch" and "Stock Type" are accepted for filter-bar parity but are
// no-ops — none of StockReceipt/StockIssue/StockAdjustment/Product has
// either concept as a real column.
router.get('/inventory/stock-summary/report', auth(), asyncHandler(async (req, res) => {
  const { warehouse, productGroup, product, itemCategory, stockType, stockStatus, asOnDate } = req.query;
  const asOn = asOnDate ? new Date(asOnDate) : new Date();
  asOn.setHours(23, 59, 59, 999);

  const productWhere = {};
  if (productGroup) productWhere.productGroup = productGroup;
  if (product) productWhere.productCode = product;
  if (itemCategory) productWhere.productType = itemCategory;

  // Inward/outward now cover every document type that moves stock — Stock
  // Receipt/Issue/Adjustment plus GRN, Delivery Challan and the invoices
  // raised without one. Previously only the three manual stock documents were
  // counted, so a warehouse could receive and despatch goods all month and
  // this report would show no movement at all. See utils/stockLedger.js.
  const [products, movements, { inward, outward }] = await Promise.all([
    prisma.product.findMany({ where: productWhere }),
    getStockMovements({ asOn, warehouse }),
    getInwardOutwardByProductCode({ asOn, warehouse }),
  ]);

  // Net movement value per warehouse (inward - outward, valued at each
  // product's costPrice) — the closest honest proxy to "stock value by
  // warehouse" this schema supports, since closing balance itself isn't
  // tracked per warehouse (see comment above). Movements from documents with
  // no warehouse column of their own (the invoices) fall into 'Unassigned'.
  const costByCode = Object.fromEntries(products.map((p) => [p.productCode, Number(p.costPrice || 0)]));
  const warehouseNet = {};
  for (const m of movements) {
    const name = m.warehouse || 'Unassigned';
    warehouseNet[name] = round2((warehouseNet[name] || 0) + m.quantity * (costByCode[m.productCode] || 0));
  }

  let rows = products.map((p) => {
    const openingQty = Number(p.openingStock || 0);
    const openingValue = openingQty * Number(p.costPrice || 0);
    const inwardQty = inward.get(p.productCode) || 0;
    const outwardQty = outward.get(p.productCode) || 0;
    const inwardValue = inwardQty * Number(p.costPrice || 0);
    const outwardValue = outwardQty * Number(p.costPrice || 0);
    const closingQty = openingQty + inwardQty - outwardQty;
    const closingValue = closingQty * Number(p.costPrice || 0);
    const reorderLevel = Number(p.reorderLevel || 0);

    let status;
    if (closingQty <= 0) status = 'Out of Stock';
    else if (reorderLevel > 0 && closingQty <= reorderLevel) status = 'Low Stock';
    else status = 'Available';

    return {
      productCode: p.productCode,
      productName: p.productName,
      productGroup: p.productGroup || 'Uncategorized',
      uom: p.uom || '—',
      openingQty, openingValue,
      inwardQty, inwardValue,
      outwardQty, outwardValue,
      closingQty, closingValue,
      stockValue: closingValue,
      status,
    };
  });

  if (stockStatus) rows = rows.filter((r) => r.status === stockStatus);

  const totals = rows.reduce((acc, r) => ({
    openingQty: acc.openingQty + r.openingQty, openingValue: acc.openingValue + r.openingValue,
    inwardQty: acc.inwardQty + r.inwardQty, inwardValue: acc.inwardValue + r.inwardValue,
    outwardQty: acc.outwardQty + r.outwardQty, outwardValue: acc.outwardValue + r.outwardValue,
    closingQty: acc.closingQty + r.closingQty, closingValue: acc.closingValue + r.closingValue,
  }), { openingQty: 0, openingValue: 0, inwardQty: 0, inwardValue: 0, outwardQty: 0, outwardValue: 0, closingQty: 0, closingValue: 0 });

  const totalStockValue = rows.reduce((sum, r) => sum + r.stockValue, 0);
  const lowStockCount = rows.filter((r) => r.status === 'Low Stock').length;
  const outOfStockCount = rows.filter((r) => r.status === 'Out of Stock').length;

  // Stock Value by Product Group (Top 5 + Others).
  const byGroupValue = {};
  rows.forEach((r) => { byGroupValue[r.productGroup] = (byGroupValue[r.productGroup] || 0) + r.stockValue; });
  const groupEntries = Object.entries(byGroupValue).sort((a, b) => b[1] - a[1]);
  const groupGrandTotal = totalStockValue || 1;
  const top5Groups = groupEntries.slice(0, 5);
  const othersGroupValue = groupEntries.slice(5).reduce((sum, [, v]) => sum + v, 0);
  const stockValueByGroup = [
    ...top5Groups.map(([name, value]) => ({ name, value: Math.round(value), percent: Math.round((value / groupGrandTotal) * 1000) / 10 })),
    ...(othersGroupValue > 0 ? [{ name: 'Others', value: Math.round(othersGroupValue), percent: Math.round((othersGroupValue / groupGrandTotal) * 1000) / 10 }] : []),
  ];

  // Stock Status Overview donut — item counts, not value.
  const statusOverview = [
    { name: 'Available', value: rows.filter((r) => r.status === 'Available').length },
    { name: 'Low Stock', value: lowStockCount },
    { name: 'Out of Stock', value: outOfStockCount },
  ];

  // Top 5 Low Stock Items — smallest remaining closing qty first, among
  // items actually flagged Low Stock.
  const topLowStockItems = rows
    .filter((r) => r.status === 'Low Stock')
    .sort((a, b) => a.closingQty - b.closingQty)
    .slice(0, 5)
    .map((r) => ({ name: r.productName, value: r.closingQty, uom: r.uom }));

  // Stock Value by Warehouse (Top 5) — net movement value, see comment above.
  const warehouseEntries = Object.entries(warehouseNet).sort((a, b) => b[1] - a[1]).slice(0, 5);
  const stockValueByWarehouse = warehouseEntries.map(([name, value]) => ({ name, value: Math.round(value) }));

  res.json({
    success: true,
    data: {
      rows,
      totals,
      stats: {
        totalProducts: rows.length,
        totalWarehouses: new Set(Object.keys(warehouseNet)).size,
        totalStockQuantity: totals.closingQty,
        totalStockValue,
        lowStockItems: lowStockCount,
        outOfStockItems: outOfStockCount,
      },
      stockValueByGroup,
      statusOverview,
      topLowStockItems,
      stockValueByWarehouse,
    },
  });
}));

// Stock Valuation report — bespoke aggregation endpoint for the Reports >
// Inventory > Stock Valuation page. Registered before the generic
// '/products' crudRouter below, same reasoning as the other product-scoped
// report routes above. Unlike Stock Summary, "Warehouse" here is simply
// Product.defaultLocation (a real per-product field) rather than something
// derived from movement history — this model doesn't track a per-warehouse
// closing balance, but it does record where each product is normally
// stocked, which is what this page actually shows one row per. "Valuation
// Method" has no real backing column anywhere (no FIFO/moving-average
// costing is implemented) — it's filter-bar-only and every row's Unit Cost
// is simply Product.costPrice, reported as "Standard Cost" regardless of
// which method is selected, rather than fabricating a FIFO/moving-average
// figure this schema has no data to support.
router.get('/inventory/stock-valuation/report', auth(), asyncHandler(async (req, res) => {
  const { warehouse, productGroup, product, asOnDate } = req.query;
  const asOn = asOnDate ? new Date(asOnDate) : new Date();
  asOn.setHours(23, 59, 59, 999);

  const productWhere = {};
  if (warehouse) productWhere.defaultLocation = warehouse;
  if (productGroup) productWhere.productGroup = productGroup;
  if (product) productWhere.productCode = product;

  const products = await prisma.product.findMany({ where: productWhere });
  const codes = products.map((p) => p.productCode);

  const [stockMovement, invoices, grns] = await Promise.all([
    // Net movement across every document type that moves stock — Stock
    // Receipt/Issue/Adjustment plus GRN, Delivery Challan and the invoices
    // raised without one. See utils/stockLedger.js.
    codes.length ? getStockMovementByProductCode({ asOn, productCodes: codes }) : new Map(),
    codes.length ? prisma.purchaseInvoice.findMany({ where: { invoiceDate: { lte: asOn } }, include: { items: { where: { productCode: { in: codes } } } }, orderBy: { invoiceDate: 'desc' } }) : [],
    codes.length ? prisma.goodsReceivedNote.findMany({ where: { receivedDate: { lte: asOn } }, include: { items: { where: { productCode: { in: codes } } } }, orderBy: { receivedDate: 'desc' } }) : [],
  ]);

  const movementByCode = {};
  const add = (code, delta) => { if (code) movementByCode[code] = (movementByCode[code] || 0) + delta; };
  for (const [code, qty] of stockMovement) add(code, qty);

  // Last Purchase Price/Date per product — most recent qualifying line
  // across both Purchase Invoice and Goods Receipt combined.
  const lastPurchaseFinal = {};
  [...invoices.flatMap((inv) => inv.items.map((item) => ({ code: item.productCode, date: inv.invoiceDate, unitPrice: Number(item.unitPrice || 0) }))),
   ...grns.flatMap((grn) => grn.items.map((item) => ({ code: item.productCode, date: grn.receivedDate, unitPrice: Number(item.unitPrice || 0) })))]
    .forEach(({ code, date, unitPrice }) => {
      if (!code) return;
      const existing = lastPurchaseFinal[code];
      if (!existing || (date && new Date(date) > new Date(existing.date || 0))) lastPurchaseFinal[code] = { date, unitPrice };
    });

  let rows = products.map((p) => {
    const onHandQty = Number(p.openingStock || 0) + (movementByCode[p.productCode] || 0);
    const unitCost = Number(p.costPrice || 0);
    const stockValue = onHandQty * unitCost;
    const lastPurchase = lastPurchaseFinal[p.productCode];
    return {
      productCode: p.productCode,
      productName: p.productName,
      productGroup: p.productGroup || 'Uncategorized',
      warehouse: p.defaultLocation || '—',
      uom: p.uom || '—',
      onHandQty,
      unitCost,
      stockValue,
      valuationMethod: 'Standard Cost',
      lastPurchasePrice: lastPurchase?.unitPrice ?? null,
      lastUpdated: lastPurchase?.date ?? null,
    };
  }).sort((a, b) => b.stockValue - a.stockValue);

  const totalStockQuantity = rows.reduce((sum, r) => sum + r.onHandQty, 0);
  const totalInventoryValue = rows.reduce((sum, r) => sum + r.stockValue, 0);
  const averageUnitCost = rows.length ? rows.reduce((sum, r) => sum + r.unitCost, 0) / rows.length : 0;
  const highestValueItem = rows[0] || null;
  const lowestValueItem = rows.length ? rows.reduce((min, r) => (r.stockValue < min.stockValue ? r : min), rows[0]) : null;

  // Inventory Value by Product Group (Top 5 + Others).
  const byGroupValue = {};
  rows.forEach((r) => { byGroupValue[r.productGroup] = (byGroupValue[r.productGroup] || 0) + r.stockValue; });
  const groupEntries = Object.entries(byGroupValue).sort((a, b) => b[1] - a[1]);
  const groupGrandTotal = totalInventoryValue || 1;
  const top5Groups = groupEntries.slice(0, 5);
  const othersGroupValue = groupEntries.slice(5).reduce((sum, [, v]) => sum + v, 0);
  const inventoryValueByGroup = [
    ...top5Groups.map(([name, value]) => ({ name, value: Math.round(value), percent: Math.round((value / groupGrandTotal) * 1000) / 10 })),
    ...(othersGroupValue > 0 ? [{ name: 'Others', value: Math.round(othersGroupValue), percent: Math.round((othersGroupValue / groupGrandTotal) * 1000) / 10 }] : []),
  ];

  // Top 10 Highest Value Products.
  const topHighestValueProducts = rows.slice(0, 10).map((r) => ({ name: r.productName, value: Math.round(r.stockValue) }));

  // Warehouse-wise Stock Value (Top 5) — real per-product defaultLocation,
  // not a movement-derived approximation.
  const byWarehouseValue = {};
  rows.forEach((r) => { byWarehouseValue[r.warehouse] = (byWarehouseValue[r.warehouse] || 0) + r.stockValue; });
  const warehouseWiseStockValue = Object.entries(byWarehouseValue)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([name, value]) => ({ name, value: Math.round(value) }));

  // Stock Value Distribution — bucket each product's own stock value.
  const distributionBuckets = { below1k: 0, r1kTo10k: 0, r10kTo50k: 0, r50kTo1L: 0, above1L: 0 };
  rows.forEach((r) => {
    const v = r.stockValue;
    if (v < 1000) distributionBuckets.below1k += 1;
    else if (v < 10000) distributionBuckets.r1kTo10k += 1;
    else if (v < 50000) distributionBuckets.r10kTo50k += 1;
    else if (v < 100000) distributionBuckets.r50kTo1L += 1;
    else distributionBuckets.above1L += 1;
  });
  const distributionTotal = rows.length || 1;
  const stockValueDistribution = [
    { name: 'Below ₹1,000', value: distributionBuckets.below1k, percent: Math.round((distributionBuckets.below1k / distributionTotal) * 1000) / 10 },
    { name: '₹1,000 - ₹10,000', value: distributionBuckets.r1kTo10k, percent: Math.round((distributionBuckets.r1kTo10k / distributionTotal) * 1000) / 10 },
    { name: '₹10,000 - ₹50,000', value: distributionBuckets.r10kTo50k, percent: Math.round((distributionBuckets.r10kTo50k / distributionTotal) * 1000) / 10 },
    { name: '₹50,000 - ₹1,00,000', value: distributionBuckets.r50kTo1L, percent: Math.round((distributionBuckets.r50kTo1L / distributionTotal) * 1000) / 10 },
    { name: 'Above ₹1,00,000', value: distributionBuckets.above1L, percent: Math.round((distributionBuckets.above1L / distributionTotal) * 1000) / 10 },
  ];

  res.json({
    success: true,
    data: {
      rows,
      totals: { onHandQty: totalStockQuantity, stockValue: totalInventoryValue },
      stats: {
        totalInventoryValue,
        totalProducts: rows.length,
        totalStockQuantity,
        averageUnitCost: Math.round(averageUnitCost * 100) / 100,
        highestValueItem: highestValueItem ? { name: highestValueItem.productName, value: highestValueItem.stockValue } : null,
        lowestValueItem: lowestValueItem ? { name: lowestValueItem.productName, value: lowestValueItem.stockValue } : null,
      },
      inventoryValueByGroup,
      topHighestValueProducts,
      warehouseWiseStockValue,
      stockValueDistribution,
    },
  });
}));

// Low Stock report — bespoke aggregation endpoint for the Reports >
// Inventory > Low Stock Report page. Same on-hand-quantity ledger and
// Product.defaultLocation-as-warehouse approach as Stock Valuation above.
// Product has no "Min Stock Level" column of its own (only reorderLevel)
// — Min Stock Level is derived as half of reorderLevel, a common
// real-world safety-stock convention, rather than a stored figure this
// schema doesn't have. Shortage Qty is always reorderLevel - onHandQty
// (never against Min Stock Level, regardless of which basis is selected)
// since that's the one shortage figure that's unambiguous either way.
// "Branch" and "Stock Type" are no-ops, same situation as Stock Summary.
router.get('/inventory/low-stock/report', auth(), asyncHandler(async (req, res) => {
  const { warehouse, productGroup, itemCategory, lowStockBasedOn, showItems, asOnDate } = req.query;
  const asOn = asOnDate ? new Date(asOnDate) : new Date();
  asOn.setHours(23, 59, 59, 999);

  const productWhere = {};
  if (warehouse) productWhere.defaultLocation = warehouse;
  if (productGroup) productWhere.productGroup = productGroup;
  if (itemCategory) productWhere.productType = itemCategory;

  const allProducts = await prisma.product.findMany({ where: productWhere });
  const codes = allProducts.map((p) => p.productCode);

  const [stockMovement, invoices, grns] = await Promise.all([
    // Net movement across every document type that moves stock — Stock
    // Receipt/Issue/Adjustment plus GRN, Delivery Challan and the invoices
    // raised without one. See utils/stockLedger.js.
    codes.length ? getStockMovementByProductCode({ asOn, productCodes: codes }) : new Map(),
    codes.length ? prisma.purchaseInvoice.findMany({ where: { invoiceDate: { lte: asOn } }, include: { items: { where: { productCode: { in: codes } } } }, orderBy: { invoiceDate: 'desc' } }) : [],
    codes.length ? prisma.goodsReceivedNote.findMany({ where: { receivedDate: { lte: asOn } }, include: { items: { where: { productCode: { in: codes } } } }, orderBy: { receivedDate: 'desc' } }) : [],
  ]);

  const movementByCode = {};
  const add = (code, delta) => { if (code) movementByCode[code] = (movementByCode[code] || 0) + delta; };
  for (const [code, qty] of stockMovement) add(code, qty);

  const lastPurchaseDateByCode = {};
  [...invoices.flatMap((inv) => inv.items.map((item) => ({ code: item.productCode, date: inv.invoiceDate }))),
   ...grns.flatMap((grn) => grn.items.map((item) => ({ code: item.productCode, date: grn.receivedDate })))]
    .forEach(({ code, date }) => {
      if (!code) return;
      const existing = lastPurchaseDateByCode[code];
      if (!existing || (date && new Date(date) > new Date(existing))) lastPurchaseDateByCode[code] = date;
    });

  const allRows = allProducts.map((p) => {
    const onHandQty = Number(p.openingStock || 0) + (movementByCode[p.productCode] || 0);
    const reorderLevel = Number(p.reorderLevel || 0);
    const minStockLevel = reorderLevel * 0.5;
    const unitCost = Number(p.costPrice || 0);
    const stockValue = onHandQty * unitCost;
    const shortageQty = Math.max(reorderLevel - onHandQty, 0);

    let bucket;
    if (onHandQty <= 0) bucket = 'Out of Stock';
    else if (onHandQty <= minStockLevel) bucket = 'Reorder Soon';
    else if (onHandQty <= reorderLevel) bucket = 'Low Stock';
    else bucket = 'Available';

    return {
      productCode: p.productCode,
      productName: p.productName,
      productGroup: p.productGroup || 'Uncategorized',
      warehouse: p.defaultLocation || '—',
      uom: p.uom || '—',
      onHandQty,
      reorderLevel,
      minStockLevel,
      shortageQty,
      unitCost,
      stockValue,
      lastPurchaseDate: lastPurchaseDateByCode[p.productCode] || null,
      bucket,
      status: bucket === 'Available' ? 'Available' : (bucket === 'Out of Stock' ? 'Out of Stock' : 'Low Stock'),
    };
  });

  // Below Reorder Level is the default working set for this whole page —
  // everything at or below reorderLevel, regardless of bucket. showItems
  // narrows (or widens, for "All Products") from there.
  let rows = allRows.filter((r) => r.bucket !== 'Available');
  if (showItems === 'Below Min Stock Level') rows = rows.filter((r) => r.onHandQty <= r.minStockLevel);
  else if (showItems === 'Out of Stock Only') rows = rows.filter((r) => r.bucket === 'Out of Stock');
  else if (showItems === 'All Products') rows = allRows;

  // lowStockBasedOn only affects which threshold column is treated as the
  // "primary" one for sorting the list — Shortage Qty itself is always
  // reorder-level-based (see comment above).
  rows = rows.sort((a, b) => (lowStockBasedOn === 'Min Stock Level'
    ? (a.onHandQty - a.minStockLevel) - (b.onHandQty - b.minStockLevel)
    : (a.onHandQty - a.reorderLevel) - (b.onHandQty - b.reorderLevel)));

  const totals = rows.reduce((acc, r) => ({
    onHandQty: acc.onHandQty + r.onHandQty,
    reorderLevel: acc.reorderLevel + r.reorderLevel,
    minStockLevel: acc.minStockLevel + r.minStockLevel,
    shortageQty: acc.shortageQty + r.shortageQty,
    stockValue: acc.stockValue + r.stockValue,
  }), { onHandQty: 0, reorderLevel: 0, minStockLevel: 0, shortageQty: 0, stockValue: 0 });

  const reorderSoonCount = rows.filter((r) => r.bucket === 'Reorder Soon').length;
  const outOfStockCount = rows.filter((r) => r.bucket === 'Out of Stock').length;
  const lowStockBelowReorderCount = rows.filter((r) => r.bucket === 'Low Stock').length;

  const statusOverview = [
    { name: 'Low Stock (Below Reorder)', value: lowStockBelowReorderCount },
    { name: 'Reorder Soon', value: reorderSoonCount },
    { name: 'Out of Stock', value: outOfStockCount },
  ];

  // Top 10 Items by Shortage Qty, across the full filtered set (not just
  // the current page).
  const topShortageItems = [...rows].sort((a, b) => b.shortageQty - a.shortageQty).slice(0, 10)
    .map((r) => ({ name: r.productName, value: Math.round(r.shortageQty * 1000) / 1000 }));

  // Low Stock by Warehouse (Top 5) — item counts.
  const byWarehouseCount = {};
  rows.forEach((r) => { byWarehouseCount[r.warehouse] = (byWarehouseCount[r.warehouse] || 0) + 1; });
  const lowStockByWarehouse = Object.entries(byWarehouseCount).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([name, value]) => ({ name, value }));

  // Low Stock Value by Product Group (Top 5 + Others).
  const byGroupValue = {};
  rows.forEach((r) => { byGroupValue[r.productGroup] = (byGroupValue[r.productGroup] || 0) + r.stockValue; });
  const groupEntries = Object.entries(byGroupValue).sort((a, b) => b[1] - a[1]);
  const groupGrandTotal = totals.stockValue || 1;
  const top5Groups = groupEntries.slice(0, 5);
  const othersGroupValue = groupEntries.slice(5).reduce((sum, [, v]) => sum + v, 0);
  const lowStockValueByGroup = [
    ...top5Groups.map(([name, value]) => ({ name, value: Math.round(value), percent: Math.round((value / groupGrandTotal) * 1000) / 10 })),
    ...(othersGroupValue > 0 ? [{ name: 'Others', value: Math.round(othersGroupValue), percent: Math.round((othersGroupValue / groupGrandTotal) * 1000) / 10 }] : []),
  ];

  res.json({
    success: true,
    data: {
      rows,
      totals,
      stats: {
        lowStockItems: rows.length,
        totalProducts: allProducts.length,
        totalWarehouses: new Set(allProducts.map((p) => p.defaultLocation).filter(Boolean)).size,
        totalStockValue: totals.stockValue,
        reorderSoon: reorderSoonCount,
        outOfStock: outOfStockCount,
      },
      statusOverview,
      topShortageItems,
      lowStockByWarehouse,
      lowStockValueByGroup,
    },
  });
}));

// Slow Moving Stock report — bespoke aggregation endpoint for the
// Reports > Inventory > Slow Moving Stock page. Same on-hand-quantity
// ledger and Product.defaultLocation-as-warehouse approach as Stock
// Valuation/Low Stock above. "Last Sale Date" is the most recent date
// across either SalesOrder or SalesInvoice items for a product (whichever
// is later) — this schema has no single canonical "sale" event, so both
// are considered candidates, same reasoning as Stock Valuation treating
// Purchase Invoice and GRN as equivalent purchase evidence. Only products
// that still have on-hand stock are relevant here (an out-of-stock
// product isn't "slow moving", it's just gone) — that overlap with Low
// Stock/Out of Stock items is intentional and mirrors how a real slow-
// moving report works. "Branch" and "Stock Type" are no-ops, same
// situation as the other inventory reports.
router.get('/inventory/slow-moving/report', auth(), asyncHandler(async (req, res) => {
  const { warehouse, productGroup, itemCategory, slowMovingBasedOn, daysThreshold, asOnDate } = req.query;
  const asOn = asOnDate ? new Date(asOnDate) : new Date();
  asOn.setHours(23, 59, 59, 999);
  const threshold = Number(daysThreshold) > 0 ? Number(daysThreshold) : 90;
  const basedOnPurchase = slowMovingBasedOn === 'Last Purchase Date';

  const productWhere = {};
  if (warehouse) productWhere.defaultLocation = warehouse;
  if (productGroup) productWhere.productGroup = productGroup;
  if (itemCategory) productWhere.productType = itemCategory;

  const allProducts = await prisma.product.findMany({ where: productWhere });
  const codes = allProducts.map((p) => p.productCode);

  const [stockMovement, orders, invoices, purchaseInvoices, grns] = await Promise.all([
    // Net movement across every document type that moves stock — Stock
    // Receipt/Issue/Adjustment plus GRN, Delivery Challan and the invoices
    // raised without one. See utils/stockLedger.js.
    codes.length ? getStockMovementByProductCode({ asOn, productCodes: codes }) : new Map(),
    codes.length ? prisma.salesOrder.findMany({ where: { orderDate: { lte: asOn } }, include: { items: { where: { productCode: { in: codes } } } } }) : [],
    codes.length ? prisma.salesInvoice.findMany({ where: { invoiceDate: { lte: asOn } }, include: { items: { where: { productCode: { in: codes } } } } }) : [],
    codes.length ? prisma.purchaseInvoice.findMany({ where: { invoiceDate: { lte: asOn } }, include: { items: { where: { productCode: { in: codes } } } } }) : [],
    codes.length ? prisma.goodsReceivedNote.findMany({ where: { receivedDate: { lte: asOn } }, include: { items: { where: { productCode: { in: codes } } } } }) : [],
  ]);

  const movementByCode = {};
  const add = (code, delta) => { if (code) movementByCode[code] = (movementByCode[code] || 0) + delta; };
  for (const [code, qty] of stockMovement) add(code, qty);

  const lastDateByCode = (candidates) => {
    const result = {};
    candidates.forEach(({ code, date }) => {
      if (!code || !date) return;
      const existing = result[code];
      if (!existing || new Date(date) > new Date(existing)) result[code] = date;
    });
    return result;
  };

  const lastSaleByCode = lastDateByCode([
    ...orders.flatMap((o) => o.items.map((item) => ({ code: item.productCode, date: o.orderDate }))),
    ...invoices.flatMap((inv) => inv.items.map((item) => ({ code: item.productCode, date: inv.invoiceDate }))),
  ]);
  const lastPurchaseByCode = lastDateByCode([
    ...purchaseInvoices.flatMap((inv) => inv.items.map((item) => ({ code: item.productCode, date: inv.invoiceDate }))),
    ...grns.flatMap((grn) => grn.items.map((item) => ({ code: item.productCode, date: grn.receivedDate }))),
  ]);

  const MS_PER_DAY = 24 * 60 * 60 * 1000;
  const allRows = allProducts.map((p) => {
    const onHandQty = Number(p.openingStock || 0) + (movementByCode[p.productCode] || 0);
    const unitCost = Number(p.costPrice || 0);
    const stockValue = onHandQty * unitCost;
    const referenceDate = basedOnPurchase ? lastPurchaseByCode[p.productCode] : lastSaleByCode[p.productCode];
    const daysInStock = referenceDate ? Math.floor((asOn - new Date(referenceDate)) / MS_PER_DAY) : null;

    return {
      productCode: p.productCode,
      productName: p.productName,
      productGroup: p.productGroup || 'Uncategorized',
      warehouse: p.defaultLocation || '—',
      uom: p.uom || '—',
      onHandQty,
      lastSaleDate: referenceDate || null,
      daysInStock,
      unitCost,
      stockValue,
      lastPurchaseDate: lastPurchaseByCode[p.productCode] || null,
    };
  });

  // Slow moving = still has stock, and either never sold/purchased (per
  // the selected basis) or hasn't moved in longer than the threshold.
  const rows = allRows
    .filter((r) => r.onHandQty > 0 && (r.daysInStock === null || r.daysInStock > threshold))
    .sort((a, b) => (b.daysInStock ?? Infinity) - (a.daysInStock ?? Infinity));

  const totals = rows.reduce((acc, r) => ({
    onHandQty: acc.onHandQty + r.onHandQty,
    stockValue: acc.stockValue + r.stockValue,
  }), { onHandQty: 0, stockValue: 0 });

  const withDays = rows.filter((r) => r.daysInStock !== null);
  const avgDaysInStock = withDays.length ? Math.round(withDays.reduce((sum, r) => sum + r.daysInStock, 0) / withDays.length) : 0;

  // Slow Moving Stock by Days in Stock — aging buckets, items never
  // sold/purchased fall into the oldest ("Above 240 Days") bucket.
  const dayBuckets = { d90to120: 0, d121to150: 0, d151to180: 0, d181to240: 0, above240: 0 };
  rows.forEach((r) => {
    const d = r.daysInStock ?? Infinity;
    if (d <= 120) dayBuckets.d90to120 += 1;
    else if (d <= 150) dayBuckets.d121to150 += 1;
    else if (d <= 180) dayBuckets.d151to180 += 1;
    else if (d <= 240) dayBuckets.d181to240 += 1;
    else dayBuckets.above240 += 1;
  });
  const daysTotal = rows.length || 1;
  const slowMovingByDaysInStock = [
    { name: '90 - 120 Days', value: dayBuckets.d90to120, percent: Math.round((dayBuckets.d90to120 / daysTotal) * 1000) / 10 },
    { name: '121 - 150 Days', value: dayBuckets.d121to150, percent: Math.round((dayBuckets.d121to150 / daysTotal) * 1000) / 10 },
    { name: '151 - 180 Days', value: dayBuckets.d151to180, percent: Math.round((dayBuckets.d151to180 / daysTotal) * 1000) / 10 },
    { name: '181 - 240 Days', value: dayBuckets.d181to240, percent: Math.round((dayBuckets.d181to240 / daysTotal) * 1000) / 10 },
    { name: 'Above 240 Days', value: dayBuckets.above240, percent: Math.round((dayBuckets.above240 / daysTotal) * 1000) / 10 },
  ];

  // Top 10 Slow Moving Items by Stock Value.
  const topSlowMovingItems = [...rows].sort((a, b) => b.stockValue - a.stockValue).slice(0, 10)
    .map((r) => ({ name: r.productName, value: Math.round(r.stockValue) }));

  // Slow Moving Stock Value by Warehouse (Top 5).
  const byWarehouseValue = {};
  rows.forEach((r) => { byWarehouseValue[r.warehouse] = (byWarehouseValue[r.warehouse] || 0) + r.stockValue; });
  const slowMovingByWarehouse = Object.entries(byWarehouseValue).sort((a, b) => b[1] - a[1]).slice(0, 5)
    .map(([name, value]) => ({ name, value: Math.round(value) }));

  // Slow Moving Stock by Product Group (Top 5 + Others).
  const byGroupValue = {};
  rows.forEach((r) => { byGroupValue[r.productGroup] = (byGroupValue[r.productGroup] || 0) + r.stockValue; });
  const groupEntries = Object.entries(byGroupValue).sort((a, b) => b[1] - a[1]);
  const groupGrandTotal = totals.stockValue || 1;
  const top5Groups = groupEntries.slice(0, 5);
  const othersGroupValue = groupEntries.slice(5).reduce((sum, [, v]) => sum + v, 0);
  const slowMovingByGroup = [
    ...top5Groups.map(([name, value]) => ({ name, value: Math.round(value), percent: Math.round((value / groupGrandTotal) * 1000) / 10 })),
    ...(othersGroupValue > 0 ? [{ name: 'Others', value: Math.round(othersGroupValue), percent: Math.round((othersGroupValue / groupGrandTotal) * 1000) / 10 }] : []),
  ];

  res.json({
    success: true,
    data: {
      rows,
      totals,
      stats: {
        slowMovingItems: rows.length,
        totalProducts: allProducts.length,
        totalWarehouses: new Set(allProducts.map((p) => p.defaultLocation).filter(Boolean)).size,
        totalStockValue: totals.stockValue,
        avgDaysInStock,
        thresholdDays: threshold,
      },
      slowMovingByDaysInStock,
      topSlowMovingItems,
      slowMovingByWarehouse,
      slowMovingByGroup,
    },
  });
}));

// Dead Stock report — bespoke aggregation endpoint for the Reports >
// Inventory > Dead Stock page. Same on-hand-quantity ledger and last-sale/
// last-purchase lookups as Slow Moving Stock above, but scoped tighter:
// dead stock is stock that has NEVER been sold (no SalesOrder or
// SalesInvoice line ever recorded for it) and was last purchased more
// than the threshold days ago — a stronger claim than "hasn't moved
// recently," which is what Slow Moving Stock covers. "Branch" and "Stock
// Type" are no-ops, same situation as the other inventory reports.
router.get('/inventory/dead-stock/report', auth(), asyncHandler(async (req, res) => {
  const { warehouse, productGroup, itemCategory, deadStockBasedOn, daysThreshold, asOnDate } = req.query;
  const asOn = asOnDate ? new Date(asOnDate) : new Date();
  asOn.setHours(23, 59, 59, 999);
  const threshold = Number(daysThreshold) > 0 ? Number(daysThreshold) : 180;
  const basedOnSale = deadStockBasedOn === 'Last Sale Date';

  const productWhere = {};
  if (warehouse) productWhere.defaultLocation = warehouse;
  if (productGroup) productWhere.productGroup = productGroup;
  if (itemCategory) productWhere.productType = itemCategory;

  const allProducts = await prisma.product.findMany({ where: productWhere });
  const codes = allProducts.map((p) => p.productCode);

  const [stockMovement, orders, invoices, purchaseInvoices, grns] = await Promise.all([
    // Net movement across every document type that moves stock — Stock
    // Receipt/Issue/Adjustment plus GRN, Delivery Challan and the invoices
    // raised without one. See utils/stockLedger.js.
    codes.length ? getStockMovementByProductCode({ asOn, productCodes: codes }) : new Map(),
    codes.length ? prisma.salesOrder.findMany({ where: {}, include: { items: { where: { productCode: { in: codes } } } } }) : [],
    codes.length ? prisma.salesInvoice.findMany({ where: {}, include: { items: { where: { productCode: { in: codes } } } } }) : [],
    codes.length ? prisma.purchaseInvoice.findMany({ where: { invoiceDate: { lte: asOn } }, include: { items: { where: { productCode: { in: codes } } } } }) : [],
    codes.length ? prisma.goodsReceivedNote.findMany({ where: { receivedDate: { lte: asOn } }, include: { items: { where: { productCode: { in: codes } } } } }) : [],
  ]);

  const movementByCode = {};
  const add = (code, delta) => { if (code) movementByCode[code] = (movementByCode[code] || 0) + delta; };
  for (const [code, qty] of stockMovement) add(code, qty);

  // Any sale at all (ever, regardless of asOnDate) disqualifies a product
  // from being "dead stock" — this is a stronger/simpler check than Slow
  // Moving Stock's "how long since the last one".
  const everSoldCodes = new Set([
    ...orders.flatMap((o) => o.items.map((item) => item.productCode)),
    ...invoices.flatMap((inv) => inv.items.map((item) => item.productCode)),
  ]);

  const lastDateByCode = (candidates) => {
    const result = {};
    candidates.forEach(({ code, date }) => {
      if (!code || !date) return;
      const existing = result[code];
      if (!existing || new Date(date) > new Date(existing)) result[code] = date;
    });
    return result;
  };
  const lastPurchaseByCode = lastDateByCode([
    ...purchaseInvoices.flatMap((inv) => inv.items.map((item) => ({ code: item.productCode, date: inv.invoiceDate }))),
    ...grns.flatMap((grn) => grn.items.map((item) => ({ code: item.productCode, date: grn.receivedDate }))),
  ]);

  const MS_PER_DAY = 24 * 60 * 60 * 1000;
  const allRows = allProducts.map((p) => {
    const onHandQty = Number(p.openingStock || 0) + (movementByCode[p.productCode] || 0);
    const unitCost = Number(p.costPrice || 0);
    const stockValue = onHandQty * unitCost;
    const neverSold = !everSoldCodes.has(p.productCode);
    // basedOnSale with a never-sold item has no date to compute from —
    // daysInStock stays null (treated as "always qualifies", same as
    // Slow Moving Stock's never-moved case).
    const referenceDate = basedOnSale ? null : lastPurchaseByCode[p.productCode];
    const daysInStock = referenceDate ? Math.floor((asOn - new Date(referenceDate)) / MS_PER_DAY) : null;

    return {
      productCode: p.productCode,
      productName: p.productName,
      productGroup: p.productGroup || 'Uncategorized',
      warehouse: p.defaultLocation || '—',
      uom: p.uom || '—',
      onHandQty,
      lastPurchaseDate: lastPurchaseByCode[p.productCode] || null,
      lastSaleDate: null,
      daysInStock,
      unitCost,
      stockValue,
      neverSold,
      status: 'Dead Stock',
    };
  });

  const rows = allRows
    .filter((r) => r.onHandQty > 0 && r.neverSold && (r.daysInStock === null || r.daysInStock > threshold))
    .sort((a, b) => (b.daysInStock ?? Infinity) - (a.daysInStock ?? Infinity));

  const totals = rows.reduce((acc, r) => ({
    onHandQty: acc.onHandQty + r.onHandQty,
    stockValue: acc.stockValue + r.stockValue,
  }), { onHandQty: 0, stockValue: 0 });

  const withDays = rows.filter((r) => r.daysInStock !== null);
  const avgDaysInStock = withDays.length ? Math.round(withDays.reduce((sum, r) => sum + r.daysInStock, 0) / withDays.length) : 0;
  const oldestStock = withDays.length ? Math.max(...withDays.map((r) => r.daysInStock)) : 0;

  // Dead Stock by Days in Stock — wider buckets than Slow Moving Stock,
  // since dead stock is inherently older.
  const dayBuckets = { d180to365: 0, d366to540: 0, d541to720: 0, above720: 0 };
  rows.forEach((r) => {
    const d = r.daysInStock ?? Infinity;
    if (d <= 365) dayBuckets.d180to365 += 1;
    else if (d <= 540) dayBuckets.d366to540 += 1;
    else if (d <= 720) dayBuckets.d541to720 += 1;
    else dayBuckets.above720 += 1;
  });
  const daysTotal = rows.length || 1;
  const deadStockByDaysInStock = [
    { name: '180 - 365 Days', value: dayBuckets.d180to365, percent: Math.round((dayBuckets.d180to365 / daysTotal) * 1000) / 10 },
    { name: '366 - 540 Days', value: dayBuckets.d366to540, percent: Math.round((dayBuckets.d366to540 / daysTotal) * 1000) / 10 },
    { name: '541 - 720 Days', value: dayBuckets.d541to720, percent: Math.round((dayBuckets.d541to720 / daysTotal) * 1000) / 10 },
    { name: 'Above 720 Days', value: dayBuckets.above720, percent: Math.round((dayBuckets.above720 / daysTotal) * 1000) / 10 },
  ];

  const topDeadStockItems = [...rows].sort((a, b) => b.stockValue - a.stockValue).slice(0, 10)
    .map((r) => ({ name: r.productName, value: Math.round(r.stockValue) }));

  const byWarehouseValue = {};
  rows.forEach((r) => { byWarehouseValue[r.warehouse] = (byWarehouseValue[r.warehouse] || 0) + r.stockValue; });
  const deadStockByWarehouse = Object.entries(byWarehouseValue).sort((a, b) => b[1] - a[1]).slice(0, 5)
    .map(([name, value]) => ({ name, value: Math.round(value) }));

  const byGroupValue = {};
  rows.forEach((r) => { byGroupValue[r.productGroup] = (byGroupValue[r.productGroup] || 0) + r.stockValue; });
  const groupEntries = Object.entries(byGroupValue).sort((a, b) => b[1] - a[1]);
  const groupGrandTotal = totals.stockValue || 1;
  const top5Groups = groupEntries.slice(0, 5);
  const othersGroupValue = groupEntries.slice(5).reduce((sum, [, v]) => sum + v, 0);
  const deadStockByGroup = [
    ...top5Groups.map(([name, value]) => ({ name, value: Math.round(value), percent: Math.round((value / groupGrandTotal) * 1000) / 10 })),
    ...(othersGroupValue > 0 ? [{ name: 'Others', value: Math.round(othersGroupValue), percent: Math.round((othersGroupValue / groupGrandTotal) * 1000) / 10 }] : []),
  ];

  res.json({
    success: true,
    data: {
      rows,
      totals,
      stats: {
        deadStockItems: rows.length,
        totalProducts: allProducts.length,
        totalWarehouses: new Set(allProducts.map((p) => p.defaultLocation).filter(Boolean)).size,
        totalStockValue: totals.stockValue,
        avgDaysInStock,
        oldestStock,
      },
      deadStockByDaysInStock,
      topDeadStockItems,
      deadStockByWarehouse,
      deadStockByGroup,
    },
  });
}));

// Reorder Level report — bespoke aggregation endpoint for the
// Reports > Inventory > Reorder Level page. Same on-hand-quantity ledger,
// Product.defaultLocation-as-warehouse, and last-purchase-date-merge
// approach as the other inventory reports above. "Suggested Order Qty" has
// no dedicated column/formula anywhere in the schema (no EOQ, lead-time,
// or safety-stock fields exist on Product) — the simplest honest business
// rule available is to suggest restocking back up to the configured
// Product.reorderLevel itself, which is what "Estimated Reorder Value" is
// then computed against (Suggested Order Qty x Unit Cost). "Reorder Qty"
// (the actual shortage) is reorderLevel - onHandQty, floored at 0. "Branch"
// is a no-op, same situation as the other inventory reports (no branch
// column on any transaction/product table).
router.get('/inventory/reorder-level/report', auth(), asyncHandler(async (req, res) => {
  const { warehouse, productGroup, itemCategory, reorderStatus, asOnDate } = req.query;
  const asOn = asOnDate ? new Date(asOnDate) : new Date();
  asOn.setHours(23, 59, 59, 999);

  const productWhere = {};
  if (warehouse) productWhere.defaultLocation = warehouse;
  if (productGroup) productWhere.productGroup = productGroup;
  if (itemCategory) productWhere.productType = itemCategory;

  const allProducts = await prisma.product.findMany({ where: productWhere });
  const codes = allProducts.map((p) => p.productCode);

  const [stockMovement, purchaseInvoices, grns] = await Promise.all([
    // Net movement across every document type that moves stock — Stock
    // Receipt/Issue/Adjustment plus GRN, Delivery Challan and the invoices
    // raised without one. See utils/stockLedger.js.
    codes.length ? getStockMovementByProductCode({ asOn, productCodes: codes }) : new Map(),
    codes.length ? prisma.purchaseInvoice.findMany({ where: { invoiceDate: { lte: asOn } }, include: { items: { where: { productCode: { in: codes } } } } }) : [],
    codes.length ? prisma.goodsReceivedNote.findMany({ where: { receivedDate: { lte: asOn } }, include: { items: { where: { productCode: { in: codes } } } } }) : [],
  ]);

  const movementByCode = {};
  const add = (code, delta) => { if (code) movementByCode[code] = (movementByCode[code] || 0) + delta; };
  for (const [code, qty] of stockMovement) add(code, qty);

  const lastPurchaseDateByCode = {};
  [...purchaseInvoices.flatMap((inv) => inv.items.map((item) => ({ code: item.productCode, date: inv.invoiceDate }))),
   ...grns.flatMap((grn) => grn.items.map((item) => ({ code: item.productCode, date: grn.receivedDate })))]
    .forEach(({ code, date }) => {
      if (!code) return;
      const existing = lastPurchaseDateByCode[code];
      if (!existing || (date && new Date(date) > new Date(existing))) lastPurchaseDateByCode[code] = date;
    });

  const allRows = allProducts.map((p) => {
    const onHandQty = Number(p.openingStock || 0) + (movementByCode[p.productCode] || 0);
    const reorderLevel = Number(p.reorderLevel || 0);
    const unitCost = Number(p.costPrice || 0);
    const reorderQty = reorderLevel > 0 ? Math.max(reorderLevel - onHandQty, 0) : 0;
    const suggestedOrderQty = reorderQty > 0 ? reorderLevel : 0;
    const estimatedValue = suggestedOrderQty * unitCost;

    let bucket;
    if (reorderLevel <= 0) bucket = 'No Reorder Level';
    else if (onHandQty <= reorderLevel) bucket = 'Below Reorder Level';
    else bucket = 'Above Reorder Level';

    return {
      productCode: p.productCode,
      productName: p.productName,
      productGroup: p.productGroup || 'Uncategorized',
      warehouse: p.defaultLocation || '—',
      uom: p.uom || '—',
      reorderLevel,
      currentStock: onHandQty,
      reorderQty,
      suggestedOrderQty,
      unitCost,
      estimatedValue,
      lastPurchaseDate: lastPurchaseDateByCode[p.productCode] || null,
      bucket,
      status: bucket,
    };
  }).sort((a, b) => a.productCode.localeCompare(b.productCode));

  // Reorder Status defaults to the report's core purpose — items currently
  // below their reorder level — same "default narrows to the working set"
  // pattern as the Low Stock report's "Show Items" filter. "All Items"
  // widens back out to every monitored product.
  let rows = allRows.filter((r) => r.bucket === 'Below Reorder Level');
  if (reorderStatus === 'Above Reorder Level') rows = allRows.filter((r) => r.bucket === 'Above Reorder Level');
  else if (reorderStatus === 'No Reorder Level') rows = allRows.filter((r) => r.bucket === 'No Reorder Level');
  else if (reorderStatus === 'All Items') rows = allRows;

  const totals = rows.reduce((acc, r) => ({
    reorderQty: acc.reorderQty + r.reorderQty,
    suggestedOrderQty: acc.suggestedOrderQty + r.suggestedOrderQty,
    estimatedValue: acc.estimatedValue + r.estimatedValue,
    currentStock: acc.currentStock + r.currentStock,
  }), { reorderQty: 0, suggestedOrderQty: 0, estimatedValue: 0, currentStock: 0 });

  const belowReorderRows = allRows.filter((r) => r.bucket === 'Below Reorder Level');
  const aboveReorderCount = allRows.filter((r) => r.bucket === 'Above Reorder Level').length;
  const noReorderLevelCount = allRows.filter((r) => r.bucket === 'No Reorder Level').length;
  const pendingReorderQty = belowReorderRows.reduce((sum, r) => sum + r.reorderQty, 0);
  const estimatedReorderValue = belowReorderRows.reduce((sum, r) => sum + r.estimatedValue, 0);
  const totalStockQty = allRows.reduce((sum, r) => sum + r.currentStock, 0);

  const reorderStatusOverview = [
    { name: 'Below Reorder Level', value: belowReorderRows.length },
    { name: 'Above Reorder Level', value: aboveReorderCount },
    { name: 'No Reorder Level', value: noReorderLevelCount },
  ];

  // Top 10 Items Requiring Reorder, ranked by shortage quantity, across the
  // full below-reorder-level set (not just the current page).
  const topReorderItems = [...belowReorderRows].sort((a, b) => b.reorderQty - a.reorderQty).slice(0, 10)
    .map((r) => ({ name: r.productName, value: Math.round(r.reorderQty * 1000) / 1000 }));

  // Reorder Items by Warehouse (Top 5) — item counts, below-reorder-level only.
  const byWarehouseCount = {};
  belowReorderRows.forEach((r) => { byWarehouseCount[r.warehouse] = (byWarehouseCount[r.warehouse] || 0) + 1; });
  const reorderItemsByWarehouse = Object.entries(byWarehouseCount).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([name, value]) => ({ name, value }));

  // Estimated Reorder Value by Product Group (Top 5 + Others), below-reorder-level only.
  const byGroupValue = {};
  belowReorderRows.forEach((r) => { byGroupValue[r.productGroup] = (byGroupValue[r.productGroup] || 0) + r.estimatedValue; });
  const groupEntries = Object.entries(byGroupValue).sort((a, b) => b[1] - a[1]);
  const groupGrandTotal = estimatedReorderValue || 1;
  const top5Groups = groupEntries.slice(0, 5);
  const othersGroupValue = groupEntries.slice(5).reduce((sum, [, v]) => sum + v, 0);
  const estimatedValueByGroup = [
    ...top5Groups.map(([name, value]) => ({ name, value: Math.round(value), percent: Math.round((value / groupGrandTotal) * 1000) / 10 })),
    ...(othersGroupValue > 0 ? [{ name: 'Others', value: Math.round(othersGroupValue), percent: Math.round((othersGroupValue / groupGrandTotal) * 1000) / 10 }] : []),
  ];

  res.json({
    success: true,
    data: {
      rows,
      totals,
      stats: {
        itemsBelowReorderLevel: belowReorderRows.length,
        totalItemsMonitored: allProducts.length,
        totalWarehouses: new Set(allProducts.map((p) => p.defaultLocation).filter(Boolean)).size,
        totalStockQty,
        pendingReorderQty,
        estimatedReorderValue,
      },
      reorderStatusOverview,
      topReorderItems,
      reorderItemsByWarehouse,
      estimatedValueByGroup,
    },
  });
}));

// Which of this product's three flow flags are pinned by existing history, so
// Product Master can render those checkboxes disabled and say what is holding
// them. Registered ahead of the generic '/products' crudRouter for the same
// reason as the inventory routes above.
//
// Keyed by product CODE rather than id, matching the sibling
// '/products/:productCode/inventory' route: the code is what the documents
// actually store, so this needs no lookup to answer.
router.get('/products/:productCode/usage', auth(), asyncHandler(async (req, res) => {
  const data = await getProductUsage(prisma, req.params.productCode);
  res.json({ success: true, data });
}));

router.use('/products', crudRouter(prisma.product, {
  searchFields: ['productCode', 'productName', 'barcode'],
  // Refuses a product with none of the three flow flags set, and separately
  // refuses one with neither Item Category box (Excisable/GST) set — see
  // validateProductUsageFlags / validateItemCategoryRequired. Both run on
  // create and update alike.
  validate: async (ctx) => {
    await validateProductUsageFlags(ctx);
    await validateItemCategoryRequired(ctx);
  },
  guard: productGuard(),
  autoNumber: { documentCode: 'PRD', field: 'productCode', delegate: 'product' },
}));

// Batch and Serial numbers — read-only here on purpose. The only place that
// creates them today is Purchase GRN's "Batches - Setup" / "Serial Numbers -
// Setup" dialog (nested under /purchase/grn below), which writes them inside
// the same transaction as the receipt itself. These two routes exist so a
// later module (Stock Issue, Sales, a traceability report) can look up
// "which batches/serials exist for this product" without a bespoke query.
// `available=true` and `warehouse=` narrow this to what the "Batches Number
// - Selection" dialog (Delivery Challan / Stock Issue) actually needs to
// offer — lots with stock still on them, sorted earliest-expiry-first so a
// FEFO pick is just "take from the top".
router.get('/product-batches', auth(), asyncHandler(async (req, res) => {
  const { productCode, warehouse, available } = req.query;
  const where = {};
  if (productCode) where.productCode = productCode;
  if (warehouse) where.warehouse = warehouse;
  if (available === 'true') where.quantity = { gt: 0 };
  const rows = await prisma.productBatch.findMany({
    where,
    orderBy: [{ expirationDate: 'asc' }, { id: 'desc' }],
  });
  res.json({ success: true, data: rows });
}));

// `status=` narrows this to what the "Serial Numbers - Selection" dialog
// needs — pass `status=In Stock` for the pool of serials still available to
// pick from.
router.get('/product-serials', auth(), asyncHandler(async (req, res) => {
  const { productCode, warehouse, status } = req.query;
  const where = {};
  if (productCode) where.productCode = productCode;
  if (warehouse) where.warehouse = warehouse;
  if (status) where.status = status;
  const rows = await prisma.productSerial.findMany({
    where,
    orderBy: { id: 'desc' },
  });
  res.json({ success: true, data: rows });
}));

// Product Catalog — a master/detail resource (ProductCatalog has many
// ProductCatalogItem rows), so it can't use the generic crudRouter, which
// only knows flat records. These bespoke routes mirror crudRouter's URL
// shape (GET /, GET /:id, POST /, PUT /:id, DELETE /:id) so the frontend
// can still use the generic createCrudApi hook-set against them. Same
// pattern as /company/approval-flows.
const productCatalogInclude = { items: { orderBy: { id: 'asc' } } };

function toCatalogItemData(item) {
  return {
    productCode: item.productCode || null,
    productName: item.productName || null,
    productGroup: item.productGroup || null,
    brand: item.brand || null,
    uom: item.uom || null,
    mrp: item.mrp ?? 0,
  };
}

router.get('/product-catalogs', auth(), asyncHandler(async (req, res) => {
  const { q } = req.query;
  const where = q
    ? { OR: [{ catalogCode: { contains: q } }, { catalogName: { contains: q } }] }
    : undefined;
  const rows = await prisma.productCatalog.findMany({ where, include: productCatalogInclude, orderBy: { id: 'desc' } });
  res.json({ success: true, data: rows });
}));

router.get('/product-catalogs/:id', auth(), asyncHandler(async (req, res) => {
  const row = await prisma.productCatalog.findUnique({ where: { id: Number(req.params.id) }, include: productCatalogInclude });
  if (!row) return res.status(404).json({ success: false, message: 'Record not found' });
  res.json({ success: true, data: row });
}));

router.post('/product-catalogs', auth(), asyncHandler(async (req, res) => {
  const { items = [], ...rawCatalog } = req.body;
  const catalog = sanitizeHeader(rawCatalog);
  const row = await prisma.$transaction(async (tx) => {
    // catalogCode comes from the CAT perpetual series — see the master
    // numbering note above the product-group mount.
    const { documentNumber, syncManual } = await resolveDocumentNumber('CAT', catalog.catalogCode, tx);
    const created = await tx.productCatalog.create({
      data: {
        ...catalog,
        catalogCode: documentNumber,
        items: { create: items.map(toCatalogItemData) },
      },
      include: productCatalogInclude,
    });
    if (syncManual) await syncManual();
    return created;
  });
  res.status(201).json({ success: true, data: row });
}));

router.put('/product-catalogs/:id', auth(), asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  const { items = [], ...catalog } = req.body;
  // Replace the mapped-product set wholesale on every save — simpler and
  // safer than diffing which rows were added/removed client-side.
  const row = await prisma.$transaction(async (tx) => {
    await tx.productCatalogItem.deleteMany({ where: { catalogId: id } });
    return tx.productCatalog.update({
      where: { id },
      data: {
        ...catalog,
        items: { create: items.map(toCatalogItemData) },
      },
      include: productCatalogInclude,
    });
  });
  res.json({ success: true, data: row });
}));

router.delete('/product-catalogs/:id', auth(['admin']), asyncHandler(async (req, res) => {
  // ProductCatalogItem.catalog has onDelete: Cascade, so items go with it.
  await prisma.productCatalog.delete({ where: { id: Number(req.params.id) } });
  res.json({ success: true, message: 'Deleted successfully' });
}));

router.use('/purchase-prices', crudRouter(prisma.purchasePrice, { searchFields: ['supplier', 'productCode', 'productName'] }));
router.use('/sales-prices', crudRouter(prisma.salesPrice, { searchFields: ['customer', 'productCode', 'productName'] }));
router.use('/customer-discounts', crudRouter(prisma.customerDiscount, { searchFields: ['customer', 'productCode', 'productName'] }));

// Business Partner
router.use('/customers', crudRouter(prisma.customer, {
  searchFields: ['customerCode', 'customerName', 'email', 'phone'],
  guard: masterGuard('customer', 'customerName'),
  autoNumber: { documentCode: 'CUS', field: 'customerCode', delegate: 'customer' },
}));
router.use('/suppliers', crudRouter(prisma.supplier, {
  searchFields: ['supplierCode', 'supplierName', 'email', 'phone'],
  guard: masterGuard('supplier', 'supplierName'),
  autoNumber: { documentCode: 'SUP', field: 'supplierCode', delegate: 'supplier' },
}));
router.use('/transporters', crudRouter(prisma.transport, {
  searchFields: ['transporterCode', 'transporterName', 'email', 'phone'],
  autoNumber: { documentCode: 'TRN', field: 'transporterCode', delegate: 'transport' },
}));

// Business Partner (unified) — a master/detail resource (BusinessPartner has
// many BusinessPartnerContact + BusinessPartnerAddress rows), so like
// Approval Flow (see routes/company.js) it can't use the generic crudRouter.
// These bespoke routes mirror crudRouter's URL shape (GET /, GET /:id,
// POST /, PUT /:id, DELETE /:id) so the frontend still uses the generic
// createCrudApi hook-set against them.
//
// Code is NOT drawn from the shared numbering-series engine (unlike
// customer/supplier codes) — the "Code" field on the Add form offers three
// modes (Manual / Auto - Customer / Auto - Supplier), the latter two each
// drawing from their own C-prefixed / S-prefixed sequence that both live in
// the same partner_code column. The numbering-series engine's self-heal has
// no notion of "two independent sequences sharing one column" — it would let
// a Supplier code's self-heal pick up a Customer code's number and skip
// ahead — so a small dedicated max-scan is used instead. See
// nextBusinessPartnerCode below and the /business-partners/next-code peek
// route the "Code" selector calls as the user picks a mode.
const businessPartnerInclude = {
  contacts: { orderBy: { rowOrder: 'asc' } },
  addresses: { orderBy: { rowOrder: 'asc' } },
};

// Scans existing partner_code values for the highest number already used
// under this prefix (e.g. "C00007" -> 7) and returns the next one,
// zero-padded to 5 digits (C00001, C00002, ... matching the reference
// template). `client` is either `prisma` (read-only peek) or a `tx` (inside
// the create transaction) — both expose the same `.businessPartner` delegate
// shape.
async function nextBusinessPartnerCode(prefix, client) {
  const rows = await client.businessPartner.findMany({
    where: { partnerCode: { startsWith: prefix } },
    select: { partnerCode: true },
  });
  const pattern = new RegExp(`^${prefix}(\\d+)$`);
  let highest = 0;
  for (const row of rows) {
    const match = String(row.partnerCode || '').match(pattern);
    if (!match) continue;
    const n = Number(match[1]);
    if (Number.isFinite(n) && n > highest) highest = n;
  }
  return `${prefix}${String(highest + 1).padStart(5, '0')}`;
}

// Peek-only — mirrors /company/document-numbers/peek's shape (POST, not
// consumed by this call) so the frontend's "Code" selector can show the
// number that will be assigned as soon as Auto - Customer/Supplier is
// picked, before the record is actually saved. A concurrent create between
// the peek and the save could in principle hand out the same number twice —
// the same accepted race the numbering engine's own master self-heal notes —
// acceptable at this app's scale.
router.post('/business-partners/next-code', auth(), asyncHandler(async (req, res) => {
  const prefix = req.body?.prefix === 'S' ? 'S' : 'C';
  const code = await nextBusinessPartnerCode(prefix, prisma);
  res.json({ success: true, data: { code } });
}));

function toBusinessPartnerContactData(c, index) {
  return {
    contactId: c.contactId || null,
    title: c.title || null,
    firstName: c.firstName,
    lastName: c.lastName || null,
    position: c.position || null,
    address: c.address || null,
    telephone: c.telephone || null,
    mobile: c.mobile || null,
    email: c.email || null,
    emailGroup: c.emailGroup || null,
    password: c.password || null,
    birthCountry: c.birthCountry || null,
    birthCity: c.birthCity || null,
    dateOfBirth: c.dateOfBirth ? new Date(c.dateOfBirth) : null,
    gender: c.gender || null,
    profession: c.profession || null,
    remarks: c.remarks || null,
    isDefault: !!c.isDefault,
    rowOrder: index + 1,
  };
}

function toBusinessPartnerAddressData(a, addressType, index) {
  return {
    addressType,
    addressName: a.addressName || null,
    street: a.street || null,
    streetNo: a.streetNo || null,
    buildingFloorRoom: a.buildingFloorRoom || null,
    block: a.block || null,
    country: a.country || null,
    state: a.state || null,
    city: a.city || null,
    zipCode: a.zipCode || null,
    taxOffice: a.taxOffice || null,
    gstType: a.gstType || null,
    gstNumber: a.gstNumber || null,
    isDefault: !!a.isDefault,
    rowOrder: index + 1,
  };
}

router.get('/business-partners', auth(), asyncHandler(async (req, res) => {
  const { q } = req.query;
  const where = q
    ? { OR: [{ partnerCode: { contains: q } }, { partnerName: { contains: q } }, { email: { contains: q } }, { mobile: { contains: q } }] }
    : undefined;
  const rows = await prisma.businessPartner.findMany({ where, include: businessPartnerInclude, orderBy: { id: 'desc' } });
  res.json({ success: true, data: rows });
}));

router.get('/business-partners/:id', auth(), asyncHandler(async (req, res) => {
  const row = await prisma.businessPartner.findUnique({ where: { id: Number(req.params.id) }, include: businessPartnerInclude });
  if (!row) return res.status(404).json({ success: false, message: 'Record not found' });
  res.json({ success: true, data: row });
}));

router.post('/business-partners', auth(), asyncHandler(async (req, res) => {
  // codeMode: 'manual' | 'auto-customer' | 'auto-supplier' — see the "Code"
  // selector's own comment above nextBusinessPartnerCode. Manual (or
  // anything unrecognised) keeps the client-typed partner.partnerCode as-is;
  // the Zod schema on the frontend already requires it non-empty in that case.
  const { contacts = [], billingAddresses = [], shippingAddresses = [], codeMode, ...partner } = req.body;
  const row = await prisma.$transaction(async (tx) => {
    let partnerCode = partner.partnerCode;
    if (codeMode === 'auto-customer') partnerCode = await nextBusinessPartnerCode('C', tx);
    else if (codeMode === 'auto-supplier') partnerCode = await nextBusinessPartnerCode('S', tx);
    const created = await tx.businessPartner.create({
      data: {
        ...partner,
        partnerCode,
        contacts: { create: contacts.map(toBusinessPartnerContactData) },
        addresses: {
          create: [
            ...billingAddresses.map((a, i) => toBusinessPartnerAddressData(a, 'Billing', i)),
            ...shippingAddresses.map((a, i) => toBusinessPartnerAddressData(a, 'Shipping', i)),
          ],
        },
      },
      include: businessPartnerInclude,
    });
    return created;
  });
  res.status(201).json({ success: true, data: row });
}));

router.put('/business-partners/:id', auth(), asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  // partnerCode (and the codeMode that produced it) are intentionally
  // dropped here: like customerCode/supplierCode, the code is locked after
  // create and never rewritten on edit.
  const { contacts = [], billingAddresses = [], shippingAddresses = [], partnerCode, codeMode, ...partner } = req.body;
  // Replace both child sets wholesale on every save — simpler and safer than
  // diffing which rows were added/removed/reordered client-side (same
  // pattern as Approval Flow's levels).
  const row = await prisma.$transaction(async (tx) => {
    await tx.businessPartnerContact.deleteMany({ where: { businessPartnerId: id } });
    await tx.businessPartnerAddress.deleteMany({ where: { businessPartnerId: id } });
    return tx.businessPartner.update({
      where: { id },
      data: {
        ...partner,
        contacts: { create: contacts.map(toBusinessPartnerContactData) },
        addresses: {
          create: [
            ...billingAddresses.map((a, i) => toBusinessPartnerAddressData(a, 'Billing', i)),
            ...shippingAddresses.map((a, i) => toBusinessPartnerAddressData(a, 'Shipping', i)),
          ],
        },
      },
      include: businessPartnerInclude,
    });
  });
  res.json({ success: true, data: row });
}));

router.delete('/business-partners/:id', auth(['admin']), asyncHandler(async (req, res) => {
  // BusinessPartnerContact/Address both have onDelete: Cascade, so children
  // go with it.
  await prisma.businessPartner.delete({ where: { id: Number(req.params.id) } });
  res.json({ success: true, message: 'Deleted successfully' });
}));

router.use('/warehouses', crudRouter(prisma.warehouse, {
  searchFields: ['warehouseCode', 'warehouseName', 'warehouseLocation'],
  autoNumber: { documentCode: 'WH', field: 'warehouseCode', delegate: 'warehouse' },
}));
// RETIRED — see the note on the Location model in schema.prisma. Kept mounted
// so anything still calling it keeps working, but nothing in the app does: the
// Location Master page now edits '/location-master' below. The LOC numbering
// series moved with it, so this route no longer auto-numbers — leaving it here
// would have two routes drawing from one counter.
router.use('/locations', crudRouter(prisma.location, {
  searchFields: ['locationCode', 'locationName', 'panNo', 'gstRegistrationNo'],
}));

// Rich Warehouse/Location masters imported from the real source system
// (Master Data.xlsx via npm run warehouse_master:seed / location_master:seed)
// — separate tables from /warehouses and /locations above, see the model
// comments in schema.prisma. No autoNumber: whsCode/code are the source
// system's own codes, typed by hand or seeded, not generated here.
router.use('/warehouse-master', crudRouter(prisma.warehouseMaster, {
  searchFields: ['whsCode', 'whsName', 'city', 'state'],
}));
// The surviving location master.
//
// Deliberately NOT auto-numbered from the LOC series. This master's codes are
// bare running integers — 1, 2, 3 … 12 — while the series issues prefixed
// document numbers (LOC-000001), which would match nothing already in the
// table and would not continue the sequence. The next code is computed on the
// page instead, one past the highest whole-number code in use, exactly as
// Account Group does for the other master numbered this way.
router.use('/location-master', crudRouter(prisma.locationMaster, {
  searchFields: ['code', 'locationName', 'panNo', 'eccNo'],
}));

// Opening Balance — per-item, per-warehouse starting stock. Also not
// autoNumber: it's keyed by (itemCode, warehouse), not a generated document
// code, and the unique constraint on the DB does the real work of stopping
// duplicates.
router.use('/opening-balance', crudRouter(prisma.openingBalance, {
  searchFields: ['itemCode', 'itemName', 'warehouse'],
}));

// Opening Balance bulk import — lets a user upload an .xlsx and insert every
// row in one go, the same shape as `npm run current_stock:seed` but driven
// from the UI instead of a source-system export sitting in backend/data/.
//
// Memory storage: the file never touches disk, it's parsed straight out of
// the buffer and discarded once the request finishes — there's nothing here
// worth persisting past the import itself.
const openingBalanceXlsxUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB is generous for a few thousand rows of text/numbers
  fileFilter: (req, file, cb) => {
    const okExt = /\.(xlsx|xls)$/i.test(file.originalname || '');
    if (!okExt) return cb(new Error('Only .xlsx or .xls files are accepted.'));
    cb(null, true);
  },
});

// Column names accepted, deliberately loose on case/spacing/punctuation
// (normaliseHeader in xlsxImport.js strips all of that) but strict on the
// actual wording — "Item Code"/"ItemCode"/"item_code" all pass, "Item"
// alone or an extra unexpected column does not, and the whole upload is
// rejected rather than partially imported. `status` is optional: a sheet
// without it just gets every row defaulted to Active below.
const OPENING_BALANCE_IMPORT_FIELDS = [
  { field: 'itemCode', headers: ['Item Code', 'ItemCode'], required: true },
  { field: 'itemName', headers: ['Item Name', 'ItemName'], required: true },
  { field: 'warehouse', headers: ['Warehouse', 'Warehouse Code', 'WarehouseCode'], required: true },
  { field: 'stock', headers: ['Stock'], required: true },
  { field: 'stockValue', headers: ['Stock Value', 'StockValue'], required: true },
  { field: 'status', headers: ['Status'], required: false },
];

router.post('/opening-balance/import-xlsx', auth(), openingBalanceXlsxUpload.single('file'), asyncHandler(async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ success: false, message: 'No file uploaded. Attach an .xlsx file.' });
  }

  let sheetName;
  let rows;
  try {
    ({ sheetName, rows } = readWorkbookRows(req.file.buffer));
  } catch (err) {
    return res.status(err.status || 400).json({ success: false, message: err.message || 'Could not read the uploaded file.' });
  }

  if (!rows.length) {
    return res.status(400).json({ success: false, message: 'The uploaded sheet is empty.' });
  }

  const [headerRow, ...dataRows] = rows;

  let columnToField;
  try {
    columnToField = validateHeaders(headerRow, OPENING_BALANCE_IMPORT_FIELDS);
  } catch (err) {
    return res.status(err.status || 400).json({ success: false, message: err.message });
  }

  // Column index -> field, resolved once against this sheet's actual header
  // order (columns can be in any order — only the wording is checked).
  const indexToField = {};
  headerRow.forEach((h, idx) => {
    const field = columnToField[h];
    if (field) indexToField[idx] = field;
  });

  const validWarehouses = new Set(
    (await prisma.warehouseMaster.findMany({ select: { whsCode: true } })).map((w) => w.whsCode)
  );

  let created = 0;
  let updated = 0;
  let skipped = 0;
  const errors = [];

  for (let i = 0; i < dataRows.length; i += 1) {
    const raw = dataRows[i] || [];
    const isBlankRow = raw.every((c) => c === null || c === undefined || String(c).trim() === '');
    if (isBlankRow) continue;

    const data = {};
    Object.entries(indexToField).forEach(([idx, field]) => {
      data[field] = raw[Number(idx)];
    });

    const rowNum = i + 2; // +1 for the header row, +1 to make it 1-indexed
    const itemCode = data.itemCode != null ? String(data.itemCode).trim() : '';
    const itemName = data.itemName != null ? String(data.itemName).trim() : '';
    const warehouse = data.warehouse != null ? String(data.warehouse).trim() : '';
    const stock = data.stock === null || data.stock === undefined || data.stock === '' ? 0 : Number(data.stock);
    const stockValue = data.stockValue === null || data.stockValue === undefined || data.stockValue === '' ? 0 : Number(data.stockValue);
    const rawStatus = data.status != null ? String(data.status).trim() : '';
    const status = rawStatus === '' ? 'Active' : rawStatus;

    if (!itemCode || !itemName || !warehouse) {
      skipped += 1;
      errors.push(`Row ${rowNum}: missing Item Code, Item Name or Warehouse.`);
      continue;
    }
    if (Number.isNaN(stock) || Number.isNaN(stockValue)) {
      skipped += 1;
      errors.push(`Row ${rowNum}: Stock/Stock Value must be numeric.`);
      continue;
    }
    if (!['Active', 'Inactive'].some((v) => v.toLowerCase() === status.toLowerCase())) {
      skipped += 1;
      errors.push(`Row ${rowNum}: Status must be Active or Inactive, got "${status}".`);
      continue;
    }
    if (!validWarehouses.has(warehouse)) {
      skipped += 1;
      errors.push(`Row ${rowNum}: warehouse "${warehouse}" was not found in the Warehouse master.`);
      continue;
    }

    const normalisedStatus = status.toLowerCase() === 'active' ? 'Active' : 'Inactive';

    // createdAt/updatedAt are never read from the sheet — the header
    // validation above would reject the upload outright if such a column
    // were present. Prisma stamps createdAt on first insert and updatedAt on
    // every write from the server clock, exactly like every other create/
    // update path in the app (see PROTECTED_FIELDS in crudFactory.js).
    try {
      const existing = await prisma.openingBalance.findUnique({
        where: { itemCode_warehouse: { itemCode, warehouse } },
      });
      await prisma.openingBalance.upsert({
        where: { itemCode_warehouse: { itemCode, warehouse } },
        update: { itemName, stock, stockValue, status: normalisedStatus },
        create: { itemCode, itemName, warehouse, stock, stockValue, status: normalisedStatus },
      });
      if (existing) updated += 1; else created += 1;
    } catch (err) {
      skipped += 1;
      errors.push(`Row ${rowNum}: ${err.message}`);
    }
  }

  res.json({
    success: true,
    message: `Imported from sheet "${sheetName}": ${created} created, ${updated} updated, ${skipped} skipped (of ${dataRows.length} data row(s)).`,
    created,
    updated,
    skipped,
    total: dataRows.length,
    errors: errors.slice(0, 50),
  });
}));

// User accounts (list/create/update/delete + per-user menu permissions) now
// live in routes/users.js, mounted at /api/users in app.js ahead of this
// router -- see that file for why it isn't just another crudRouter entry.

// Purchase Quotation — a master/detail resource (PurchaseQuotation has many
// PurchaseQuotationItem rows), so it can't use the generic crudRouter. These
// bespoke routes mirror crudRouter's URL shape (GET /, GET /:id, POST /,
// PUT /:id, DELETE /:id) so the frontend can still use the generic
// createCrudApi hook-set against them. Same pattern as /company/approval-flows
// and /product-catalogs. Totals are always recomputed server-side from the
// submitted items rather than trusted from the client.
const purchaseQuotationInclude = { items: { orderBy: { id: 'asc' } } };

// Purchase Quotation lines now carry their own discountPercent, like every
// other document type. Without it, a discount negotiated at quotation stage
// had nowhere to live and silently disappeared when the quotation was turned
// into a Purchase Order.
function toQuotationItemData(item) {
  return mapLine(item);
}

// Subtotal = sum of line amounts. The header discount reduces that to the
// taxable amount, then each line is taxed at its own rate on its share of the
// taxable amount and the results are summed — a document mixing 5% and 18%
// goods gets the right blended tax. Intra-state supply splits the total into
// CGST/SGST; inter-state charges the whole amount as IGST. See
// utils/documentTotals.js.
function computeQuotationTotals(items, discountPercent, interState) {
  return headerTotals(computeTotals(items, discountPercent, { interState, roundOff: true }));
}

// Price Comparison report — bespoke aggregation endpoint for the
// Reports > Purchase > Price Comparison page. Registered before the plain
// '/purchase/quotations' route below, same reasoning/placement as the
// other purchase reports. Each row is one PurchaseQuotationItem "quote
// line" (a single supplier's quoted price for a product, on a given
// quotation), with Lowest/Highest/Average Quote and a Difference vs the
// lowest computed across every qualifying quote line for that same
// productCode — not just the current page. `branch` is accepted for
// filter-bar parity but is a no-op — PurchaseQuotation has no branch
// column (see schema.prisma), same situation as `source` on the other
// purchase reports.
router.get('/purchase/quotations/price-comparison/report', auth(), asyncHandler(async (req, res) => {
  const { fromDate, toDate, productGroup, product, supplier, branch } = req.query;

  const where = {};
  if (supplier) where.supplier = supplier;
  if (fromDate || toDate) {
    where.quotationDate = {};
    if (fromDate) where.quotationDate.gte = new Date(fromDate);
    if (toDate) where.quotationDate.lte = new Date(toDate);
  }

  const [quotations, products] = await Promise.all([
    prisma.purchaseQuotation.findMany({ where, include: { items: { orderBy: { id: 'asc' } } }, orderBy: { quotationDate: 'asc' } }),
    prisma.product.findMany({ select: { productCode: true, productGroup: true } }),
  ]);
  const groupByCode = Object.fromEntries(products.map((p) => [p.productCode, p.productGroup || 'Uncategorized']));

  // Flatten quotations into one line per (quotation, item) pair.
  let lines = [];
  quotations.forEach((q) => {
    q.items.forEach((item) => {
      const code = item.productCode || 'UNKNOWN';
      if (product && code !== product) return;
      const group = groupByCode[code] || 'Uncategorized';
      if (productGroup && group !== productGroup) return;
      lines.push({
        productCode: code,
        productName: item.productName || code,
        group,
        supplier: q.supplier || 'Unknown',
        quotationNo: q.quotationNo,
        quotationDate: q.quotationDate,
        quotedPrice: Number(item.unitPrice || 0),
        validUpto: q.validUpto,
      });
    });
  });

  // Lowest/Highest/Average Quote per product, across every qualifying
  // line for that productCode (not scoped to a single quotation round).
  const byProduct = {};
  lines.forEach((l) => {
    if (!byProduct[l.productCode]) byProduct[l.productCode] = { productName: l.productName, quotes: [] };
    byProduct[l.productCode].quotes.push(l.quotedPrice);
  });
  Object.values(byProduct).forEach((v) => {
    v.lowest = Math.min(...v.quotes);
    v.highest = Math.max(...v.quotes);
    v.average = v.quotes.reduce((sum, x) => sum + x, 0) / v.quotes.length;
  });

  const rows = lines
    .map((l) => {
      const stats = byProduct[l.productCode];
      const diffAmount = l.quotedPrice - stats.lowest;
      const diffPercent = stats.lowest > 0 ? Math.round((diffAmount / stats.lowest) * 1000) / 10 : 0;
      return {
        ...l,
        lowestQuote: stats.lowest,
        highestQuote: stats.highest,
        averageQuote: Math.round(stats.average * 100) / 100,
        diffAmount,
        diffPercent,
      };
    })
    .sort((a, b) => (a.productCode < b.productCode ? -1 : a.productCode > b.productCode ? 1 : new Date(a.quotationDate) - new Date(b.quotationDate)));

  const quotedPrices = rows.map((r) => r.quotedPrice);
  const lowestQuotedPrice = quotedPrices.length ? Math.min(...quotedPrices) : 0;
  const highestQuotedPrice = quotedPrices.length ? Math.max(...quotedPrices) : 0;
  const averageQuotePrice = quotedPrices.length ? quotedPrices.reduce((sum, p) => sum + p, 0) / quotedPrices.length : 0;
  // Widest per-product spread (that product's own highest minus lowest
  // quote) across every product in the filtered set.
  const maxPriceDifference = Object.values(byProduct).reduce((max, v) => Math.max(max, v.highest - v.lowest), 0);
  const suppliersCompared = new Set(rows.map((r) => r.supplier)).size;

  // Top 10 Lowest Quote Products — one entry per distinct product, in the
  // order first encountered in the (date-ordered) quotation set.
  const seenProducts = new Set();
  const topLowestQuoteProducts = [];
  for (const l of lines) {
    if (seenProducts.has(l.productCode)) continue;
    seenProducts.add(l.productCode);
    topLowestQuoteProducts.push({ name: l.productName, value: byProduct[l.productCode].lowest });
    if (topLowestQuoteProducts.length >= 10) break;
  }

  // Top 10 Highest Quote Variance (%) — only products with more than one
  // quote line have a meaningful spread.
  const topHighestVarianceProducts = Object.values(byProduct)
    .filter((v) => v.quotes.length > 1 && v.lowest > 0)
    .map((v) => ({ name: v.productName, value: Math.round(((v.highest - v.lowest) / v.lowest) * 1000) / 10 }))
    .sort((a, b) => b.value - a.value)
    .slice(0, 10);

  // Quote Price Trend — average quoted price per calendar day that has a
  // quote line, oldest to newest.
  const dailyBuckets = {};
  lines.forEach((l) => {
    if (!l.quotationDate) return;
    const d = new Date(l.quotationDate);
    const key = `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
    if (!dailyBuckets[key]) {
      dailyBuckets[key] = { sortKey: d.getTime(), name: `${String(d.getDate()).padStart(2, '0')} ${SALES_TREND_MONTH_LABELS[d.getMonth()]}`, sum: 0, count: 0 };
    }
    dailyBuckets[key].sum += l.quotedPrice;
    dailyBuckets[key].count += 1;
  });
  const trend = Object.values(dailyBuckets)
    .sort((a, b) => a.sortKey - b.sortKey)
    .map(({ name, sum, count }) => ({ name, value: Math.round((sum / count) * 100) / 100 }));

  res.json({
    success: true,
    data: {
      rows,
      totals: { lowestQuote: lowestQuotedPrice, highestQuote: highestQuotedPrice, averageQuote: Math.round(averageQuotePrice * 100) / 100 },
      stats: {
        totalQuotations: rows.length,
        lowestQuotedPrice,
        highestQuotedPrice,
        averageQuotePrice: Math.round(averageQuotePrice * 100) / 100,
        maxPriceDifference,
        suppliersCompared,
      },
      topLowestQuoteProducts,
      topHighestVarianceProducts,
      trend,
    },
  });
}));

// Purchase Price History (Product-wise) report — bespoke aggregation
// endpoint for the Reports > Purchase > Price History page. A single
// `product` is required (mirrors the filter bar's required Product field)
// — with no product selected there's nothing to chart, so this returns an
// empty shape rather than querying anything. Combines both purchase
// document types that carry a per-line unit price for a product: Purchase
// Invoice and Goods Receipt (GRN), the same two transaction types
// PurchaseOrder's own receiving/invoicing lifecycle produces. Neither
// PurchaseInvoiceItem nor GoodsReceivedNoteItem stores a discount or
// branch, so those columns are always 0 / '—' rather than fabricated —
// same convention as the discount-less columns on the other purchase
// reports. `historyView` (5/10/15/20/50, or unset for "Entire") windows
// the *most recent* N transactions — that window backs the table, the
// stats, and every chart on this page, so all of it stays internally
// consistent regardless of which window is selected.
router.get('/purchase/products/price-history/report', auth(), asyncHandler(async (req, res) => {
  const { product, supplier, fromDate, toDate, historyView } = req.query;

  if (!product) {
    return res.json({
      success: true,
      data: {
        productInfo: null,
        rows: [],
        stats: {},
        trend: [],
        supplierAverages: [],
        quantityVsPrice: [],
      },
    });
  }

  const invoiceWhere = {};
  const grnWhere = {};
  if (supplier) { invoiceWhere.supplier = supplier; grnWhere.supplier = supplier; }
  if (fromDate || toDate) {
    invoiceWhere.invoiceDate = {};
    grnWhere.receivedDate = {};
    if (fromDate) { invoiceWhere.invoiceDate.gte = new Date(fromDate); grnWhere.receivedDate.gte = new Date(fromDate); }
    if (toDate) { invoiceWhere.invoiceDate.lte = new Date(toDate); grnWhere.receivedDate.lte = new Date(toDate); }
  }

  const [invoices, grns, productRow, suppliers] = await Promise.all([
    prisma.purchaseInvoice.findMany({ where: invoiceWhere, include: { items: { where: { productCode: product } } } }),
    prisma.goodsReceivedNote.findMany({ where: grnWhere, include: { items: { where: { productCode: product } } } }),
    prisma.product.findUnique({ where: { productCode: product } }),
    prisma.supplier.findMany({ select: { supplierCode: true, supplierName: true } }),
  ]);
  const codeByName = Object.fromEntries(suppliers.map((s) => [s.supplierName, s.supplierCode]));

  let rows = [];
  invoices.forEach((inv) => {
    inv.items.forEach((item) => {
      rows.push({
        purchaseDate: inv.invoiceDate,
        documentNo: inv.invoiceNo,
        supplierCode: codeByName[inv.supplier] || '—',
        supplierName: inv.supplier || 'Unknown',
        quantity: Number(item.quantity || 0),
        uom: item.uom || productRow?.uom || '—',
        unitPrice: Number(item.unitPrice || 0),
        discountPercent: 0,
        netPrice: Number(item.unitPrice || 0),
        purchaseAmount: Number(item.amount || 0),
        purchaseType: 'Purchase Invoice',
        branch: '—',
        buyer: '—',
      });
    });
  });
  grns.forEach((grn) => {
    grn.items.forEach((item) => {
      rows.push({
        purchaseDate: grn.receivedDate,
        documentNo: grn.grnNo,
        supplierCode: codeByName[grn.supplier] || '—',
        supplierName: grn.supplier || 'Unknown',
        quantity: Number(item.receivedQuantity || 0),
        uom: item.uom || productRow?.uom || '—',
        unitPrice: Number(item.unitPrice || 0),
        discountPercent: 0,
        netPrice: Number(item.unitPrice || 0),
        purchaseAmount: Number(item.amount || 0),
        purchaseType: 'Goods Receipt',
        branch: '—',
        buyer: grn.receivedBy || '—',
      });
    });
  });

  rows.sort((a, b) => new Date(b.purchaseDate || 0) - new Date(a.purchaseDate || 0));

  const HISTORY_LIMITS = { 5: 5, 10: 10, 15: 15, 20: 20, 50: 50 };
  if (historyView && HISTORY_LIMITS[historyView]) rows = rows.slice(0, HISTORY_LIMITS[historyView]);

  const prices = rows.map((r) => r.unitPrice);
  const currentPrice = rows[0]?.unitPrice ?? 0;
  const currentDate = rows[0]?.purchaseDate ?? null;
  const lowestPrice = prices.length ? Math.min(...prices) : 0;
  const highestPrice = prices.length ? Math.max(...prices) : 0;
  const averagePrice = prices.length ? prices.reduce((sum, p) => sum + p, 0) / prices.length : 0;

  // Chronological (oldest-first) view of the same window, for the charts.
  const chronological = [...rows].sort((a, b) => new Date(a.purchaseDate || 0) - new Date(b.purchaseDate || 0));
  const trend = chronological.map((r) => ({
    name: r.purchaseDate ? `${String(new Date(r.purchaseDate).getDate()).padStart(2, '0')} ${SALES_TREND_MONTH_LABELS[new Date(r.purchaseDate).getMonth()]} ${new Date(r.purchaseDate).getFullYear()}` : '—',
    value: r.unitPrice,
  }));
  const quantityVsPrice = chronological.map((r) => ({
    name: r.purchaseDate ? `${SALES_TREND_MONTH_LABELS[new Date(r.purchaseDate).getMonth()]} '${String(new Date(r.purchaseDate).getFullYear()).slice(-2)}` : '—',
    quantity: r.quantity,
    unitPrice: r.unitPrice,
  }));

  const bySupplier = {};
  rows.forEach((r) => {
    if (!bySupplier[r.supplierName]) bySupplier[r.supplierName] = { sum: 0, count: 0 };
    bySupplier[r.supplierName].sum += r.unitPrice;
    bySupplier[r.supplierName].count += 1;
  });
  const supplierAverages = Object.entries(bySupplier)
    .map(([name, v]) => ({ name, value: Math.round((v.sum / v.count) * 100) / 100 }))
    .sort((a, b) => b.value - a.value);

  res.json({
    success: true,
    data: {
      productInfo: productRow ? {
        productCode: productRow.productCode,
        productName: productRow.productName,
        productGroup: productRow.productGroup || 'Uncategorized',
        uom: productRow.uom || '—',
        standardCost: Number(productRow.costPrice || 0),
      } : null,
      rows,
      stats: {
        currentPrice,
        currentDate,
        lastPrice: currentPrice,
        lastPurchaseDate: currentDate,
        lowestPrice,
        highestPrice,
        averagePrice: Math.round(averagePrice * 100) / 100,
        totalTransactions: rows.length,
      },
      trend,
      supplierAverages,
      quantityVsPrice,
    },
  });
}));

router.get('/purchase/quotations', auth(), asyncHandler(async (req, res) => {
  const { q } = req.query;
  const where = q
    ? {
        OR: [
          { quotationNo: { contains: q } },
          { supplier: { contains: q } },
          { referenceNo: { contains: q } },
        ],
      }
    : undefined;
  const rows = await prisma.purchaseQuotation.findMany({ where, include: purchaseQuotationInclude, orderBy: { id: 'desc' } });
  res.json({ success: true, data: rows });
}));

router.get('/purchase/quotations/:id', auth(), asyncHandler(async (req, res) => {
  const row = await prisma.purchaseQuotation.findUnique({ where: { id: Number(req.params.id) }, include: purchaseQuotationInclude });
  if (!row) return res.status(404).json({ success: false, message: 'Record not found' });
  res.json({ success: true, data: row });
}));

router.post('/purchase/quotations', auth(), asyncHandler(async (req, res) => {
  const { items = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  const itemData = items.map(toQuotationItemData);
  const row = await prisma.$transaction(async (tx) => {
    // Tax treatment is resolved inside the transaction because it depends
    // on the company's registered state: an inter-state supply is charged
    // wholly as IGST, an intra-state one split into CGST/SGST.
    const interState = await resolveTaxTreatment(tx, header.placeOfSupply);
    const totals = computeQuotationTotals(itemData, header.discountPercent, interState);
    // quotationNo now comes from the configured PQ numbering series rather
    // than free text — see resolveDocumentNumber above.
    const { documentNumber, syncManual } = await resolveDocumentNumber('PQ', header.quotationNo, tx);
    const created = await tx.purchaseQuotation.create({
      data: { ...header, quotationNo: documentNumber, ...totals, items: { create: itemData } },
      include: purchaseQuotationInclude,
    });
    if (syncManual) await syncManual();
    // Status is server-owned on this document (Open until a Purchase Order is
    // raised from it), so it is recomputed rather than trusted from the
    // request payload.
    await recomputePurchaseQuotationStatus(tx, created.quotationNo);
    return tx.purchaseQuotation.findUnique({ where: { id: created.id }, include: purchaseQuotationInclude });
  });
  res.status(201).json({ success: true, data: row });
}));

router.put('/purchase/quotations/:id', auth(), asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  const { items = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  const itemData = items.map(toQuotationItemData);
  // Replace the item set wholesale on every save — simpler and safer than
  // diffing which rows were added/removed/reordered client-side.
  const row = await prisma.$transaction(async (tx) => {
    // Tax treatment is resolved inside the transaction because it depends
    // on the company's registered state: an inter-state supply is charged
    // wholly as IGST, an intra-state one split into CGST/SGST.
    const interState = await resolveTaxTreatment(tx, header.placeOfSupply);
    const totals = computeQuotationTotals(itemData, header.discountPercent, interState);
    await tx.purchaseQuotationItem.deleteMany({ where: { quotationId: id } });
    const updated = await tx.purchaseQuotation.update({
      where: { id },
      data: { ...header, ...totals, items: { create: itemData } },
      include: purchaseQuotationInclude,
    });
    await recomputePurchaseQuotationStatus(tx, updated.quotationNo);
    return tx.purchaseQuotation.findUnique({ where: { id }, include: purchaseQuotationInclude });
  });
  res.json({ success: true, data: row });
}));

router.delete('/purchase/quotations/:id', auth(['admin']), asyncHandler(async (req, res) => {
  // PurchaseQuotationItem.quotation has onDelete: Cascade, so items go with it.
  await prisma.purchaseQuotation.delete({ where: { id: Number(req.params.id) } });
  res.json({ success: true, message: 'Deleted successfully' });
}));

// Purchase Order — a master/detail resource (PurchaseOrder has many
// PurchaseOrderItem rows), same bespoke-route pattern as /purchase/quotations
// above. Totals are always recomputed server-side from the submitted items.
const purchaseOrderInclude = { items: { orderBy: { id: 'asc' } } };

function toOrderItemData(item) {
  return mapLine(item);
}

// Same engine as computeQuotationTotals — kept as a named wrapper since
// PurchaseOrder and PurchaseQuotation are independent models and the routes
// read better naming the document they belong to.
function computeOrderTotals(items, discountPercent, interState) {
  return headerTotals(computeTotals(items, discountPercent, { interState, roundOff: true }));
}

// Purchase Order Register report — bespoke aggregation endpoint for the
// Reports > Purchase > Purchase Order Register page. Registered before the
// plain '/purchase/orders' route below, same reasoning/placement as the
// Sales Order Register report. `source` is accepted for filter-bar parity
// with the sales-side registers but is a no-op here — unlike SalesOrder/
// SalesInvoice, PurchaseOrder has no source column (see schema.prisma), so
// there's nothing real to filter on yet. "Other Charges" is likewise not a
// stored figure on this model (no freight/other-charges column), so it's
// reported as 0 rather than fabricated — Net Amount is simply the
// taxable amount plus tax, same as PurchaseOrder.amount.
router.get('/purchase/orders/register/report', auth(), asyncHandler(async (req, res) => {
  const { fromDate, toDate, supplier, status } = req.query;

  const where = {};
  if (supplier) where.supplier = supplier;
  if (status) where.status = status;
  if (fromDate || toDate) {
    where.poDate = {};
    if (fromDate) where.poDate.gte = new Date(fromDate);
    if (toDate) where.poDate.lte = new Date(toDate);
  }

  const [orders, suppliers] = await Promise.all([
    prisma.purchaseOrder.findMany({ where, include: purchaseOrderInclude, orderBy: { poDate: 'desc' } }),
    prisma.supplier.findMany({ select: { supplierCode: true, supplierName: true } }),
  ]);
  const codeByName = Object.fromEntries(suppliers.map((s) => [s.supplierName, s.supplierCode]));

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const MS_PER_DAY = 24 * 60 * 60 * 1000;

  const rows = orders.map((o) => {
    const goodsAmount = Number(o.subtotal || 0);
    const taxAmount = Number(o.cgstAmount || 0) + Number(o.sgstAmount || 0);
    const otherCharges = 0;
    const netAmount = Number(o.amount || 0);
    const orderedQuantity = o.items.reduce((sum, i) => sum + Number(i.quantity || 0), 0);

    const expectedDate = o.deliveryDate ? new Date(o.deliveryDate) : null;
    if (expectedDate) expectedDate.setHours(0, 0, 0, 0);
    const daysPending = expectedDate ? Math.round((expectedDate - today) / MS_PER_DAY) : null;

    return {
      id: o.id,
      poNo: o.poNo,
      poDate: o.poDate,
      supplierCode: codeByName[o.supplier] || '—',
      supplier: o.supplier,
      goodsAmount,
      taxAmount,
      otherCharges,
      netAmount,
      orderedQuantity,
      status: o.status,
      expectedDate: o.deliveryDate,
      daysPending,
    };
  });

  const totals = rows.reduce((acc, r) => ({
    goodsAmount: acc.goodsAmount + r.goodsAmount,
    taxAmount: acc.taxAmount + r.taxAmount,
    otherCharges: acc.otherCharges + r.otherCharges,
    netAmount: acc.netAmount + r.netAmount,
    orderedQuantity: acc.orderedQuantity + r.orderedQuantity,
  }), { goodsAmount: 0, taxAmount: 0, otherCharges: 0, netAmount: 0, orderedQuantity: 0 });

  res.json({
    success: true,
    data: {
      rows,
      totals,
      stats: {
        totalOrders: rows.length,
        totalOrderAmount: totals.goodsAmount,
        totalOrderedQuantity: totals.orderedQuantity,
        totalTaxAmount: totals.taxAmount,
        totalNetAmount: totals.netAmount,
        avgOrderValue: rows.length > 0 ? totals.netAmount / rows.length : 0,
      },
    },
  });
}));

// Pending Purchase Order report — bespoke aggregation endpoint for the
// Reports > Purchase > Pending Purchase Order page. Same GRN-joined-by-poNo
// approach as the Sales Order Register report uses for DeliveryChallan, but
// keyed off GoodsReceivedNoteItem.receivedQuantity (that model tracks a
// running receivedQuantity/previouslyReceived per line, unlike
// DeliveryChallanItem). "Buying Group" has no stored column on PurchaseOrder
// — it's derived per order as the quantity-weighted majority
// Product.productGroup across the order's own items (joined by
// productCode), same convention Product-wise Sales uses for its Category
// column. `source` is accepted for filter-bar parity but is a no-op, same
// situation as the other two purchase reports above (no source column on
// this model). Date filters apply to Expected Date (deliveryDate), not PO
// Date, per the filter bar's own labels.
router.get('/purchase/orders/pending/report', auth(), asyncHandler(async (req, res) => {
  const { supplier, fromExpectedDate, toExpectedDate, buyingGroup, source } = req.query;

  const where = { status: { notIn: ['Cancelled', 'Closed'] } };
  if (supplier) where.supplier = supplier;
  if (fromExpectedDate || toExpectedDate) {
    where.deliveryDate = {};
    if (fromExpectedDate) where.deliveryDate.gte = new Date(fromExpectedDate);
    if (toExpectedDate) where.deliveryDate.lte = new Date(toExpectedDate);
  }

  const orders = await prisma.purchaseOrder.findMany({ where, include: purchaseOrderInclude, orderBy: { poDate: 'desc' } });
  const poNos = orders.map((o) => o.poNo).filter(Boolean);

  const [grnItems, suppliers, products] = await Promise.all([
    poNos.length
      ? prisma.goodsReceivedNoteItem.findMany({ where: { grn: { poNo: { in: poNos } } }, include: { grn: { select: { poNo: true } } } })
      : Promise.resolve([]),
    prisma.supplier.findMany({ select: { supplierCode: true, supplierName: true } }),
    prisma.product.findMany({ select: { productCode: true, productGroup: true } }),
  ]);
  const codeByName = Object.fromEntries(suppliers.map((s) => [s.supplierName, s.supplierCode]));
  const groupByCode = Object.fromEntries(products.map((p) => [p.productCode, p.productGroup || 'Uncategorized']));

  const receivedQtyByPoNo = {};
  grnItems.forEach((item) => {
    const poNo = item.grn?.poNo;
    if (!poNo) return;
    receivedQtyByPoNo[poNo] = (receivedQtyByPoNo[poNo] || 0) + Number(item.receivedQuantity || 0);
  });

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const MS_PER_DAY = 24 * 60 * 60 * 1000;

  let rows = orders.map((o) => {
    const orderedQty = o.items.reduce((sum, i) => sum + Number(i.quantity || 0), 0);
    const receivedQty = receivedQtyByPoNo[o.poNo] || 0;
    const pendingQty = Math.max(orderedQty - receivedQty, 0);

    const goodsAmount = Number(o.subtotal || 0);
    const taxAmount = Number(o.cgstAmount || 0) + Number(o.sgstAmount || 0);
    const netAmount = Number(o.amount || 0);

    // Quantity-weighted majority productGroup across this order's items.
    const groupWeights = {};
    o.items.forEach((i) => {
      const group = groupByCode[i.productCode] || 'Uncategorized';
      groupWeights[group] = (groupWeights[group] || 0) + Number(i.quantity || 0);
    });
    const buyingGroupForOrder = Object.entries(groupWeights).sort((a, b) => b[1] - a[1])[0]?.[0] || 'Uncategorized';

    const expectedDate = o.deliveryDate ? new Date(o.deliveryDate) : null;
    if (expectedDate) expectedDate.setHours(0, 0, 0, 0);
    const daysPending = expectedDate ? Math.round((expectedDate - today) / MS_PER_DAY) : null;

    return {
      id: o.id,
      poNo: o.poNo,
      poDate: o.poDate,
      supplierCode: codeByName[o.supplier] || '—',
      supplier: o.supplier,
      expectedDate: o.deliveryDate,
      buyingGroup: buyingGroupForOrder,
      goodsAmount,
      taxAmount,
      netAmount,
      pendingQty,
      daysPending,
      status: 'Pending',
    };
  }).filter((r) => r.pendingQty > 0);

  if (buyingGroup) rows = rows.filter((r) => r.buyingGroup === buyingGroup);

  const totals = rows.reduce((acc, r) => ({
    goodsAmount: acc.goodsAmount + r.goodsAmount,
    taxAmount: acc.taxAmount + r.taxAmount,
    netAmount: acc.netAmount + r.netAmount,
    pendingQty: acc.pendingQty + r.pendingQty,
    daysPendingSum: acc.daysPendingSum + (r.daysPending || 0),
  }), { goodsAmount: 0, taxAmount: 0, netAmount: 0, pendingQty: 0, daysPendingSum: 0 });

  // Pending by Supplier (Top 5) donut — same top-5 + "Others" shape as the
  // customer-wise/product-wise sales report contribution series, valued by
  // Goods Amount (matches the Total Order Amount stat).
  const bySupplier = {};
  rows.forEach((r) => { bySupplier[r.supplier] = (bySupplier[r.supplier] || 0) + r.goodsAmount; });
  const supplierEntries = Object.entries(bySupplier).sort((a, b) => b[1] - a[1]);
  const supplierGrandTotal = totals.goodsAmount || 1;
  const topSupplierEntries = supplierEntries.slice(0, 5);
  const othersSupplierValue = supplierEntries.slice(5).reduce((sum, [, v]) => sum + v, 0);
  const topSuppliers = [
    ...topSupplierEntries.map(([name, value]) => ({ name, value: Math.round(value), percent: Math.round((value / supplierGrandTotal) * 1000) / 10 })),
    ...(othersSupplierValue > 0 ? [{ name: 'Others', value: Math.round(othersSupplierValue), percent: Math.round((othersSupplierValue / supplierGrandTotal) * 1000) / 10 }] : []),
  ];

  // Pending by Buying Group donut — valued by Pending Quantity (matches
  // the Total Pending Quantity stat), one slice per group (no Others
  // bucket — there are only ever a handful of product groups).
  const byGroup = {};
  rows.forEach((r) => { byGroup[r.buyingGroup] = (byGroup[r.buyingGroup] || 0) + r.pendingQty; });
  const groupGrandTotal = totals.pendingQty || 1;
  const buyingGroupContribution = Object.entries(byGroup)
    .map(([name, value]) => ({ name, value: Math.round(value), percent: Math.round((value / groupGrandTotal) * 1000) / 10 }))
    .sort((a, b) => b.value - a.value);

  // Pending by Expected Date — Goods Amount bucketed by days remaining
  // until the expected date (negative values, i.e. already overdue, fall
  // into the nearest/"0 - 7 Days" bucket alongside due-now orders).
  const expectedDateBuckets = { d0to7: 0, d8to15: 0, d16to30: 0, above30: 0 };
  rows.forEach((r) => {
    const d = r.daysPending ?? 0;
    if (d <= 7) expectedDateBuckets.d0to7 += r.goodsAmount;
    else if (d <= 15) expectedDateBuckets.d8to15 += r.goodsAmount;
    else if (d <= 30) expectedDateBuckets.d16to30 += r.goodsAmount;
    else expectedDateBuckets.above30 += r.goodsAmount;
  });

  res.json({
    success: true,
    data: {
      rows,
      totals,
      stats: {
        totalPendingOrders: rows.length,
        totalOrderAmount: totals.goodsAmount,
        totalPendingQuantity: totals.pendingQty,
        totalTaxAmount: totals.taxAmount,
        totalNetAmount: totals.netAmount,
        avgDaysPending: rows.length > 0 ? Math.round((totals.daysPendingSum / rows.length) * 100) / 100 : 0,
      },
      topSuppliers,
      buyingGroupContribution,
      expectedDateBuckets,
    },
  });
}));

router.get('/purchase/orders', auth(), asyncHandler(async (req, res) => {
  const { q } = req.query;
  const where = q
    ? {
        OR: [
          { poNo: { contains: q } },
          { supplier: { contains: q } },
          { referenceNo: { contains: q } },
        ],
      }
    : undefined;
  const rows = await prisma.purchaseOrder.findMany({ where, include: purchaseOrderInclude, orderBy: { id: 'desc' } });
  res.json({ success: true, data: rows });
}));

router.get('/purchase/orders/:id', auth(), asyncHandler(async (req, res) => {
  const row = await prisma.purchaseOrder.findUnique({ where: { id: Number(req.params.id) }, include: purchaseOrderInclude });
  if (!row) return res.status(404).json({ success: false, message: 'Record not found' });
  res.json({ success: true, data: row });
}));

router.post('/purchase/orders', auth(), asyncHandler(async (req, res) => {
  const { items = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  const itemData = items.map(toOrderItemData);
  const row = await prisma.$transaction(async (tx) => {
    // Tax treatment is resolved inside the transaction because it depends
    // on the company's registered state: an inter-state supply is charged
    // wholly as IGST, an intra-state one split into CGST/SGST.
    const interState = await resolveTaxTreatment(tx, header.placeOfSupply);
    const totals = computeOrderTotals(itemData, header.discountPercent, interState);
    // poNo now comes from the configured PO numbering series rather than
    // free text — see resolveDocumentNumber above.
    const { documentNumber, syncManual } = await resolveDocumentNumber('PO', header.poNo, tx);
    const created = await tx.purchaseOrder.create({
      data: { ...header, poNo: documentNumber, ...totals, items: { create: itemData } },
      include: purchaseOrderInclude,
    });
    if (syncManual) await syncManual();
    // Ordering against a quotation closes it — see
    // recomputePurchaseQuotationStatus in utils/documentFlow.js.
    await recomputePurchaseQuotationStatus(tx, created.quotationNo);
    return created;
  });
  res.status(201).json({ success: true, data: row });
}));

router.put('/purchase/orders/:id', auth(), asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  const { items = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  const itemData = items.map(toOrderItemData);
  // Replace the item set wholesale on every save — simpler and safer than
  // diffing which rows were added/removed/reordered client-side.
  const row = await prisma.$transaction(async (tx) => {
    // Tax treatment is resolved inside the transaction because it depends
    // on the company's registered state: an inter-state supply is charged
    // wholly as IGST, an intra-state one split into CGST/SGST.
    const interState = await resolveTaxTreatment(tx, header.placeOfSupply);
    const totals = computeOrderTotals(itemData, header.discountPercent, interState);
    const previousOrder = await tx.purchaseOrder.findUnique({
      where: { id }, select: { quotationNo: true },
    });
    await tx.purchaseOrderItem.deleteMany({ where: { orderId: id } });
    const updated = await tx.purchaseOrder.update({
      where: { id },
      data: { ...header, ...totals, items: { create: itemData } },
      include: purchaseOrderInclude,
    });
    // Closing status follows the link, so both ends of a repoint have to be
    // recomputed: the quotation now being ordered against closes, and the one
    // that was abandoned reopens.
    await recomputePurchaseQuotationStatus(tx, updated.quotationNo);
    if (previousOrder?.quotationNo && previousOrder.quotationNo !== updated.quotationNo) {
      await recomputePurchaseQuotationStatus(tx, previousOrder.quotationNo);
    }
    return updated;
  });
  res.json({ success: true, data: row });
}));

router.delete('/purchase/orders/:id', auth(['admin']), asyncHandler(async (req, res) => {
  // PurchaseOrderItem.order has onDelete: Cascade, so items go with it.
  // Removing the order reopens the quotation it was raised from.
  const id = Number(req.params.id);
  await prisma.$transaction(async (tx) => {
    const existing = await tx.purchaseOrder.findUnique({ where: { id }, select: { quotationNo: true } });
    await tx.purchaseOrder.delete({ where: { id } });
    await recomputePurchaseQuotationStatus(tx, existing?.quotationNo);
  });
  res.json({ success: true, message: 'Deleted successfully' });
}));

// Goods Received Note — a master/detail resource (GoodsReceivedNote has many
// GoodsReceivedNoteItem rows), same bespoke-route pattern as /purchase/orders
// above. Totals (flat 9% CGST + 9% SGST on subtotal, no per-item tax rate or
// discount, per the GRN mockup) are always recomputed server-side.
const grnInclude = {
  items: {
    orderBy: { id: 'asc' },
    include: {
      batches: { orderBy: { id: 'asc' } },
      serials: { orderBy: { id: 'asc' } },
    },
  },
};

// Builds the nested Prisma `create` for a line's batches/serials from the
// rows the "Batches - Setup" / "Serial Numbers - Setup" dialog produced.
// Absent or empty arrays are simply omitted — a None/untracked product's
// line never had a `batches`/`serials` key to begin with.
function toBatchCreateData(row, header) {
  return {
    batchNo: row.batchNo,
    productCode: row.productCode || null,
    quantity: Number(row.quantity) || 0,
    batchAttribute1: row.batchAttribute1 || null,
    batchAttribute2: row.batchAttribute2 || null,
    expirationDate: row.expirationDate ? new Date(row.expirationDate) : null,
    mfrDate: row.mfrDate ? new Date(row.mfrDate) : null,
    admissionDate: row.admissionDate ? new Date(row.admissionDate) : null,
    location: row.location || null,
    details: row.details || null,
    warehouse: header?.warehouse || null,
  };
}

function toSerialCreateData(row, header) {
  return {
    serialNo: row.serialNo,
    productCode: row.productCode || null,
    lotNo: row.lotNo || null,
    expirationDate: row.expirationDate ? new Date(row.expirationDate) : null,
    mfrDate: row.mfrDate ? new Date(row.mfrDate) : null,
    admissionDate: row.admissionDate ? new Date(row.admissionDate) : null,
    mfrWarrantyStart: row.mfrWarrantyStart ? new Date(row.mfrWarrantyStart) : null,
    mfrWarrantyEnd: row.mfrWarrantyEnd ? new Date(row.mfrWarrantyEnd) : null,
    location: row.location || null,
    warehouse: header?.warehouse || null,
  };
}

function buildBatchSerialCreates(raw, header) {
  const out = {};
  if (Array.isArray(raw.batches) && raw.batches.length) {
    out.batches = { create: raw.batches.map((b) => toBatchCreateData({ ...b, productCode: raw.productCode }, header)) };
  }
  if (Array.isArray(raw.serials) && raw.serials.length) {
    out.serials = { create: raw.serials.map((s) => toSerialCreateData({ ...s, productCode: raw.productCode }, header)) };
  }
  return out;
}

// GRN lines are valued on the quantity actually received, not the quantity
// ordered, and now carry their own tax rate. Previously this document had no
// tax column at all and computeGrnTotals hard-coded CGST and SGST at 9% each
// — every GRN was taxed at 18% whatever the goods attract, so a receipt of
// 5%-rated stock never tied out against the PO above it or the Purchase
// Invoice below it.
// `header` is the GRN header (post-sanitize, pre-numbering) — its warehouse
// is stamped onto every batch/serial row this line creates, since the
// dialog itself doesn't collect a warehouse (a GRN receives into one
// warehouse for the whole document).
function toGrnItemData(item, header) {
  return mapLine(item, {
    quantityField: 'receivedQuantity',
    extras: (raw) => ({
      poQuantity: Number(raw.poQuantity) || 0,
      previouslyReceived: Number(raw.previouslyReceived) || 0,
      ...buildBatchSerialCreates(raw, header),
    }),
  });
}

function computeGrnTotals(items, discountPercent, interState) {
  const totals = computeTotals(items, discountPercent, { interState, roundOff: true });
  return headerTotals(totals, { totalItems: items.length });
}

/**
 * Reject a receipt that would take cumulative receipts past what was ordered.
 *
 * SAP blocks over-delivery beyond a configured tolerance rather than quietly
 * accepting it, because an over-receipt inflates stock and creates an invoice
 * the PO cannot cover. There is no tolerance master in this schema yet, so the
 * rule here is the strict one: received + previously received may not exceed
 * the PO quantity. Lines with no PO quantity (a GRN raised without a PO) are
 * unconstrained, which is the legitimate free-text-receipt case.
 */
/**
 * Reject a document that would take a product's on-hand stock below zero.
 *
 * Nothing checked this before: a Stock Issue or Delivery Challan could
 * despatch a hundred units of something the warehouse held ten of, and the
 * only sign was a negative figure appearing in the stock reports days later.
 * Negative stock also makes valuation meaningless, since there is no cost
 * layer to value the shortfall against.
 *
 * `excludeDocument` is passed on an update so the document's own current
 * effect is not counted against it — otherwise editing a posted issue from 10
 * units to 8 would be measured as if 8 more were leaving on top of the 10
 * already gone.
 */
async function assertNoNegativeStock(tx, items, { quantityField = 'quantity' } = {}) {
  const required = new Map();
  for (const item of items) {
    const code = item.productCode;
    const qty = Number(item[quantityField]) || 0;
    if (!code || qty <= 0) continue;
    required.set(code, round2((required.get(code) || 0) + qty));
  }
  if (!required.size) return;

  const onHand = await getCurrentStockForMany([...required.keys()], { client: tx });

  const shortfalls = [];
  for (const [code, needed] of required) {
    const available = onHand.get(code);
    // A product code with no master record cannot be stock-controlled; leave
    // it to the referential checks rather than blocking the posting here.
    if (available === undefined) continue;
    if (needed > available + 0.005) {
      shortfalls.push(`${code}: issuing ${needed} but only ${available} on hand`);
    }
  }

  if (shortfalls.length) {
    const err = new Error(`Insufficient stock — ${shortfalls.join('; ')}`);
    err.status = 409;
    throw err;
  }
}

/**
 * Is this invoice the document that moves the goods?
 *
 * Yes only when nothing upstream already moved them: a purchase invoice with
 * no GRN behind it, a sales invoice with no delivery challan. This single
 * predicate is what keeps the no-double-inventory rule true, and it is
 * deliberately the same test utils/stockLedger.js applies in its
 * purchaseInvoice / salesInvoice `headerFilter` — the derived on-hand quantity
 * and the [dbo].[Stock] journal have to agree about which invoices moved
 * stock, and they can only agree if they ask the same question.
 *
 * An empty string counts as absent, not as a reference: the forms submit ''
 * for a cleared Copy From, and reading that as "has a GRN" would silently stop
 * the invoice journalling anything.
 */
function isDirectInvoice(sourceDocNo) {
  return !sourceDocNo || String(sourceDocNo).trim() === '';
}

/**
 * Warehouse is mandatory on an invoice that is about to move stock, and
 * meaningless on one that is not.
 *
 * Never defaulted from the branch. The warehouse decides which cost layer the
 * movement builds or consumes and, on the sales side, whether the issue would
 * take that warehouse negative — choosing one silently would post a stock
 * movement nobody agreed to, into a location nobody checked.
 */
function assertInvoiceWarehouse(header, sourceDocNo, { documentLabel, sourceLabel }) {
  if (!isDirectInvoice(sourceDocNo)) return;
  if (header.warehouse && String(header.warehouse).trim() !== '') return;

  const err = new Error(
    `Warehouse is required on a ${documentLabel} raised without a ${sourceLabel}: `
    + 'this invoice is what moves the stock, so it has to say which warehouse.'
  );
  err.status = 400;
  throw err;
}

function assertNoOverReceipt(items) {
  const offending = [];
  for (const item of items) {
    const ordered = Number(item.poQuantity) || 0;
    if (ordered <= 0) continue;
    const cumulative = round2((Number(item.previouslyReceived) || 0) + (Number(item.receivedQuantity) || 0));
    if (cumulative > ordered) {
      offending.push(
        `${item.productCode || item.productName || 'line'}: receiving ${cumulative} against an ordered quantity of ${ordered}`
      );
    }
  }
  if (offending.length) {
    const err = new Error(`Received quantity exceeds the ordered quantity — ${offending.join('; ')}`);
    err.status = 400;
    throw err;
  }
}

router.get('/purchase/grn', auth(), asyncHandler(async (req, res) => {
  const { q } = req.query;
  const where = q
    ? {
        OR: [
          { grnNo: { contains: q } },
          { supplier: { contains: q } },
          { poNo: { contains: q } },
          { deliveryChallanNo: { contains: q } },
        ],
      }
    : undefined;
  const rows = await prisma.goodsReceivedNote.findMany({ where, include: grnInclude, orderBy: { id: 'desc' } });
  res.json({ success: true, data: rows });
}));

router.get('/purchase/grn/:id', auth(), asyncHandler(async (req, res) => {
  const row = await prisma.goodsReceivedNote.findUnique({ where: { id: Number(req.params.id) }, include: grnInclude });
  if (!row) return res.status(404).json({ success: false, message: 'Record not found' });
  res.json({ success: true, data: row });
}));

router.post('/purchase/grn', auth(), asyncHandler(async (req, res) => {
  const { items = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  // Block a Batch/Serial-tracked line that isn't fully allocated across its
  // batches/serials — see assertBatchSerialAllocation. Runs on the raw items
  // (still carrying their `batches`/`serials` arrays), before toGrnItemData
  // collapses each line to DB columns.
  await assertBatchSerialAllocation(prisma, items, { quantityField: 'receivedQuantity' });
  // Batch/serial numbers are unique system-wide — see assertUniqueBatchesAndSerials.
  await assertUniqueBatchesAndSerials(prisma, items);
  const itemData = items.map((item) => toGrnItemData(item, header));
  // Block a receipt that would take cumulative receipts past the ordered
  // quantity — an over-receipt inflates stock and produces an invoice the
  // purchase order cannot cover.
  assertNoOverReceipt(itemData);
  const row = await prisma.$transaction(async (tx) => {
    // Tax treatment is resolved inside the transaction because it depends
    // on the company's registered state: an inter-state supply is charged
    // wholly as IGST, an intra-state one split into CGST/SGST.
    const interState = await resolveTaxTreatment(tx, header.placeOfSupply);
    const totals = computeGrnTotals(itemData, header.discountPercent, interState);
    // grnNo now comes from the configured GRN numbering series rather than
    // free text — see resolveDocumentNumber above.
    const { documentNumber, syncManual } = await resolveDocumentNumber('GRN', header.grnNo, tx);
    await assertMasterExists(tx, 'supplier', header.supplier);
    const created = await tx.goodsReceivedNote.create({
      data: { ...header, grnNo: documentNumber, ...totals, items: { create: itemData } },
      include: grnInclude,
    });
    if (syncManual) await syncManual();
    // Recompute the order this document fulfils — see utils/documentFlow.js.
    await recomputePurchaseOrder(tx, created.poNo);
    // Journal the movement into [dbo].[Stock] — inward, once the GRN is no
    // longer Draft/Cancelled. See utils/stockTable.js.
    await postStockEntries(tx, {
      transType: TRANS_TYPES.PURCHASE_GRN,
      transNum: created.id,
      status: created.status,
      warehouse: created.warehouse,
      lines: grnLines(itemData),
      userId: req.user?.id,
    });
    // And the accounting document behind it -- Dr Inventory / Cr Goods
    // Clearing (GRNI). Same transaction, so a failed save takes the ledger
    // entry with it. See utils/glPosting.js.
    await syncJournalEntry(tx, {
      sourceType: JOURNAL_SOURCE_TYPES.PURCHASE_GRN,
      sourceDocNo: created.grnNo,
      status: created.status,
      doc: { ...created, items: itemData },
    });
    // Settle this GRN's own Open/Closed state last, once its lines exist and
    // the stock entry has been journalled against the status the form
    // actually submitted. See recomputeGrnStatus in utils/documentFlow.js.
    await recomputeGrnStatus(tx, created.grnNo);
    return tx.goodsReceivedNote.findUnique({ where: { id: created.id }, include: grnInclude });
  });
  res.status(201).json({ success: true, data: row });
}));

router.put('/purchase/grn/:id', auth(), asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  const { items = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  // Block a Batch/Serial-tracked line that isn't fully allocated across its
  // batches/serials — see assertBatchSerialAllocation.
  await assertBatchSerialAllocation(prisma, items, { quantityField: 'receivedQuantity' });
  // Batch/serial numbers are unique system-wide — see assertUniqueBatchesAndSerials.
  // excludeGrnId means re-saving this GRN with its own previously-saved
  // numbers unchanged isn't flagged as colliding with itself.
  await assertUniqueBatchesAndSerials(prisma, items, { excludeGrnId: id });
  const itemData = items.map((item) => toGrnItemData(item, header));
  // Block a receipt that would take cumulative receipts past the ordered
  // quantity — an over-receipt inflates stock and produces an invoice the
  // purchase order cannot cover.
  assertNoOverReceipt(itemData);
  // Replace the item set wholesale on every save — simpler and safer than
  // diffing which rows were added/removed/reordered client-side.
  const row = await prisma.$transaction(async (tx) => {
    // Tax treatment is resolved inside the transaction because it depends
    // on the company's registered state: an inter-state supply is charged
    // wholly as IGST, an intra-state one split into CGST/SGST.
    const interState = await resolveTaxTreatment(tx, header.placeOfSupply);
    const totals = computeGrnTotals(itemData, header.discountPercent, interState);
    const previousGrn = await tx.goodsReceivedNote.findUnique({ where: { id }, select: { poNo: true } });
    await tx.goodsReceivedNoteItem.deleteMany({ where: { grnId: id } });
    await assertMasterExists(tx, 'supplier', header.supplier);
    const updated = await tx.goodsReceivedNote.update({
      where: { id },
      data: { ...header, ...totals, items: { create: itemData } },
      include: grnInclude,
    });
    // Recompute the order this document fulfils — see utils/documentFlow.js.
    await recomputePurchaseOrder(tx, updated.poNo);
    if (previousGrn?.poNo && previousGrn.poNo !== updated.poNo) {
      await recomputePurchaseOrder(tx, previousGrn.poNo);
    }
    // A GRN saved as Draft and later marked Received journals on that later
    // save; one already journalled is left alone. See utils/stockTable.js.
    await postStockEntries(tx, {
      transType: TRANS_TYPES.PURCHASE_GRN,
      transNum: updated.id,
      status: updated.status,
      warehouse: updated.warehouse,
      lines: grnLines(itemData),
      userId: req.user?.id,
    });
    // Rebuild the accounting document from what this GRN now says -- an
    // edited receipt has different accounting, and one pulled back to Draft
    // should have none at all.
    await syncJournalEntry(tx, {
      sourceType: JOURNAL_SOURCE_TYPES.PURCHASE_GRN,
      sourceDocNo: updated.grnNo,
      status: updated.status,
      doc: { ...updated, items: itemData },
    });
    // Re-settle Open/Closed against what is actually invoiced — editing a
    // GRN's lines changes what "fully invoiced" means for it, and a GRN
    // promoted out of its Draft staging state by this very save has to be
    // evaluated for the first time here.
    await recomputeGrnStatus(tx, updated.grnNo);
    return tx.goodsReceivedNote.findUnique({ where: { id }, include: grnInclude });
  });
  res.json({ success: true, data: row });
}));

router.delete('/purchase/grn/:id', auth(['admin']), asyncHandler(async (req, res) => {
  // Deleting the document deletes its accounting document too -- a
  // ledger entry for a document that no longer exists is worse than no
  // entry at all. See reverseJournalEntry in utils/glPosting.js.
  await removeJournalEntryForDocument(
    prisma, JOURNAL_SOURCE_TYPES.PURCHASE_GRN, 'goodsReceivedNote', 'grnNo', Number(req.params.id)
  );
  // Removing a receipt reopens whatever it had closed on the purchase order.
  const grnId = Number(req.params.id);
  await prisma.$transaction(async (tx) => {
    const existing = await tx.goodsReceivedNote.findUnique({ where: { id: grnId }, select: { poNo: true } });
    await tx.goodsReceivedNote.delete({ where: { id: grnId } });
    await recomputePurchaseOrder(tx, existing?.poNo);
  });
  // GoodsReceivedNoteItem.grn has onDelete: Cascade, so items go with it.
  res.json({ success: true, message: 'Deleted successfully' });
}));

// Purchase Invoice — a master/detail resource (PurchaseInvoice has many
// PurchaseInvoiceItem rows), same bespoke-route pattern as /purchase/orders
// and /purchase/grn above. Unlike PurchaseOrder, each item can carry its own
// discountPercent (per the mockup's item-level Discount % column) in
// addition to the header-level discountPercent, and totals include a
// roundOff adjustment to a whole-currency grand total.
const purchaseInvoiceInclude = { items: { orderBy: { id: 'asc' } } };

function toInvoiceItemData(item) {
  return mapLine(item);
}

function computeInvoiceTotals(items, discountPercent, interState) {
  return headerTotals(computeTotals(items, discountPercent, { interState, roundOff: true }));
}

// Purchase Invoice Register report — bespoke aggregation endpoint for the
// Reports > Purchase > Purchase Invoice Register page. Registered before
// the plain '/purchase/invoices' route below, same reasoning/placement as
// the Purchase Order Register report. Days Pending and the aging-bucket
// summary reuse SupplierOutstanding (joined by invoiceNo) rather than
// re-deriving balances from paymentStatus alone, same convention as
// /payables/outstanding/report — that table is what actually tracks the
// shrinking balanceAmount as Payment Entries are applied. `source` is
// accepted for filter-bar parity but is a no-op — PurchaseInvoice has no
// source column, same situation as the Purchase Order Register above.

// --- Route Map -------------------------------------------------------------
// The whole document chain one document belongs to, for the Route Map dialog
// on every Purchase and Sales list page.
//
// One endpoint rather than one per document type: the map is the same object
// whichever end of the chain it is opened from, so the only thing that varies
// is the anchor. See utils/routeMap.js for how the chain is walked.
//
// Read-only and cheap enough not to need caching — the walk is a handful of
// indexed single-row lookups, bounded by the depth of the chain.
const ROUTE_MAP_ANCHORS = {
  sales: ['enquiry', 'quotation', 'order', 'challan', 'invoice', 'return', 'creditMemo', 'payment'],
  purchase: ['quotation', 'order', 'grn', 'invoice', 'return', 'creditMemo', 'payment'],
};

// One handler, mounted twice under an explicit literal path per flow.
// Deliberately not a `/:flow(sales|purchase)/route-map` pattern route: custom
// match groups are a path-to-regexp feature whose support differs between
// Express major versions, and two mounts cost nothing to be certain of.
const routeMapHandler = (flow) => asyncHandler(async (req, res) => {
  const { type, no } = req.query;

  // Validated rather than passed straight through: `type` selects which table
  // the walk seeds from, so an unrecognised value should be a clear 400 and
  // not a silently empty map that looks like a document with no history.
  if (!ROUTE_MAP_ANCHORS[flow].includes(type)) {
    return res.status(400).json({
      success: false,
      message: `Unknown ${flow} document type "${type || ''}".`,
    });
  }
  if (!no || !String(no).trim()) {
    return res.status(400).json({ success: false, message: 'A document number is required.' });
  }

  const data = await buildRouteMap(prisma, flow, { type, no: String(no).trim() });
  return res.json({ success: true, data });
});

router.get('/sales/route-map', auth(), routeMapHandler('sales'));
router.get('/purchase/route-map', auth(), routeMapHandler('purchase'));

// --- Purchase Return -------------------------------------------------------
// Goods going back to a supplier, raised against a GRN. It carries the same
// money shape as the other purchase documents — the totals and the CGST/SGST
// vs IGST split are computed here from the lines, never accepted from the
// client, so a stored total can never disagree with the lines beside it.
//
// It still posts no stock movement and no payables adjustment: the document
// records the value of what is going back and nothing more.
const purchaseReturnInclude = { items: { orderBy: { id: 'asc' }, include: { batchAllocations: { orderBy: { id: 'asc' } }, serialAllocations: { orderBy: { id: 'asc' } } } } };

const toPurchaseReturnItem = (item) => mapLine(item, {
  quantityField: 'returnQuantity',
  // Carried from the GRN line so the form can cap the return at what came in.
  extras: (raw) => ({ receivedQuantity: Number(raw.receivedQuantity) || 0 }),
});

function computePurchaseReturnTotals(items, discountPercent, interState) {
  const totals = computeTotals(items, discountPercent, { interState, roundOff: true });
  return headerTotals(totals, { totalItems: items.length });
}

router.get('/purchase/returns', auth(), asyncHandler(async (req, res) => {
  const { q } = req.query;
  const where = q
    ? { OR: [{ returnNo: { contains: q } }, { supplier: { contains: q } }, { grnNo: { contains: q } }] }
    : undefined;
  const rows = await prisma.purchaseReturn.findMany({
    where, include: purchaseReturnInclude, orderBy: { id: 'desc' },
  });
  res.json({ success: true, data: rows });
}));

router.get('/purchase/returns/:id', auth(), asyncHandler(async (req, res) => {
  const row = await prisma.purchaseReturn.findUnique({
    where: { id: Number(req.params.id) }, include: purchaseReturnInclude,
  });
  if (!row) return res.status(404).json({ success: false, message: 'Record not found' });
  res.json({ success: true, data: row });
}));

router.post('/purchase/returns', auth(), asyncHandler(async (req, res) => {
  const { items = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  const itemData = items.map(toPurchaseReturnItem);
  // A Batch/Serial-tracked line must SELECT existing batches/serials to
  // cover the returned quantity — same "Selection" rule as Delivery
  // Challan/Stock Issue, since a return draws down stock exactly like they do.
  await assertBatchSerialIssueAllocation(prisma, items, { quantityField: 'returnQuantity' });
  await assertBatchSerialAvailability(prisma, items);
  const row = await prisma.$transaction(async (tx) => {
    // Resolved inside the transaction because it depends on the company's
    // registered state: an inter-state supply is charged wholly as IGST.
    const interState = await resolveTaxTreatment(tx, header.placeOfSupply);
    const totals = computePurchaseReturnTotals(itemData, header.discountPercent, interState);
    const { documentNumber, syncManual } = await resolveDocumentNumber('PRT', header.returnNo, tx);
    await assertMasterExists(tx, 'supplier', header.supplier);
    // Goods can go back to the supplier only until the GRN has been invoiced;
    // after that a Purchase Credit Memo is the instrument. See routeMap.js.
    await assertReturnAllowed(tx, { kind: 'purchase', docNo: header.grnNo });
    // Nor can it take back more than the GRN actually received once every
    // OTHER purchase return already raised against it is accounted for — the
    // server-side backstop behind the client's own "remaining after other
    // returns" cap (see documentFlow.js).
    await assertNoOverConsumption(tx, {
      sourceModel: tx.goodsReceivedNote,
      sourceDocField: 'grnNo',
      sourceDocNo: header.grnNo,
      sourceQuantityField: 'receivedQuantity',
      consumerModel: tx.purchaseReturn,
      consumerDocField: 'grnNo',
      consumerQuantityField: 'returnQuantity',
      consumerDocNoField: 'returnNo',
      items: itemData,
      label: 'return',
    });
    // Goods physically leaving cannot take the warehouse's stock below zero.
    await assertNoNegativeStock(tx, itemData, { quantityField: 'returnQuantity' });
    const created = await tx.purchaseReturn.create({
      data: { ...header, returnNo: documentNumber, ...totals, items: { create: itemData } },
      include: purchaseReturnInclude,
    });
    if (syncManual) await syncManual();
    // Decrement the selected batches/serials and record the allocation —
    // see applyBatchSerialIssueEffects.
    await applyBatchSerialIssueEffects(tx, items, created.items, { linkField: 'purchaseReturnItemId' });
    // Journal the movement into [dbo].[Stock] — outward, once the return is
    // no longer Draft/Cancelled. See utils/stockTable.js.
    await postStockEntries(tx, {
      transType: TRANS_TYPES.PURCHASE_RETURN,
      transNum: created.id,
      status: created.status,
      warehouse: created.warehouse,
      lines: purchaseReturnLines(itemData),
      userId: req.user?.id,
    });
    // Dr Goods Clearing / Cr Inventory -- the goods side only. The financial
    // claim on the supplier is raised by a Purchase Credit Memo.
    await syncJournalEntry(tx, {
      sourceType: JOURNAL_SOURCE_TYPES.PURCHASE_RETURN,
      sourceDocNo: created.returnNo,
      status: created.status,
      doc: { ...created, items: itemData },
    });
    return created;
  });
  res.status(201).json({ success: true, data: row });
}));

router.put('/purchase/returns/:id', auth(), asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  const { items = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  const itemData = items.map(toPurchaseReturnItem);
  await assertBatchSerialIssueAllocation(prisma, items, { quantityField: 'returnQuantity' });
  await assertBatchSerialAvailability(prisma, items, { excludePurchaseReturnId: id });
  const row = await prisma.$transaction(async (tx) => {
    const interState = await resolveTaxTreatment(tx, header.placeOfSupply);
    const totals = computePurchaseReturnTotals(itemData, header.discountPercent, interState);
    // Checked on edit too, not just on create: re-pointing an existing return
    // at a GRN that has since been invoiced is the same rule break, and only
    // guarding the create would leave that route open. `unchangedFrom` keeps a
    // return that was raised legitimately editable after its GRN is invoiced.
    const existing = await tx.purchaseReturn.findUnique({
      where: { id }, select: { grnNo: true, items: true },
    });
    await assertReturnAllowed(tx, {
      kind: 'purchase', docNo: header.grnNo, unchangedFrom: existing?.grnNo,
    });
    await assertNoOverConsumption(tx, {
      sourceModel: tx.goodsReceivedNote,
      sourceDocField: 'grnNo',
      sourceDocNo: header.grnNo,
      sourceQuantityField: 'receivedQuantity',
      consumerModel: tx.purchaseReturn,
      consumerDocField: 'grnNo',
      consumerQuantityField: 'returnQuantity',
      consumerDocNoField: 'returnNo',
      items: itemData,
      excludeConsumerDocNo: header.returnNo,
      // Only an increase over what THIS return already held counts against
      // the shared pool — see the note on assertNoOverConsumption. Without
      // this, resaving a return unchanged would recount its own existing
      // quantity as brand-new demand on top of itself.
      previousItems: existing?.items || [],
      label: 'return',
    });
    // Undo the stock effect of this document's CURRENT batch/serial
    // selections before its items (and their allocation rows) are replaced
    // — see restoreBatchSerialIssueEffects.
    await restoreBatchSerialIssueEffects(tx, { purchaseReturnId: id });
    // Lines are replaced wholesale: the form always submits the document's
    // complete current state, so delete-then-recreate inside one transaction
    // is the simplest thing that cannot leave a stale line behind.
    await tx.purchaseReturnItem.deleteMany({ where: { returnId: id } });
    await assertNoNegativeStock(tx, itemData, { quantityField: 'returnQuantity' });
    const updated = await tx.purchaseReturn.update({
      where: { id },
      data: { ...header, ...totals, items: { create: itemData } },
      include: purchaseReturnInclude,
    });
    // Apply the new selection's stock effect — see applyBatchSerialIssueEffects.
    await applyBatchSerialIssueEffects(tx, items, updated.items, { linkField: 'purchaseReturnItemId' });
    // A return saved as Draft and later Open/Closed journals on that later
    // save; one already journalled is left alone. See utils/stockTable.js.
    await postStockEntries(tx, {
      transType: TRANS_TYPES.PURCHASE_RETURN,
      transNum: updated.id,
      status: updated.status,
      warehouse: updated.warehouse,
      lines: purchaseReturnLines(itemData),
      userId: req.user?.id,
    });
    // Rebuild the accounting document from what this return now says.
    await syncJournalEntry(tx, {
      sourceType: JOURNAL_SOURCE_TYPES.PURCHASE_RETURN,
      sourceDocNo: updated.returnNo,
      status: updated.status,
      doc: { ...updated, items: itemData },
    });
    return updated;
  });
  res.json({ success: true, data: row });
}));

router.delete('/purchase/returns/:id', auth(['admin']), asyncHandler(async (req, res) => {
  // Deleting the document deletes its accounting document too -- a
  // ledger entry for a document that no longer exists is worse than no
  // entry at all. See reverseJournalEntry in utils/glPosting.js.
  await removeJournalEntryForDocument(
    prisma, JOURNAL_SOURCE_TYPES.PURCHASE_RETURN, 'purchaseReturn', 'returnNo', Number(req.params.id)
  );
  const id = Number(req.params.id);
  await prisma.$transaction(async (tx) => {
    // Give back whatever batch quantity/serial status this return's
    // selections had taken, before the items (and their allocation rows)
    // cascade away with the document.
    await restoreBatchSerialIssueEffects(tx, { purchaseReturnId: id });
    await tx.purchaseReturn.delete({ where: { id } });
  });
  res.json({ success: true, message: 'Deleted successfully' });
}));


// --- Purchase Credit Memo --------------------------------------------------
// A credit received from a supplier, raised against a Purchase Invoice.
// Totals and the CGST/SGST vs IGST split are computed here from the lines and
// never accepted from the client, exactly as for the other purchase documents.
// It posts no payables adjustment: the memo records the credit's value only.
const creditMemoInclude = { items: { orderBy: { id: 'asc' }, include: { batchAllocations: { orderBy: { id: 'asc' } }, serialAllocations: { orderBy: { id: 'asc' } } } } };

const toCreditMemoItem = (item) => mapLine(item, {
  quantityField: 'quantity',
  extras: (raw) => ({ invoicedQuantity: Number(raw.invoicedQuantity) || 0 }),
});

function computeCreditMemoTotals(items, discountPercent, interState) {
  const totals = computeTotals(items, discountPercent, { interState, roundOff: true });
  return headerTotals(totals, { totalItems: items.length });
}

router.get('/purchase/credit-memos', auth(), asyncHandler(async (req, res) => {
  const { q } = req.query;
  const where = q
    ? { OR: [{ creditNo: { contains: q } }, { supplier: { contains: q } }, { invoiceNo: { contains: q } }] }
    : undefined;
  const rows = await prisma.purchaseCreditMemo.findMany({
    where, include: creditMemoInclude, orderBy: { id: 'desc' },
  });
  res.json({ success: true, data: rows });
}));

router.get('/purchase/credit-memos/:id', auth(), asyncHandler(async (req, res) => {
  const row = await prisma.purchaseCreditMemo.findUnique({
    where: { id: Number(req.params.id) }, include: creditMemoInclude,
  });
  if (!row) return res.status(404).json({ success: false, message: 'Record not found' });
  res.json({ success: true, data: row });
}));

router.post('/purchase/credit-memos', auth(), asyncHandler(async (req, res) => {
  const { items = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  const itemData = items.map(toCreditMemoItem);
  await assertBatchSerialIssueAllocation(prisma, items, { quantityField: 'quantity' });
  await assertBatchSerialAvailability(prisma, items);
  const row = await prisma.$transaction(async (tx) => {
    const interState = await resolveTaxTreatment(tx, header.placeOfSupply);
    const totals = computeCreditMemoTotals(itemData, header.discountPercent, interState);
    const { documentNumber, syncManual } = await resolveDocumentNumber('PCM', header.creditNo, tx);
    await assertMasterExists(tx, 'supplier', header.supplier);
    // A credit memo reverses billed value, so there has to be a live invoice
    // behind it — the counterpart of the return guard. See routeMap.js.
    await assertCreditMemoAllowed(tx, { kind: 'purchase', invoiceNo: header.invoiceNo });
    // Nor can it credit more than the invoice actually billed once every
    // OTHER purchase credit memo already raised against it is accounted for
    // — the server-side backstop behind the client's own "remaining after
    // other memos" cap (see documentFlow.js).
    await assertNoOverConsumption(tx, {
      sourceModel: tx.purchaseInvoice,
      sourceDocField: 'invoiceNo',
      sourceDocNo: header.invoiceNo,
      sourceQuantityField: 'quantity',
      consumerModel: tx.purchaseCreditMemo,
      consumerDocField: 'invoiceNo',
      consumerQuantityField: 'quantity',
      consumerDocNoField: 'creditNo',
      items: itemData,
      label: 'credit',
    });
    // Goods physically leaving cannot take the warehouse's stock below zero.
    await assertNoNegativeStock(tx, itemData);
    const created = await tx.purchaseCreditMemo.create({
      data: { ...header, creditNo: documentNumber, ...totals, items: { create: itemData } },
      include: creditMemoInclude,
    });
    if (syncManual) await syncManual();
    await applyBatchSerialIssueEffects(tx, items, created.items, { linkField: 'purchaseCreditMemoItemId' });
    await postStockEntries(tx, {
      transType: TRANS_TYPES.PURCHASE_CREDIT_MEMO,
      transNum: created.id,
      status: created.status,
      warehouse: created.warehouse,
      lines: purchaseCreditMemoLines(itemData),
      userId: req.user?.id,
    });
    // Dr Accounts Payable / Cr Inventory + Input GST.
    await syncJournalEntry(tx, {
      sourceType: JOURNAL_SOURCE_TYPES.PURCHASE_CREDIT_MEMO,
      sourceDocNo: created.creditNo,
      status: created.status,
      doc: { ...created, items: itemData },
    });
    return created;
  });
  res.status(201).json({ success: true, data: row });
}));

router.put('/purchase/credit-memos/:id', auth(), asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  const { items = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  const itemData = items.map(toCreditMemoItem);
  await assertBatchSerialIssueAllocation(prisma, items, { quantityField: 'quantity' });
  await assertBatchSerialAvailability(prisma, items, { excludePurchaseCreditMemoId: id });
  const row = await prisma.$transaction(async (tx) => {
    const interState = await resolveTaxTreatment(tx, header.placeOfSupply);
    const totals = computeCreditMemoTotals(itemData, header.discountPercent, interState);
    await assertCreditMemoAllowed(tx, { kind: 'purchase', invoiceNo: header.invoiceNo });
    const existing = await tx.purchaseCreditMemo.findUnique({
      where: { id }, select: { items: true },
    });
    await assertNoOverConsumption(tx, {
      sourceModel: tx.purchaseInvoice,
      sourceDocField: 'invoiceNo',
      sourceDocNo: header.invoiceNo,
      sourceQuantityField: 'quantity',
      consumerModel: tx.purchaseCreditMemo,
      consumerDocField: 'invoiceNo',
      consumerQuantityField: 'quantity',
      consumerDocNoField: 'creditNo',
      items: itemData,
      excludeConsumerDocNo: header.creditNo,
      previousItems: existing?.items || [],
      label: 'credit',
    });
    await restoreBatchSerialIssueEffects(tx, { purchaseCreditMemoId: id });
    // Lines are replaced wholesale — the form always submits the document's
    // complete current state.
    await tx.purchaseCreditMemoItem.deleteMany({ where: { creditMemoId: id } });
    await assertNoNegativeStock(tx, itemData);
    const updated = await tx.purchaseCreditMemo.update({
      where: { id },
      data: { ...header, ...totals, items: { create: itemData } },
      include: creditMemoInclude,
    });
    await applyBatchSerialIssueEffects(tx, items, updated.items, { linkField: 'purchaseCreditMemoItemId' });
    await postStockEntries(tx, {
      transType: TRANS_TYPES.PURCHASE_CREDIT_MEMO,
      transNum: updated.id,
      status: updated.status,
      warehouse: updated.warehouse,
      lines: purchaseCreditMemoLines(itemData),
      userId: req.user?.id,
    });
    // Rebuild the accounting document from what this credit memo now says.
    await syncJournalEntry(tx, {
      sourceType: JOURNAL_SOURCE_TYPES.PURCHASE_CREDIT_MEMO,
      sourceDocNo: updated.creditNo,
      status: updated.status,
      doc: { ...updated, items: itemData },
    });
    return updated;
  });
  res.json({ success: true, data: row });
}));

router.delete('/purchase/credit-memos/:id', auth(['admin']), asyncHandler(async (req, res) => {
  // Deleting the document deletes its accounting document too -- a
  // ledger entry for a document that no longer exists is worse than no
  // entry at all. See reverseJournalEntry in utils/glPosting.js.
  await removeJournalEntryForDocument(
    prisma, JOURNAL_SOURCE_TYPES.PURCHASE_CREDIT_MEMO, 'purchaseCreditMemo', 'creditNo', Number(req.params.id)
  );
  const id = Number(req.params.id);
  await prisma.$transaction(async (tx) => {
    await restoreBatchSerialIssueEffects(tx, { purchaseCreditMemoId: id });
    await tx.purchaseCreditMemo.delete({ where: { id } });
  });
  res.json({ success: true, message: 'Deleted successfully' });
}));


// --- Sales Credit Memo -----------------------------------------------------
// A credit issued to a customer, raised against a Sales Invoice. Totals and the
// CGST/SGST vs IGST split are computed here from the lines, never accepted from
// the client. Posts no stock movement and no receivables adjustment: the memo
// records the credit's value only.
const salesCreditMemoInclude = { items: { orderBy: { id: 'asc' }, include: { batchAllocations: { orderBy: { id: 'asc' } }, serialAllocations: { orderBy: { id: 'asc' } } } } };

const toSalesCreditMemoItem = (item) => mapLine(item, {
  quantityField: 'quantity',
  extras: (raw) => ({ invoicedQuantity: Number(raw.invoicedQuantity) || 0 }),
});

function computeSalesCreditMemoTotals(items, discountPercent, interState) {
  const totals = computeTotals(items, discountPercent, { interState, roundOff: true });
  return headerTotals(totals, { totalItems: items.length });
}

router.get('/sales/credit-memos', auth(), asyncHandler(async (req, res) => {
  const { q } = req.query;
  const where = q
    ? { OR: [{ creditNo: { contains: q } }, { customer: { contains: q } }, { invoiceNo: { contains: q } }] }
    : undefined;
  const rows = await prisma.salesCreditMemo.findMany({
    where, include: salesCreditMemoInclude, orderBy: { id: 'desc' },
  });
  res.json({ success: true, data: rows });
}));

router.get('/sales/credit-memos/:id', auth(), asyncHandler(async (req, res) => {
  const row = await prisma.salesCreditMemo.findUnique({
    where: { id: Number(req.params.id) }, include: salesCreditMemoInclude,
  });
  if (!row) return res.status(404).json({ success: false, message: 'Record not found' });
  res.json({ success: true, data: row });
}));

router.post('/sales/credit-memos', auth(), asyncHandler(async (req, res) => {
  const { items = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  const itemData = items.map(toSalesCreditMemoItem);
  // "Restock" — a Batch/Serial-tracked line must select the existing
  // (currently Issued) batches/serials being credited back in. See
  // assertBatchSerialRestockAllocation / assertBatchSerialRestockAvailability
  // in utils/businessRules.js.
  await assertBatchSerialRestockAllocation(prisma, items, { quantityField: 'quantity' });
  await assertBatchSerialRestockAvailability(prisma, items);
  const row = await prisma.$transaction(async (tx) => {
    const interState = await resolveTaxTreatment(tx, header.placeOfSupply);
    const totals = computeSalesCreditMemoTotals(itemData, header.discountPercent, interState);
    const { documentNumber, syncManual } = await resolveDocumentNumber('SCM', header.creditNo, tx);
    await assertMasterExists(tx, 'customer', header.customer);
    // A credit memo reverses billed value, so there has to be a live invoice
    // behind it — the counterpart of the return guard. See routeMap.js.
    await assertCreditMemoAllowed(tx, { kind: 'sales', invoiceNo: header.invoiceNo });
    // Nor can it credit more than the invoice actually billed once every
    // OTHER sales credit memo already raised against it is accounted for —
    // the server-side backstop behind the client's own "remaining after
    // other memos" cap (see documentFlow.js).
    await assertNoOverConsumption(tx, {
      sourceModel: tx.salesInvoice,
      sourceDocField: 'invoiceNo',
      sourceDocNo: header.invoiceNo,
      sourceQuantityField: 'quantity',
      consumerModel: tx.salesCreditMemo,
      consumerDocField: 'invoiceNo',
      consumerQuantityField: 'quantity',
      consumerDocNoField: 'creditNo',
      items: itemData,
      label: 'credit',
    });
    const created = await tx.salesCreditMemo.create({
      data: { ...header, creditNo: documentNumber, ...totals, items: { create: itemData } },
      include: salesCreditMemoInclude,
    });
    if (syncManual) await syncManual();
    // Restock — increments each selected batch's quantity and flips each
    // selected serial back to 'In Stock'. See applyBatchSerialRestockEffects.
    await applyBatchSerialRestockEffects(tx, items, created.items, { linkField: 'salesCreditMemoItemId' });
    // Journal the movement into [dbo].[Stock] — inward, no negative-stock
    // guard needed (adding stock back can never take it negative), once the
    // memo is no longer Draft/Cancelled. See utils/stockTable.js.
    await postStockEntries(tx, {
      transType: TRANS_TYPES.SALES_CREDIT_MEMO,
      transNum: created.id,
      status: created.status,
      warehouse: created.warehouse,
      lines: salesCreditMemoLines(itemData),
      userId: req.user?.id,
    });
    // Dr Sales Returns + Output GST / Cr Accounts Receivable, plus the goods
    // coming back at cost.
    await syncJournalEntry(tx, {
      sourceType: JOURNAL_SOURCE_TYPES.SALES_CREDIT_MEMO,
      sourceDocNo: created.creditNo,
      status: created.status,
      doc: { ...created, items: itemData },
    });
    return created;
  });
  res.status(201).json({ success: true, data: row });
}));

router.put('/sales/credit-memos/:id', auth(), asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  const { items = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  const itemData = items.map(toSalesCreditMemoItem);
  await assertBatchSerialRestockAllocation(prisma, items, { quantityField: 'quantity' });
  await assertBatchSerialRestockAvailability(prisma, items, { excludeSalesCreditMemoId: id });
  const row = await prisma.$transaction(async (tx) => {
    const interState = await resolveTaxTreatment(tx, header.placeOfSupply);
    const totals = computeSalesCreditMemoTotals(itemData, header.discountPercent, interState);
    await assertCreditMemoAllowed(tx, { kind: 'sales', invoiceNo: header.invoiceNo });
    const existing = await tx.salesCreditMemo.findUnique({
      where: { id }, select: { items: true },
    });
    await assertNoOverConsumption(tx, {
      sourceModel: tx.salesInvoice,
      sourceDocField: 'invoiceNo',
      sourceDocNo: header.invoiceNo,
      sourceQuantityField: 'quantity',
      consumerModel: tx.salesCreditMemo,
      consumerDocField: 'invoiceNo',
      consumerQuantityField: 'quantity',
      consumerDocNoField: 'creditNo',
      items: itemData,
      excludeConsumerDocNo: header.creditNo,
      previousItems: existing?.items || [],
      label: 'credit',
    });
    // Undo this document's CURRENT restock effect before its items (and
    // their allocation rows) are replaced — see restoreBatchSerialRestockEffects.
    await restoreBatchSerialRestockEffects(tx, { salesCreditMemoId: id });
    // Lines are replaced wholesale — the form always submits the document's
    // complete current state.
    await tx.salesCreditMemoItem.deleteMany({ where: { creditMemoId: id } });
    const updated = await tx.salesCreditMemo.update({
      where: { id },
      data: { ...header, ...totals, items: { create: itemData } },
      include: salesCreditMemoInclude,
    });
    await applyBatchSerialRestockEffects(tx, items, updated.items, { linkField: 'salesCreditMemoItemId' });
    await postStockEntries(tx, {
      transType: TRANS_TYPES.SALES_CREDIT_MEMO,
      transNum: updated.id,
      status: updated.status,
      warehouse: updated.warehouse,
      lines: salesCreditMemoLines(itemData),
      userId: req.user?.id,
    });
    // Rebuild the accounting document from what this credit memo now says.
    await syncJournalEntry(tx, {
      sourceType: JOURNAL_SOURCE_TYPES.SALES_CREDIT_MEMO,
      sourceDocNo: updated.creditNo,
      status: updated.status,
      doc: { ...updated, items: itemData },
    });
    return updated;
  });
  res.json({ success: true, data: row });
}));

router.delete('/sales/credit-memos/:id', auth(['admin']), asyncHandler(async (req, res) => {
  // Deleting the document deletes its accounting document too -- a
  // ledger entry for a document that no longer exists is worse than no
  // entry at all. See reverseJournalEntry in utils/glPosting.js.
  await removeJournalEntryForDocument(
    prisma, JOURNAL_SOURCE_TYPES.SALES_CREDIT_MEMO, 'salesCreditMemo', 'creditNo', Number(req.params.id)
  );
  const id = Number(req.params.id);
  await prisma.$transaction(async (tx) => {
    // Undo the restock effect (put serials back to Issued, take the
    // quantity back off the batches) before the items — and their
    // allocation rows — cascade away with the document.
    await restoreBatchSerialRestockEffects(tx, { salesCreditMemoId: id });
    await tx.salesCreditMemo.delete({ where: { id } });
  });
  res.json({ success: true, message: 'Deleted successfully' });
}));


// --- Sales Return ----------------------------------------------------------
// Goods coming back from a customer, raised against a Delivery Challan. Totals
// and the CGST/SGST vs IGST split are computed here from the lines, never
// accepted from the client. Posts no stock movement and no receivables
// adjustment: the document records the value of what is coming back.
const salesReturnInclude = { items: { orderBy: { id: 'asc' }, include: { batchAllocations: { orderBy: { id: 'asc' } }, serialAllocations: { orderBy: { id: 'asc' } } } } };

const toSalesReturnItem = (item) => mapLine(item, {
  quantityField: 'returnQuantity',
  extras: (raw) => ({ deliveredQuantity: Number(raw.deliveredQuantity) || 0 }),
});

function computeSalesReturnTotals(items, discountPercent, interState) {
  const totals = computeTotals(items, discountPercent, { interState, roundOff: true });
  return headerTotals(totals, { totalItems: items.length });
}

router.get('/sales/returns', auth(), asyncHandler(async (req, res) => {
  const { q } = req.query;
  const where = q
    ? { OR: [{ returnNo: { contains: q } }, { customer: { contains: q } }, { challanNo: { contains: q } }] }
    : undefined;
  const rows = await prisma.salesReturn.findMany({
    where, include: salesReturnInclude, orderBy: { id: 'desc' },
  });
  res.json({ success: true, data: rows });
}));

router.get('/sales/returns/:id', auth(), asyncHandler(async (req, res) => {
  const row = await prisma.salesReturn.findUnique({
    where: { id: Number(req.params.id) }, include: salesReturnInclude,
  });
  if (!row) return res.status(404).json({ success: false, message: 'Record not found' });
  res.json({ success: true, data: row });
}));

router.post('/sales/returns', auth(), asyncHandler(async (req, res) => {
  const { items = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  const itemData = items.map(toSalesReturnItem);
  // "Restock" — see the matching comment on the Sales Credit Memo route.
  await assertBatchSerialRestockAllocation(prisma, items, { quantityField: 'returnQuantity' });
  await assertBatchSerialRestockAvailability(prisma, items);
  const row = await prisma.$transaction(async (tx) => {
    const interState = await resolveTaxTreatment(tx, header.placeOfSupply);
    const totals = computeSalesReturnTotals(itemData, header.discountPercent, interState);
    const { documentNumber, syncManual } = await resolveDocumentNumber('SRT', header.returnNo, tx);
    await assertMasterExists(tx, 'customer', header.customer);
    // Goods can come back from the customer only until the challan has been
    // invoiced; after that a Sales Credit Memo is the instrument. See
    // routeMap.js for why.
    await assertReturnAllowed(tx, { kind: 'sales', docNo: header.challanNo });
    // Nor can it take back more than the challan actually despatched once
    // every OTHER sales return already raised against it is accounted for —
    // the server-side backstop behind the client's own "remaining after
    // other returns" cap (see documentFlow.js).
    await assertNoOverConsumption(tx, {
      sourceModel: tx.deliveryChallan,
      sourceDocField: 'challanNo',
      sourceDocNo: header.challanNo,
      sourceQuantityField: 'quantity',
      consumerModel: tx.salesReturn,
      consumerDocField: 'challanNo',
      consumerQuantityField: 'returnQuantity',
      consumerDocNoField: 'returnNo',
      items: itemData,
      label: 'return',
    });
    const created = await tx.salesReturn.create({
      data: { ...header, returnNo: documentNumber, ...totals, items: { create: itemData } },
      include: salesReturnInclude,
    });
    if (syncManual) await syncManual();
    await applyBatchSerialRestockEffects(tx, items, created.items, { linkField: 'salesReturnItemId' });
    // Journal the movement into [dbo].[Stock] — inward, once the return is
    // no longer Draft/Cancelled. See utils/stockTable.js.
    await postStockEntries(tx, {
      transType: TRANS_TYPES.SALES_RETURN,
      transNum: created.id,
      status: created.status,
      warehouse: created.warehouse,
      lines: salesReturnLines(itemData),
      userId: req.user?.id,
    });
    // Dr Inventory / Cr Cost of Goods Sold -- the goods side only. The
    // customer is credited by a Sales Credit Memo.
    await syncJournalEntry(tx, {
      sourceType: JOURNAL_SOURCE_TYPES.SALES_RETURN,
      sourceDocNo: created.returnNo,
      status: created.status,
      doc: { ...created, items: itemData },
    });
    return created;
  });
  res.status(201).json({ success: true, data: row });
}));

router.put('/sales/returns/:id', auth(), asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  const { items = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  const itemData = items.map(toSalesReturnItem);
  await assertBatchSerialRestockAllocation(prisma, items, { quantityField: 'returnQuantity' });
  await assertBatchSerialRestockAvailability(prisma, items, { excludeSalesReturnId: id });
  const row = await prisma.$transaction(async (tx) => {
    const interState = await resolveTaxTreatment(tx, header.placeOfSupply);
    const totals = computeSalesReturnTotals(itemData, header.discountPercent, interState);
    // Same rule on edit — but only when the challan reference actually
    // changes, so a legitimately raised return stays editable after invoicing.
    const existing = await tx.salesReturn.findUnique({
      where: { id }, select: { challanNo: true, items: true },
    });
    await assertNoOverConsumption(tx, {
      sourceModel: tx.deliveryChallan,
      sourceDocField: 'challanNo',
      sourceDocNo: header.challanNo,
      sourceQuantityField: 'quantity',
      consumerModel: tx.salesReturn,
      consumerDocField: 'challanNo',
      consumerQuantityField: 'returnQuantity',
      consumerDocNoField: 'returnNo',
      items: itemData,
      excludeConsumerDocNo: header.returnNo,
      previousItems: existing?.items || [],
      label: 'return',
    });
    await assertReturnAllowed(tx, {
      kind: 'sales', docNo: header.challanNo, unchangedFrom: existing?.challanNo,
    });
    // Undo this document's CURRENT restock effect before its items (and
    // their allocation rows) are replaced — see restoreBatchSerialRestockEffects.
    await restoreBatchSerialRestockEffects(tx, { salesReturnId: id });
    // Lines are replaced wholesale — the form always submits the document's
    // complete current state.
    await tx.salesReturnItem.deleteMany({ where: { returnId: id } });
    const updated = await tx.salesReturn.update({
      where: { id },
      data: { ...header, ...totals, items: { create: itemData } },
      include: salesReturnInclude,
    });
    await applyBatchSerialRestockEffects(tx, items, updated.items, { linkField: 'salesReturnItemId' });
    await postStockEntries(tx, {
      transType: TRANS_TYPES.SALES_RETURN,
      transNum: updated.id,
      status: updated.status,
      warehouse: updated.warehouse,
      lines: salesReturnLines(itemData),
      userId: req.user?.id,
    });
    // Rebuild the accounting document from what this return now says.
    await syncJournalEntry(tx, {
      sourceType: JOURNAL_SOURCE_TYPES.SALES_RETURN,
      sourceDocNo: updated.returnNo,
      status: updated.status,
      doc: { ...updated, items: itemData },
    });
    return updated;
  });
  res.json({ success: true, data: row });
}));

router.delete('/sales/returns/:id', auth(['admin']), asyncHandler(async (req, res) => {
  // Deleting the document deletes its accounting document too -- a
  // ledger entry for a document that no longer exists is worse than no
  // entry at all. See reverseJournalEntry in utils/glPosting.js.
  await removeJournalEntryForDocument(
    prisma, JOURNAL_SOURCE_TYPES.SALES_RETURN, 'salesReturn', 'returnNo', Number(req.params.id)
  );
  const id = Number(req.params.id);
  await prisma.$transaction(async (tx) => {
    await restoreBatchSerialRestockEffects(tx, { salesReturnId: id });
    await tx.salesReturn.delete({ where: { id } });
  });
  res.json({ success: true, message: 'Deleted successfully' });
}));


router.get('/purchase/invoices/register/report', auth(), asyncHandler(async (req, res) => {
  const { fromDate, toDate, supplier, status } = req.query;

  const where = {};
  if (supplier) where.supplier = supplier;
  if (status) where.paymentStatus = status;
  if (fromDate || toDate) {
    where.invoiceDate = {};
    if (fromDate) where.invoiceDate.gte = new Date(fromDate);
    if (toDate) where.invoiceDate.lte = new Date(toDate);
  }

  const invoices = await prisma.purchaseInvoice.findMany({ where, orderBy: { invoiceDate: 'desc' } });
  const invoiceNos = invoices.map((i) => i.invoiceNo).filter(Boolean);

  const [suppliers, outstandingRows] = await Promise.all([
    prisma.supplier.findMany({ select: { supplierCode: true, supplierName: true } }),
    invoiceNos.length
      ? prisma.supplierOutstanding.findMany({ where: { invoiceNo: { in: invoiceNos } } })
      : Promise.resolve([]),
  ]);
  const codeByName = Object.fromEntries(suppliers.map((s) => [s.supplierName, s.supplierCode]));
  const outstandingByInvoiceNo = Object.fromEntries(outstandingRows.map((o) => [o.invoiceNo, o]));

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const MS_PER_DAY = 24 * 60 * 60 * 1000;

  const rows = invoices.map((inv) => {
    const subTotal = Number(inv.subtotal || 0);
    const taxableAmount = Number(inv.taxableAmount || 0);
    const discountAmount = subTotal - taxableAmount;
    const taxAmount = Number(inv.cgstAmount || 0) + Number(inv.sgstAmount || 0);
    const netAmount = Number(inv.amount || 0);

    let daysPending = 0;
    if (inv.paymentStatus !== 'Paid' && inv.dueDate) {
      const due = new Date(inv.dueDate);
      due.setHours(0, 0, 0, 0);
      daysPending = Math.max(Math.round((today - due) / MS_PER_DAY), 0);
    }

    return {
      id: inv.id,
      invoiceNo: inv.invoiceNo,
      invoiceDate: inv.invoiceDate,
      supplierCode: codeByName[inv.supplier] || '—',
      supplier: inv.supplier,
      grnNo: inv.grnNo,
      poNo: inv.poNo,
      subTotal,
      discountAmount,
      taxAmount,
      netAmount,
      status: inv.paymentStatus,
      dueDate: inv.dueDate,
      daysPending,
    };
  });

  const totals = rows.reduce((acc, r) => ({
    subTotal: acc.subTotal + r.subTotal,
    discountAmount: acc.discountAmount + r.discountAmount,
    taxAmount: acc.taxAmount + r.taxAmount,
    netAmount: acc.netAmount + r.netAmount,
  }), { subTotal: 0, discountAmount: 0, taxAmount: 0, netAmount: 0 });

  // Paid/Unpaid/Partial breakdown — full invoice Net Amount per bucket,
  // grouped by the invoice's own paymentStatus (no partial-payment split
  // is stored anywhere for a "Partially Paid" invoice's paid vs remaining).
  const paymentBreakdown = rows.reduce((acc, r) => {
    if (r.status === 'Paid') acc.paidAmount += r.netAmount;
    else if (r.status === 'Partially Paid') acc.partialAmount += r.netAmount;
    else acc.unpaidAmount += r.netAmount;
    return acc;
  }, { paidAmount: 0, unpaidAmount: 0, partialAmount: 0 });

  // Aging buckets — real remaining balanceAmount from SupplierOutstanding
  // (joined by invoiceNo), same day-bucketing as /payables/outstanding/report.
  const aging = { d0to30: 0, d31to60: 0, d61to90: 0, above90: 0 };
  rows.forEach((r) => {
    const outstanding = outstandingByInvoiceNo[r.invoiceNo];
    const balance = outstanding
      ? (outstanding.balanceAmount != null ? Number(outstanding.balanceAmount) : Number(outstanding.invoiceAmount || 0) - Number(outstanding.paidAmount || 0))
      : (r.status === 'Paid' ? 0 : r.netAmount);
    if (r.status === 'Paid' || balance <= 0 || !r.dueDate) return;
    const due = new Date(r.dueDate);
    due.setHours(0, 0, 0, 0);
    const daysOverdue = Math.round((today - due) / MS_PER_DAY);
    if (daysOverdue <= 30) aging.d0to30 += balance;
    else if (daysOverdue <= 60) aging.d31to60 += balance;
    else if (daysOverdue <= 90) aging.d61to90 += balance;
    else aging.above90 += balance;
  });

  res.json({
    success: true,
    data: {
      rows,
      totals,
      stats: {
        totalInvoices: rows.length,
        totalInvoiceAmount: totals.subTotal,
        totalTaxAmount: totals.taxAmount,
        totalDiscountAmount: totals.discountAmount,
        totalNetAmount: totals.netAmount,
        avgInvoiceValue: rows.length > 0 ? totals.netAmount / rows.length : 0,
      },
      paymentBreakdown,
      aging,
    },
  });
}));

router.get('/purchase/invoices', auth(), asyncHandler(async (req, res) => {
  const { q } = req.query;
  const where = q
    ? {
        OR: [
          { invoiceNo: { contains: q } },
          { supplier: { contains: q } },
          { grnNo: { contains: q } },
          { poNo: { contains: q } },
        ],
      }
    : undefined;
  const rows = await prisma.purchaseInvoice.findMany({ where, include: purchaseInvoiceInclude, orderBy: { id: 'desc' } });
  res.json({ success: true, data: rows });
}));

router.get('/purchase/invoices/:id', auth(), asyncHandler(async (req, res) => {
  const row = await prisma.purchaseInvoice.findUnique({ where: { id: Number(req.params.id) }, include: purchaseInvoiceInclude });
  if (!row) return res.status(404).json({ success: false, message: 'Record not found' });
  res.json({ success: true, data: row });
}));

// Keeps SupplierOutstanding in sync with a Purchase Invoice's header fields
// whenever the invoice is saved or removed — mirrors syncCustomerOutstanding
// below (see its comment for the full rationale). Purchase Invoice's status
// options are Draft/Posted/Cancelled, so "active" here means status ===
// 'Posted'.
/**
 * Refuse to withdraw or restate an invoice that settlements have already been
 * applied to.
 *
 * The previous behaviour was to delete the outstanding row outright whenever
 * an invoice went back to Draft or was Cancelled. That destroyed the record of
 * every receipt/payment applied to it: the money stayed on the Collection or
 * Payment document, which still named an invoice number that no longer had a
 * ledger entry, and reversing those documents afterwards silently did nothing
 * because the row they look for was gone. The party's balance was then
 * permanently wrong with no audit trail explaining why.
 *
 * The correct sequence — the one SAP enforces — is to reverse the settlements
 * first, then withdraw the invoice. This makes that explicit rather than
 * quietly losing the data.
 */
function assertNoSettlementsApplied(openItem, { invoiceNo, action, reverseWhat }) {
  const paid = Number(openItem?.paidAmount || 0);
  if (paid > 0.005) {
    const err = new Error(
      `Invoice ${invoiceNo} cannot be ${action}: ${paid.toFixed(2)} has already been settled `
      + `against it. Reverse or unpost the ${reverseWhat} first.`
    );
    err.status = 409;
    throw err;
  }
}

async function syncSupplierOutstanding(tx, { invoiceNo, supplierName, invoiceDate, dueDate, invoiceAmount, status, paymentStatus }) {
  if (!invoiceNo) return;
  const existing = await tx.supplierOutstanding.findFirst({ where: { invoiceNo } });
  const isActive = status && status !== 'Draft' && status !== 'Cancelled';

  if (!isActive) {
    if (existing) {
      assertNoSettlementsApplied(existing, {
        invoiceNo,
        action: status === 'Cancelled' ? 'cancelled' : 'returned to Draft',
        reverseWhat: 'payments applied to it',
      });
      await tx.supplierOutstanding.delete({ where: { id: existing.id } });
    }
    return;
  }

  if (existing) {
    const paidAmount = Number(existing.paidAmount || 0);
    // An invoice cannot be edited down below what has already been settled
    // against it — the difference would be a credit with nowhere to sit.
    if (Number(invoiceAmount) + 0.005 < paidAmount) {
      const err = new Error(
        `Invoice ${invoiceNo} cannot be reduced to ${Number(invoiceAmount).toFixed(2)}: `
        + `${paidAmount.toFixed(2)} has already been settled against it.`
      );
      err.status = 409;
      throw err;
    }
    // balanceAmount is derived from paidAmount, never adjusted independently —
    // the same rule utils/openItemLedger.js follows, so the two can never
    // disagree about what an invoice still owes.
    const balanceAmount = round2(Number(invoiceAmount) - paidAmount);
    await tx.supplierOutstanding.update({
      where: { id: existing.id },
      data: {
        supplierName, invoiceDate, dueDate, invoiceAmount,
        balanceAmount,
        status: balanceAmount <= 0.005 ? 'Paid' : (paidAmount > 0.005 ? 'Partial' : 'Unpaid'),
      },
    });
  } else {
    await tx.supplierOutstanding.create({
      data: {
        supplierName, invoiceNo, invoiceDate, dueDate,
        invoiceAmount, paidAmount: 0, balanceAmount: invoiceAmount,
        status: paymentStatus || 'Unpaid',
      },
    });
  }
}

router.post('/purchase/invoices', auth(), asyncHandler(async (req, res) => {
  const { items = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  const itemData = items.map(toInvoiceItemData);
  // A purchase invoice with no GRN behind it is what receives the goods, so
  // it has to name the warehouse they land in.
  assertInvoiceWarehouse(header, header.grnNo, {
    documentLabel: 'Purchase Invoice', sourceLabel: 'GRN',
  });
  const row = await prisma.$transaction(async (tx) => {
    // Tax treatment is resolved inside the transaction because it depends
    // on the company's registered state: an inter-state supply is charged
    // wholly as IGST, an intra-state one split into CGST/SGST.
    const interState = await resolveTaxTreatment(tx, header.placeOfSupply);
    const totals = computeInvoiceTotals(itemData, header.discountPercent, interState);
    // invoiceNo now comes from the configured PI numbering series rather
    // than free text — see resolveDocumentNumber above.
    const { documentNumber, syncManual } = await resolveDocumentNumber('PI', header.invoiceNo, tx);
    const created = await tx.purchaseInvoice.create({
      data: { ...header, invoiceNo: documentNumber, ...totals, items: { create: itemData } },
      include: purchaseInvoiceInclude,
    });
    if (syncManual) await syncManual();
    await syncSupplierOutstanding(tx, {
      invoiceNo: created.invoiceNo, supplierName: created.supplier, invoiceDate: created.invoiceDate,
      dueDate: created.dueDate, invoiceAmount: totals.amount, status: created.status, paymentStatus: created.paymentStatus,
    });
    // Pulls this invoice's paymentStatus back into step with whatever
    // SupplierOutstanding now says is settled against it — see
    // syncPurchaseInvoicePaymentStatus above.
    await syncPurchaseInvoicePaymentStatus(tx, created.invoiceNo);
    // Recompute the order this document fulfils — see utils/documentFlow.js.
    await recomputePurchaseOrder(tx, created.poNo);
    // And the receipt it bills: a GRN is Open until every line it received
    // has been invoiced, then Closed.
    await recomputeGrnStatus(tx, created.grnNo);
    // Journal the movement into [dbo].[Stock] — inward — but ONLY when this
    // invoice is the document that received the goods. With a GRN behind it
    // the receipt already journalled them and this posts nothing, which is
    // what keeps stock from being counted twice. See utils/stockTable.js.
    if (isDirectInvoice(created.grnNo)) {
      await postStockEntries(tx, {
        transType: TRANS_TYPES.PURCHASE_INVOICE,
        transNum: created.id,
        status: created.status,
        warehouse: created.warehouse,
        lines: purchaseInvoiceLines(itemData),
        userId: req.user?.id,
      });
    }
    // The accounting document is NOT gated the way the stock posting above
    // is. An invoice with a GRN behind it moves no stock, but it still has
    // to clear Goods Clearing and raise the payable -- glPosting.js decides
    // which of the two schemas applies from the same grnNo.
    await syncJournalEntry(tx, {
      sourceType: JOURNAL_SOURCE_TYPES.PURCHASE_INVOICE,
      sourceDocNo: created.invoiceNo,
      status: created.status,
      doc: { ...created, items: itemData },
    });
    return created;
  });
  res.status(201).json({ success: true, data: row });
}));

router.put('/purchase/invoices/:id', auth(), asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  const { items = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  const itemData = items.map(toInvoiceItemData);
  assertInvoiceWarehouse(header, header.grnNo, {
    documentLabel: 'Purchase Invoice', sourceLabel: 'GRN',
  });
  // Replace the item set wholesale on every save — simpler and safer than
  // diffing which rows were added/removed/reordered client-side.
  const row = await prisma.$transaction(async (tx) => {
    // Tax treatment is resolved inside the transaction because it depends
    // on the company's registered state: an inter-state supply is charged
    // wholly as IGST, an intra-state one split into CGST/SGST.
    const interState = await resolveTaxTreatment(tx, header.placeOfSupply);
    const totals = computeInvoiceTotals(itemData, header.discountPercent, interState);
    const existingInvoice = await tx.purchaseInvoice.findUnique({
      where: { id }, select: { poNo: true, grnNo: true },
    });
    await tx.purchaseInvoiceItem.deleteMany({ where: { invoiceId: id } });
    const updated = await tx.purchaseInvoice.update({
      where: { id },
      data: { ...header, ...totals, items: { create: itemData } },
      include: purchaseInvoiceInclude,
    });
    await syncSupplierOutstanding(tx, {
      invoiceNo: updated.invoiceNo, supplierName: updated.supplier, invoiceDate: updated.invoiceDate,
      dueDate: updated.dueDate, invoiceAmount: totals.amount, status: updated.status, paymentStatus: updated.paymentStatus,
    });
    // Pulls this invoice's paymentStatus back into step with whatever
    // SupplierOutstanding now says is settled against it — see
    // syncPurchaseInvoicePaymentStatus above.
    await syncPurchaseInvoicePaymentStatus(tx, updated.invoiceNo);
    // Recompute the order this document fulfils — see utils/documentFlow.js.
    await recomputePurchaseOrder(tx, updated.poNo);
    if (existingInvoice?.poNo && existingInvoice.poNo !== updated.poNo) {
      await recomputePurchaseOrder(tx, existingInvoice.poNo);
    }
    // Both ends of a repoint: the receipt now being billed may close, and the
    // one this invoice no longer bills reopens.
    await recomputeGrnStatus(tx, updated.grnNo);
    if (existingInvoice?.grnNo && existingInvoice.grnNo !== updated.grnNo) {
      await recomputeGrnStatus(tx, existingInvoice.grnNo);
    }
    // An invoice saved as Draft and later Posted journals on that later save;
    // one already journalled is left alone (postStockEntries is insert-only
    // and keyed on transType+transNum). Still gated on being the direct
    // path — an invoice that acquired a GRN reference must not journal.
    if (isDirectInvoice(updated.grnNo)) {
      await postStockEntries(tx, {
        transType: TRANS_TYPES.PURCHASE_INVOICE,
        transNum: updated.id,
        status: updated.status,
        warehouse: updated.warehouse,
        lines: purchaseInvoiceLines(itemData),
        userId: req.user?.id,
      });
    }
    // Ungated for the same reason as the create path above.
    await syncJournalEntry(tx, {
      sourceType: JOURNAL_SOURCE_TYPES.PURCHASE_INVOICE,
      sourceDocNo: updated.invoiceNo,
      status: updated.status,
      doc: { ...updated, items: itemData },
    });
    return updated;
  });
  res.json({ success: true, data: row });
}));

router.delete('/purchase/invoices/:id', auth(['admin']), asyncHandler(async (req, res) => {
  // Deleting the document deletes its accounting document too -- a
  // ledger entry for a document that no longer exists is worse than no
  // entry at all. See reverseJournalEntry in utils/glPosting.js.
  await removeJournalEntryForDocument(
    prisma, JOURNAL_SOURCE_TYPES.PURCHASE_INVOICE, 'purchaseInvoice', 'invoiceNo', Number(req.params.id)
  );
  const id = Number(req.params.id);
  // PurchaseInvoiceItem.invoice has onDelete: Cascade, so items go with it.
  // The matching SupplierOutstanding row (if any) isn't linked by a FK, so
  // it's cleaned up explicitly here.
  await prisma.$transaction(async (tx) => {
    const existing = await tx.purchaseInvoice.findUnique({ where: { id } });
    if (existing?.invoiceNo) {
      // Deleting an invoice that has been settled would strand the money on
      // the payment documents that paid it: they would still name an invoice
      // number with no ledger entry behind it, and the party's balance would
      // be permanently overstated with nothing recording why. Reverse the
      // settlements first.
      const openItem = await tx.supplierOutstanding.findFirst({ where: { invoiceNo: existing.invoiceNo } });
      assertNoSettlementsApplied(openItem, {
        invoiceNo: existing.invoiceNo,
        action: 'deleted',
        reverseWhat: 'payments applied to it',
      });
      const settling = await tx.paymentInvoiceApplication.findFirst({ where: { invoiceNo: existing.invoiceNo } });
      if (settling) {
        const err = new Error(
          `Invoice ${existing.invoiceNo} cannot be deleted: it is referenced by a payment. `
          + `Remove that payment first.`
        );
        err.status = 409;
        throw err;
      }
      await tx.supplierOutstanding.deleteMany({ where: { invoiceNo: existing.invoiceNo } });
    }
    await tx.purchaseInvoice.delete({ where: { id } });
    await recomputePurchaseOrder(tx, existing?.poNo);
    // Removing the bill reopens the receipt it had closed.
    await recomputeGrnStatus(tx, existing?.grnNo);
  });
  res.json({ success: true, message: 'Deleted successfully' });
}));

// Enquiry Register report — bespoke read-only filtered listing for the
// Reports > Sales > Enquiry Register page. Mounted BEFORE the crudRouter
// mount below (same reasoning as /receivables/outstanding/report) so the
// literal '/register/report' path isn't swallowed by crudRouter's '/:id'
// route. crudRouter's generic list only supports a single '?q=' free-text
// search, but this report needs multi-field filtering (date range, exact
// customer/salesperson/status/source match), so it's a hand-written route
// following the dashboard.js/CustomerOutstanding style: auth() +
// asyncHandler, prisma query with a built-up `where`, single JSON response.
router.get('/sales/enquiries/register/report', auth(), asyncHandler(async (req, res) => {
  const { fromDate, toDate, customerName, assignedTo, status, sourceOfEnquiry } = req.query;

  const where = {};
  if (customerName) where.customerName = customerName;
  if (assignedTo) where.assignedTo = assignedTo;
  if (status) where.status = status;
  if (sourceOfEnquiry) where.sourceOfEnquiry = sourceOfEnquiry;
  if (fromDate || toDate) {
    where.enquiryDate = {};
    if (fromDate) where.enquiryDate.gte = new Date(fromDate);
    if (toDate) where.enquiryDate.lte = new Date(toDate);
  }

  const rows = await prisma.enquiry.findMany({ where, orderBy: { enquiryDate: 'desc' } });

  res.json({ success: true, data: { rows } });
}));

const ENQUIRY_ANALYSIS_MONTH_LABELS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

// Groups `rows` by `keyFn(row)` (skipping rows where it returns falsy),
// returning [{ name, value, percent }] sorted by value desc — the recharts-
// ready shape used by TopSellingProductsCard.jsx's donut+legend pattern.
function bucketWithPercent(rows, keyFn) {
  const counts = {};
  rows.forEach((r) => {
    const key = keyFn(r);
    if (!key) return;
    counts[key] = (counts[key] || 0) + 1;
  });
  const total = rows.length || 1;
  return Object.entries(counts)
    .map(([name, value]) => ({ name, value, percent: Math.round((value / total) * 1000) / 10 }))
    .sort((a, b) => b.value - a.value);
}

// Enquiry Analysis report — bespoke aggregation endpoint for the Reports >
// Sales > Enquiry Analysis dashboard page. Same reasoning/placement as the
// Enquiry Register report above: mounted before the crudRouter mount so
// '/analysis/report' isn't swallowed by crudRouter's '/:id' route. Follows
// dashboard.js's style (auth() + asyncHandler, prisma query + JS reshaping
// into chart-ready { name, value } / { name, value, percent } series, single
// JSON response) rather than crudRouter, since this is a computed aggregate.
router.get('/sales/enquiries/analysis/report', auth(), asyncHandler(async (req, res) => {
  const { fromDate, toDate, customerName, assignedTo, sourceOfEnquiry } = req.query;

  const where = {};
  if (customerName) where.customerName = customerName;
  if (assignedTo) where.assignedTo = assignedTo;
  if (sourceOfEnquiry) where.sourceOfEnquiry = sourceOfEnquiry;
  if (fromDate || toDate) {
    where.enquiryDate = {};
    if (fromDate) where.enquiryDate.gte = new Date(fromDate);
    if (toDate) where.enquiryDate.lte = new Date(toDate);
  }

  const rows = await prisma.enquiry.findMany({ where, orderBy: { enquiryDate: 'asc' } });

  // Status counts — same status vocabulary as the master Enquiry page, not a
  // separate report-only vocabulary, so this stays consistent with the rest
  // of the app. That vocabulary is now a plain Open/Closed: an enquiry is
  // Open until a Sales Quotation quotes it (see recomputeEnquiryStatus in
  // utils/documentFlow.js), and the older
  // New/In Progress/Follow-up/Quotation Sent/Converted/Closed-Lost buckets
  // no longer exist to be counted.
  const countStatus = (s) => rows.filter((r) => r.status === s).length;
  const stats = {
    total: rows.length,
    open: countStatus('Open'),
    closed: countStatus('Closed'),
  };

  const statusBreakdown = bucketWithPercent(rows, (r) => r.status);
  const sourceBreakdown = bucketWithPercent(rows, (r) => r.sourceOfEnquiry);

  // Daily trend — one point per calendar day that has an enquiry, oldest to
  // newest (rows are already ordered by enquiryDate asc).
  const dailyBuckets = {};
  rows.forEach((r) => {
    if (!r.enquiryDate) return;
    const d = new Date(r.enquiryDate);
    const key = `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
    if (!dailyBuckets[key]) {
      dailyBuckets[key] = { sortKey: d.getTime(), name: `${String(d.getDate()).padStart(2, '0')} ${ENQUIRY_ANALYSIS_MONTH_LABELS[d.getMonth()]}`, value: 0 };
    }
    dailyBuckets[key].value += 1;
  });
  const dailyTrend = Object.values(dailyBuckets)
    .sort((a, b) => a.sortKey - b.sortKey)
    .map(({ name, value }) => ({ name, value }));

  // Top customers by enquiry count.
  const customerCounts = {};
  rows.forEach((r) => {
    if (!r.customerName) return;
    customerCounts[r.customerName] = (customerCounts[r.customerName] || 0) + 1;
  });
  const topCustomers = Object.entries(customerCounts)
    .map(([customerName, count]) => ({ customerName, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 10);

  // Enquiries by salesperson (assignedTo is a plain string, no SalesEmployee
  // FK on Enquiry — see tempmem.md).
  const bySalesPerson = bucketWithPercent(rows, (r) => r.assignedTo).map(({ name, value }) => ({ name, value }));

  // "Converted" now means exactly one thing: a quotation was raised against
  // the enquiry, which is what Closed records. The old funnel distinguished
  // Quotation Sent from Converted from Closed-Lost; with a two-value status
  // there is no won/lost distinction left to report, so the rate is simply
  // the share of enquiries that reached a quotation.
  const conversion = {
    totalEnquiries: stats.total,
    open: stats.open,
    closed: stats.closed,
    conversionRate: stats.total > 0 ? Math.round((stats.closed / stats.total) * 1000) / 10 : 0,
  };

  res.json({
    success: true,
    data: {
      stats,
      statusBreakdown,
      sourceBreakdown,
      dailyTrend,
      topCustomers,
      bySalesPerson,
      conversion,
      rows,
    },
  });
}));

// Enquiry / Follow-up — flat resources, plain crudRouter for list/get/
// update/delete (FollowUp's enquiryId FK is just a foreign key on an
// otherwise flat record, not a master/detail child-collection like
// SalesQuotation/PurchaseOrder, so no bespoke route is needed for it at
// all). CREATE is the one exception: crudFactory's `transform` hook runs
// synchronously and can't await the numbering service, so enquiryNo needs
// its own bespoke POST route registered here, ahead of the crudRouter
// mount below — Express dispatches POST /sales/enquiries to this handler
// first and never reaches crudRouter's generic create for that method,
// while GET/PUT/DELETE still fall through to crudRouter unchanged.
router.post('/sales/enquiries', auth(), asyncHandler(async (req, res) => {
  const header = req.body;
  const row = await prisma.$transaction(async (tx) => {
    // enquiryNo now comes from the configured ENQ numbering series rather
    // than free text — see resolveDocumentNumber above.
    const { documentNumber, syncManual } = await resolveDocumentNumber('ENQ', header.enquiryNo, tx);
    const created = await tx.enquiry.create({ data: { ...header, enquiryNo: documentNumber } });
    if (syncManual) await syncManual();
    // Status is server-owned (Open until a Sales Quotation quotes it), so it
    // is recomputed rather than trusted from the request payload.
    await recomputeEnquiryStatus(tx, created.enquiryNo);
    return tx.enquiry.findUnique({ where: { id: created.id } });
  });
  res.status(201).json({ success: true, data: row });
}));
router.use('/sales/enquiries', crudRouter(prisma.enquiry, { searchFields: ['enquiryNo', 'customerName', 'mobileNo'] }));
router.use('/sales/follow-ups', crudRouter(prisma.followUp, { searchFields: ['followUpNo', 'followUpBy', 'followUpWith'] }));

// Sales Quotation — a master/detail resource (SalesQuotation has many
// SalesQuotationItem rows), same bespoke-route pattern as /purchase/invoices
// above. Each item can carry its own discountPercent (per the mockup's
// item-level Discount % column) in addition to the header-level
// discountPercent, and totals include a roundOff adjustment to a
// whole-currency grand total.
const salesQuotationInclude = { items: { orderBy: { id: 'asc' } } };

function toSalesQuotationItemData(item) {
  return mapLine(item);
}

function computeSalesQuotationTotals(items, discountPercent, interState) {
  return headerTotals(computeTotals(items, discountPercent, { interState, roundOff: true }));
}

router.get('/sales/quotations', auth(), asyncHandler(async (req, res) => {
  const { q } = req.query;
  const where = q
    ? {
        OR: [
          { quotationNo: { contains: q } },
          { customer: { contains: q } },
          { referenceNo: { contains: q } },
        ],
      }
    : undefined;
  const rows = await prisma.salesQuotation.findMany({ where, include: salesQuotationInclude, orderBy: { id: 'desc' } });
  res.json({ success: true, data: rows });
}));

router.get('/sales/quotations/:id', auth(), asyncHandler(async (req, res) => {
  const row = await prisma.salesQuotation.findUnique({ where: { id: Number(req.params.id) }, include: salesQuotationInclude });
  if (!row) return res.status(404).json({ success: false, message: 'Record not found' });
  res.json({ success: true, data: row });
}));

router.post('/sales/quotations', auth(), asyncHandler(async (req, res) => {
  const { items = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  const itemData = items.map(toSalesQuotationItemData);
  const row = await prisma.$transaction(async (tx) => {
    // Tax treatment is resolved inside the transaction because it depends
    // on the company's registered state: an inter-state supply is charged
    // wholly as IGST, an intra-state one split into CGST/SGST.
    const interState = await resolveTaxTreatment(tx, header.placeOfSupply);
    const totals = computeSalesQuotationTotals(itemData, header.discountPercent, interState);
    // quotationNo now comes from the configured SQ numbering series rather
    // than free text — see resolveDocumentNumber above.
    const { documentNumber, syncManual } = await resolveDocumentNumber('SQ', header.quotationNo, tx);
    const created = await tx.salesQuotation.create({
      data: { ...header, quotationNo: documentNumber, ...totals, items: { create: itemData } },
      include: salesQuotationInclude,
    });
    if (syncManual) await syncManual();
    // Quoting an enquiry answers it, so the enquiry closes. The quotation's
    // own status is recomputed rather than trusted from the request: status
    // is server-owned on this document now (Open until an order is raised
    // from it), and a stale value in the payload must not stick.
    await recomputeEnquiryStatus(tx, created.enquiryNo);
    await recomputeSalesQuotationStatus(tx, created.quotationNo);
    return tx.salesQuotation.findUnique({ where: { id: created.id }, include: salesQuotationInclude });
  });
  res.status(201).json({ success: true, data: row });
}));

router.put('/sales/quotations/:id', auth(), asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  const { items = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  const itemData = items.map(toSalesQuotationItemData);
  // Replace the item set wholesale on every save — simpler and safer than
  // diffing which rows were added/removed/reordered client-side.
  const row = await prisma.$transaction(async (tx) => {
    // Tax treatment is resolved inside the transaction because it depends
    // on the company's registered state: an inter-state supply is charged
    // wholly as IGST, an intra-state one split into CGST/SGST.
    const interState = await resolveTaxTreatment(tx, header.placeOfSupply);
    const totals = computeSalesQuotationTotals(itemData, header.discountPercent, interState);
    const previousQuotation = await tx.salesQuotation.findUnique({
      where: { id }, select: { enquiryNo: true },
    });
    await tx.salesQuotationItem.deleteMany({ where: { quotationId: id } });
    const updated = await tx.salesQuotation.update({
      where: { id },
      data: { ...header, ...totals, items: { create: itemData } },
      include: salesQuotationInclude,
    });
    // Both ends of a repoint: the enquiry now being quoted closes, the one
    // that was abandoned reopens.
    await recomputeEnquiryStatus(tx, updated.enquiryNo);
    if (previousQuotation?.enquiryNo && previousQuotation.enquiryNo !== updated.enquiryNo) {
      await recomputeEnquiryStatus(tx, previousQuotation.enquiryNo);
    }
    await recomputeSalesQuotationStatus(tx, updated.quotationNo);
    return tx.salesQuotation.findUnique({ where: { id }, include: salesQuotationInclude });
  });
  res.json({ success: true, data: row });
}));

router.delete('/sales/quotations/:id', auth(['admin']), asyncHandler(async (req, res) => {
  // SalesQuotationItem.quotation has onDelete: Cascade, so items go with it.
  // Removing the quotation reopens the enquiry it was answering.
  const id = Number(req.params.id);
  await prisma.$transaction(async (tx) => {
    const existing = await tx.salesQuotation.findUnique({ where: { id }, select: { enquiryNo: true } });
    await tx.salesQuotation.delete({ where: { id } });
    await recomputeEnquiryStatus(tx, existing?.enquiryNo);
  });
  res.json({ success: true, message: 'Deleted successfully' });
}));

// Sales Order — a master/detail resource (SalesOrder has many
// SalesOrderItem rows), same bespoke-route pattern as /sales/quotations
// above. Each item can carry its own discountPercent, and totals include a
// roundOff adjustment to a whole-currency grand total.
const salesOrderInclude = { items: { orderBy: { id: 'asc' } } };

function toSalesOrderItemData(item) {
  return mapLine(item);
}

function computeSalesOrderTotals(items, discountPercent, interState) {
  return headerTotals(computeTotals(items, discountPercent, { interState, roundOff: true }));
}

// Sales Order Register report — bespoke aggregation endpoint for the
// Reports > Sales > Sales Order Register page. Registered before the plain
// '/sales/orders' / '/sales/orders/:id' routes below (same reasoning as the
// Enquiry Register/Analysis reports) even though Express wouldn't actually
// route '/register/report' into ':id' here (different segment count) —
// kept first for consistency with the rest of this file. Delivery Status
// has no stored column on SalesOrder (see schema.prisma), so it's derived
// per order by comparing total ordered quantity against total delivered
// quantity from any DeliveryChallan rows matched by the plain orderNo
// string (no Prisma relation exists between the two models).
router.get('/sales/orders/register/report', auth(), asyncHandler(async (req, res) => {
  const { fromDate, toDate, customer, salesPerson, status, source } = req.query;

  const where = {};
  if (customer) where.customer = customer;
  if (salesPerson) where.salesPerson = salesPerson;
  if (status) where.status = status;
  if (source) where.source = source;
  if (fromDate || toDate) {
    where.orderDate = {};
    if (fromDate) where.orderDate.gte = new Date(fromDate);
    if (toDate) where.orderDate.lte = new Date(toDate);
  }

  const orders = await prisma.salesOrder.findMany({ where, include: salesOrderInclude, orderBy: { orderDate: 'desc' } });
  const orderNos = orders.map((o) => o.orderNo).filter(Boolean);

  const challans = orderNos.length
    ? await prisma.deliveryChallan.findMany({ where: { orderNo: { in: orderNos } }, include: { items: true } })
    : [];
  const deliveredQtyByOrderNo = {};
  challans.forEach((c) => {
    if (!c.orderNo) return;
    const qty = c.items.reduce((sum, i) => sum + Number(i.quantity || 0), 0);
    deliveredQtyByOrderNo[c.orderNo] = (deliveredQtyByOrderNo[c.orderNo] || 0) + qty;
  });

  const rows = orders.map((o) => {
    const orderedQty = o.items.reduce((sum, i) => sum + Number(i.quantity || 0), 0);
    const deliveredQty = deliveredQtyByOrderNo[o.orderNo] || 0;
    let deliveryStatus = null;
    if (o.status !== 'Cancelled') {
      if (deliveredQty <= 0) deliveryStatus = 'Pending';
      else if (deliveredQty >= orderedQty && orderedQty > 0) deliveryStatus = 'Delivered';
      else deliveryStatus = 'Partially Delivered';
    }
    return {
      id: o.id,
      orderNo: o.orderNo,
      orderDate: o.orderDate,
      customer: o.customer,
      salesPerson: o.salesPerson,
      source: o.source,
      amount: o.amount,
      deliveryDate: o.deliveryDate,
      status: o.status,
      deliveryStatus,
    };
  });

  const cancelledOrders = rows.filter((r) => r.status === 'Cancelled').length;
  const totalOrderAmount = rows.reduce((sum, r) => sum + Number(r.amount || 0), 0);
  const totalDeliveredAmount = rows.filter((r) => r.deliveryStatus === 'Delivered').reduce((sum, r) => sum + Number(r.amount || 0), 0);
  const totalPendingAmount = rows.filter((r) => r.deliveryStatus === 'Pending' || r.deliveryStatus === 'Partially Delivered').reduce((sum, r) => sum + Number(r.amount || 0), 0);

  res.json({
    success: true,
    data: {
      rows,
      stats: {
        totalOrders: rows.length,
        totalOrderAmount,
        totalDeliveredAmount,
        totalPendingAmount,
        cancelledOrders,
      },
    },
  });
}));

// Pending Sales Order report — bespoke aggregation endpoint for the
// Reports > Sales > Pending Sales Order page. Same orderNo-joined
// DeliveryChallan approach as the Sales Order Register report above, but
// keyed off delivered *amount* (not quantity) since that's what this page
// shows per row, and scoped to only orders that are still outstanding
// (not Cancelled, and not fully delivered). "Status" here is an aging
// bucket derived from Required Date vs today — Overdue / Due Within 7 Days
// / Due After 7 Days — a different axis than SalesOrder.status (Draft/
// Confirmed/...), which has no stored column of its own either.
router.get('/sales/orders/pending/report', auth(), asyncHandler(async (req, res) => {
  const { fromDate, toDate, customer, salesPerson, status, source } = req.query;

  const where = { status: { not: 'Cancelled' } };
  if (customer) where.customer = customer;
  if (salesPerson) where.salesPerson = salesPerson;
  if (source) where.source = source;
  if (fromDate || toDate) {
    where.orderDate = {};
    if (fromDate) where.orderDate.gte = new Date(fromDate);
    if (toDate) where.orderDate.lte = new Date(toDate);
  }

  const orders = await prisma.salesOrder.findMany({ where, orderBy: { orderDate: 'desc' } });
  const orderNos = orders.map((o) => o.orderNo).filter(Boolean);

  const challans = orderNos.length
    ? await prisma.deliveryChallan.findMany({ where: { orderNo: { in: orderNos } } })
    : [];
  const deliveredAmountByOrderNo = {};
  challans.forEach((c) => {
    if (!c.orderNo) return;
    deliveredAmountByOrderNo[c.orderNo] = (deliveredAmountByOrderNo[c.orderNo] || 0) + Number(c.amount || 0);
  });

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const MS_PER_DAY = 24 * 60 * 60 * 1000;

  const rows = orders
    .map((o) => {
      const orderAmount = Number(o.amount || 0);
      const deliveredAmount = Math.min(deliveredAmountByOrderNo[o.orderNo] || 0, orderAmount);
      const pendingAmount = Math.max(orderAmount - deliveredAmount, 0);

      const requiredDate = o.deliveryDate ? new Date(o.deliveryDate) : null;
      if (requiredDate) requiredDate.setHours(0, 0, 0, 0);
      let agingStatus;
      if (!requiredDate) agingStatus = 'Due After 7 Days';
      else if (requiredDate < today) agingStatus = 'Overdue';
      else if ((requiredDate - today) / MS_PER_DAY <= 7) agingStatus = 'Due Within 7 Days';
      else agingStatus = 'Due After 7 Days';

      const orderDate = o.orderDate ? new Date(o.orderDate) : null;
      const daysPending = orderDate ? Math.max(Math.round((today - orderDate) / MS_PER_DAY), 0) : 0;

      return {
        id: o.id,
        orderNo: o.orderNo,
        orderDate: o.orderDate,
        customer: o.customer,
        salesPerson: o.salesPerson,
        source: o.source,
        requiredDate: o.deliveryDate,
        orderAmount,
        deliveredAmount,
        pendingAmount,
        status: agingStatus,
        daysPending,
      };
    })
    // Only orders still outstanding belong on a "pending" report.
    .filter((r) => r.pendingAmount > 0)
    .filter((r) => !status || r.status === status);

  const totals = rows.reduce((acc, r) => ({
    totalOrderAmount: acc.totalOrderAmount + r.orderAmount,
    totalPendingAmount: acc.totalPendingAmount + r.pendingAmount,
  }), { totalOrderAmount: 0, totalPendingAmount: 0 });

  res.json({
    success: true,
    data: {
      rows,
      stats: {
        totalPendingOrders: rows.length,
        totalOrderAmount: totals.totalOrderAmount,
        totalPendingAmount: totals.totalPendingAmount,
        overdueOrders: rows.filter((r) => r.status === 'Overdue').length,
        dueWithin7Days: rows.filter((r) => r.status === 'Due Within 7 Days').length,
        dueAfter7Days: rows.filter((r) => r.status === 'Due After 7 Days').length,
      },
    },
  });
}));

router.get('/sales/orders', auth(), asyncHandler(async (req, res) => {
  const { q } = req.query;
  const where = q
    ? {
        OR: [
          { orderNo: { contains: q } },
          { customer: { contains: q } },
          { referenceNo: { contains: q } },
        ],
      }
    : undefined;
  const rows = await prisma.salesOrder.findMany({ where, include: salesOrderInclude, orderBy: { id: 'desc' } });
  res.json({ success: true, data: rows });
}));

router.get('/sales/orders/:id', auth(), asyncHandler(async (req, res) => {
  const row = await prisma.salesOrder.findUnique({ where: { id: Number(req.params.id) }, include: salesOrderInclude });
  if (!row) return res.status(404).json({ success: false, message: 'Record not found' });
  res.json({ success: true, data: row });
}));

router.post('/sales/orders', auth(), asyncHandler(async (req, res) => {
  const { items = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  const itemData = items.map(toSalesOrderItemData);
  const row = await prisma.$transaction(async (tx) => {
    // Tax treatment is resolved inside the transaction because it depends
    // on the company's registered state: an inter-state supply is charged
    // wholly as IGST, an intra-state one split into CGST/SGST.
    const interState = await resolveTaxTreatment(tx, header.placeOfSupply);
    const totals = computeSalesOrderTotals(itemData, header.discountPercent, interState);
    // A sales order is a commitment of credit — check the customer can take
    // it before numbering one. creditLimit was captured and displayed but
    // never enforced.assertWithinCreditLimit treats an unset limit as
    // "no limit", not "no credit".
    await assertMasterExists(tx, 'customer', header.customer);
    await assertWithinCreditLimit(tx, {
      customerName: header.customer, documentAmount: totals.amount, documentLabel: 'order',
    });
    // orderNo now comes from the configured SO numbering series rather than
    // free text — see resolveDocumentNumber above.
    const { documentNumber, syncManual } = await resolveDocumentNumber('SO', header.orderNo, tx);
    const created = await tx.salesOrder.create({
      data: { ...header, orderNo: documentNumber, ...totals, items: { create: itemData } },
      include: salesOrderInclude,
    });
    if (syncManual) await syncManual();
    // Ordering against a quotation closes it — see
    // recomputeSalesQuotationStatus in utils/documentFlow.js.
    await recomputeSalesQuotationStatus(tx, created.quotationNo);
    return created;
  });
  res.status(201).json({ success: true, data: row });
}));

router.put('/sales/orders/:id', auth(), asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  const { items = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  const itemData = items.map(toSalesOrderItemData);
  // Replace the item set wholesale on every save — simpler and safer than
  // diffing which rows were added/removed/reordered client-side.
  const row = await prisma.$transaction(async (tx) => {
    // Tax treatment is resolved inside the transaction because it depends
    // on the company's registered state: an inter-state supply is charged
    // wholly as IGST, an intra-state one split into CGST/SGST.
    const interState = await resolveTaxTreatment(tx, header.placeOfSupply);
    const totals = computeSalesOrderTotals(itemData, header.discountPercent, interState);
    const previousOrder = await tx.salesOrder.findUnique({
      where: { id }, select: { quotationNo: true },
    });
    await tx.salesOrderItem.deleteMany({ where: { orderId: id } });
    await assertMasterExists(tx, 'customer', header.customer);
    await assertWithinCreditLimit(tx, {
      customerName: header.customer, documentAmount: totals.amount, documentLabel: 'order',
    });
    const updated = await tx.salesOrder.update({
      where: { id },
      data: { ...header, ...totals, items: { create: itemData } },
      include: salesOrderInclude,
    });
    // Closing status follows the link, so both ends of a repoint have to be
    // recomputed: the quotation now being ordered against closes, and the one
    // that was abandoned reopens.
    await recomputeSalesQuotationStatus(tx, updated.quotationNo);
    if (previousOrder?.quotationNo && previousOrder.quotationNo !== updated.quotationNo) {
      await recomputeSalesQuotationStatus(tx, previousOrder.quotationNo);
    }
    return updated;
  });
  res.json({ success: true, data: row });
}));

router.delete('/sales/orders/:id', auth(['admin']), asyncHandler(async (req, res) => {
  // SalesOrderItem.order has onDelete: Cascade, so items go with it.
  // Removing the order reopens the quotation it was raised from.
  const id = Number(req.params.id);
  await prisma.$transaction(async (tx) => {
    const existing = await tx.salesOrder.findUnique({ where: { id }, select: { quotationNo: true } });
    await tx.salesOrder.delete({ where: { id } });
    await recomputeSalesQuotationStatus(tx, existing?.quotationNo);
  });
  res.json({ success: true, message: 'Deleted successfully' });
}));
// Delivery Challan — a master/detail resource (DeliveryChallan has many
// DeliveryChallanItem rows), same bespoke-route pattern as /sales/orders
// above. Unlike quotations/orders, items carry no per-item discount or tax
// rate — tax is a flat 9% CGST + 9% SGST on the subtotal (per the mockup),
// same as /purchase/grn, plus a roundOff adjustment to a whole-currency
// grand total.
const deliveryChallanInclude = { items: { orderBy: { id: 'asc' } } };

// Delivery Challan lines now carry their own tax and discount rates. As with
// the GRN, this document previously had no tax column and computeChallanTotals
// hard-coded CGST and SGST at 9% each — a challan for exempt or 5%-rated goods
// was still billed 18%, and the challan never agreed with the Sales Invoice
// raised from it.
function toChallanItemData(item) {
  return mapLine(item, { extras: (raw) => ({ batchNo: raw.batchNo || null }) });
}

function computeChallanTotals(items, discountPercent, interState) {
  return headerTotals(computeTotals(items, discountPercent, { interState, roundOff: true }));
}

router.get('/sales/delivery-challans', auth(), asyncHandler(async (req, res) => {
  const { q } = req.query;
  const where = q
    ? {
        OR: [
          { challanNo: { contains: q } },
          { orderNo: { contains: q } },
          { customer: { contains: q } },
        ],
      }
    : undefined;
  const rows = await prisma.deliveryChallan.findMany({ where, include: deliveryChallanInclude, orderBy: { id: 'desc' } });
  res.json({ success: true, data: rows });
}));

router.get('/sales/delivery-challans/:id', auth(), asyncHandler(async (req, res) => {
  const row = await prisma.deliveryChallan.findUnique({ where: { id: Number(req.params.id) }, include: deliveryChallanInclude });
  if (!row) return res.status(404).json({ success: false, message: 'Record not found' });
  res.json({ success: true, data: row });
}));

router.post('/sales/delivery-challans', auth(), asyncHandler(async (req, res) => {
  const { items = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  const itemData = items.map(toChallanItemData);
  // A Batch/Serial-tracked line must SELECT existing batches/serials to
  // cover its quantity — the "Batches Number - Selection" / "Serial Numbers
  // - Selection" dialog. See assertBatchSerialIssueAllocation /
  // assertBatchSerialAvailability in utils/businessRules.js. This is the
  // issue-side counterpart of GRN/Stock Receipt's assertBatchSerialAllocation
  // (which CREATES new numbers instead of selecting existing ones).
  await assertBatchSerialIssueAllocation(prisma, items, { quantityField: 'quantity' });
  await assertBatchSerialAvailability(prisma, items);
  const row = await prisma.$transaction(async (tx) => {
    // Tax treatment is resolved inside the transaction because it depends
    // on the company's registered state: an inter-state supply is charged
    // wholly as IGST, an intra-state one split into CGST/SGST.
    const interState = await resolveTaxTreatment(tx, header.placeOfSupply);
    const totals = computeChallanTotals(itemData, header.discountPercent, interState);
    await assertMasterExists(tx, 'customer', header.customer);
    // A despatch cannot exceed what the order calls for, nor take stock
    // below zero.
    await assertNoOverDelivery(tx, { orderNo: header.orderNo, items: itemData });
    await assertNoNegativeStock(tx, itemData);
    const costedItems = await stampCostPrices(tx, itemData);
    // challanNo now comes from the configured DC numbering series rather
    // than free text — see resolveDocumentNumber above.
    const { documentNumber, syncManual } = await resolveDocumentNumber('DC', header.challanNo, tx);
    const created = await tx.deliveryChallan.create({
      data: { ...header, challanNo: documentNumber, ...totals, items: { create: costedItems } },
      include: deliveryChallanInclude,
    });
    if (syncManual) await syncManual();
    // Decrement the selected batches/serials and record the allocation —
    // see applyBatchSerialIssueEffects. Zipped against `items` (the raw
    // request lines) by position; created.items is ordered by id ascending,
    // the same order the lines were created in.
    await applyBatchSerialIssueEffects(tx, items, created.items, { linkField: 'deliveryChallanItemId' });
    // Recompute the order this document fulfils, so its status and open
    // quantities reflect what has actually shipped or been billed. Nothing
    // propagated before, so orders stayed Open however much had gone out.
    await recomputeSalesOrder(tx, created.orderNo);
    // Journal the movement into [dbo].[Stock] — outward, once the challan is
    // no longer Pending/Cancelled. See utils/stockTable.js.
    await postStockEntries(tx, {
      transType: TRANS_TYPES.DELIVERY_CHALLAN,
      transNum: created.id,
      status: created.status,
      warehouse: created.fromWarehouse,
      lines: challanLines(costedItems),
      userId: req.user?.id,
    });
    // Dr Cost of Goods Sold / Cr Inventory, at the cost stamped on each line
    // above. No revenue here -- the customer has the goods but has not been
    // billed; the invoice books that side.
    await syncJournalEntry(tx, {
      sourceType: JOURNAL_SOURCE_TYPES.DELIVERY_CHALLAN,
      sourceDocNo: created.challanNo,
      status: created.status,
      doc: { ...created, items: costedItems },
    });
    // Settle this challan's own Open/Closed state last, once its lines exist
    // and the stock entry has been journalled against the status the form
    // actually submitted. A brand-new challan has nothing invoiced against it
    // so this normally lands on 'Open' — but a re-created challan number that
    // an invoice already references would correctly land on 'Closed'.
    await recomputeDeliveryChallanStatus(tx, created.challanNo);
    return tx.deliveryChallan.findUnique({ where: { id: created.id }, include: deliveryChallanInclude });
  });
  res.status(201).json({ success: true, data: row });
}));

router.put('/sales/delivery-challans/:id', auth(), asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  const { items = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  const itemData = items.map(toChallanItemData);
  // Same Batch/Serial "Selection" rules as create — see
  // assertBatchSerialIssueAllocation / assertBatchSerialAvailability above.
  // excludeChallanId adds this document's own existing selections back to
  // the available pool before comparing (see the function's own comment),
  // so re-saving it with its own numbers unchanged isn't flagged as
  // unavailable.
  await assertBatchSerialIssueAllocation(prisma, items, { quantityField: 'quantity' });
  await assertBatchSerialAvailability(prisma, items, { excludeChallanId: id });
  // Replace the item set wholesale on every save — simpler and safer than
  // diffing which rows were added/removed/reordered client-side.
  const row = await prisma.$transaction(async (tx) => {
    // Tax treatment is resolved inside the transaction because it depends
    // on the company's registered state: an inter-state supply is charged
    // wholly as IGST, an intra-state one split into CGST/SGST.
    const interState = await resolveTaxTreatment(tx, header.placeOfSupply);
    const totals = computeChallanTotals(itemData, header.discountPercent, interState);
    const previousChallan = await tx.deliveryChallan.findUnique({
      where: { id }, select: { challanNo: true, orderNo: true },
    });
    // Undo the stock effect of this document's CURRENT batch/serial
    // selections before its items (and their allocation rows) are replaced
    // — see restoreBatchSerialIssueEffects. Must run before the deleteMany
    // below, since the allocation rows cascade away with their item.
    await restoreBatchSerialIssueEffects(tx, { challanId: id });
    await tx.deliveryChallanItem.deleteMany({ where: { challanId: id } });
    await assertMasterExists(tx, 'customer', header.customer);
    await assertNoOverDelivery(tx, {
      orderNo: header.orderNo, items: itemData, excludeChallanNo: previousChallan?.challanNo,
    });
    await assertNoNegativeStock(tx, itemData);
    const costedItems = await stampCostPrices(tx, itemData);
    const updated = await tx.deliveryChallan.update({
      where: { id },
      data: { ...header, ...totals, items: { create: costedItems } },
      include: deliveryChallanInclude,
    });
    // Apply the new selection's stock effect — see
    // applyBatchSerialIssueEffects.
    await applyBatchSerialIssueEffects(tx, items, updated.items, { linkField: 'deliveryChallanItemId' });
    // Recompute the order this document fulfils, so its status and open
    // quantities reflect what has actually shipped or been billed. Nothing
    // propagated before, so orders stayed Open however much had gone out.
    await recomputeSalesOrder(tx, updated.orderNo);
    if (previousChallan?.orderNo && previousChallan.orderNo !== updated.orderNo) {
      // Repointed at a different order — the old one has to reopen.
      await recomputeSalesOrder(tx, previousChallan.orderNo);
    }
    // A challan saved as Pending and later Dispatched/Delivered journals on
    // that later save; one already journalled is left alone. See
    // utils/stockTable.js.
    await postStockEntries(tx, {
      transType: TRANS_TYPES.DELIVERY_CHALLAN,
      transNum: updated.id,
      status: updated.status,
      warehouse: updated.fromWarehouse,
      lines: challanLines(costedItems),
      userId: req.user?.id,
    });
    // Rebuild the accounting document from what this challan now says.
    await syncJournalEntry(tx, {
      sourceType: JOURNAL_SOURCE_TYPES.DELIVERY_CHALLAN,
      sourceDocNo: updated.challanNo,
      status: updated.status,
      doc: { ...updated, items: costedItems },
    });
    // Re-settle Open/Closed against what is actually invoiced — editing a
    // challan's lines changes what "fully invoiced" means for it, and a
    // challan promoted out of its Pending staging state by this very save
    // has to be evaluated for the first time here.
    await recomputeDeliveryChallanStatus(tx, updated.challanNo);
    return tx.deliveryChallan.findUnique({ where: { id }, include: deliveryChallanInclude });
  });
  res.json({ success: true, data: row });
}));

router.delete('/sales/delivery-challans/:id', auth(['admin']), asyncHandler(async (req, res) => {
  // Deleting the document deletes its accounting document too -- a
  // ledger entry for a document that no longer exists is worse than no
  // entry at all. See reverseJournalEntry in utils/glPosting.js.
  await removeJournalEntryForDocument(
    prisma, JOURNAL_SOURCE_TYPES.DELIVERY_CHALLAN, 'deliveryChallan', 'challanNo', Number(req.params.id)
  );
  // Removing a despatch reopens whatever it had closed on the order.
  const id = Number(req.params.id);
  await prisma.$transaction(async (tx) => {
    // Give back whatever batch quantity/serial status this challan's
    // selections had taken, before the items (and their allocation rows)
    // cascade away with the document.
    await restoreBatchSerialIssueEffects(tx, { challanId: id });
    const existing = await tx.deliveryChallan.findUnique({ where: { id }, select: { orderNo: true } });
    await tx.deliveryChallan.delete({ where: { id } });
    await recomputeSalesOrder(tx, existing?.orderNo);
  });
  // DeliveryChallanItem.challan has onDelete: Cascade, so items go with it.
  res.json({ success: true, message: 'Deleted successfully' });
}));
// Sales Invoice — a master/detail resource (SalesInvoice has many
// SalesInvoiceItem rows), same bespoke-route pattern as /sales/orders and
// /purchase/invoices above. Each item can carry its own discountPercent,
// and totals include a roundOff adjustment to a whole-currency grand total.
const salesInvoiceInclude = { items: { orderBy: { id: 'asc' } } };

function toSalesInvoiceItemData(item) {
  return mapLine(item);
}

function computeSalesInvoiceTotals(items, discountPercent, interState) {
  return headerTotals(computeTotals(items, discountPercent, { interState, roundOff: true }));
}

const SALES_TREND_MONTH_LABELS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

// Customer-wise Sales report — bespoke aggregation endpoint for the
// Reports > Sales > Customer-wise Sales page. Groups filtered SalesInvoice
// rows by customer (plain string, no Customer FK — same as everywhere else
// in this app), joining Customer master for customerCode display and
// CustomerOutstanding (by invoiceNo, within the filtered invoice set) for a
// Receivable Amount column, same convention as the Sales Invoice Register/
// /receivables/outstanding/report routes above.
router.get('/sales/invoices/customer-wise/report', auth(), asyncHandler(async (req, res) => {
  const { fromDate, toDate, customer, salesPerson, source } = req.query;

  // Draft and cancelled invoices are not revenue — see
  // UNREALISED_DOCUMENT_STATUSES.
  const where = { ...REALISED_ONLY };
  if (customer) where.customer = customer;
  if (salesPerson) where.salesPerson = salesPerson;
  if (source) where.source = source;
  if (fromDate || toDate) {
    where.invoiceDate = {};
    if (fromDate) where.invoiceDate.gte = new Date(fromDate);
    if (toDate) where.invoiceDate.lte = new Date(toDate);
  }

  const [invoices, customers] = await Promise.all([
    prisma.salesInvoice.findMany({ where, orderBy: { invoiceDate: 'asc' } }),
    prisma.customer.findMany({ select: { customerCode: true, customerName: true } }),
  ]);
  const codeByName = Object.fromEntries(customers.map((c) => [c.customerName, c.customerCode]));

  const invoiceNos = invoices.map((i) => i.invoiceNo).filter(Boolean);
  const outstandingRows = invoiceNos.length
    ? await prisma.customerOutstanding.findMany({ where: { invoiceNo: { in: invoiceNos } } })
    : [];
  const outstandingByInvoiceNo = Object.fromEntries(outstandingRows.map((o) => [o.invoiceNo, o]));

  const byCustomer = {};
  invoices.forEach((inv) => {
    const name = inv.customer || 'Unknown';
    if (!byCustomer[name]) {
      byCustomer[name] = {
        customerCode: codeByName[name] || '—',
        customerName: name,
        totalInvoices: 0,
        totalSalesAmount: 0,
        totalTaxAmount: 0,
        totalDiscount: 0,
        netSalesAmount: 0,
        receivableAmount: 0,
        lastInvoiceDate: null,
      };
    }
    const bucket = byCustomer[name];
    const subtotal = Number(inv.subtotal || 0);
    const taxableAmount = Number(inv.taxableAmount || 0);
    bucket.totalInvoices += 1;
    bucket.totalSalesAmount += subtotal;
    bucket.totalTaxAmount += Number(inv.cgstAmount || 0) + Number(inv.sgstAmount || 0);
    bucket.totalDiscount += subtotal - taxableAmount;
    bucket.netSalesAmount += Number(inv.amount || 0);
    const outstanding = outstandingByInvoiceNo[inv.invoiceNo];
    if (outstanding) bucket.receivableAmount += Number(outstanding.balanceAmount || 0);
    if (!bucket.lastInvoiceDate || (inv.invoiceDate && new Date(inv.invoiceDate) > new Date(bucket.lastInvoiceDate))) {
      bucket.lastInvoiceDate = inv.invoiceDate;
    }
  });

  const rows = Object.values(byCustomer).sort((a, b) => b.totalSalesAmount - a.totalSalesAmount);

  const totals = rows.reduce((acc, r) => ({
    totalInvoices: acc.totalInvoices + r.totalInvoices,
    totalSalesAmount: acc.totalSalesAmount + r.totalSalesAmount,
    totalTaxAmount: acc.totalTaxAmount + r.totalTaxAmount,
    totalDiscount: acc.totalDiscount + r.totalDiscount,
    netSalesAmount: acc.netSalesAmount + r.netSalesAmount,
    receivableAmount: acc.receivableAmount + r.receivableAmount,
  }), { totalInvoices: 0, totalSalesAmount: 0, totalTaxAmount: 0, totalDiscount: 0, netSalesAmount: 0, receivableAmount: 0 });

  // Top 5 customers by sales amount, in Lakhs — bar chart series.
  const topCustomers = rows.slice(0, 5).map((r) => ({ name: r.customerName, value: Math.round((r.totalSalesAmount / 100000) * 100) / 100 }));

  // Sales contribution donut: top 5 + an "Others" bucket, with percent —
  // same shape as dashboard.js's topSellingProducts.
  const grandTotal = totals.totalSalesAmount || 1;
  const top5 = rows.slice(0, 5);
  const othersValue = rows.slice(5).reduce((sum, r) => sum + r.totalSalesAmount, 0);
  const contribution = [
    ...top5.map((r) => ({ name: r.customerName, value: Math.round(r.totalSalesAmount), percent: Math.round((r.totalSalesAmount / grandTotal) * 1000) / 10 })),
    ...(othersValue > 0 ? [{ name: 'Others', value: Math.round(othersValue), percent: Math.round((othersValue / grandTotal) * 1000) / 10 }] : []),
  ];

  // Daily sales trend, in Lakhs — one point per calendar day that has an
  // invoice, oldest to newest (invoices already ordered by invoiceDate asc).
  const dailyBuckets = {};
  invoices.forEach((inv) => {
    if (!inv.invoiceDate) return;
    const d = new Date(inv.invoiceDate);
    const key = `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
    if (!dailyBuckets[key]) {
      dailyBuckets[key] = { sortKey: d.getTime(), name: `${String(d.getDate()).padStart(2, '0')} ${SALES_TREND_MONTH_LABELS[d.getMonth()]}`, value: 0 };
    }
    dailyBuckets[key].value += Number(inv.amount || 0);
  });
  const trend = Object.values(dailyBuckets)
    .sort((a, b) => a.sortKey - b.sortKey)
    .map(({ name, value }) => ({ name, value: Math.round((value / 100000) * 100) / 100 }));

  res.json({
    success: true,
    data: {
      rows,
      totals,
      stats: {
        totalCustomers: rows.length,
        totalSalesAmount: totals.totalSalesAmount,
        totalTaxAmount: totals.totalTaxAmount,
        totalDiscountAmount: totals.totalDiscount,
        netSalesAmount: totals.netSalesAmount,
      },
      topCustomers,
      contribution,
      trend,
    },
  });
}));

// Product-wise Sales report — bespoke aggregation endpoint for the
// Reports > Sales > Product-wise Sales page. Groups SalesInvoiceItem rows
// (across filtered SalesInvoice headers) by productCode, joining Product
// master for category (productGroup) and a UOM fallback since not every
// historical item row necessarily carries its own uom. Per-item
// "Total Sales Amount" is the pre-discount line value (quantity * unitPrice)
// so Discount Amount and Net Sales Amount can be shown as separate columns,
// same convention as toSalesInvoiceItemData's gross/amount split above.
router.get('/sales/invoices/product-wise/report', auth(), asyncHandler(async (req, res) => {
  const { fromDate, toDate, product, category, salesPerson, source } = req.query;

  // Draft and cancelled invoices are not revenue — see
  // UNREALISED_DOCUMENT_STATUSES.
  const where = { ...REALISED_ONLY };
  if (salesPerson) where.salesPerson = salesPerson;
  if (source) where.source = source;
  if (fromDate || toDate) {
    where.invoiceDate = {};
    if (fromDate) where.invoiceDate.gte = new Date(fromDate);
    if (toDate) where.invoiceDate.lte = new Date(toDate);
  }

  const [invoices, products] = await Promise.all([
    prisma.salesInvoice.findMany({ where, orderBy: { invoiceDate: 'asc' }, include: { items: { orderBy: { id: 'asc' } } } }),
    prisma.product.findMany({ select: { productCode: true, productGroup: true, uom: true } }),
  ]);
  const productMeta = Object.fromEntries(
    products.map((p) => [p.productCode, { category: p.productGroup || 'Uncategorized', uom: p.uom || null }]),
  );

  const byProduct = {};
  const invoiceNosOverall = new Set();
  const dailyBuckets = {};

  invoices.forEach((inv) => {
    inv.items.forEach((item) => {
      const code = item.productCode || 'UNKNOWN';
      const meta = productMeta[code] || {};
      const cat = meta.category || 'Uncategorized';
      if (product && code !== product) return;
      if (category && cat !== category) return;

      if (!byProduct[code]) {
        byProduct[code] = {
          productCode: code,
          productName: item.productName || code,
          category: cat,
          uom: item.uom || meta.uom || '—',
          salesQuantity: 0,
          totalSalesAmount: 0,
          discountAmount: 0,
          netSalesAmount: 0,
          invoiceNos: new Set(),
        };
      }
      const bucket = byProduct[code];
      const quantity = Number(item.quantity || 0);
      const unitPrice = Number(item.unitPrice || 0);
      const gross = quantity * unitPrice;
      const discountPercent = Number(item.discountPercent || 0);
      const discountAmount = gross * (discountPercent / 100);
      const net = gross - discountAmount;

      bucket.salesQuantity += quantity;
      bucket.totalSalesAmount += gross;
      bucket.discountAmount += discountAmount;
      bucket.netSalesAmount += net;
      bucket.invoiceNos.add(inv.invoiceNo);
      invoiceNosOverall.add(inv.invoiceNo);

      if (inv.invoiceDate) {
        const d = new Date(inv.invoiceDate);
        const key = `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
        if (!dailyBuckets[key]) {
          dailyBuckets[key] = { sortKey: d.getTime(), name: `${String(d.getDate()).padStart(2, '0')} ${SALES_TREND_MONTH_LABELS[d.getMonth()]}`, value: 0 };
        }
        dailyBuckets[key].value += net;
      }
    });
  });

  const rows = Object.values(byProduct).map((b) => ({
    productCode: b.productCode,
    productName: b.productName,
    category: b.category,
    salesQuantity: b.salesQuantity,
    uom: b.uom,
    totalInvoices: b.invoiceNos.size,
    totalSalesAmount: b.totalSalesAmount,
    discountAmount: b.discountAmount,
    netSalesAmount: b.netSalesAmount,
    avgSellingPrice: b.salesQuantity > 0 ? b.netSalesAmount / b.salesQuantity : 0,
  })).sort((a, b) => b.totalSalesAmount - a.totalSalesAmount);

  const totals = rows.reduce((acc, r) => ({
    totalInvoices: acc.totalInvoices + r.totalInvoices,
    salesQuantity: acc.salesQuantity + r.salesQuantity,
    totalSalesAmount: acc.totalSalesAmount + r.totalSalesAmount,
    discountAmount: acc.discountAmount + r.discountAmount,
    netSalesAmount: acc.netSalesAmount + r.netSalesAmount,
  }), { totalInvoices: 0, salesQuantity: 0, totalSalesAmount: 0, discountAmount: 0, netSalesAmount: 0 });

  // Top 5 products by sales amount, in Lakhs — bar chart series.
  const topProducts = rows.slice(0, 5).map((r) => ({ name: r.productName, value: Math.round((r.totalSalesAmount / 100000) * 100) / 100 }));

  // Sales Amount by Category donut — grouped across every matching row
  // (not just the top 5), same shape as the customer-wise contribution
  // series but bucketed by category instead of an "Others" cutoff.
  const grandTotal = totals.totalSalesAmount || 1;
  const categoryTotals = {};
  rows.forEach((r) => {
    if (!categoryTotals[r.category]) categoryTotals[r.category] = 0;
    categoryTotals[r.category] += r.totalSalesAmount;
  });
  const categoryContribution = Object.entries(categoryTotals)
    .map(([name, value]) => ({ name, value: Math.round(value), percent: Math.round((value / grandTotal) * 1000) / 10 }))
    .sort((a, b) => b.value - a.value);

  const trend = Object.values(dailyBuckets)
    .sort((a, b) => a.sortKey - b.sortKey)
    .map(({ name, value }) => ({ name, value: Math.round((value / 100000) * 100) / 100 }));

  res.json({
    success: true,
    data: {
      rows,
      totals,
      stats: {
        totalProducts: rows.length,
        totalInvoices: invoiceNosOverall.size,
        totalSalesQuantity: totals.salesQuantity,
        totalSalesAmount: totals.totalSalesAmount,
        totalDiscountAmount: totals.discountAmount,
        netSalesAmount: totals.netSalesAmount,
      },
      topProducts,
      categoryContribution,
      trend,
    },
  });
}));

// Salesman-wise Sales report — bespoke aggregation endpoint for the
// Reports > Sales > Salesman-wise Sales page. Groups filtered SalesInvoice
// header rows by salesPerson (plain string, no FK — same convention as
// customer), joining SalesEmployee master for an employeeCode display
// column. documentType is accepted for filter-bar parity with the UI but
// currently a no-op — every row this report aggregates already comes from
// SalesInvoice, the only sales document type with a stats-ready shape.
router.get('/sales/invoices/salesman-wise/report', auth(), asyncHandler(async (req, res) => {
  const { fromDate, toDate, salesPerson, customer, source } = req.query;

  // Draft and cancelled invoices are not revenue — see
  // UNREALISED_DOCUMENT_STATUSES.
  const where = { ...REALISED_ONLY };
  if (salesPerson) where.salesPerson = salesPerson;
  if (customer) where.customer = customer;
  if (source) where.source = source;
  if (fromDate || toDate) {
    where.invoiceDate = {};
    if (fromDate) where.invoiceDate.gte = new Date(fromDate);
    if (toDate) where.invoiceDate.lte = new Date(toDate);
  }

  const [invoices, salesEmployees] = await Promise.all([
    prisma.salesInvoice.findMany({ where, orderBy: { invoiceDate: 'asc' } }),
    prisma.salesEmployee.findMany({ select: { employeeCode: true, employeeName: true } }),
  ]);
  const codeByName = Object.fromEntries(salesEmployees.map((e) => [e.employeeName, e.employeeCode]));

  const bySalesperson = {};
  const dailyBuckets = {};

  invoices.forEach((inv) => {
    const name = inv.salesPerson || 'Unassigned';
    if (!bySalesperson[name]) {
      bySalesperson[name] = {
        salespersonCode: codeByName[name] || '—',
        salespersonName: name,
        totalInvoices: 0,
        salesQuantity: 0,
        totalSalesAmount: 0,
        totalDiscount: 0,
        totalTaxAmount: 0,
        netSalesAmount: 0,
      };
    }
    const bucket = bySalesperson[name];
    const subtotal = Number(inv.subtotal || 0);
    const taxableAmount = Number(inv.taxableAmount || 0);
    bucket.totalInvoices += 1;
    bucket.totalSalesAmount += subtotal;
    bucket.totalDiscount += subtotal - taxableAmount;
    bucket.totalTaxAmount += Number(inv.cgstAmount || 0) + Number(inv.sgstAmount || 0);
    bucket.netSalesAmount += Number(inv.amount || 0);

    if (inv.invoiceDate) {
      const d = new Date(inv.invoiceDate);
      const key = `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
      if (!dailyBuckets[key]) {
        dailyBuckets[key] = { sortKey: d.getTime(), name: `${String(d.getDate()).padStart(2, '0')} ${SALES_TREND_MONTH_LABELS[d.getMonth()]}`, value: 0 };
      }
      dailyBuckets[key].value += Number(inv.amount || 0);
    }
  });

  // Sales quantity per salesperson comes from item lines — a second pass
  // via a fresh query, since SalesInvoiceItem has no salesPerson column of
  // its own and has to be joined back through its parent invoice.
  const invoiceIds = invoices.map((i) => i.id);
  const items = invoiceIds.length
    ? await prisma.salesInvoiceItem.findMany({ where: { invoiceId: { in: invoiceIds } }, select: { invoiceId: true, quantity: true } })
    : [];
  const salesPersonByInvoiceId = Object.fromEntries(invoices.map((i) => [i.id, i.salesPerson || 'Unassigned']));
  items.forEach((item) => {
    const name = salesPersonByInvoiceId[item.invoiceId];
    if (name && bySalesperson[name]) bySalesperson[name].salesQuantity += Number(item.quantity || 0);
  });

  const rows = Object.values(bySalesperson)
    .map((r) => ({ ...r, avgInvoiceValue: r.totalInvoices > 0 ? r.netSalesAmount / r.totalInvoices : 0 }))
    .sort((a, b) => b.totalSalesAmount - a.totalSalesAmount);

  const totals = rows.reduce((acc, r) => ({
    totalInvoices: acc.totalInvoices + r.totalInvoices,
    salesQuantity: acc.salesQuantity + r.salesQuantity,
    totalSalesAmount: acc.totalSalesAmount + r.totalSalesAmount,
    totalDiscount: acc.totalDiscount + r.totalDiscount,
    totalTaxAmount: acc.totalTaxAmount + r.totalTaxAmount,
    netSalesAmount: acc.netSalesAmount + r.netSalesAmount,
  }), { totalInvoices: 0, salesQuantity: 0, totalSalesAmount: 0, totalDiscount: 0, totalTaxAmount: 0, netSalesAmount: 0 });

  // Top 5 salespersons by sales amount, in Lakhs — bar chart series.
  const topSalespersons = rows.slice(0, 5).map((r) => ({ name: r.salespersonName, value: Math.round((r.totalSalesAmount / 100000) * 100) / 100 }));

  // Sales contribution donut: top 5 + an "Others" bucket, with percent —
  // same shape as the customer-wise/product-wise contribution series.
  const grandTotal = totals.totalSalesAmount || 1;
  const top5 = rows.slice(0, 5);
  const othersValue = rows.slice(5).reduce((sum, r) => sum + r.totalSalesAmount, 0);
  const contribution = [
    ...top5.map((r) => ({ name: r.salespersonName, value: Math.round(r.totalSalesAmount), percent: Math.round((r.totalSalesAmount / grandTotal) * 1000) / 10 })),
    ...(othersValue > 0 ? [{ name: 'Others', value: Math.round(othersValue), percent: Math.round((othersValue / grandTotal) * 1000) / 10 }] : []),
  ];

  const trend = Object.values(dailyBuckets)
    .sort((a, b) => a.sortKey - b.sortKey)
    .map(({ name, value }) => ({ name, value: Math.round((value / 100000) * 100) / 100 }));

  res.json({
    success: true,
    data: {
      rows,
      totals,
      stats: {
        totalSalespersons: rows.length,
        totalInvoices: totals.totalInvoices,
        totalSalesAmount: totals.totalSalesAmount,
        totalDiscountAmount: totals.totalDiscount,
        totalTaxAmount: totals.totalTaxAmount,
        netSalesAmount: totals.netSalesAmount,
      },
      topSalespersons,
      contribution,
      trend,
    },
  });
}));

// Profitability Analysis report — bespoke aggregation endpoint for the
// Reports > Sales > Profitability Analysis page. SalesInvoiceItem has no
// cost column of its own, so Cost Amount is derived per line as
// quantity * Product.costPrice (joined by productCode, same plain-string
// convention as everywhere else in this file — no FK on the item model).
// Sales Amount per line is the post-item-discount, pre-tax value (same
// gross/amount split as toSalesInvoiceItemData), matching what the other
// sales-by-* reports call "Net Sales Amount". `basis` picks which grouping
// (customer or product) backs the paginated Profitability Details table;
// the two Top-5 panels are always computed regardless of basis.
router.get('/sales/invoices/profitability/report', auth(), asyncHandler(async (req, res) => {
  const { fromDate, toDate, basis, customer, product, salesPerson } = req.query;

  // Draft and cancelled invoices are not revenue — see
  // UNREALISED_DOCUMENT_STATUSES.
  const where = { ...REALISED_ONLY };
  if (customer) where.customer = customer;
  if (salesPerson) where.salesPerson = salesPerson;
  if (fromDate || toDate) {
    where.invoiceDate = {};
    if (fromDate) where.invoiceDate.gte = new Date(fromDate);
    if (toDate) where.invoiceDate.lte = new Date(toDate);
  }

  const [invoices, products, customers] = await Promise.all([
    prisma.salesInvoice.findMany({ where, orderBy: { invoiceDate: 'asc' }, include: { items: { orderBy: { id: 'asc' } } } }),
    prisma.product.findMany({ select: { productCode: true, costPrice: true } }),
    prisma.customer.findMany({ select: { customerCode: true, customerName: true } }),
  ]);
  // Cost comes from the figure stamped on the invoice line at the time it
  // was raised. The product master is consulted only for invoices written
  // before that column existed (costPrice 0), so historic margins stop
  // moving every time somebody edits a cost price.
  const costPriceByCode = Object.fromEntries(products.map((p) => [p.productCode, Number(p.costPrice || 0)]));
  const customerCodeByName = Object.fromEntries(customers.map((c) => [c.customerName, c.customerCode]));

  const byCustomer = {};
  const byProduct = {};
  const dailyBuckets = {};

  invoices.forEach((inv) => {
    const custName = inv.customer || 'Unknown';
    // The header discount has to come off too, or margin is overstated on
    // every invoice that carries one. This report previously applied only the
    // line-level discount, so an invoice discounted 10% at the header was
    // reported at 10% more revenue and 10% more gross profit than it earned.
    const headerDiscountFactor = 1 - (Number(inv.discountPercent || 0) / 100);

    inv.items.forEach((item) => {
      const code = item.productCode || 'UNKNOWN';
      if (product && code !== product) return;

      const quantity = Number(item.quantity || 0);
      const unitPrice = Number(item.unitPrice || 0);
      const discountPercent = Number(item.discountPercent || 0);
      const gross = quantity * unitPrice;
      const salesAmount = round2((gross - gross * (discountPercent / 100)) * headerDiscountFactor);
      const stampedCost = Number(item.costPrice) || 0;
      const unitCost = stampedCost > 0 ? stampedCost : (costPriceByCode[code] || 0);
      const costAmount = round2(quantity * unitCost);
      const grossProfit = round2(salesAmount - costAmount);

      if (!byCustomer[custName]) {
        byCustomer[custName] = { customerCode: customerCodeByName[custName] || '—', customerName: custName, salesAmount: 0, costAmount: 0 };
      }
      byCustomer[custName].salesAmount += salesAmount;
      byCustomer[custName].costAmount += costAmount;

      if (!byProduct[code]) {
        byProduct[code] = { productCode: code, productName: item.productName || code, salesAmount: 0, costAmount: 0 };
      }
      byProduct[code].salesAmount += salesAmount;
      byProduct[code].costAmount += costAmount;

      if (inv.invoiceDate) {
        const d = new Date(inv.invoiceDate);
        const key = `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
        if (!dailyBuckets[key]) {
          dailyBuckets[key] = { sortKey: d.getTime(), name: `${String(d.getDate()).padStart(2, '0')} ${SALES_TREND_MONTH_LABELS[d.getMonth()]}`, salesAmount: 0, grossProfit: 0 };
        }
        dailyBuckets[key].salesAmount += salesAmount;
        dailyBuckets[key].grossProfit += grossProfit;
      }
    });
  });

  const withProfit = (r) => {
    const grossProfit = r.salesAmount - r.costAmount;
    const gpPercent = r.salesAmount > 0 ? Math.round((grossProfit / r.salesAmount) * 1000) / 10 : 0;
    return { ...r, grossProfit, gpPercent };
  };

  const customerRows = Object.values(byCustomer).map(withProfit).sort((a, b) => b.salesAmount - a.salesAmount);
  const productRows = Object.values(byProduct).map(withProfit).sort((a, b) => b.salesAmount - a.salesAmount);

  const totals = { salesAmount: 0, costAmount: 0 };
  customerRows.forEach((r) => { totals.salesAmount += r.salesAmount; totals.costAmount += r.costAmount; });
  const grandGrossProfit = totals.salesAmount - totals.costAmount;
  const grandGpPercent = totals.salesAmount > 0 ? Math.round((grandGrossProfit / totals.salesAmount) * 1000) / 10 : 0;
  const grandTotal = totals.salesAmount || 1;

  const topCustomers = customerRows.slice(0, 5);
  const topProducts = productRows.slice(0, 5);
  const topCustomersTotal = topCustomers.reduce((acc, r) => ({
    salesAmount: acc.salesAmount + r.salesAmount, costAmount: acc.costAmount + r.costAmount, grossProfit: acc.grossProfit + r.grossProfit,
  }), { salesAmount: 0, costAmount: 0, grossProfit: 0 });
  const topProductsTotal = topProducts.reduce((acc, r) => ({
    salesAmount: acc.salesAmount + r.salesAmount, costAmount: acc.costAmount + r.costAmount, grossProfit: acc.grossProfit + r.grossProfit,
  }), { salesAmount: 0, costAmount: 0, grossProfit: 0 });

  // Details table rows — keyed by the requested basis, each with a % of
  // total sales share (based on the grand total across every row, not
  // just the current page).
  const detailsSource = basis === 'product' ? productRows : customerRows;
  const rows = detailsSource.map((r) => ({ ...r, percentOfTotalSales: Math.round((r.salesAmount / grandTotal) * 1000) / 10 }));

  const trend = Object.values(dailyBuckets)
    .sort((a, b) => a.sortKey - b.sortKey)
    .map(({ name, salesAmount, grossProfit }) => ({
      name,
      salesAmount: Math.round((salesAmount / 100000) * 100) / 100,
      gpPercent: salesAmount > 0 ? Math.round((grossProfit / salesAmount) * 1000) / 10 : 0,
    }));

  res.json({
    success: true,
    data: {
      rows,
      totals: { salesAmount: totals.salesAmount, costAmount: totals.costAmount, grossProfit: grandGrossProfit },
      stats: {
        totalSalesAmount: totals.salesAmount,
        totalCostAmount: totals.costAmount,
        grossProfit: grandGrossProfit,
        grossProfitPercent: grandGpPercent,
      },
      topCustomers,
      topCustomersTotal,
      topProducts,
      topProductsTotal,
      trend,
    },
  });
}));

// Sales Invoice Register report — bespoke aggregation endpoint for the
// Reports > Sales > Sales Invoice Register page. Registered before the
// plain '/sales/invoices' route below, same reasoning/placement as the
// Sales Order Register report. SalesInvoice stores no flat "discount
// amount" or "tax amount" column (only discountPercent + the derived
// subtotal/taxableAmount/cgstAmount/sgstAmount/amount), so those are
// computed per row here. "Overdue Amount" is not something SalesInvoice
// tracks itself (no balance/paid columns on this model) — it's joined from
// CustomerOutstanding by invoiceNo, the same table/convention
// /receivables/outstanding/report already uses for aging.
router.get('/sales/invoices/register/report', auth(), asyncHandler(async (req, res) => {
  const { fromDate, toDate, customer, salesPerson, status, source } = req.query;

  const where = {};
  if (customer) where.customer = customer;
  if (salesPerson) where.salesPerson = salesPerson;
  if (status) where.status = status;
  if (source) where.source = source;
  if (fromDate || toDate) {
    where.invoiceDate = {};
    if (fromDate) where.invoiceDate.gte = new Date(fromDate);
    if (toDate) where.invoiceDate.lte = new Date(toDate);
  }

  const invoices = await prisma.salesInvoice.findMany({ where, orderBy: { invoiceDate: 'desc' } });
  const invoiceNos = invoices.map((i) => i.invoiceNo).filter(Boolean);

  const outstandingRows = invoiceNos.length
    ? await prisma.customerOutstanding.findMany({ where: { invoiceNo: { in: invoiceNos } } })
    : [];
  const outstandingByInvoiceNo = Object.fromEntries(outstandingRows.map((o) => [o.invoiceNo, o]));

  const now = new Date();
  now.setHours(0, 0, 0, 0);

  const rows = invoices.map((inv) => {
    const subtotal = Number(inv.subtotal || 0);
    const taxableAmount = Number(inv.taxableAmount || 0);
    const taxAmount = Number(inv.cgstAmount || 0) + Number(inv.sgstAmount || 0);
    const discountAmount = subtotal - taxableAmount;
    const netAmount = Number(inv.amount || 0);
    return {
      id: inv.id,
      invoiceNo: inv.invoiceNo,
      invoiceDate: inv.invoiceDate,
      customer: inv.customer,
      salesPerson: inv.salesPerson,
      source: inv.source,
      dueDate: inv.dueDate,
      invoiceAmount: subtotal,
      taxAmount,
      discountAmount,
      netAmount,
      status: inv.status,
      paymentStatus: inv.paymentStatus,
    };
  });

  const totalInvoiceAmount = rows.reduce((sum, r) => sum + r.invoiceAmount, 0);
  const totalTaxAmount = rows.reduce((sum, r) => sum + r.taxAmount, 0);
  const totalDiscountAmount = rows.reduce((sum, r) => sum + r.discountAmount, 0);
  const netInvoiceAmount = rows.reduce((sum, r) => sum + r.netAmount, 0);
  const overdueAmount = invoices.reduce((sum, inv) => {
    const outstanding = outstandingByInvoiceNo[inv.invoiceNo];
    if (!outstanding) return sum;
    const balance = Number(outstanding.balanceAmount || 0);
    const due = outstanding.dueDate ? new Date(outstanding.dueDate) : null;
    if (balance > 0 && due && due < now) return sum + balance;
    return sum;
  }, 0);

  res.json({
    success: true,
    data: {
      rows,
      stats: {
        totalInvoices: rows.length,
        totalInvoiceAmount,
        totalTaxAmount,
        totalDiscountAmount,
        netInvoiceAmount,
        overdueAmount,
      },
    },
  });
}));

router.get('/sales/invoices', auth(), asyncHandler(async (req, res) => {
  const { q } = req.query;
  const where = q
    ? {
        OR: [
          { invoiceNo: { contains: q } },
          { customer: { contains: q } },
          { orderNo: { contains: q } },
        ],
      }
    : undefined;
  const rows = await prisma.salesInvoice.findMany({ where, include: salesInvoiceInclude, orderBy: { id: 'desc' } });
  res.json({ success: true, data: rows });
}));

router.get('/sales/invoices/:id', auth(), asyncHandler(async (req, res) => {
  const row = await prisma.salesInvoice.findUnique({ where: { id: Number(req.params.id) }, include: salesInvoiceInclude });
  if (!row) return res.status(404).json({ success: false, message: 'Record not found' });
  res.json({ success: true, data: row });
}));

// Keeps CustomerOutstanding in sync with a Sales Invoice's header fields
// whenever the invoice is saved or removed, which is the missing link that
// otherwise leaves Customer Outstanding/Collection Entry permanently empty
// (nothing else in this file ever wrote to that table). Draft/Cancelled
// invoices have no outstanding row (any existing row is removed, e.g. if the
// invoice is cancelled after being Sent); any other status (Sent/Paid/
// Overdue) gets one created or refreshed. paidAmount is left untouched on
// updates since that's owned by Collection Entry's applyToCustomerOutstanding
// — only the invoice-level fields (customer, dates, amount) are re-synced,
// and balanceAmount/status are recomputed against whatever paidAmount
// already exists.
async function syncCustomerOutstanding(tx, { invoiceNo, customerName, invoiceDate, dueDate, invoiceAmount, status, paymentStatus }) {
  if (!invoiceNo) return;
  const existing = await tx.customerOutstanding.findFirst({ where: { invoiceNo } });
  const isActive = status && status !== 'Draft' && status !== 'Cancelled';

  if (!isActive) {
    if (existing) {
      assertNoSettlementsApplied(existing, {
        invoiceNo,
        action: status === 'Cancelled' ? 'cancelled' : 'returned to Draft',
        reverseWhat: 'collections applied to it',
      });
      await tx.customerOutstanding.delete({ where: { id: existing.id } });
    }
    return;
  }

  if (existing) {
    const paidAmount = Number(existing.paidAmount || 0);
    // An invoice cannot be edited down below what has already been settled
    // against it — the difference would be a credit with nowhere to sit.
    if (Number(invoiceAmount) + 0.005 < paidAmount) {
      const err = new Error(
        `Invoice ${invoiceNo} cannot be reduced to ${Number(invoiceAmount).toFixed(2)}: `
        + `${paidAmount.toFixed(2)} has already been settled against it.`
      );
      err.status = 409;
      throw err;
    }
    // balanceAmount is derived from paidAmount, never adjusted independently —
    // the same rule utils/openItemLedger.js follows, so the two can never
    // disagree about what an invoice still owes.
    const balanceAmount = round2(Number(invoiceAmount) - paidAmount);
    await tx.customerOutstanding.update({
      where: { id: existing.id },
      data: {
        customerName, invoiceDate, dueDate, invoiceAmount,
        balanceAmount,
        status: balanceAmount <= 0.005 ? 'Paid' : (paidAmount > 0.005 ? 'Partial' : 'Unpaid'),
      },
    });
  } else {
    await tx.customerOutstanding.create({
      data: {
        customerName, invoiceNo, invoiceDate, dueDate,
        invoiceAmount, paidAmount: 0, balanceAmount: invoiceAmount,
        status: paymentStatus || 'Unpaid',
      },
    });
  }
}

router.post('/sales/invoices', auth(), asyncHandler(async (req, res) => {
  const { items = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  const itemData = items.map(toSalesInvoiceItemData);
  // A sales invoice with no delivery challan behind it is what despatches the
  // goods, so it has to name the warehouse they leave from.
  assertInvoiceWarehouse(header, header.deliveryChallanNo, {
    documentLabel: 'Sales Invoice', sourceLabel: 'Delivery Challan',
  });
  const row = await prisma.$transaction(async (tx) => {
    // Tax treatment is resolved inside the transaction because it depends
    // on the company's registered state: an inter-state supply is charged
    // wholly as IGST, an intra-state one split into CGST/SGST.
    const interState = await resolveTaxTreatment(tx, header.placeOfSupply);
    const totals = computeSalesInvoiceTotals(itemData, header.discountPercent, interState);
    await assertMasterExists(tx, 'customer', header.customer);
    await assertWithinCreditLimit(tx, {
      customerName: header.customer, documentAmount: totals.amount, documentLabel: 'invoice',
    });
    // Only the direct path issues stock, so only the direct path can take it
    // negative. An invoice behind a challan moves nothing here — the challan
    // already passed this same check when it despatched.
    if (isDirectInvoice(header.deliveryChallanNo)) {
      await assertNoNegativeStock(tx, itemData);
    }
    const costedItems = await stampCostPrices(tx, itemData);
    // invoiceNo now comes from the configured SI numbering series rather
    // than free text — see resolveDocumentNumber above.
    const { documentNumber, syncManual } = await resolveDocumentNumber('SI', header.invoiceNo, tx);
    const created = await tx.salesInvoice.create({
      data: { ...header, invoiceNo: documentNumber, ...totals, items: { create: costedItems } },
      include: salesInvoiceInclude,
    });
    if (syncManual) await syncManual();
    await syncCustomerOutstanding(tx, {
      invoiceNo: created.invoiceNo, customerName: created.customer, invoiceDate: created.invoiceDate,
      dueDate: created.dueDate, invoiceAmount: totals.amount, status: created.status, paymentStatus: created.paymentStatus,
    });
    // Pulls this invoice's paymentStatus (and the fulfilled order's) back into
    // step with whatever CustomerOutstanding now says is settled against it —
    // see syncSalesInvoicePaymentStatus above.
    await syncSalesInvoicePaymentStatus(tx, created.invoiceNo);
    // Recompute the order this document fulfils — see utils/documentFlow.js.
    await recomputeSalesOrder(tx, created.orderNo);
    // And the challan it bills: a Delivery Challan is Open until every line
    // it despatched has been invoiced, then Closed.
    await recomputeDeliveryChallanStatus(tx, created.deliveryChallanNo);
    // Journal the movement into [dbo].[Stock] — outward — but ONLY when this
    // invoice is the document that despatched the goods. With a challan
    // behind it the challan already journalled them and this posts nothing,
    // which is what keeps stock from being reduced twice. `costedItems`, not
    // itemData: the outward movement consumes cost layers, so the lines have
    // to carry the cost prices stamped above.
    if (isDirectInvoice(created.deliveryChallanNo)) {
      await postStockEntries(tx, {
        transType: TRANS_TYPES.SALES_INVOICE,
        transNum: created.id,
        status: created.status,
        warehouse: created.warehouse,
        lines: salesInvoiceLines(costedItems),
        userId: req.user?.id,
      });
    }
    // Ungated: an invoice raised against a delivery challan moves no stock
    // (the challan did), but it is the document that books revenue, output
    // GST and the receivable. glPosting.js adds the COGS side only when
    // there was no challan.
    await syncJournalEntry(tx, {
      sourceType: JOURNAL_SOURCE_TYPES.SALES_INVOICE,
      sourceDocNo: created.invoiceNo,
      status: created.status,
      doc: { ...created, items: costedItems },
    });
    return created;
  });
  res.status(201).json({ success: true, data: row });
}));

router.put('/sales/invoices/:id', auth(), asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  const { items = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  const itemData = items.map(toSalesInvoiceItemData);
  assertInvoiceWarehouse(header, header.deliveryChallanNo, {
    documentLabel: 'Sales Invoice', sourceLabel: 'Delivery Challan',
  });
  // Replace the item set wholesale on every save — simpler and safer than
  // diffing which rows were added/removed/reordered client-side.
  const row = await prisma.$transaction(async (tx) => {
    // Tax treatment is resolved inside the transaction because it depends
    // on the company's registered state: an inter-state supply is charged
    // wholly as IGST, an intra-state one split into CGST/SGST.
    const interState = await resolveTaxTreatment(tx, header.placeOfSupply);
    const totals = computeSalesInvoiceTotals(itemData, header.discountPercent, interState);
    await tx.salesInvoiceItem.deleteMany({ where: { invoiceId: id } });
    await assertMasterExists(tx, 'customer', header.customer);
    const existingInvoice = await tx.salesInvoice.findUnique({
      where: { id }, select: { invoiceNo: true, orderNo: true, deliveryChallanNo: true },
    });
    await assertWithinCreditLimit(tx, {
      customerName: header.customer, documentAmount: totals.amount,
      excludeInvoiceNo: existingInvoice?.invoiceNo, documentLabel: 'invoice',
    });
    // Same rule as create: only the direct path issues stock, so only it can
    // take stock negative.
    if (isDirectInvoice(header.deliveryChallanNo)) {
      await assertNoNegativeStock(tx, itemData);
    }
    const costedItems = await stampCostPrices(tx, itemData);
    const updated = await tx.salesInvoice.update({
      where: { id },
      data: { ...header, ...totals, items: { create: costedItems } },
      include: salesInvoiceInclude,
    });
    await syncCustomerOutstanding(tx, {
      invoiceNo: updated.invoiceNo, customerName: updated.customer, invoiceDate: updated.invoiceDate,
      dueDate: updated.dueDate, invoiceAmount: totals.amount, status: updated.status, paymentStatus: updated.paymentStatus,
    });
    // Pulls this invoice's paymentStatus (and the fulfilled order's) back into
    // step with whatever CustomerOutstanding now says is settled against it —
    // see syncSalesInvoicePaymentStatus above.
    await syncSalesInvoicePaymentStatus(tx, updated.invoiceNo);
    // Recompute the order this document fulfils — see utils/documentFlow.js.
    await recomputeSalesOrder(tx, updated.orderNo);
    if (existingInvoice?.orderNo && existingInvoice.orderNo !== updated.orderNo) {
      await recomputeSalesOrder(tx, existingInvoice.orderNo);
      await recomputeSalesOrderPaymentStatus(tx, existingInvoice.orderNo);
    }
    // Both ends of a repoint: the challan now being billed may close, and the
    // one this invoice no longer bills reopens.
    await recomputeDeliveryChallanStatus(tx, updated.deliveryChallanNo);
    if (existingInvoice?.deliveryChallanNo && existingInvoice.deliveryChallanNo !== updated.deliveryChallanNo) {
      await recomputeDeliveryChallanStatus(tx, existingInvoice.deliveryChallanNo);
    }
    // An invoice saved as Draft and later Posted journals on that later save;
    // one already journalled is left alone (postStockEntries is insert-only
    // and keyed on transType+transNum). Still gated on the direct path — an
    // invoice that acquired a challan reference must not journal.
    if (isDirectInvoice(updated.deliveryChallanNo)) {
      await postStockEntries(tx, {
        transType: TRANS_TYPES.SALES_INVOICE,
        transNum: updated.id,
        status: updated.status,
        warehouse: updated.warehouse,
        lines: salesInvoiceLines(costedItems),
        userId: req.user?.id,
      });
    }
    // Ungated for the same reason as the create path above.
    await syncJournalEntry(tx, {
      sourceType: JOURNAL_SOURCE_TYPES.SALES_INVOICE,
      sourceDocNo: updated.invoiceNo,
      status: updated.status,
      doc: { ...updated, items: costedItems },
    });
    return updated;
  });
  res.json({ success: true, data: row });
}));

router.delete('/sales/invoices/:id', auth(['admin']), asyncHandler(async (req, res) => {
  // Deleting the document deletes its accounting document too -- a
  // ledger entry for a document that no longer exists is worse than no
  // entry at all. See reverseJournalEntry in utils/glPosting.js.
  await removeJournalEntryForDocument(
    prisma, JOURNAL_SOURCE_TYPES.SALES_INVOICE, 'salesInvoice', 'invoiceNo', Number(req.params.id)
  );
  const id = Number(req.params.id);
  // SalesInvoiceItem.invoice has onDelete: Cascade, so items go with it.
  // The matching CustomerOutstanding row (if any) isn't linked by a FK, so
  // it's cleaned up explicitly here.
  await prisma.$transaction(async (tx) => {
    const existing = await tx.salesInvoice.findUnique({ where: { id } });
    if (existing?.invoiceNo) {
      // Deleting an invoice that has been settled would strand the money on
      // the collection documents that paid it: they would still name an invoice
      // number with no ledger entry behind it, and the party's balance would
      // be permanently overstated with nothing recording why. Reverse the
      // settlements first.
      const openItem = await tx.customerOutstanding.findFirst({ where: { invoiceNo: existing.invoiceNo } });
      assertNoSettlementsApplied(openItem, {
        invoiceNo: existing.invoiceNo,
        action: 'deleted',
        reverseWhat: 'collections applied to it',
      });
      const settling = await tx.collectionInvoiceApplication.findFirst({ where: { invoiceNo: existing.invoiceNo } });
      if (settling) {
        const err = new Error(
          `Invoice ${existing.invoiceNo} cannot be deleted: it is referenced by a collection. `
          + `Remove that collection first.`
        );
        err.status = 409;
        throw err;
      }
      await tx.customerOutstanding.deleteMany({ where: { invoiceNo: existing.invoiceNo } });
    }
    await tx.salesInvoice.delete({ where: { id } });
    await recomputeSalesOrder(tx, existing?.orderNo);
    // Removing the bill reopens the challan it had closed.
    await recomputeDeliveryChallanStatus(tx, existing?.deliveryChallanNo);
  });
  res.json({ success: true, message: 'Deleted successfully' });
}));

// Inventory
// Stock Receipt — a master/detail resource (StockReceipt has many
// StockReceiptItem rows), same bespoke-route pattern as /sales/delivery-challans
// above. Items carry a batch no. and expiry date but no tax or discount —
// this is an internal stock movement document, not a tax invoice — so the
// total is simply the sum of item amounts (qty * rate).
const stockReceiptInclude = {
  items: {
    orderBy: { id: 'asc' },
    include: {
      batches: { orderBy: { id: 'asc' } },
      serials: { orderBy: { id: 'asc' } },
    },
  },
};

// `header` carries the receipt's warehouse — stamped onto every batch/serial
// row this line creates via buildBatchSerialCreates, same as the GRN side
// (see toGrnItemData above; buildBatchSerialCreates/toBatchCreateData/
// toSerialCreateData are shared between both document types).
function toStockReceiptItemData(item, header) {
  const quantity = Number(item.quantity) || 0;
  const unitPrice = Number(item.unitPrice) || 0;
  return {
    productCode: item.productCode || null,
    productName: item.productName || null,
    hsnCode: item.hsnCode || null,
    batchNo: item.batchNo || null,
    expiryDate: item.expiryDate || null,
    uom: item.uom || null,
    quantity,
    unitPrice,
    amount: round2(quantity * unitPrice),
    ...buildBatchSerialCreates(item, header),
  };
}

function computeStockReceiptTotals(items) {
  // Rounded to paise: the raw float sum is what made stock valuation
  // reports disagree with the documents they are built from.
  return { amount: round2(items.reduce((sum, i) => sum + round2(i.amount), 0)) };
}

router.get('/inventory/stock-receipts', auth(), asyncHandler(async (req, res) => {
  const { q } = req.query;
  const where = q
    ? {
        OR: [
          { receiptNo: { contains: q } },
          { referenceNo: { contains: q } },
        ],
      }
    : undefined;
  const rows = await prisma.stockReceipt.findMany({ where, include: stockReceiptInclude, orderBy: { id: 'desc' } });
  res.json({ success: true, data: rows });
}));

router.get('/inventory/stock-receipts/:id', auth(), asyncHandler(async (req, res) => {
  const row = await prisma.stockReceipt.findUnique({ where: { id: Number(req.params.id) }, include: stockReceiptInclude });
  if (!row) return res.status(404).json({ success: false, message: 'Record not found' });
  res.json({ success: true, data: row });
}));

router.post('/inventory/stock-receipts', auth(), asyncHandler(async (req, res) => {
  const { items = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  // Same Batch/Serial rules as Purchase GRN — see assertBatchSerialAllocation
  // and assertUniqueBatchesAndSerials in utils/businessRules.js.
  await assertBatchSerialAllocation(prisma, items, { quantityField: 'quantity' });
  await assertUniqueBatchesAndSerials(prisma, items);
  const itemData = items.map((item) => toStockReceiptItemData(item, header));
  const totals = computeStockReceiptTotals(itemData);
  const row = await prisma.$transaction(async (tx) => {
    // receiptNo now comes from the configured SRC numbering series rather
    // than free text — see resolveDocumentNumber above.
    const { documentNumber, syncManual } = await resolveDocumentNumber('SRC', header.receiptNo, tx);
    const created = await tx.stockReceipt.create({
      data: { ...header, receiptNo: documentNumber, ...totals, items: { create: itemData } },
      include: stockReceiptInclude,
    });
    if (syncManual) await syncManual();
    // Journal the movement into [dbo].[Stock] — inward, and only once the
    // receipt is Posted. See utils/stockTable.js.
    await postStockEntries(tx, {
      transType: TRANS_TYPES.STOCK_RECEIPT,
      transNum: created.id,
      status: created.status,
      warehouse: created.warehouse,
      lines: receiptLines(itemData),
      userId: req.user?.id,
    });
    // Dr Inventory / Cr Inventory Offset - Increase. Filed under the
    // 'Stock Return' transaction type: stock arriving with no purchase
    // behind it.
    await syncJournalEntry(tx, {
      sourceType: JOURNAL_SOURCE_TYPES.STOCK_RETURN,
      sourceDocNo: created.receiptNo,
      status: created.status,
      doc: { ...created, items: itemData },
    });
    return created;
  });
  res.status(201).json({ success: true, data: row });
}));

router.put('/inventory/stock-receipts/:id', auth(), asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  const { items = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  // Same Batch/Serial rules as Purchase GRN — see assertBatchSerialAllocation
  // and assertUniqueBatchesAndSerials in utils/businessRules.js.
  await assertBatchSerialAllocation(prisma, items, { quantityField: 'quantity' });
  await assertUniqueBatchesAndSerials(prisma, items, { excludeStockReceiptId: id });
  const itemData = items.map((item) => toStockReceiptItemData(item, header));
  const totals = computeStockReceiptTotals(itemData);
  // Replace the item set wholesale on every save — simpler and safer than
  // diffing which rows were added/removed/reordered client-side.
  const row = await prisma.$transaction(async (tx) => {
    await tx.stockReceiptItem.deleteMany({ where: { receiptId: id } });
    const updated = await tx.stockReceipt.update({
      where: { id },
      data: { ...header, ...totals, items: { create: itemData } },
      include: stockReceiptInclude,
    });
    // A receipt saved as Draft and later Posted journals on that later save;
    // one already journalled is left alone (postStockEntries is insert-only
    // and posts a given document exactly once). See utils/stockTable.js.
    await postStockEntries(tx, {
      transType: TRANS_TYPES.STOCK_RECEIPT,
      transNum: updated.id,
      status: updated.status,
      warehouse: updated.warehouse,
      lines: receiptLines(itemData),
      userId: req.user?.id,
    });
    // Rebuild the accounting document from what this receipt now says.
    await syncJournalEntry(tx, {
      sourceType: JOURNAL_SOURCE_TYPES.STOCK_RETURN,
      sourceDocNo: updated.receiptNo,
      status: updated.status,
      doc: { ...updated, items: itemData },
    });
    return updated;
  });
  res.json({ success: true, data: row });
}));

router.delete('/inventory/stock-receipts/:id', auth(['admin']), asyncHandler(async (req, res) => {
  // Deleting the document deletes its accounting document too -- a
  // ledger entry for a document that no longer exists is worse than no
  // entry at all. See reverseJournalEntry in utils/glPosting.js.
  await removeJournalEntryForDocument(
    prisma, JOURNAL_SOURCE_TYPES.STOCK_RETURN, 'stockReceipt', 'receiptNo', Number(req.params.id)
  );
  // StockReceiptItem.receipt has onDelete: Cascade, so items go with it.
  await prisma.stockReceipt.delete({ where: { id: Number(req.params.id) } });
  res.json({ success: true, message: 'Deleted successfully' });
}));
// Stock Issue — a master/detail resource (StockIssue has many
// StockIssueItem rows), same bespoke-route pattern as /inventory/stock-receipts
// above. Items carry a batch no. and expiry date; the unit rate isn't shown
// as an editable column in the mockup (it's valued at the product's cost
// price automatically), but is still stored per item so the total can be
// computed and the issue can be costed later.
const stockIssueInclude = { items: { orderBy: { id: 'asc' } } };

function toStockIssueItemData(item) {
  const quantity = Number(item.quantity) || 0;
  const unitPrice = Number(item.unitPrice) || 0;
  return {
    productCode: item.productCode || null,
    productName: item.productName || null,
    hsnCode: item.hsnCode || null,
    batchNo: item.batchNo || null,
    expiryDate: item.expiryDate || null,
    uom: item.uom || null,
    quantity,
    unitPrice,
    amount: round2(quantity * unitPrice),
  };
}

function computeStockIssueTotals(items) {
  // Rounded to paise: the raw float sum is what made stock valuation
  // reports disagree with the documents they are built from.
  return { amount: round2(items.reduce((sum, i) => sum + round2(i.amount), 0)) };
}

router.get('/inventory/stock-issues', auth(), asyncHandler(async (req, res) => {
  const { q } = req.query;
  const where = q
    ? {
        OR: [
          { issueNo: { contains: q } },
          { referenceNo: { contains: q } },
        ],
      }
    : undefined;
  const rows = await prisma.stockIssue.findMany({ where, include: stockIssueInclude, orderBy: { id: 'desc' } });
  res.json({ success: true, data: rows });
}));

router.get('/inventory/stock-issues/:id', auth(), asyncHandler(async (req, res) => {
  const row = await prisma.stockIssue.findUnique({ where: { id: Number(req.params.id) }, include: stockIssueInclude });
  if (!row) return res.status(404).json({ success: false, message: 'Record not found' });
  res.json({ success: true, data: row });
}));

router.post('/inventory/stock-issues', auth(), asyncHandler(async (req, res) => {
  const { items = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  const itemData = items.map(toStockIssueItemData);
  const totals = computeStockIssueTotals(itemData);
  // A Batch/Serial-tracked line must SELECT existing batches/serials to
  // cover its quantity — the "Batches Number - Selection" / "Serial Numbers
  // - Selection" dialog. See assertBatchSerialIssueAllocation /
  // assertBatchSerialAvailability in utils/businessRules.js.
  await assertBatchSerialIssueAllocation(prisma, items, { quantityField: 'quantity' });
  await assertBatchSerialAvailability(prisma, items);
  const row = await prisma.$transaction(async (tx) => {
    // issueNo now comes from the configured SIG numbering series rather
    // than free text — see resolveDocumentNumber above.
    // A despatch cannot take stock below zero — see assertNoNegativeStock.
    await assertNoNegativeStock(tx, itemData);
    const { documentNumber, syncManual } = await resolveDocumentNumber('SIG', header.issueNo, tx);
    const created = await tx.stockIssue.create({
      data: { ...header, issueNo: documentNumber, ...totals, items: { create: itemData } },
      include: stockIssueInclude,
    });
    if (syncManual) await syncManual();
    // Decrement the selected batches/serials and record the allocation —
    // see applyBatchSerialIssueEffects. Zipped against `items` (the raw
    // request lines) by position; created.items is ordered by id ascending,
    // the same order the lines were created in.
    await applyBatchSerialIssueEffects(tx, items, created.items, { linkField: 'stockIssueItemId' });
    // Journal the movement into [dbo].[Stock] — outward, and only once the
    // issue is Posted. See utils/stockTable.js.
    await postStockEntries(tx, {
      transType: TRANS_TYPES.STOCK_ISSUE,
      transNum: created.id,
      status: created.status,
      warehouse: created.toWarehouse,
      lines: issueLines(itemData),
      userId: req.user?.id,
    });
    // Dr Inventory Offset - Decrease / Cr Inventory. Deliberately NOT COGS:
    // consumption that earned no revenue would distort gross margin.
    await syncJournalEntry(tx, {
      sourceType: JOURNAL_SOURCE_TYPES.STOCK_ISSUE,
      sourceDocNo: created.issueNo,
      status: created.status,
      doc: { ...created, items: itemData },
    });
    return created;
  });
  res.status(201).json({ success: true, data: row });
}));

router.put('/inventory/stock-issues/:id', auth(), asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  const { items = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  const itemData = items.map(toStockIssueItemData);
  const totals = computeStockIssueTotals(itemData);
  // Same Batch/Serial "Selection" rules as create — excludeStockIssueId adds
  // this document's own existing selections back to the available pool
  // before comparing (see assertBatchSerialAvailability's own comment).
  await assertBatchSerialIssueAllocation(prisma, items, { quantityField: 'quantity' });
  await assertBatchSerialAvailability(prisma, items, { excludeStockIssueId: id });
  // Replace the item set wholesale on every save — simpler and safer than
  // diffing which rows were added/removed/reordered client-side.
  const row = await prisma.$transaction(async (tx) => {
    // Undo the stock effect of this document's CURRENT batch/serial
    // selections before its items (and their allocation rows) are replaced
    // — must run before the deleteMany below, since the allocation rows
    // cascade away with their item. See restoreBatchSerialIssueEffects.
    await restoreBatchSerialIssueEffects(tx, { stockIssueId: id });
    await tx.stockIssueItem.deleteMany({ where: { issueId: id } });
    // A despatch cannot take stock below zero — see assertNoNegativeStock.
    await assertNoNegativeStock(tx, itemData);
    const updated = await tx.stockIssue.update({
      where: { id },
      data: { ...header, ...totals, items: { create: itemData } },
      include: stockIssueInclude,
    });
    // Apply the new selection's stock effect — see
    // applyBatchSerialIssueEffects.
    await applyBatchSerialIssueEffects(tx, items, updated.items, { linkField: 'stockIssueItemId' });
    // Journals on the save that first makes this Posted; already-journalled
    // issues are untouched. See utils/stockTable.js.
    await postStockEntries(tx, {
      transType: TRANS_TYPES.STOCK_ISSUE,
      transNum: updated.id,
      status: updated.status,
      warehouse: updated.toWarehouse,
      lines: issueLines(itemData),
      userId: req.user?.id,
    });
    // Rebuild the accounting document from what this issue now says.
    await syncJournalEntry(tx, {
      sourceType: JOURNAL_SOURCE_TYPES.STOCK_ISSUE,
      sourceDocNo: updated.issueNo,
      status: updated.status,
      doc: { ...updated, items: itemData },
    });
    return updated;
  });
  res.json({ success: true, data: row });
}));

router.delete('/inventory/stock-issues/:id', auth(['admin']), asyncHandler(async (req, res) => {
  // Deleting the document deletes its accounting document too -- a
  // ledger entry for a document that no longer exists is worse than no
  // entry at all. See reverseJournalEntry in utils/glPosting.js.
  await removeJournalEntryForDocument(
    prisma, JOURNAL_SOURCE_TYPES.STOCK_ISSUE, 'stockIssue', 'issueNo', Number(req.params.id)
  );
  const id = Number(req.params.id);
  await prisma.$transaction(async (tx) => {
    // Give back whatever batch quantity/serial status this issue's
    // selections had taken, before the items (and their allocation rows)
    // cascade away with the document.
    await restoreBatchSerialIssueEffects(tx, { stockIssueId: id });
    await tx.stockIssue.delete({ where: { id } });
  });
  // StockIssueItem.issue has onDelete: Cascade, so items go with it.
  res.json({ success: true, message: 'Deleted successfully' });
}));
// Stock Adjustment — a master/detail resource (StockAdjustment has many
// StockAdjustmentItem rows), same bespoke-route pattern as /inventory/stock-issues
// above. Each line captures the product's Current Stock, an Increase/Decrease
// type, a Quantity and a Reason. The physical count and the signed difference
// (physical - system) are still derived and stored exactly as before
// (physical = current stock +/- quantity) so every existing stock
// valuation/report query built on differenceQuantity keeps working unchanged.
// The adjustment value is that signed difference costed at the product's
// unit price (a shortfall reduces value, a surplus increases it).
const stockAdjustmentInclude = { items: { orderBy: { id: 'asc' } } };

/**
 * @param {object} item     the raw request line
 * @param {Map}    onHand   server-computed stock by product code
 *
 * The system quantity is read from the ledger, not from `item.currentStock`
 * as the client sent it. An adjustment exists to reconcile a physical count
 * against *the system's* view; taking the system side from the same request
 * that carries the physical count meant the recorded difference was whatever
 * the client said it was. A stale form — or a forged request — wrote a
 * difference that moved stock by the wrong amount, and because the adjustment
 * is itself a stock movement, the error compounded on the next count.
 */
function toStockAdjustmentItemData(item, onHand = null) {
  const currentStock = onHand && onHand.has(item.productCode)
    ? Number(onHand.get(item.productCode)) || 0
    : Number(item.currentStock) || 0;
  const quantity = Number(item.quantity) || 0;
  const itemAdjustmentType = item.itemAdjustmentType === 'Decrease' ? 'Decrease' : 'Increase';
  const signedQuantity = itemAdjustmentType === 'Decrease' ? -quantity : quantity;
  const physicalQuantity = currentStock + signedQuantity;
  const unitPrice = Number(item.unitPrice) || 0;
  const differenceQuantity = physicalQuantity - currentStock;
  return {
    productCode: item.productCode || null,
    productName: item.productName || null,
    hsnCode: item.hsnCode || null,
    batchNo: item.batchNo || null,
    expiryDate: item.expiryDate || null,
    uom: item.uom || null,
    systemQuantity: currentStock,
    physicalQuantity,
    differenceQuantity,
    itemAdjustmentType,
    quantity,
    reason: item.reason || null,
    unitPrice,
    amount: round2(differenceQuantity * unitPrice),
  };
}

function computeStockAdjustmentTotals(items) {
  // Rounded to paise: the raw float sum is what made stock valuation
  // reports disagree with the documents they are built from.
  return { amount: round2(items.reduce((sum, i) => sum + round2(i.amount), 0)) };
}

router.get('/inventory/stock-adjustments', auth(), asyncHandler(async (req, res) => {
  const { q } = req.query;
  const where = q
    ? {
        OR: [
          { adjustmentNo: { contains: q } },
          { referenceNo: { contains: q } },
          { reason: { contains: q } },
        ],
      }
    : undefined;
  const rows = await prisma.stockAdjustment.findMany({ where, include: stockAdjustmentInclude, orderBy: { id: 'desc' } });
  res.json({ success: true, data: rows });
}));

router.get('/inventory/stock-adjustments/:id', auth(), asyncHandler(async (req, res) => {
  const row = await prisma.stockAdjustment.findUnique({ where: { id: Number(req.params.id) }, include: stockAdjustmentInclude });
  if (!row) return res.status(404).json({ success: false, message: 'Record not found' });
  res.json({ success: true, data: row });
}));

router.post('/inventory/stock-adjustments', auth(), asyncHandler(async (req, res) => {
  const { items = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  const row = await prisma.$transaction(async (tx) => {
    // System quantity comes from the ledger, never from the request — see
    // toStockAdjustmentItemData.
    const onHand = await getCurrentStockForMany(items.map((i) => i.productCode), { client: tx });
    const itemData = items.map((i) => toStockAdjustmentItemData(i, onHand));
    const totals = computeStockAdjustmentTotals(itemData);
    // adjustmentNo now comes from the configured ADJ numbering series
    // rather than free text — see resolveDocumentNumber above.
    const { documentNumber, syncManual } = await resolveDocumentNumber('ADJ', header.adjustmentNo, tx);
    const created = await tx.stockAdjustment.create({
      data: { ...header, adjustmentNo: documentNumber, ...totals, items: { create: itemData } },
      include: stockAdjustmentInclude,
    });
    if (syncManual) await syncManual();
    // Journal the movement into [dbo].[Stock] — per line, an Increase posts
    // inward and a Decrease outward, only once Posted. See utils/stockTable.js.
    await postStockEntries(tx, {
      transType: TRANS_TYPES.STOCK_ADJUSTMENT,
      transNum: created.id,
      status: created.status,
      warehouse: created.warehouse,
      lines: adjustmentLines(itemData),
      userId: req.user?.id,
    });
    return created;
  });
  res.status(201).json({ success: true, data: row });
}));

router.put('/inventory/stock-adjustments/:id', auth(), asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  const { items = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  // Replace the item set wholesale on every save — simpler and safer than
  // diffing which rows were added/removed/reordered client-side.
  const row = await prisma.$transaction(async (tx) => {
    await tx.stockAdjustmentItem.deleteMany({ where: { adjustmentId: id } });
    // System quantity comes from the ledger, never from the request — and is
    // read after this document's own previous lines are cleared, so an edit
    // measures against stock excluding its own prior effect.
    const onHand = await getCurrentStockForMany(items.map((i) => i.productCode), { client: tx });
    const itemData = items.map((i) => toStockAdjustmentItemData(i, onHand));
    const totals = computeStockAdjustmentTotals(itemData);
    const updated = await tx.stockAdjustment.update({
      where: { id },
      data: { ...header, ...totals, items: { create: itemData } },
      include: stockAdjustmentInclude,
    });
    // Journals on the save that first makes this Posted; already-journalled
    // adjustments are untouched. See utils/stockTable.js.
    await postStockEntries(tx, {
      transType: TRANS_TYPES.STOCK_ADJUSTMENT,
      transNum: updated.id,
      status: updated.status,
      warehouse: updated.warehouse,
      lines: adjustmentLines(itemData),
      userId: req.user?.id,
    });
    return updated;
  });
  res.json({ success: true, data: row });
}));

router.delete('/inventory/stock-adjustments/:id', auth(['admin']), asyncHandler(async (req, res) => {
  // StockAdjustmentItem.adjustment has onDelete: Cascade, so items go with it.
  await prisma.stockAdjustment.delete({ where: { id: Number(req.params.id) } });
  res.json({ success: true, message: 'Deleted successfully' });
}));

// Stock Transfer ("Material Transfer") — a master/detail resource
// (StockTransfer has many StockTransferItem rows), same bespoke-route
// pattern as /inventory/stock-issues above. Unlike Stock Receipt/Issue/
// Adjustment (each touches exactly one warehouse), a transfer moves stock
// between two — every line always moves within the header's own From/To
// Warehouse pair (see the StockTransfer model comment in schema.prisma), so
// each line's own fromWarehouse/toWarehouse is set here from the header
// rather than trusted from the client.
const stockTransferInclude = { items: { orderBy: { id: 'asc' }, include: { batchAllocations: { orderBy: { id: 'asc' } }, serialAllocations: { orderBy: { id: 'asc' } } } } };

/**
 * @param {object} item    the raw request line
 * @param {object} header  the sanitized document header (fromWarehouse/toWarehouse
 *                         act only as the fallback when a line doesn't name
 *                         its own — see the fromWarehouse/toWarehouse note
 *                         below)
 * @param {Map}    onHand  server-computed company-wide stock by product code
 *
 * totalStock is a read-only reference snapshot (same "never trust the
 * client's figure" rule as StockAdjustmentItem.systemQuantity) — it plays no
 * part in the transfer's own movement math, which is exactly `quantity` on
 * both legs.
 *
 * fromWarehouse/toWarehouse are read from the LINE first, falling back to the
 * header only when a line leaves them blank. Each item row is independently
 * editable in the UI — a single Stock Transfer can move different products
 * between different warehouse pairs — so the header's From/To Warehouse are a
 * default for new rows, not a value every line is forced to share.
 */
function toStockTransferItemData(item, header, onHand = null) {
  const totalStock = onHand && onHand.has(item.productCode)
    ? Number(onHand.get(item.productCode)) || 0
    : Number(item.totalStock) || 0;
  const quantity = Number(item.quantity) || 0;
  const unitPrice = Number(item.unitPrice) || 0;
  const itemCost = item.itemCost != null ? Number(item.itemCost) : unitPrice;
  return {
    productCode: item.productCode || null,
    productName: item.productName || null,
    fromWarehouse: item.fromWarehouse || header.fromWarehouse || null,
    toWarehouse: item.toWarehouse || header.toWarehouse || null,
    totalStock,
    uom: item.uom || null,
    quantity,
    unitPrice,
    itemCost,
    accountCode: item.accountCode || null,
    project: item.project || null,
    remarks: item.remarks || null,
    amount: round2(quantity * unitPrice),
  };
}

function computeStockTransferTotals(items) {
  // Rounded to paise: the raw float sum is what made stock valuation
  // reports disagree with the documents they are built from.
  return { amount: round2(items.reduce((sum, i) => sum + round2(i.amount), 0)) };
}

/**
 * Every line must name both legs of its own movement — without this, a line
 * that reached here with a blank fromWarehouse/toWarehouse (the frontend
 * requires both, but the API is the actual boundary) would post to the
 * journal with warehouse NULL, a movement nothing can be filtered or
 * reconciled against.
 */
function assertStockTransferItemsHaveWarehouses(itemData) {
  const offending = itemData
    .map((i, idx) => ({ idx, i }))
    .filter(({ i }) => !i.fromWarehouse || !i.toWarehouse);
  if (offending.length) {
    const err = new Error(
      `Every item needs a From Warehouse and To Warehouse — row ${offending[0].idx + 1} is missing one.`
    );
    err.status = 400;
    throw err;
  }
}

/**
 * A transfer's outbound leg can't take its own From Warehouse's stock below
 * zero — checked per (product, From Warehouse), not company-wide.
 *
 * assertNoNegativeStock (used elsewhere) only ever had a company-wide figure
 * to check against, which is why the comment on the POST route below used to
 * call this a known gap: a product sitting entirely in Warehouse A could be
 * "transferred" out of Warehouse B, which holds none of it, and the
 * company-wide total would still look fine while Warehouse B's own position
 * went negative. getCurrentStockByWarehouseForMany (utils/stockLedger.js)
 * exists precisely so this can be checked against the FROM warehouse's own
 * on-hand figure instead.
 */
async function assertNoNegativeWarehouseStock(tx, itemData) {
  const required = new Map(); // "productCode::warehouse" -> quantity
  for (const item of itemData) {
    const code = item.productCode;
    const warehouse = item.fromWarehouse;
    const qty = Number(item.quantity) || 0;
    if (!code || !warehouse || qty <= 0) continue;
    const key = `${code}::${warehouse}`;
    required.set(key, round2((required.get(key) || 0) + qty));
  }
  if (!required.size) return;

  const pairs = [...required.keys()].map((key) => {
    const sep = key.lastIndexOf('::');
    return { productCode: key.slice(0, sep), warehouse: key.slice(sep + 2) };
  });
  const onHand = await getCurrentStockByWarehouseForMany(pairs, { client: tx });

  const shortfalls = [];
  for (const [key, needed] of required) {
    const available = onHand.get(key) ?? 0;
    if (needed > available + 0.005) {
      const sep = key.lastIndexOf('::');
      shortfalls.push(
        `${key.slice(0, sep)} at ${key.slice(sep + 2)}: transferring ${needed} but only ${available} on hand in that warehouse`
      );
    }
  }
  if (shortfalls.length) {
    const err = new Error(`Insufficient stock in the From Warehouse — ${shortfalls.join('; ')}`);
    err.status = 409;
    throw err;
  }
}

router.get('/inventory/stock-transfers', auth(), asyncHandler(async (req, res) => {
  const { q } = req.query;
  const where = q
    ? {
        OR: [
          { transferNo: { contains: q } },
          { partyName: { contains: q } },
        ],
      }
    : undefined;
  const rows = await prisma.stockTransfer.findMany({ where, include: stockTransferInclude, orderBy: { id: 'desc' } });
  res.json({ success: true, data: rows });
}));

router.get('/inventory/stock-transfers/:id', auth(), asyncHandler(async (req, res) => {
  const row = await prisma.stockTransfer.findUnique({ where: { id: Number(req.params.id) }, include: stockTransferInclude });
  if (!row) return res.status(404).json({ success: false, message: 'Record not found' });
  res.json({ success: true, data: row });
}));

router.post('/inventory/stock-transfers', auth(), asyncHandler(async (req, res) => {
  const { items = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  // "Relocate" — a Batch/Serial-tracked line must select the existing
  // batch/serial being moved (whole-batch-only for a batch — see
  // assertWholeBatchRelocation), and it must currently sit in the line's own
  // From Warehouse. See the *Relocate* functions in utils/businessRules.js.
  await assertBatchSerialRelocateAllocation(prisma, items, { quantityField: 'quantity' });
  await assertWholeBatchRelocation(prisma, items);
  await assertRelocateWarehouseMatches(prisma, items);
  const row = await prisma.$transaction(async (tx) => {
    // System stock comes from the ledger, never from the request — see
    // toStockTransferItemData.
    const onHand = await getCurrentStockForMany(items.map((i) => i.productCode), { client: tx });
    const itemData = items.map((i) => toStockTransferItemData(i, header, onHand));
    assertStockTransferItemsHaveWarehouses(itemData);
    // Company-wide guard (catches a product the company doesn't hold enough
    // of at all) plus the warehouse-scoped one (catches a From Warehouse that
    // doesn't hold enough of it even though another warehouse does) — see
    // assertNoNegativeWarehouseStock's own doc comment.
    await assertNoNegativeStock(tx, itemData);
    await assertNoNegativeWarehouseStock(tx, itemData);
    const totals = computeStockTransferTotals(itemData);
    // transferNo now comes from the configured MT numbering series rather
    // than free text — see resolveDocumentNumber above.
    const { documentNumber, syncManual } = await resolveDocumentNumber('MT', header.transferNo, tx);
    const created = await tx.stockTransfer.create({
      data: { ...header, transferNo: documentNumber, ...totals, items: { create: itemData } },
      include: stockTransferInclude,
    });
    if (syncManual) await syncManual();
    // Move the selected batch/serial's own `warehouse` column to the line's
    // toWarehouse and record the allocation — see applyBatchSerialRelocateEffects.
    await applyBatchSerialRelocateEffects(tx, items, created.items, { linkField: 'stockTransferItemId' });
    // Journal the movement into [dbo].[Stock] TWICE — an outbound leg at
    // fromWarehouse and an inbound leg at toWarehouse, both keyed off this
    // same document id but under distinct TransType values, only once
    // Posted. See utils/stockTable.js's TRANS_TYPES.STOCK_TRANSFER_OUT/IN.
    await postStockEntries(tx, {
      transType: TRANS_TYPES.STOCK_TRANSFER_OUT,
      transNum: created.id,
      status: created.status,
      warehouse: created.fromWarehouse,
      lines: transferOutLines(itemData),
      userId: req.user?.id,
    });
    await postStockEntries(tx, {
      transType: TRANS_TYPES.STOCK_TRANSFER_IN,
      transNum: created.id,
      status: created.status,
      warehouse: created.toWarehouse,
      lines: transferInLines(itemData),
      userId: req.user?.id,
    });
    // Dr Inventory (destination) / Cr Inventory (source). Posts only when the
    // two warehouses determine to different inventory accounts -- within one
    // account it nets to nothing and is skipped.
    await syncJournalEntry(tx, {
      sourceType: JOURNAL_SOURCE_TYPES.STOCK_TRANSFER,
      sourceDocNo: created.transferNo,
      status: created.status,
      doc: { ...created, items: itemData },
    });
    return created;
  });
  res.status(201).json({ success: true, data: row });
}));

router.put('/inventory/stock-transfers/:id', auth(), asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  const { items = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  await assertBatchSerialRelocateAllocation(prisma, items, { quantityField: 'quantity' });
  await assertWholeBatchRelocation(prisma, items);
  // Replace the item set wholesale on every save — simpler and safer than
  // diffing which rows were added/removed/reordered client-side.
  const row = await prisma.$transaction(async (tx) => {
    // Undo this document's CURRENT relocate effect (puts each moved batch/
    // serial's warehouse back to its OWN fromWarehouse) before its items
    // (and their allocation rows) are replaced — see
    // restoreBatchSerialRelocateEffects. Must run before the deleteMany
    // below and before the warehouse-match check, since re-saving this
    // transfer's own unchanged lines should not be flagged as "not at the
    // From Warehouse" against a warehouse THIS document itself just moved.
    await restoreBatchSerialRelocateEffects(tx, { transferId: id });
    await assertRelocateWarehouseMatches(tx, items);
    await tx.stockTransferItem.deleteMany({ where: { transferId: id } });
    // System stock comes from the ledger, never from the request — and is
    // read after this document's own previous lines are cleared, so an edit
    // measures against stock excluding its own prior effect.
    const onHand = await getCurrentStockForMany(items.map((i) => i.productCode), { client: tx });
    const itemData = items.map((i) => toStockTransferItemData(i, header, onHand));
    assertStockTransferItemsHaveWarehouses(itemData);
    await assertNoNegativeStock(tx, itemData);
    await assertNoNegativeWarehouseStock(tx, itemData);
    const totals = computeStockTransferTotals(itemData);
    const updated = await tx.stockTransfer.update({
      where: { id },
      data: { ...header, ...totals, items: { create: itemData } },
      include: stockTransferInclude,
    });
    await applyBatchSerialRelocateEffects(tx, items, updated.items, { linkField: 'stockTransferItemId' });
    // Journals on the save that first makes this Posted; already-journalled
    // transfers are untouched on either leg. See utils/stockTable.js.
    await postStockEntries(tx, {
      transType: TRANS_TYPES.STOCK_TRANSFER_OUT,
      transNum: updated.id,
      status: updated.status,
      warehouse: updated.fromWarehouse,
      lines: transferOutLines(itemData),
      userId: req.user?.id,
    });
    await postStockEntries(tx, {
      transType: TRANS_TYPES.STOCK_TRANSFER_IN,
      transNum: updated.id,
      status: updated.status,
      warehouse: updated.toWarehouse,
      lines: transferInLines(itemData),
      userId: req.user?.id,
    });
    // Rebuild the accounting document from what this transfer now says.
    await syncJournalEntry(tx, {
      sourceType: JOURNAL_SOURCE_TYPES.STOCK_TRANSFER,
      sourceDocNo: updated.transferNo,
      status: updated.status,
      doc: { ...updated, items: itemData },
    });
    return updated;
  });
  res.json({ success: true, data: row });
}));

router.delete('/inventory/stock-transfers/:id', auth(['admin']), asyncHandler(async (req, res) => {
  // Deleting the document deletes its accounting document too -- a
  // ledger entry for a document that no longer exists is worse than no
  // entry at all. See reverseJournalEntry in utils/glPosting.js.
  await removeJournalEntryForDocument(
    prisma, JOURNAL_SOURCE_TYPES.STOCK_TRANSFER, 'stockTransfer', 'transferNo', Number(req.params.id)
  );
  const id = Number(req.params.id);
  await prisma.$transaction(async (tx) => {
    // Put every relocated batch/serial's warehouse back before the items —
    // and their allocation rows — cascade away with the document.
    // StockTransferItem.transfer has onDelete: Cascade, so items go with it.
    await restoreBatchSerialRelocateEffects(tx, { transferId: id });
    await tx.stockTransfer.delete({ where: { id } });
  });
  res.json({ success: true, message: 'Deleted successfully' });
}));

// Receivables
// Bespoke aging-report endpoint for the Customer Outstanding page — mounted
// BEFORE the crudRouter below so `/report` doesn't get swallowed by that
// router's `/:id` route. Follows the dashboard.js style (auth + asyncHandler,
// prisma query + JS reshaping, single JSON response) rather than crudRouter,
// since this is a computed aggregate, not a CRUD resource.
// customerGroup filters against Customer.customerType (there's no separate
// "customer group" table/column — customerType is the only classification
// field on Customer, and its sample values, Manufacturing/Trading/
// Construction/Retail, match the report design's "Customer Group" exactly).
// "outstandingType" (All / Invoices + Debit Notes) and "currency" are
// no-ops — there's no DebitNote model in this schema (CustomerOutstanding
// rows are always sales-invoice-derived), and neither CustomerOutstanding
// nor Customer stores a currency column, so every row is implicitly the
// company's base currency. "Branch" is a no-op for the same reason as the
// other reports (no branch column anywhere in this data model).
router.get('/receivables/outstanding/report', auth(), asyncHandler(async (req, res) => {
  const {
    branch, customerGroup, salesPerson, customerName, outstandingType, include,
    showInactiveCustomers, currency, asOnDate, agingBasedOn,
  } = req.query;
  const basisField = agingBasedOn === 'Invoice Date' ? 'invoiceDate' : 'dueDate';
  const asOn = asOnDate ? new Date(asOnDate) : new Date();
  asOn.setHours(0, 0, 0, 0);

  const customerWhere = {};
  if (customerGroup) customerWhere.customerType = customerGroup;
  if (salesPerson) customerWhere.salesPerson = salesPerson;
  if (customerName) customerWhere.customerName = customerName;
  // Default is to hide inactive customers, same "Show Inactive Customers"
  // convention used on list pages elsewhere in the app.
  if (showInactiveCustomers !== 'Yes') customerWhere.status = 'Active';

  const customers = await prisma.customer.findMany({ where: customerWhere });
  const names = customers.map((c) => c.customerName);

  const outstandingRows = names.length
    ? await prisma.customerOutstanding.findMany({ where: { customerName: { in: names } } })
    : [];

  const rowsByName = {};
  outstandingRows.forEach((row) => {
    const name = row.customerName || 'Unknown';
    (rowsByName[name] = rowsByName[name] || []).push(row);
  });

  // Base iteration is over the filtered Customer list (not just customers
  // who happen to have an outstanding row), so "Include: All Customers"
  // can surface zero-balance customers too.
  const allRows = customers.map((cust) => {
    const custRows = rowsByName[cust.customerName] || [];
    // Five underlying buckets — notDue (not yet due) and d1to30 (1-30 days
    // overdue) are tracked separately so the Receivables > Customer
    // Outstanding page (which shows them as distinct "Current" / "1 - 30
    // Days" columns) can use them. `current` is kept as notDue + d1to30
    // combined, exactly as before, so the Reports > Customer Outstanding
    // page's existing "0 - 30 Days" column/chart is unaffected.
    const bucket = { notDue: 0, d1to30: 0, d31to60: 0, d61to90: 0, above90: 0 };
    let overdueDays = 0;
    let lastInvoiceDate = null;
    // Sum of every invoice raised for this customer (Paid included), as
    // opposed to totalOutstanding below which only counts the unpaid
    // remainder. This is what a collection against the customer must NOT
    // move — it's a running record of everything ever invoiced, so the
    // aging buckets/Total Outstanding can shrink as payments come in
    // without this figure moving with them.
    let totalInvoiceAmount = 0;

    custRows.forEach((row) => {
      if (row.invoiceDate && (!lastInvoiceDate || new Date(row.invoiceDate) > new Date(lastInvoiceDate))) {
        lastInvoiceDate = row.invoiceDate;
      }
      totalInvoiceAmount += Number(row.invoiceAmount || 0);

      const balance = row.balanceAmount != null
        ? Number(row.balanceAmount)
        : Number(row.invoiceAmount || 0) - Number(row.paidAmount || 0);
      if (row.status === 'Paid' || balance <= 0) return;

      const basisDate = row[basisField];
      let daysOverdue = 0;
      if (basisDate) {
        const d = new Date(basisDate);
        d.setHours(0, 0, 0, 0);
        daysOverdue = Math.round((asOn - d) / (1000 * 60 * 60 * 24));
      }
      if (daysOverdue > overdueDays) overdueDays = daysOverdue;

      if (daysOverdue <= 0) bucket.notDue += balance;
      else if (daysOverdue <= 30) bucket.d1to30 += balance;
      else if (daysOverdue <= 60) bucket.d31to60 += balance;
      else if (daysOverdue <= 90) bucket.d61to90 += balance;
      else bucket.above90 += balance;
    });

    // Total Outstanding is the money actually still owed — the sum of the
    // unpaid buckets — NOT the sum of every invoice ever raised for this
    // customer. Summing raw invoiceAmount regardless of paid status (the
    // previous behavior) meant a customer with one Paid and one Unpaid
    // invoice showed a Total Outstanding bigger than what any of the aging
    // columns added up to, and a customer whose invoices were all fully
    // paid still showed a nonzero Total Outstanding.
    const totalOutstanding = bucket.notDue + bucket.d1to30 + bucket.d31to60 + bucket.d61to90 + bucket.above90;
    const status = totalOutstanding <= 0 ? 'No Outstanding' : (overdueDays > 0 ? 'Overdue' : 'Current');
    // Row-level overdue total — everything past due, i.e. every bucket
    // except notDue.
    const overdueAmount = bucket.d1to30 + bucket.d31to60 + bucket.d61to90 + bucket.above90;

    return {
      customerCode: cust.customerCode,
      customerName: cust.customerName,
      customerGroup: cust.customerType || 'Uncategorized',
      salesPerson: cust.salesPerson || '—',
      creditLimit: Number(cust.creditLimit || 0),
      totalInvoiceAmount,
      totalOutstanding,
      current: bucket.notDue + bucket.d1to30,
      ...bucket,
      overdueAmount,
      overdueDays,
      lastInvoiceDate,
      status,
    };
  }).sort((a, b) => a.customerCode.localeCompare(b.customerCode));

  // "Include" narrows to customers who actually carry a balance — the
  // default working set for this report — same "default narrows, All
  // widens" pattern used on the inventory reports above.
  const rows = include === 'All Customers' ? allRows : allRows.filter((r) => r.totalOutstanding > 0);

  const totals = rows.reduce((acc, r) => {
    acc.notDue += r.notDue;
    acc.d1to30 += r.d1to30;
    acc.current += r.current;
    acc.d31to60 += r.d31to60;
    acc.d61to90 += r.d61to90;
    acc.above90 += r.above90;
    acc.totalOutstanding += r.totalOutstanding;
    acc.totalInvoiceAmount += r.totalInvoiceAmount;
    acc.creditLimit += r.creditLimit;
    return acc;
  }, {
    notDue: 0, d1to30: 0, current: 0, d31to60: 0, d61to90: 0, above90: 0, totalOutstanding: 0, totalInvoiceAmount: 0, creditLimit: 0,
  });
  // Everything past due — every bucket except notDue. (Previously omitted
  // d1to30, which under-counted "overdue"; nothing downstream depended on
  // that number, since this field wasn't surfaced on any page until now.)
  totals.overdue = totals.d1to30 + totals.d31to60 + totals.d61to90 + totals.above90;

  // "Due Today" stat always uses dueDate specifically (regardless of the
  // Aging Based On filter), matching the design's literal "Due Today" label.
  let dueToday = 0;
  outstandingRows.forEach((row) => {
    const balance = row.balanceAmount != null
      ? Number(row.balanceAmount)
      : Number(row.invoiceAmount || 0) - Number(row.paidAmount || 0);
    if (row.status === 'Paid' || balance <= 0 || !row.dueDate) return;
    const d = new Date(row.dueDate);
    d.setHours(0, 0, 0, 0);
    if (d.getTime() === asOn.getTime()) dueToday += balance;
  });

  // Outstanding by Ageing — donut over the four buckets, across the full
  // filtered/included set.
  const ageingTotal = totals.totalOutstanding || 1;
  const outstandingByAgeing = [
    { name: '0 - 30 Days', value: Math.round(totals.current), percent: Math.round((totals.current / ageingTotal) * 1000) / 10 },
    { name: '31 - 60 Days', value: Math.round(totals.d31to60), percent: Math.round((totals.d31to60 / ageingTotal) * 1000) / 10 },
    { name: '61 - 90 Days', value: Math.round(totals.d61to90), percent: Math.round((totals.d61to90 / ageingTotal) * 1000) / 10 },
    { name: 'Above 90 Days', value: Math.round(totals.above90), percent: Math.round((totals.above90 / ageingTotal) * 1000) / 10 },
  ];

  // Top 10 Customers by Outstanding Amount.
  const topCustomersByOutstanding = [...rows].sort((a, b) => b.totalOutstanding - a.totalOutstanding).slice(0, 10)
    .map((r) => ({ name: r.customerName, value: Math.round(r.totalOutstanding) }));

  // Outstanding by Customer Group (Top 5 + Others).
  const byGroupValue = {};
  rows.forEach((r) => { byGroupValue[r.customerGroup] = (byGroupValue[r.customerGroup] || 0) + r.totalOutstanding; });
  const groupEntries = Object.entries(byGroupValue).sort((a, b) => b[1] - a[1]);
  const groupGrandTotal = totals.totalOutstanding || 1;
  const top5Groups = groupEntries.slice(0, 5);
  const othersGroupValue = groupEntries.slice(5).reduce((sum, [, v]) => sum + v, 0);
  const outstandingByCustomerGroup = [
    ...top5Groups.map(([name, value]) => ({ name, value: Math.round(value), percent: Math.round((value / groupGrandTotal) * 1000) / 10 })),
    ...(othersGroupValue > 0 ? [{ name: 'Others', value: Math.round(othersGroupValue), percent: Math.round((othersGroupValue / groupGrandTotal) * 1000) / 10 }] : []),
  ];

  res.json({
    success: true,
    data: {
      asOnDate: asOn,
      agingBasedOn: agingBasedOn || 'Due Date',
      stats: {
        totalCustomers: rows.length,
        totalOutstandingAmount: totals.totalOutstanding,
        current: totals.current,
        d31to60: totals.d31to60,
        d61to90: totals.d61to90,
        above90: totals.above90,
        overdueAmount: totals.overdue,
        dueToday,
      },
      rows,
      totals,
      outstandingByAgeing,
      topCustomersByOutstanding,
      outstandingByCustomerGroup,
    },
  });
}));

router.use('/receivables/outstanding', crudRouter(prisma.customerOutstanding, { searchFields: ['customerName', 'invoiceNo'] }));

// Collection Entry -- a master/detail resource (Collection has many
// CollectionInvoiceApplication rows), same bespoke-route pattern as
// PurchaseInvoice/ApprovalFlow (mirrors crudRouter's URL/method/response
// shape so the frontend keeps using the generic collectionApi from
// createCrudApi). Replaces the old flat crudRouter(prisma.collection, ...)
// mount now that the model has a nested line-items collection.
// Customer receipts and supplier payments settle open items through the same
// ledger (utils/openItemLedger.js). It replaced two hand-rolled copies whose
// apply and reverse steps clamped differently — apply floored the balance at
// zero, reverse capped it at the invoice amount — so once two receipts had
// closed an invoice, reversing either one restored the wrong balance and the
// difference was unrecoverable. The ledger only ever moves `paidAmount`, by
// exactly the amount applied, and recomputes the balance from it, which makes
// apply/reverse an exact identity in any order.
const customerLedger = createOpenItemLedger({
  delegateOf: (tx) => tx.customerOutstanding,
  partyField: 'customerName',
  documentWord: 'receipt',
});

const supplierLedger = createOpenItemLedger({
  delegateOf: (tx) => tx.supplierOutstanding,
  partyField: 'supplierName',
  documentWord: 'payment',
});

const applyToCustomerOutstanding = (tx, apps) => customerLedger.apply(tx, apps);
const reverseCustomerOutstanding = (tx, apps) => customerLedger.reverse(tx, apps);
const applyToSupplierOutstanding = (tx, apps) => supplierLedger.apply(tx, apps);
const reverseSupplierOutstanding = (tx, apps) => supplierLedger.reverse(tx, apps);

// Maps the open-item ledger's settlement status (Paid/Partial/Unpaid, see
// utils/openItemLedger.js's settlementStatus()) to the wording SalesInvoice
// and SalesOrder use for the same idea ('Paid'/'Partially Paid'/'Unpaid').
function toPaymentStatus(ledgerStatus) {
  if (ledgerStatus === 'Paid') return 'Paid';
  if (ledgerStatus === 'Partial') return 'Partially Paid';
  return 'Unpaid';
}

// A sales order's paymentStatus follows the invoice(s) raised against it —
// Paid once every one of them is Paid, Partially Paid as soon as any of them
// carries a payment, otherwise Unpaid. An order with no active invoice yet is
// left alone (still whatever it was created with) rather than being forced to
// Unpaid, so this never fights with an order that was never invoiced.
async function recomputeSalesOrderPaymentStatus(tx, orderNo) {
  if (!orderNo) return;
  const invoices = await tx.salesInvoice.findMany({
    where: { orderNo, status: { notIn: ['Draft', 'Cancelled'] } },
    select: { paymentStatus: true },
  });
  if (!invoices.length) return;
  let paymentStatus = 'Unpaid';
  if (invoices.every((inv) => inv.paymentStatus === 'Paid')) paymentStatus = 'Paid';
  else if (invoices.some((inv) => inv.paymentStatus === 'Paid' || inv.paymentStatus === 'Partially Paid')) paymentStatus = 'Partially Paid';
  await tx.salesOrder.updateMany({ where: { orderNo }, data: { paymentStatus } });
}

// Keeps SalesInvoice.paymentStatus — and, through it, the fulfilling
// SalesOrder's paymentStatus — in step with what CustomerOutstanding actually
// records as settled. Collection Entry only ever wrote to CustomerOutstanding
// itself (via customerLedger.apply/reverse above); nothing propagated that
// back to the invoice or order, so both kept showing "Unpaid" forever even
// after a collection paid the invoice off in full. Called after every place
// that changes an invoice's open-item balance: posting/editing/deleting a
// Collection, and creating/editing the invoice itself.
async function syncSalesInvoicePaymentStatus(tx, invoiceNo) {
  if (!invoiceNo) return;
  const openItem = await tx.customerOutstanding.findFirst({ where: { invoiceNo } });
  const paymentStatus = toPaymentStatus(openItem?.status);
  const invoice = await tx.salesInvoice.findFirst({ where: { invoiceNo } });
  if (!invoice) return;
  if (invoice.paymentStatus !== paymentStatus) {
    await tx.salesInvoice.update({ where: { id: invoice.id }, data: { paymentStatus } });
  }
  await recomputeSalesOrderPaymentStatus(tx, invoice.orderNo);
}

// Keeps PurchaseInvoice.paymentStatus in step with what SupplierOutstanding
// actually records as settled — same gap as SalesInvoice above, mirrored on
// the payables side: Payment Entry only ever wrote to SupplierOutstanding
// itself (via supplierLedger.apply/reverse above), so a purchase invoice paid
// off in full through Payment Entry still showed "Unpaid" forever. Unlike
// SalesOrder, PurchaseOrder has no paymentStatus column at all (see
// schema.prisma), so there is no order-level cascade needed here — this is
// the whole fix. Called after every place that changes an invoice's open-item
// balance: posting/editing/deleting a Payment Entry, and creating/editing the
// invoice itself.
async function syncPurchaseInvoicePaymentStatus(tx, invoiceNo) {
  if (!invoiceNo) return;
  const openItem = await tx.supplierOutstanding.findFirst({ where: { invoiceNo } });
  const paymentStatus = toPaymentStatus(openItem?.status);
  const invoice = await tx.purchaseInvoice.findFirst({ where: { invoiceNo } });
  if (!invoice) return;
  if (invoice.paymentStatus !== paymentStatus) {
    await tx.purchaseInvoice.update({ where: { id: invoice.id }, data: { paymentStatus } });
  }
}

const collectionInclude = { invoiceApplications: { orderBy: { id: 'asc' } } };

function toCollectionApplicationData(app) {
  return {
    invoiceNo: app.invoiceNo || null,
    invoiceDate: app.invoiceDate || null,
    dueDate: app.dueDate || null,
    totalAmount: app.totalAmount != null ? Number(app.totalAmount) : 0,
    outstandingAtTimeOfApplication: app.outstandingAtTimeOfApplication != null ? Number(app.outstandingAtTimeOfApplication) : 0,
    amountApplied: app.amountApplied != null ? Number(app.amountApplied) : 0,
  };
}



router.get('/receivables/collections', auth(), asyncHandler(async (req, res) => {
  const { q } = req.query;
  const where = q
    ? {
        OR: [
          { collectionNo: { contains: q } },
          { customerName: { contains: q } },
        ],
      }
    : undefined;
  const rows = await prisma.collection.findMany({ where, include: collectionInclude, orderBy: { id: 'desc' } });
  res.json({ success: true, data: rows });
}));

router.get('/receivables/collections/:id', auth(), asyncHandler(async (req, res) => {
  const row = await prisma.collection.findUnique({ where: { id: Number(req.params.id) }, include: collectionInclude });
  if (!row) return res.status(404).json({ success: false, message: 'Record not found' });
  res.json({ success: true, data: row });
}));

router.post('/receivables/collections', auth(), asyncHandler(async (req, res) => {
  const { invoiceApplications = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  const appData = invoiceApplications.map(toCollectionApplicationData);
  const totalAppliedAmount = appData.reduce((sum, a) => sum + Number(a.amountApplied || 0), 0);
  const row = await prisma.$transaction(async (tx) => {
    // collectionNo now comes from the configured RV (Receipt Voucher)
    // numbering series rather than free text — see resolveDocumentNumber
    // above.
    const { documentNumber, syncManual } = await resolveDocumentNumber('RV', header.collectionNo, tx);
    const created = await tx.collection.create({
      data: { ...header, collectionNo: documentNumber, totalAppliedAmount, invoiceApplications: { create: appData } },
      include: collectionInclude,
    });
    if (syncManual) await syncManual();
    if (created.status === 'Posted') {
      // Validate before applying, and after any previous version of this
      // receipt has been reversed, so the balances checked are the ones the
      // new applications will actually be measured against. A receipt that
      // over-settles is rejected outright rather than partially posted.
      await customerLedger.assertApplicationsValid(tx, appData, {
        paymentAmount: created.paymentAmount,
        partyName: created.customerName,
      });
      await applyToCustomerOutstanding(tx, appData);
      for (const app of appData) {
        if (app.invoiceNo) await syncSalesInvoicePaymentStatus(tx, app.invoiceNo);
      }
    }
    await syncBankReconciliationTxn(tx, {
      bankAccount: created.depositTo, voucherType: 'Receipt', voucherNo: created.collectionNo,
      txnDate: created.receiptDate, type: 'Credit', amount: created.paymentAmount,
      description: `Receipt from ${created.customerName || 'customer'}`, remarks: created.notes,
      isActive: created.status === 'Posted',
    });
    return created;
  });
  res.status(201).json({ success: true, data: row });
}));

router.put('/receivables/collections/:id', auth(), asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  const { invoiceApplications = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  const appData = invoiceApplications.map(toCollectionApplicationData);
  const totalAppliedAmount = appData.reduce((sum, a) => sum + Number(a.amountApplied || 0), 0);
  // Replace the applied-invoice set wholesale on every save -- simpler and
  // safer than diffing which rows were added/removed/edited client-side.
  const row = await prisma.$transaction(async (tx) => {
    // If this collection was already Posted before this save, its previous
    // invoiceApplications were already subtracted from CustomerOutstanding —
    // reverse that first so re-saving (with the same or edited amounts)
    // doesn't double-decrement the invoice balance.
    const existing = await tx.collection.findUnique({ where: { id }, include: collectionInclude });
    if (existing?.status === 'Posted') {
      await reverseCustomerOutstanding(tx, existing.invoiceApplications);
    }
    await tx.collectionInvoiceApplication.deleteMany({ where: { collectionId: id } });
    const updated = await tx.collection.update({
      where: { id },
      data: { ...header, totalAppliedAmount, invoiceApplications: { create: appData } },
      include: collectionInclude,
    });
    if (updated.status === 'Posted') {
      // Validate before applying, and after any previous version of this
      // receipt has been reversed, so the balances checked are the ones the
      // new applications will actually be measured against. A receipt that
      // over-settles is rejected outright rather than partially posted.
      await customerLedger.assertApplicationsValid(tx, appData, {
        paymentAmount: updated.paymentAmount,
        partyName: updated.customerName,
      });
      await applyToCustomerOutstanding(tx, appData);
    }
    // Sync every invoice touched by either the old or the new application
    // set — an invoice dropped from this collection needs its paymentStatus
    // pulled back down just as much as one newly added to it needs pushing up.
    const touchedInvoiceNos = new Set([
      ...(existing?.invoiceApplications || []).map((a) => a.invoiceNo).filter(Boolean),
      ...appData.map((a) => a.invoiceNo).filter(Boolean),
    ]);
    for (const invoiceNo of touchedInvoiceNos) {
      await syncSalesInvoicePaymentStatus(tx, invoiceNo);
    }
    await syncBankReconciliationTxn(tx, {
      bankAccount: updated.depositTo, voucherType: 'Receipt', voucherNo: updated.collectionNo,
      txnDate: updated.receiptDate, type: 'Credit', amount: updated.paymentAmount,
      description: `Receipt from ${updated.customerName || 'customer'}`, remarks: updated.notes,
      isActive: updated.status === 'Posted',
    });
    return updated;
  });
  res.json({ success: true, data: row });
}));

router.delete('/receivables/collections/:id', auth(['admin']), asyncHandler(async (req, res) => {
  // CollectionInvoiceApplication.collection has onDelete: Cascade, so
  // applications go with it. If this collection was Posted, its effect on
  // CustomerOutstanding needs reversing first, or the deleted collection's
  // payment stays "applied" forever with no record of why the balance is low.
  await prisma.$transaction(async (tx) => {
    const existing = await tx.collection.findUnique({ where: { id: Number(req.params.id) }, include: collectionInclude });
    if (existing?.status === 'Posted') {
      await reverseCustomerOutstanding(tx, existing.invoiceApplications);
    }
    if (existing) {
      await syncBankReconciliationTxn(tx, {
        bankAccount: existing.depositTo, voucherNo: existing.collectionNo, isActive: false,
      });
    }
    await tx.collection.delete({ where: { id: Number(req.params.id) } });
    if (existing?.status === 'Posted') {
      for (const app of existing.invoiceApplications) {
        if (app.invoiceNo) await syncSalesInvoicePaymentStatus(tx, app.invoiceNo);
      }
    }
  });
  res.json({ success: true, message: 'Deleted successfully' });
}));

// Collection Register report — bespoke aggregation endpoint for the
// Reports > Receivable > Collection Register page. One row per Collection
// (receipt) header within the selected date range. `fromDate`/`toDate` are
// resolved from the "Period Range" preset on the frontend (MTD/WTD/QTD/
// YTD/Custom Range), same "frontend resolves the preset, backend just
// filters a plain date range" approach used elsewhere. Invoice Amount/Paid
// Amount/Outstanding are derived from this collection's own
// CollectionInvoiceApplication rows (totalAmount/amountApplied/
// outstandingAtTimeOfApplication) rather than the Collection header's
// paymentAmount, since a single receipt can span multiple invoices;
// collections with no applications (a payment on account, not yet applied
// to any invoice) fall back to paymentAmount for both Invoice Amount and
// Paid Amount, with zero Outstanding. "Branch" and "Currency" are no-ops —
// no branch column exists anywhere in this data model, and every amount
// here is implicitly the company's base currency (Collection.
// paymentCurrency defaults to INR and nothing downstream varies by it).
router.get('/receivables/collection-register/report', auth(), asyncHandler(async (req, res) => {
  const {
    fromDate, toDate, customerGroup, salesPerson, customer, paymentMode,
    include, showInactiveCustomers,
  } = req.query;

  const from = fromDate ? new Date(fromDate) : new Date(new Date().getFullYear(), new Date().getMonth(), 1);
  from.setHours(0, 0, 0, 0);
  const to = toDate ? new Date(toDate) : new Date();
  to.setHours(23, 59, 59, 999);

  const customerWhere = {};
  if (customerGroup) customerWhere.customerType = customerGroup;
  if (salesPerson) customerWhere.salesPerson = salesPerson;
  if (customer) customerWhere.customerName = customer;
  if (showInactiveCustomers !== 'Yes') customerWhere.status = 'Active';

  const customers = await prisma.customer.findMany({ where: customerWhere });
  const names = customers.map((c) => c.customerName);
  const custByName = Object.fromEntries(customers.map((c) => [c.customerName, c]));

  // "Include" narrows by document status. Cancelled collections are always
  // excluded — they represent voided/reversed entries, never real cash
  // received.
  let statusWhere = { in: ['Posted', 'Draft'] };
  if (include === 'Posted Only') statusWhere = 'Posted';
  else if (include === 'Draft Only') statusWhere = 'Draft';

  const collectionWhere = {
    receiptDate: { gte: from, lte: to },
    status: statusWhere,
  };
  if (names.length) collectionWhere.customerName = { in: names };
  if (paymentMode) collectionWhere.paymentMode = paymentMode;

  const collections = names.length
    ? await prisma.collection.findMany({
      where: collectionWhere,
      include: { invoiceApplications: true },
      orderBy: { receiptDate: 'desc' },
    })
    : [];

  const rows = collections.map((c) => {
    const cust = custByName[c.customerName] || {};
    let invoiceAmount = 0;
    let paidAmount = 0;
    let outstanding = 0;
    if (c.invoiceApplications.length) {
      c.invoiceApplications.forEach((app) => {
        invoiceAmount += Number(app.totalAmount || 0);
        paidAmount += Number(app.amountApplied || 0);
        outstanding += Math.max(Number(app.outstandingAtTimeOfApplication || 0) - Number(app.amountApplied || 0), 0);
      });
    } else {
      invoiceAmount = Number(c.paymentAmount || 0);
      paidAmount = Number(c.paymentAmount || 0);
    }

    return {
      id: c.id,
      receiptNo: c.collectionNo,
      receiptDate: c.receiptDate,
      customerCode: cust.customerCode || '—',
      customerName: c.customerName || 'Unknown',
      paymentMode: c.paymentMode || '—',
      referenceNo: c.instrumentNo || '—',
      bankName: c.depositTo || '—',
      invoiceAmount,
      paidAmount,
      outstanding,
      collectedBy: c.receivedBy || '—',
      status: c.status,
    };
  });

  const totals = rows.reduce((acc, r) => ({
    invoiceAmount: acc.invoiceAmount + r.invoiceAmount,
    paidAmount: acc.paidAmount + r.paidAmount,
    outstanding: acc.outstanding + r.outstanding,
  }), { invoiceAmount: 0, paidAmount: 0, outstanding: 0 });

  const totalCollections = totals.paidAmount;
  const KNOWN_MODES = ['Cash', 'Cheque', 'Bank Transfer', 'UPI', 'NEFT', 'RTGS'];
  const cashAmount = rows.filter((r) => r.paymentMode === 'Cash').reduce((sum, r) => sum + r.paidAmount, 0);
  const otherModeAmount = rows.filter((r) => !KNOWN_MODES.includes(r.paymentMode)).reduce((sum, r) => sum + r.paidAmount, 0);
  const bankAmount = Math.max(totalCollections - cashAmount - otherModeAmount, 0);

  // Collection by Payment Mode — donut over the exact payment mode values
  // in use (Top 5 + Others), across the full filtered set.
  const byModeValue = {};
  rows.forEach((r) => { byModeValue[r.paymentMode] = (byModeValue[r.paymentMode] || 0) + r.paidAmount; });
  const modeEntries = Object.entries(byModeValue).sort((a, b) => b[1] - a[1]);
  const modeGrandTotal = totalCollections || 1;
  const top5Modes = modeEntries.slice(0, 5);
  const othersModeValue = modeEntries.slice(5).reduce((sum, [, v]) => sum + v, 0);
  const collectionByPaymentMode = [
    ...top5Modes.map(([name, value]) => ({ name, value: Math.round(value), percent: Math.round((value / modeGrandTotal) * 1000) / 10 })),
    ...(othersModeValue > 0 ? [{ name: 'Others', value: Math.round(othersModeValue), percent: Math.round((othersModeValue / modeGrandTotal) * 1000) / 10 }] : []),
  ];

  // Collection Trend (Last 7 Days) — always the 7 calendar days ending at
  // `to`, regardless of the selected Period Range preset (which might cover
  // fewer than 7 days, e.g. WTD), same idea as the "Due Today" stat on
  // Customer Outstanding always using a fixed basis rather than the
  // report's main filter. Queried independently of `rows` above so a short
  // period range doesn't truncate the trend window.
  const trendDays = [];
  for (let i = 6; i >= 0; i -= 1) {
    const d = new Date(to);
    d.setDate(d.getDate() - i);
    d.setHours(0, 0, 0, 0);
    trendDays.push(d);
  }
  const trendFrom = trendDays[0];
  const trendWhere = { receiptDate: { gte: trendFrom, lte: to }, status: statusWhere };
  if (names.length) trendWhere.customerName = { in: names };
  if (paymentMode) trendWhere.paymentMode = paymentMode;
  const trendCollections = names.length
    ? await prisma.collection.findMany({ where: trendWhere, select: { receiptDate: true, paymentAmount: true } })
    : [];
  const pad2 = (n) => String(n).padStart(2, '0');
  const collectionTrend = trendDays.map((d) => {
    const dayTotal = trendCollections
      .filter((r) => r.receiptDate && new Date(r.receiptDate).toDateString() === d.toDateString())
      .reduce((sum, r) => sum + Number(r.paymentAmount || 0), 0);
    return { name: `${pad2(d.getDate())}/${pad2(d.getMonth() + 1)}`, value: Math.round(dayTotal) };
  });

  // Top 5 Customers by Collection.
  const byCustomerValue = {};
  rows.forEach((r) => { byCustomerValue[r.customerName] = (byCustomerValue[r.customerName] || 0) + r.paidAmount; });
  const top5CustomersByCollection = Object.entries(byCustomerValue).sort((a, b) => b[1] - a[1]).slice(0, 5)
    .map(([name, value]) => ({ name, value: Math.round(value) }));

  res.json({
    success: true,
    data: {
      rows,
      totals,
      stats: {
        totalCollections,
        totalReceipts: rows.length,
        totalCustomers: new Set(rows.map((r) => r.customerName)).size,
        cashAmount,
        bankAmount,
        otherModeAmount,
      },
      collectionByPaymentMode,
      collectionTrend,
      top5CustomersByCollection,
    },
  });
}));

// Payables
// Bespoke aging-report endpoint for the Supplier Outstanding page — mounted
// BEFORE the crudRouter below so `/report` doesn't get swallowed by that
// router's `/:id` route. Unlike /receivables/outstanding/report (which ages
// backward from "days since due"), this report is forward-looking — it
// buckets each open invoice by how soon it falls due (Overdue / Due Within
// 30 Days / Due 31-60 Days / Due Above 60 Days), matching the design's
// payables-focused framing ("what do we owe, and when"). "supplierGroup"
// filters against Supplier.supplierType (the only classification field on
// Supplier, whose sample values — Raw Materials/Electricals/Packaging/
// etc — match the report design's "Supplier Group" exactly). "Branch" and
// "Currency" are no-ops for the same reason as the other reports.
// "Show Paid Invoices" is a genuinely new toggle versus the old version of
// this report: default (No) excludes fully-paid SupplierOutstanding rows
// entirely from both the invoice count and Total Outstanding sum, giving a
// real live "what's currently owed" picture; "Yes" brings historical paid
// invoices back in (their own past invoiceAmount, contributing 0 to every
// ageing bucket), for a full historical register view.
function computeSupplierOutstandingSnapshot(outstandingRows, asOn, basisField, showPaidInvoices) {
  const bySupplier = {};
  outstandingRows.forEach((row) => {
    const balance = row.balanceAmount != null
      ? Number(row.balanceAmount)
      : Number(row.invoiceAmount || 0) - Number(row.paidAmount || 0);
    const isPaid = row.status === 'Paid' || balance <= 0;
    if (isPaid && showPaidInvoices !== 'Yes') return;

    const name = row.supplierName || 'Unknown';
    if (!bySupplier[name]) {
      bySupplier[name] = {
        totalInvoices: 0, totalOutstanding: 0,
        overdue: 0, dueWithin30: 0, due31to60: 0, dueAbove60: 0,
        // Backward "days since due" aging (same bucketing the Receivables >
        // Customer Outstanding report uses), tracked alongside the
        // forward-looking dueWithin30/due31to60/dueAbove60/overdue buckets
        // above (which the Reports > Supplier Outstanding page's chart and
        // table still read as-is). Only used by the Payables > Supplier
        // Outstanding page.
        agedNotDue: 0, agedD1to30: 0, agedD31to60: 0, agedD61to90: 0, agedAbove90: 0,
      };
    }
    const bucket = bySupplier[name];
    bucket.totalInvoices += 1;
    if (isPaid) {
      // Only reached when showPaidInvoices === 'Yes' — contributes this
      // invoice's original amount to the historical Total Outstanding
      // figure (per the "full historical register view" behavior above),
      // but nothing to any ageing bucket, since it's already settled.
      bucket.totalOutstanding += Number(row.invoiceAmount || 0);
      return;
    }
    // Total Outstanding is the money actually still owed — the remaining
    // balance — not the invoice's original amount. Using invoiceAmount here
    // (the previous behavior) meant a Partial invoice's already-paid
    // portion still counted toward Total Outstanding, so it came out
    // bigger than what any of the ageing columns added up to.
    bucket.totalOutstanding += balance;

    const basisDate = row[basisField];
    let daysPast = 0;
    if (basisDate) {
      const d = new Date(basisDate);
      d.setHours(0, 0, 0, 0);
      daysPast = Math.round((asOn - d) / (1000 * 60 * 60 * 24));
    }

    if (daysPast > 0) bucket.overdue += balance;
    else if (-daysPast <= 30) bucket.dueWithin30 += balance;
    else if (-daysPast <= 60) bucket.due31to60 += balance;
    else bucket.dueAbove60 += balance;

    if (daysPast <= 0) bucket.agedNotDue += balance;
    else if (daysPast <= 30) bucket.agedD1to30 += balance;
    else if (daysPast <= 60) bucket.agedD31to60 += balance;
    else if (daysPast <= 90) bucket.agedD61to90 += balance;
    else bucket.agedAbove90 += balance;
  });
  return bySupplier;
}

router.get('/payables/outstanding/report', auth(), asyncHandler(async (req, res) => {
  const {
    branch, supplierGroup, supplier, currency, include, showPaidInvoices, asOnDate, agingBasedOn,
  } = req.query;
  const basisField = agingBasedOn === 'Invoice Date' ? 'invoiceDate' : 'dueDate';
  const asOn = asOnDate ? new Date(asOnDate) : new Date();
  asOn.setHours(0, 0, 0, 0);

  const supplierWhere = { status: 'Active' };
  if (supplierGroup) supplierWhere.supplierType = supplierGroup;
  if (supplier) supplierWhere.supplierName = supplier;

  const suppliers = await prisma.supplier.findMany({ where: supplierWhere });
  const names = suppliers.map((s) => s.supplierName);
  const codeGroupByName = Object.fromEntries(suppliers.map((s) => [s.supplierName, { code: s.supplierCode, group: s.supplierType || 'Uncategorized' }]));

  const outstandingRows = names.length
    ? await prisma.supplierOutstanding.findMany({ where: { supplierName: { in: names } } })
    : [];

  const bySupplier = computeSupplierOutstandingSnapshot(outstandingRows, asOn, basisField, showPaidInvoices);

  const allRows = suppliers.map((s) => {
    const agg = bySupplier[s.supplierName] || {
      totalInvoices: 0, totalOutstanding: 0, overdue: 0, dueWithin30: 0, due31to60: 0, dueAbove60: 0,
      agedNotDue: 0, agedD1to30: 0, agedD31to60: 0, agedD61to90: 0, agedAbove90: 0,
    };
    return {
      supplierCode: s.supplierCode,
      supplierName: s.supplierName,
      supplierGroup: s.supplierType || 'Uncategorized',
      totalInvoices: agg.totalInvoices,
      totalOutstanding: agg.totalOutstanding,
      overdue: agg.overdue,
      dueWithin30: agg.dueWithin30,
      due31to60: agg.due31to60,
      dueAbove60: agg.dueAbove60,
      // Backward-aged buckets + row-level overdue total for the Payables >
      // Supplier Outstanding page.
      notDue: agg.agedNotDue,
      d1to30: agg.agedD1to30,
      d31to60: agg.agedD31to60,
      d61to90: agg.agedD61to90,
      above90: agg.agedAbove90,
      overdueAmount: agg.agedD1to30 + agg.agedD31to60 + agg.agedD61to90 + agg.agedAbove90,
    };
  }).sort((a, b) => a.supplierCode.localeCompare(b.supplierCode));

  // "Include": 'Overdue Invoices Only' narrows to suppliers currently past
  // due (same "default is everyone, narrower option filters down" pattern
  // used elsewhere, e.g. Reorder Level's "Reorder Status"). 'Suppliers with
  // Outstanding Only' is broader than that — any real balance owed, whether
  // or not it's due yet — which is what actually matches "this supplier has
  // an open invoice" (unlike 'Overdue', which would hide a supplier whose
  // only unpaid invoice isn't due yet).
  const rows = include === 'Overdue Invoices Only'
    ? allRows.filter((r) => r.overdue > 0)
    : include === 'Suppliers with Outstanding Only'
    ? allRows.filter((r) => r.totalOutstanding > 0)
    : allRows;

  const totals = rows.reduce((acc, r) => {
    acc.totalInvoices += r.totalInvoices;
    acc.totalOutstanding += r.totalOutstanding;
    acc.overdue += r.overdue;
    acc.dueWithin30 += r.dueWithin30;
    acc.due31to60 += r.due31to60;
    acc.dueAbove60 += r.dueAbove60;
    acc.notDue += r.notDue;
    acc.d1to30 += r.d1to30;
    acc.d31to60 += r.d31to60;
    acc.d61to90 += r.d61to90;
    acc.above90 += r.above90;
    acc.overdueAmount += r.overdueAmount;
    return acc;
  }, {
    totalInvoices: 0, totalOutstanding: 0, overdue: 0, dueWithin30: 0, due31to60: 0, dueAbove60: 0,
    notDue: 0, d1to30: 0, d31to60: 0, d61to90: 0, above90: 0, overdueAmount: 0,
  });

  // "Due Today" — same convention as the Receivables report: always keyed
  // off dueDate specifically, regardless of the Aging Based On filter.
  let dueToday = 0;
  outstandingRows.forEach((row) => {
    const balance = row.balanceAmount != null
      ? Number(row.balanceAmount)
      : Number(row.invoiceAmount || 0) - Number(row.paidAmount || 0);
    if (row.status === 'Paid' || balance <= 0 || !row.dueDate) return;
    const d = new Date(row.dueDate);
    d.setHours(0, 0, 0, 0);
    if (d.getTime() === asOn.getTime()) dueToday += balance;
  });

  const ageingTotal = totals.totalOutstanding || 1;
  const outstandingByAgeing = [
    { name: 'Overdue', value: Math.round(totals.overdue), percent: Math.round((totals.overdue / ageingTotal) * 1000) / 10 },
    { name: 'Due Within 30 Days', value: Math.round(totals.dueWithin30), percent: Math.round((totals.dueWithin30 / ageingTotal) * 1000) / 10 },
    { name: 'Due 31-60 Days', value: Math.round(totals.due31to60), percent: Math.round((totals.due31to60 / ageingTotal) * 1000) / 10 },
    { name: 'Due Above 60 Days', value: Math.round(totals.dueAbove60), percent: Math.round((totals.dueAbove60 / ageingTotal) * 1000) / 10 },
  ];

  // Top 5 Suppliers by Outstanding.
  const top5SuppliersByOutstanding = [...rows].sort((a, b) => b.totalOutstanding - a.totalOutstanding).slice(0, 5)
    .map((r) => ({ name: r.supplierName, value: Math.round(r.totalOutstanding) }));

  // Outstanding Trend (Last 6 Months) — a snapshot of what Total
  // Outstanding would have been if this same report were run as of the end
  // of each of the last 6 months (same filters, same showPaidInvoices
  // toggle), not a month-over-month collections delta.
  const outstandingTrend = [];
  for (let i = 5; i >= 0; i -= 1) {
    const monthEnd = new Date(asOn.getFullYear(), asOn.getMonth() - i + 1, 0);
    monthEnd.setHours(23, 59, 59, 999);
    const snapshotDate = i === 0 ? asOn : monthEnd;
    const snapshot = computeSupplierOutstandingSnapshot(outstandingRows, snapshotDate, basisField, showPaidInvoices);
    const monthTotal = Object.values(snapshot).reduce((sum, s) => sum + s.totalOutstanding, 0);
    outstandingTrend.push({ name: snapshotDate.toLocaleDateString('en-US', { month: 'short', year: 'numeric' }), value: Math.round(monthTotal) });
  }

  res.json({
    success: true,
    data: {
      asOnDate: asOn,
      agingBasedOn: agingBasedOn || 'Due Date',
      stats: {
        totalSuppliers: rows.length,
        totalOutstandingAmount: totals.totalOutstanding,
        overdue: totals.overdue,
        dueWithin30: totals.dueWithin30,
        due31to60: totals.due31to60,
        dueAbove60: totals.dueAbove60,
        overdueAmount: totals.overdueAmount,
        dueToday,
      },
      rows,
      totals,
      outstandingByAgeing,
      top5SuppliersByOutstanding,
      outstandingTrend,
    },
  });
}));

router.use('/payables/outstanding', crudRouter(prisma.supplierOutstanding, { searchFields: ['supplierName', 'invoiceNo'] }));

// Payment Entry -- a master/detail resource (SupplierPayment has many
// PaymentInvoiceApplication rows), same bespoke-route pattern as the
// Collection Entry routes above (mirrors crudRouter's URL/method/response
// shape so the frontend keeps using the generic supplierPaymentApi from
// createCrudApi). Replaces the old flat crudRouter(prisma.supplierPayment,
// ...) mount now that the model has a nested line-items collection.
const supplierPaymentInclude = { invoiceApplications: { orderBy: { id: 'asc' } } };

function toPaymentApplicationData(app) {
  return {
    invoiceNo: app.invoiceNo || null,
    invoiceDate: app.invoiceDate || null,
    dueDate: app.dueDate || null,
    totalAmount: app.totalAmount != null ? Number(app.totalAmount) : 0,
    outstandingAtTimeOfApplication: app.outstandingAtTimeOfApplication != null ? Number(app.outstandingAtTimeOfApplication) : 0,
    amountApplied: app.amountApplied != null ? Number(app.amountApplied) : 0,
  };
}



router.get('/payables/payments', auth(), asyncHandler(async (req, res) => {
  const { q } = req.query;
  const where = q
    ? {
        OR: [
          { paymentNo: { contains: q } },
          { supplierName: { contains: q } },
        ],
      }
    : undefined;
  const rows = await prisma.supplierPayment.findMany({ where, include: supplierPaymentInclude, orderBy: { id: 'desc' } });
  res.json({ success: true, data: rows });
}));

router.get('/payables/payments/:id', auth(), asyncHandler(async (req, res) => {
  const row = await prisma.supplierPayment.findUnique({ where: { id: Number(req.params.id) }, include: supplierPaymentInclude });
  if (!row) return res.status(404).json({ success: false, message: 'Record not found' });
  res.json({ success: true, data: row });
}));

router.post('/payables/payments', auth(), asyncHandler(async (req, res) => {
  const { invoiceApplications = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  const appData = invoiceApplications.map(toPaymentApplicationData);
  const totalAppliedAmount = appData.reduce((sum, a) => sum + Number(a.amountApplied || 0), 0);
  const row = await prisma.$transaction(async (tx) => {
    // paymentNo now comes from the configured PV (Payment Voucher)
    // numbering series rather than free text — see resolveDocumentNumber
    // above.
    const { documentNumber, syncManual } = await resolveDocumentNumber('PV', header.paymentNo, tx);
    const created = await tx.supplierPayment.create({
      data: { ...header, paymentNo: documentNumber, totalAppliedAmount, invoiceApplications: { create: appData } },
      include: supplierPaymentInclude,
    });
    if (syncManual) await syncManual();
    if (created.status === 'Posted') {
      // Same pre-flight as the receipts side — see customerLedger above.
      await supplierLedger.assertApplicationsValid(tx, appData, {
        paymentAmount: created.paymentAmount,
        partyName: created.supplierName,
      });
      await applyToSupplierOutstanding(tx, appData);
      for (const app of appData) {
        if (app.invoiceNo) await syncPurchaseInvoicePaymentStatus(tx, app.invoiceNo);
      }
    }
    await syncBankReconciliationTxn(tx, {
      bankAccount: created.payFromAccount, voucherType: 'Payment', voucherNo: created.paymentNo,
      txnDate: created.paymentDate, type: 'Debit', amount: created.paymentAmount,
      description: `Payment to ${created.supplierName || 'supplier'}`, remarks: created.notes,
      isActive: created.status === 'Posted',
    });
    return created;
  });
  res.status(201).json({ success: true, data: row });
}));

router.put('/payables/payments/:id', auth(), asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  const { invoiceApplications = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  const appData = invoiceApplications.map(toPaymentApplicationData);
  const totalAppliedAmount = appData.reduce((sum, a) => sum + Number(a.amountApplied || 0), 0);
  // Replace the applied-invoice set wholesale on every save -- simpler and
  // safer than diffing which rows were added/removed/edited client-side.
  const row = await prisma.$transaction(async (tx) => {
    // If this payment was already Posted before this save, its previous
    // invoiceApplications were already subtracted from SupplierOutstanding —
    // reverse that first so re-saving (with the same or edited amounts)
    // doesn't double-decrement the invoice balance.
    const existing = await tx.supplierPayment.findUnique({ where: { id }, include: supplierPaymentInclude });
    if (existing?.status === 'Posted') {
      await reverseSupplierOutstanding(tx, existing.invoiceApplications);
    }
    await tx.paymentInvoiceApplication.deleteMany({ where: { paymentId: id } });
    const updated = await tx.supplierPayment.update({
      where: { id },
      data: { ...header, totalAppliedAmount, invoiceApplications: { create: appData } },
      include: supplierPaymentInclude,
    });
    if (updated.status === 'Posted') {
      // Same pre-flight as the receipts side — see customerLedger above.
      await supplierLedger.assertApplicationsValid(tx, appData, {
        paymentAmount: updated.paymentAmount,
        partyName: updated.supplierName,
      });
      await applyToSupplierOutstanding(tx, appData);
    }
    // Sync every invoice touched by either the old or the new application
    // set — an invoice dropped from this payment needs its paymentStatus
    // pulled back down just as much as one newly added to it needs pushing up.
    const touchedInvoiceNos = new Set([
      ...(existing?.invoiceApplications || []).map((a) => a.invoiceNo).filter(Boolean),
      ...appData.map((a) => a.invoiceNo).filter(Boolean),
    ]);
    for (const invoiceNo of touchedInvoiceNos) {
      await syncPurchaseInvoicePaymentStatus(tx, invoiceNo);
    }
    await syncBankReconciliationTxn(tx, {
      bankAccount: updated.payFromAccount, voucherType: 'Payment', voucherNo: updated.paymentNo,
      txnDate: updated.paymentDate, type: 'Debit', amount: updated.paymentAmount,
      description: `Payment to ${updated.supplierName || 'supplier'}`, remarks: updated.notes,
      isActive: updated.status === 'Posted',
    });
    return updated;
  });
  res.json({ success: true, data: row });
}));

router.delete('/payables/payments/:id', auth(['admin']), asyncHandler(async (req, res) => {
  // PaymentInvoiceApplication.payment has onDelete: Cascade, so
  // applications go with it. If this payment was Posted, its effect on
  // SupplierOutstanding needs reversing first, or the deleted payment's
  // amount stays "applied" forever with no record of why the balance is low.
  await prisma.$transaction(async (tx) => {
    const existing = await tx.supplierPayment.findUnique({ where: { id: Number(req.params.id) }, include: supplierPaymentInclude });
    if (existing?.status === 'Posted') {
      await reverseSupplierOutstanding(tx, existing.invoiceApplications);
    }
    if (existing) {
      await syncBankReconciliationTxn(tx, {
        bankAccount: existing.payFromAccount, voucherNo: existing.paymentNo, isActive: false,
      });
    }
    await tx.supplierPayment.delete({ where: { id: Number(req.params.id) } });
    if (existing?.status === 'Posted') {
      for (const app of existing.invoiceApplications) {
        if (app.invoiceNo) await syncPurchaseInvoicePaymentStatus(tx, app.invoiceNo);
      }
    }
  });
  res.json({ success: true, message: 'Deleted successfully' });
}));

// Payment Register report — bespoke aggregation endpoint for the
// Reports > Payable > Payment Register page. Mirrors
// /receivables/collection-register/report's structure exactly
// (SupplierPayment/PaymentInvoiceApplication/Supplier stand in for
// Collection/CollectionInvoiceApplication/Customer). "Discount" has no
// backing column anywhere on SupplierPayment or PaymentInvoiceApplication
// — there's no discount-on-payment concept in this schema — so it's
// always 0, with "Net Paid" simply equal to Paid Amount as a result.
// "Payment Method", "Reference Type", "Show Cancelled Payments", and
// "Show Unreconciled Payments" are no-ops: the only payment
// classification on SupplierPayment is `paymentMode` (which has its own
// filter), there's no reference-type classification on
// instrumentNo, no "Cancelled" status value ever assigned to a
// SupplierPayment (only Draft/Posted), and no bank-reconciliation flag
// anywhere in this data model. "Branch" and "Currency" are no-ops for the
// same reason as the other reports.
router.get('/payables/payment-register/report', auth(), asyncHandler(async (req, res) => {
  const {
    fromDate, toDate, supplierGroup, supplier, paymentMode, include,
  } = req.query;

  const from = fromDate ? new Date(fromDate) : new Date(new Date().getFullYear(), new Date().getMonth(), 1);
  from.setHours(0, 0, 0, 0);
  const to = toDate ? new Date(toDate) : new Date();
  to.setHours(23, 59, 59, 999);

  const supplierWhere = { status: 'Active' };
  if (supplierGroup) supplierWhere.supplierType = supplierGroup;
  if (supplier) supplierWhere.supplierName = supplier;

  const suppliers = await prisma.supplier.findMany({ where: supplierWhere });
  const names = suppliers.map((s) => s.supplierName);
  const codeBySupplierName = Object.fromEntries(suppliers.map((s) => [s.supplierName, s.supplierCode]));

  let statusWhere = { in: ['Posted', 'Draft'] };
  if (include === 'Posted Only') statusWhere = 'Posted';
  else if (include === 'Draft Only') statusWhere = 'Draft';

  const paymentWhere = {
    paymentDate: { gte: from, lte: to },
    status: statusWhere,
  };
  if (names.length) paymentWhere.supplierName = { in: names };
  if (paymentMode) paymentWhere.paymentMode = paymentMode;

  const payments = names.length
    ? await prisma.supplierPayment.findMany({
      where: paymentWhere,
      include: { invoiceApplications: true },
      orderBy: { paymentDate: 'desc' },
    })
    : [];

  const rows = payments.map((p) => {
    let invoiceAmount = 0;
    let paidAmount = 0;
    if (p.invoiceApplications.length) {
      p.invoiceApplications.forEach((app) => {
        invoiceAmount += Number(app.totalAmount || 0);
        paidAmount += Number(app.amountApplied || 0);
      });
    } else {
      invoiceAmount = Number(p.paymentAmount || 0);
      paidAmount = Number(p.paymentAmount || 0);
    }
    const discount = 0;

    return {
      id: p.id,
      paymentNo: p.paymentNo,
      paymentDate: p.paymentDate,
      supplierCode: codeBySupplierName[p.supplierName] || '—',
      supplierName: p.supplierName || 'Unknown',
      paymentMode: p.paymentMode || '—',
      referenceNo: p.instrumentNo || '—',
      bankName: p.payFromAccount || '—',
      invoiceAmount,
      paymentAmount: paidAmount,
      discount,
      netPaid: paidAmount - discount,
      paidBy: p.paidBy || '—',
      status: p.status,
    };
  });

  const totals = rows.reduce((acc, r) => ({
    invoiceAmount: acc.invoiceAmount + r.invoiceAmount,
    paymentAmount: acc.paymentAmount + r.paymentAmount,
    discount: acc.discount + r.discount,
    netPaid: acc.netPaid + r.netPaid,
  }), { invoiceAmount: 0, paymentAmount: 0, discount: 0, netPaid: 0 });

  const totalPayments = totals.paymentAmount;
  const KNOWN_MODES = ['Cash', 'Cheque', 'Bank Transfer', 'UPI', 'NEFT', 'RTGS'];
  const cashAmount = rows.filter((r) => r.paymentMode === 'Cash').reduce((sum, r) => sum + r.paymentAmount, 0);
  const upiAmount = rows.filter((r) => r.paymentMode === 'UPI').reduce((sum, r) => sum + r.paymentAmount, 0);
  const bankAmount = Math.max(totalPayments - cashAmount - upiAmount, 0);

  // Payment by Payment Mode — donut over the exact payment mode values in
  // use (Top 5 + Others), across the full filtered set.
  const byModeValue = {};
  rows.forEach((r) => { byModeValue[r.paymentMode] = (byModeValue[r.paymentMode] || 0) + r.paymentAmount; });
  const modeEntries = Object.entries(byModeValue).sort((a, b) => b[1] - a[1]);
  const modeGrandTotal = totalPayments || 1;
  const top5Modes = modeEntries.slice(0, 5);
  const othersModeValue = modeEntries.slice(5).reduce((sum, [, v]) => sum + v, 0);
  const paymentByPaymentMode = [
    ...top5Modes.map(([name, value]) => ({ name, value: Math.round(value), percent: Math.round((value / modeGrandTotal) * 1000) / 10 })),
    ...(othersModeValue > 0 ? [{ name: 'Others', value: Math.round(othersModeValue), percent: Math.round((othersModeValue / modeGrandTotal) * 1000) / 10 }] : []),
  ];

  // Payment Trend (Last 7 Days) — always the 7 calendar days ending at
  // `to`, regardless of the selected Period Range preset, queried
  // independently of `rows` so a short period range doesn't truncate it —
  // same approach as Collection Register's trend chart.
  const trendDays = [];
  for (let i = 6; i >= 0; i -= 1) {
    const d = new Date(to);
    d.setDate(d.getDate() - i);
    d.setHours(0, 0, 0, 0);
    trendDays.push(d);
  }
  const trendFrom = trendDays[0];
  const trendWhere = { paymentDate: { gte: trendFrom, lte: to }, status: statusWhere };
  if (names.length) trendWhere.supplierName = { in: names };
  if (paymentMode) trendWhere.paymentMode = paymentMode;
  const trendPayments = names.length
    ? await prisma.supplierPayment.findMany({ where: trendWhere, select: { paymentDate: true, paymentAmount: true } })
    : [];
  const pad2 = (n) => String(n).padStart(2, '0');
  const paymentTrend = trendDays.map((d) => {
    const dayTotal = trendPayments
      .filter((r) => r.paymentDate && new Date(r.paymentDate).toDateString() === d.toDateString())
      .reduce((sum, r) => sum + Number(r.paymentAmount || 0), 0);
    return { name: `${pad2(d.getDate())}/${pad2(d.getMonth() + 1)}`, value: Math.round(dayTotal) };
  });

  // Top 5 Suppliers by Payment.
  const bySupplierValue = {};
  rows.forEach((r) => { bySupplierValue[r.supplierName] = (bySupplierValue[r.supplierName] || 0) + r.paymentAmount; });
  const top5SuppliersByPayment = Object.entries(bySupplierValue).sort((a, b) => b[1] - a[1]).slice(0, 5)
    .map(([name, value]) => ({ name, value: Math.round(value) }));

  res.json({
    success: true,
    data: {
      rows,
      totals,
      stats: {
        totalPayments,
        totalPaymentTransactions: rows.length,
        suppliersPaid: new Set(rows.map((r) => r.supplierName)).size,
        bankAmount,
        cashAmount,
        upiAmount,
      },
      paymentByPaymentMode,
      paymentTrend,
      top5SuppliersByPayment,
    },
  });
}));

// Payment Receipt ("Incoming Payment") -- a master/detail resource
// (PaymentReceipt has many PaymentReceiptApplication rows), same
// bespoke-route pattern as Collection/SupplierPayment above. Unlike those
// two (each locked to one party type), a Payment Receipt posts against a
// Customer, a Vendor, or a raw Chart-Of-Accounts Account, chosen via
// partyType -- so which open-item ledger (if any) it settles through is
// resolved per-record rather than fixed at mount time. Customer/Vendor
// receipts reuse the exact same customerLedger/supplierLedger instances
// Collection/SupplierPayment already use, so apply/reverse stays a single
// shared implementation. An Account party type, and any receipt with
// paymentOnAccount checked, never touch CustomerOutstanding/
// SupplierOutstanding at all -- there is no advance/GL-journal table in this
// schema for either case to post against, so those receipts are simply
// recorded with no ledger side effects.
const paymentReceiptInclude = { applications: { orderBy: { id: 'asc' } } };

function toPaymentReceiptApplicationData(app) {
  return {
    invoiceNo: app.invoiceNo || null,
    invoiceDate: app.invoiceDate || null,
    dueDate: app.dueDate || null,
    totalAmount: app.totalAmount != null ? Number(app.totalAmount) : 0,
    outstandingAtTimeOfApplication: app.outstandingAtTimeOfApplication != null ? Number(app.outstandingAtTimeOfApplication) : 0,
    amountApplied: app.amountApplied != null ? Number(app.amountApplied) : 0,
  };
}

/** Which open-item ledger (if any) a Payment Receipt settles through. */
function ledgerForPaymentReceipt(row) {
  if (row.paymentOnAccount) return null;
  if (row.partyType === 'Customer') return customerLedger;
  if (row.partyType === 'Vendor') return supplierLedger;
  return null; // 'Account' has no open-item ledger to settle against.
}

/** Which invoice/paymentStatus cascade (if any) a Payment Receipt feeds. */
function paymentStatusSyncFor(row) {
  if (row.partyType === 'Customer') return syncSalesInvoicePaymentStatus;
  if (row.partyType === 'Vendor') return syncPurchaseInvoicePaymentStatus;
  return null;
}

router.get('/banking/payment-receipts', auth(), asyncHandler(async (req, res) => {
  const { q } = req.query;
  const where = q
    ? {
        OR: [
          { paymentReceiptNo: { contains: q } },
          { partyName: { contains: q } },
        ],
      }
    : undefined;
  const rows = await prisma.paymentReceipt.findMany({ where, include: paymentReceiptInclude, orderBy: { id: 'desc' } });
  res.json({ success: true, data: rows });
}));

router.get('/banking/payment-receipts/:id', auth(), asyncHandler(async (req, res) => {
  const row = await prisma.paymentReceipt.findUnique({ where: { id: Number(req.params.id) }, include: paymentReceiptInclude });
  if (!row) return res.status(404).json({ success: false, message: 'Record not found' });
  res.json({ success: true, data: row });
}));

router.post('/banking/payment-receipts', auth(), asyncHandler(async (req, res) => {
  const { applications = [], ...rawHeader } = req.body;
  // `roundOff` is a plain user-typed figure here (there's nothing to compute
  // it from, unlike the tax-rounding use of the same column name on
  // Sales/Purchase documents), so it has to be let through explicitly —
  // same reason Cheque's `amount` is allowed through below.
  const header = sanitizeHeader(rawHeader, { allow: ['roundOff'], alsoBlock: ['appliedAmount', 'openBalance'] });
  // An Account party has no outstanding invoices to apply against, and
  // Payment on Account is explicitly "don't settle anything" — either way
  // the applications the client sent are ignored rather than saved.
  const appData = (header.partyType === 'Account' || header.paymentOnAccount)
    ? []
    : applications.map(toPaymentReceiptApplicationData);
  const appliedAmount = round2(appData.reduce((sum, a) => sum + Number(a.amountApplied || 0), 0));
  const openBalance = round2(Number(header.totalAmountDue || 0) - appliedAmount - Number(header.roundOff || 0));

  const row = await prisma.$transaction(async (tx) => {
    // paymentReceiptNo comes from the configured IP (Payment Receipt)
    // numbering series rather than free text — see resolveDocumentNumber
    // above.
    const { documentNumber, syncManual } = await resolveDocumentNumber('IP', header.paymentReceiptNo, tx);
    const created = await tx.paymentReceipt.create({
      data: { ...header, paymentReceiptNo: documentNumber, appliedAmount, openBalance, applications: { create: appData } },
      include: paymentReceiptInclude,
    });
    if (syncManual) await syncManual();

    const ledger = ledgerForPaymentReceipt(created);
    if (created.status === 'Posted' && ledger) {
      // Validate before applying — a receipt that over-settles is rejected
      // outright rather than partially posted, same rule as Collection/
      // SupplierPayment.
      await ledger.assertApplicationsValid(tx, appData, {
        paymentAmount: created.totalAmountDue,
        partyName: created.partyName,
      });
      await ledger.apply(tx, appData);
      const syncStatus = paymentStatusSyncFor(created);
      if (syncStatus) {
        for (const app of appData) {
          if (app.invoiceNo) await syncStatus(tx, app.invoiceNo);
        }
      }
    }
    // Dr Cash/Bank / Cr the party's control account. Valued at appliedAmount
    // -- what actually settled against the ledger. See utils/glPosting.js.
    await syncJournalEntry(tx, {
      sourceType: JOURNAL_SOURCE_TYPES.PAYMENT_RECEIPT,
      sourceDocNo: created.paymentReceiptNo,
      status: created.status,
      doc: created,
    });
    return created;
  });
  res.status(201).json({ success: true, data: row });
}));

router.put('/banking/payment-receipts/:id', auth(), asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  const { applications = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader, { allow: ['roundOff'], alsoBlock: ['appliedAmount', 'openBalance'] });
  const appData = (header.partyType === 'Account' || header.paymentOnAccount)
    ? []
    : applications.map(toPaymentReceiptApplicationData);
  const appliedAmount = round2(appData.reduce((sum, a) => sum + Number(a.amountApplied || 0), 0));
  const openBalance = round2(Number(header.totalAmountDue || 0) - appliedAmount - Number(header.roundOff || 0));

  // Replace the applied-invoice set wholesale on every save -- simpler and
  // safer than diffing which rows were added/removed/edited client-side.
  const row = await prisma.$transaction(async (tx) => {
    // If this receipt was already Posted before this save (against whatever
    // party type it had *then*), reverse that first — using the OLD row's
    // ledger, not the new one, since partyType/paymentOnAccount may have
    // changed on this very save.
    const existing = await tx.paymentReceipt.findUnique({ where: { id }, include: paymentReceiptInclude });
    if (existing?.status === 'Posted') {
      const existingLedger = ledgerForPaymentReceipt(existing);
      if (existingLedger) await existingLedger.reverse(tx, existing.applications);
    }
    await tx.paymentReceiptApplication.deleteMany({ where: { paymentReceiptId: id } });
    const updated = await tx.paymentReceipt.update({
      where: { id },
      data: { ...header, appliedAmount, openBalance, applications: { create: appData } },
      include: paymentReceiptInclude,
    });

    const ledger = ledgerForPaymentReceipt(updated);
    if (updated.status === 'Posted' && ledger) {
      await ledger.assertApplicationsValid(tx, appData, {
        paymentAmount: updated.totalAmountDue,
        partyName: updated.partyName,
      });
      await ledger.apply(tx, appData);
    }
    // Sync every invoice touched by either the old or the new application
    // set — one dropped from this receipt needs its paymentStatus pulled
    // back down just as much as one newly added needs pushing up. Uses the
    // NEW row's party type, since an invoice can only belong to one side.
    const syncStatus = paymentStatusSyncFor(updated);
    if (syncStatus) {
      const touchedInvoiceNos = new Set([
        ...(existing?.applications || []).map((a) => a.invoiceNo).filter(Boolean),
        ...appData.map((a) => a.invoiceNo).filter(Boolean),
      ]);
      for (const invoiceNo of touchedInvoiceNos) {
        await syncStatus(tx, invoiceNo);
      }
    }
    // Rebuild the accounting document from what this receipt now says -- a
    // receipt pulled back to Draft loses its ledger entry entirely.
    await syncJournalEntry(tx, {
      sourceType: JOURNAL_SOURCE_TYPES.PAYMENT_RECEIPT,
      sourceDocNo: updated.paymentReceiptNo,
      status: updated.status,
      doc: updated,
    });
    return updated;
  });
  res.json({ success: true, data: row });
}));

router.delete('/banking/payment-receipts/:id', auth(['admin']), asyncHandler(async (req, res) => {
  // Deleting the document deletes its accounting document too -- a
  // ledger entry for a document that no longer exists is worse than no
  // entry at all. See reverseJournalEntry in utils/glPosting.js.
  await removeJournalEntryForDocument(
    prisma, JOURNAL_SOURCE_TYPES.PAYMENT_RECEIPT, 'paymentReceipt', 'paymentReceiptNo', Number(req.params.id)
  );
  // PaymentReceiptApplication.paymentReceipt has onDelete: Cascade, so
  // applications go with it. If this receipt was Posted, its effect on the
  // relevant ledger needs reversing first, or the deleted receipt's amount
  // stays "applied" forever with no record of why the balance is low.
  await prisma.$transaction(async (tx) => {
    const existing = await tx.paymentReceipt.findUnique({ where: { id: Number(req.params.id) }, include: paymentReceiptInclude });
    if (existing?.status === 'Posted') {
      const ledger = ledgerForPaymentReceipt(existing);
      if (ledger) await ledger.reverse(tx, existing.applications);
    }
    await tx.paymentReceipt.delete({ where: { id: Number(req.params.id) } });
    if (existing?.status === 'Posted') {
      const syncStatus = paymentStatusSyncFor(existing);
      if (syncStatus) {
        for (const app of existing.applications) {
          if (app.invoiceNo) await syncStatus(tx, app.invoiceNo);
        }
      }
    }
  });
  res.json({ success: true, message: 'Deleted successfully' });
}));

// Payment Voucher ("Outgoing Payment") -- a master/detail resource
// (PaymentVoucher has many PaymentVoucherApplication rows), the outgoing
// counterpart to Payment Receipt above. Only Vendor and Account party types
// exist here — there is no "pay a customer" concept — so Vendor settles
// through the very same supplierLedger Payment Entry/Payment Receipt already
// use, and Account (or any voucher with paymentOnAccount checked) never
// touches SupplierOutstanding at all, for the same reason Payment Receipt's
// Account/paymentOnAccount path doesn't.
const paymentVoucherInclude = { applications: { orderBy: { id: 'asc' } } };

function toPaymentVoucherApplicationData(app) {
  return {
    invoiceNo: app.invoiceNo || null,
    invoiceDate: app.invoiceDate || null,
    dueDate: app.dueDate || null,
    totalAmount: app.totalAmount != null ? Number(app.totalAmount) : 0,
    outstandingAtTimeOfApplication: app.outstandingAtTimeOfApplication != null ? Number(app.outstandingAtTimeOfApplication) : 0,
    amountApplied: app.amountApplied != null ? Number(app.amountApplied) : 0,
  };
}

/** Which open-item ledger (if any) a Payment Voucher settles through. */
function ledgerForPaymentVoucher(row) {
  if (row.paymentOnAccount) return null;
  if (row.partyType === 'Vendor') return supplierLedger;
  return null; // 'Account' has no open-item ledger to settle against.
}

router.get('/banking/payment-vouchers', auth(), asyncHandler(async (req, res) => {
  const { q } = req.query;
  const where = q
    ? {
        OR: [
          { paymentVoucherNo: { contains: q } },
          { partyName: { contains: q } },
        ],
      }
    : undefined;
  const rows = await prisma.paymentVoucher.findMany({ where, include: paymentVoucherInclude, orderBy: { id: 'desc' } });
  res.json({ success: true, data: rows });
}));

router.get('/banking/payment-vouchers/:id', auth(), asyncHandler(async (req, res) => {
  const row = await prisma.paymentVoucher.findUnique({ where: { id: Number(req.params.id) }, include: paymentVoucherInclude });
  if (!row) return res.status(404).json({ success: false, message: 'Record not found' });
  res.json({ success: true, data: row });
}));

router.post('/banking/payment-vouchers', auth(), asyncHandler(async (req, res) => {
  const { applications = [], ...rawHeader } = req.body;
  // `roundOff` is a plain user-typed figure here, same reasoning as Payment
  // Receipt's POST above.
  const header = sanitizeHeader(rawHeader, { allow: ['roundOff'], alsoBlock: ['appliedAmount', 'openBalance'] });
  // An Account party has no outstanding invoices to apply against, and
  // Payment on Account is explicitly "don't settle anything".
  const appData = (header.partyType === 'Account' || header.paymentOnAccount)
    ? []
    : applications.map(toPaymentVoucherApplicationData);
  const appliedAmount = round2(appData.reduce((sum, a) => sum + Number(a.amountApplied || 0), 0));
  const openBalance = round2(Number(header.totalDue || 0) - appliedAmount - Number(header.roundOff || 0));

  const row = await prisma.$transaction(async (tx) => {
    // paymentVoucherNo comes from the configured OP (Payment Voucher)
    // numbering series rather than free text — see resolveDocumentNumber
    // above.
    const { documentNumber, syncManual } = await resolveDocumentNumber('OP', header.paymentVoucherNo, tx);
    const created = await tx.paymentVoucher.create({
      data: { ...header, paymentVoucherNo: documentNumber, appliedAmount, openBalance, applications: { create: appData } },
      include: paymentVoucherInclude,
    });
    if (syncManual) await syncManual();

    const ledger = ledgerForPaymentVoucher(created);
    if (created.status === 'Posted' && ledger) {
      // Validate before applying — a voucher that over-settles is rejected
      // outright rather than partially posted, same rule as Payment Entry/
      // Payment Receipt.
      await ledger.assertApplicationsValid(tx, appData, {
        paymentAmount: created.totalDue,
        partyName: created.partyName,
      });
      await ledger.apply(tx, appData);
      for (const app of appData) {
        if (app.invoiceNo) await syncPurchaseInvoicePaymentStatus(tx, app.invoiceNo);
      }
    }
    // Dr the party's control account / Cr Cash/Bank. See utils/glPosting.js.
    await syncJournalEntry(tx, {
      sourceType: JOURNAL_SOURCE_TYPES.PAYMENT_VOUCHER,
      sourceDocNo: created.paymentVoucherNo,
      status: created.status,
      doc: created,
    });
    return created;
  });
  res.status(201).json({ success: true, data: row });
}));

router.put('/banking/payment-vouchers/:id', auth(), asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  const { applications = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader, { allow: ['roundOff'], alsoBlock: ['appliedAmount', 'openBalance'] });
  const appData = (header.partyType === 'Account' || header.paymentOnAccount)
    ? []
    : applications.map(toPaymentVoucherApplicationData);
  const appliedAmount = round2(appData.reduce((sum, a) => sum + Number(a.amountApplied || 0), 0));
  const openBalance = round2(Number(header.totalDue || 0) - appliedAmount - Number(header.roundOff || 0));

  // Replace the applied-invoice set wholesale on every save -- simpler and
  // safer than diffing which rows were added/removed/edited client-side.
  const row = await prisma.$transaction(async (tx) => {
    // If this voucher was already Posted before this save (against whatever
    // party type it had *then*), reverse that first — using the OLD row's
    // ledger, not the new one, since partyType/paymentOnAccount may have
    // changed on this very save.
    const existing = await tx.paymentVoucher.findUnique({ where: { id }, include: paymentVoucherInclude });
    if (existing?.status === 'Posted') {
      const existingLedger = ledgerForPaymentVoucher(existing);
      if (existingLedger) await existingLedger.reverse(tx, existing.applications);
    }
    await tx.paymentVoucherApplication.deleteMany({ where: { paymentVoucherId: id } });
    const updated = await tx.paymentVoucher.update({
      where: { id },
      data: { ...header, appliedAmount, openBalance, applications: { create: appData } },
      include: paymentVoucherInclude,
    });

    const ledger = ledgerForPaymentVoucher(updated);
    if (updated.status === 'Posted' && ledger) {
      await ledger.assertApplicationsValid(tx, appData, {
        paymentAmount: updated.totalDue,
        partyName: updated.partyName,
      });
      await ledger.apply(tx, appData);
    }
    // Sync every invoice touched by either the old or the new application
    // set — one dropped from this voucher needs its paymentStatus pulled
    // back down just as much as one newly added needs pushing up.
    const touchedInvoiceNos = new Set([
      ...(existing?.applications || []).map((a) => a.invoiceNo).filter(Boolean),
      ...appData.map((a) => a.invoiceNo).filter(Boolean),
    ]);
    for (const invoiceNo of touchedInvoiceNos) {
      await syncPurchaseInvoicePaymentStatus(tx, invoiceNo);
    }
    // Rebuild the accounting document from what this voucher now says.
    await syncJournalEntry(tx, {
      sourceType: JOURNAL_SOURCE_TYPES.PAYMENT_VOUCHER,
      sourceDocNo: updated.paymentVoucherNo,
      status: updated.status,
      doc: updated,
    });
    return updated;
  });
  res.json({ success: true, data: row });
}));

router.delete('/banking/payment-vouchers/:id', auth(['admin']), asyncHandler(async (req, res) => {
  // Deleting the document deletes its accounting document too -- a
  // ledger entry for a document that no longer exists is worse than no
  // entry at all. See reverseJournalEntry in utils/glPosting.js.
  await removeJournalEntryForDocument(
    prisma, JOURNAL_SOURCE_TYPES.PAYMENT_VOUCHER, 'paymentVoucher', 'paymentVoucherNo', Number(req.params.id)
  );
  // PaymentVoucherApplication.paymentVoucher has onDelete: Cascade, so
  // applications go with it. If this voucher was Posted, its effect on
  // SupplierOutstanding needs reversing first, or the deleted voucher's
  // amount stays "applied" forever with no record of why the balance is low.
  await prisma.$transaction(async (tx) => {
    const existing = await tx.paymentVoucher.findUnique({ where: { id: Number(req.params.id) }, include: paymentVoucherInclude });
    if (existing?.status === 'Posted') {
      const ledger = ledgerForPaymentVoucher(existing);
      if (ledger) await ledger.reverse(tx, existing.applications);
    }
    await tx.paymentVoucher.delete({ where: { id: Number(req.params.id) } });
    if (existing?.status === 'Posted') {
      for (const app of existing.applications) {
        if (app.invoiceNo) await syncPurchaseInvoicePaymentStatus(tx, app.invoiceNo);
      }
    }
  });
  res.json({ success: true, message: 'Deleted successfully' });
}));

// Banking
// Deposit Entry -- a master/detail resource (BankDeposit has many
// DepositItem rows), same bespoke-route pattern as Payment Entry above
// (mirrors crudRouter's URL/method/response shape so the frontend keeps
// using the generic bankDepositApi from createCrudApi). Replaces the old
// flat crudRouter(prisma.bankDeposit, ...) mount now that the model has a
// nested line-items collection.
const bankDepositInclude = { items: { orderBy: { id: 'asc' } } };

function toDepositItemData(item) {
  return {
    paymentMode: item.paymentMode || null,
    instrumentNo: item.instrumentNo || null,
    instrumentDate: item.instrumentDate || null,
    accountDescription: item.accountDescription || null,
    amount: round2(item.amount != null ? Number(item.amount) : 0),
  };
}

/**
 * Reject a deposit line for a negative amount.
 *
 * A deposit slip records money going *into* the bank; a negative line is not a
 * withdrawal, it is a data-entry error. The form already blocks the minus key
 * and the Zod schema rejects it, but neither of those protects the API — and
 * the deposit total now feeds the Cash Book, Bank Book and Day Book balances,
 * so a negative line posted directly would quietly understate the bank
 * position rather than failing visibly.
 *
 * A zero line is allowed: a slip can legitimately carry a placeholder row that
 * has not been filled in yet.
 */
function assertNonNegativeDepositItems(items) {
  const offending = items
    .map((item, index) => ({ index, amount: Number(item.amount) || 0 }))
    .filter((row) => row.amount < 0)
    .map((row) => `line ${row.index + 1} (${row.amount.toFixed(2)})`);

  if (offending.length) {
    const err = new Error(
      `A deposit amount cannot be negative — ${offending.join(', ')}.`
    );
    err.status = 400;
    throw err;
  }
}

// The term-deposit fields arrive as strings from the form (or as '' when
// left blank on a non-term deposit), and Prisma's Decimal columns reject
// both — normalise them to a number or null before they reach the header
// spread.
function toBankDepositHeaderData(header) {
  const blankToNull = (v) => (v === '' || v == null ? null : v);
  const numberOrNull = (v) => {
    const n = blankToNull(v);
    return n == null || Number.isNaN(Number(n)) ? null : Number(n);
  };
  return {
    ...header,
    interestRate: numberOrNull(header.interestRate),
    maturityDate: blankToNull(header.maturityDate),
    maturityAmount: numberOrNull(header.maturityAmount),
  };
}

router.get('/banking/deposits', auth(), asyncHandler(async (req, res) => {
  const { q } = req.query;
  const where = q
    ? {
        OR: [
          { depositNo: { contains: q } },
          { depositTo: { contains: q } },
          { receivedFrom: { contains: q } },
        ],
      }
    : undefined;
  const rows = await prisma.bankDeposit.findMany({ where, include: bankDepositInclude, orderBy: { id: 'desc' } });
  res.json({ success: true, data: rows });
}));

router.get('/banking/deposits/:id', auth(), asyncHandler(async (req, res) => {
  const row = await prisma.bankDeposit.findUnique({ where: { id: Number(req.params.id) }, include: bankDepositInclude });
  if (!row) return res.status(404).json({ success: false, message: 'Record not found' });
  res.json({ success: true, data: row });
}));

router.post('/banking/deposits', auth(), asyncHandler(async (req, res) => {
  const { items = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  const itemData = items.map(toDepositItemData);
  assertNonNegativeDepositItems(itemData);
  const totalDepositAmount = round2(itemData.reduce((sum, i) => sum + Number(i.amount || 0), 0));

  const row = await prisma.$transaction(async (tx) => {
    // depositNo now comes from the configured DEP numbering series rather
    // than free text — see resolveDocumentNumber above.
    const { documentNumber, syncManual } = await resolveDocumentNumber('DEP', header.depositNo, tx);
    const created = await tx.bankDeposit.create({
      data: { ...header, depositNo: documentNumber, totalDepositAmount, items: { create: itemData } },
      include: bankDepositInclude,
    });
    if (syncManual) await syncManual();
    await syncBankReconciliationTxn(tx, {
      bankAccount: created.depositTo, voucherType: 'Deposit', voucherNo: created.depositNo,
      txnDate: created.depositDate, type: 'Credit', amount: created.totalDepositAmount,
      description: `Deposit from ${created.receivedFrom || 'deposit'}`, remarks: created.remarks,
      isActive: created.status === 'Posted',
    });
    return created;
  });
  res.status(201).json({ success: true, data: row });
}));

router.put('/banking/deposits/:id', auth(), asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  const { items = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader);
  const itemData = items.map(toDepositItemData);
  assertNonNegativeDepositItems(itemData);
  const totalDepositAmount = round2(itemData.reduce((sum, i) => sum + Number(i.amount || 0), 0));
  // Replace the deposit-item set wholesale on every save -- simpler and
  // safer than diffing which rows were added/removed/edited client-side.
  const row = await prisma.$transaction(async (tx) => {
    await tx.depositItem.deleteMany({ where: { depositId: id } });
    const updated = await tx.bankDeposit.update({
      where: { id },
      data: { ...toBankDepositHeaderData(header), totalDepositAmount, items: { create: itemData } },
      include: bankDepositInclude,
    });
    await syncBankReconciliationTxn(tx, {
      bankAccount: updated.depositTo, voucherType: 'Deposit', voucherNo: updated.depositNo,
      txnDate: updated.depositDate, type: 'Credit', amount: updated.totalDepositAmount,
      description: `Deposit from ${updated.receivedFrom || 'deposit'}`, remarks: updated.remarks,
      isActive: updated.status === 'Posted',
    });
    return updated;
  });
  res.json({ success: true, data: row });
}));

router.delete('/banking/deposits/:id', auth(['admin']), asyncHandler(async (req, res) => {
  // DepositItem.deposit has onDelete: Cascade, so items go with it.
  await prisma.$transaction(async (tx) => {
    const existing = await tx.bankDeposit.findUnique({ where: { id: Number(req.params.id) } });
    if (existing) {
      await syncBankReconciliationTxn(tx, {
        bankAccount: existing.depositTo, voucherNo: existing.depositNo, isActive: false,
      });
    }
    await tx.bankDeposit.delete({ where: { id: Number(req.params.id) } });
  });
  res.json({ success: true, message: 'Deleted successfully' });
}));
// Auto-creates/updates/removes a source: 'System' BankReconciliationTransaction
// row whenever a BankDeposit/Collection/SupplierPayment/Cheque is saved
// against a bank account. Without this, Bank Reconciliation's System
// Transactions side never reflected anything the app actually did — it was
// pure manual entry, disconnected from every real Deposit/Collection/Payment/
// Cheque. One growing BankReconciliation master row per bank account (the
// most recently created one for that account, or a freshly-created one if
// none exists yet) accumulates these lines; a real, separate reconciliation
// workflow would let the user close/roll a period, but this app has no such
// concept, so all system activity for an account lands on its single running
// master row. Bank-statement ('Bank' source) lines are still entered/matched
// manually on the Bank Reconciliation page — this only ever touches
// source: 'System' rows, identified by voucherNo (so re-saving the same
// voucher updates its existing line instead of duplicating it, and whatever
// Match/Unmatch status the user already set is left alone).
async function syncBankReconciliationTxn(tx, { bankAccount, voucherType, voucherNo, txnDate, type, amount, description, remarks, isActive }) {
  if (!bankAccount || !voucherNo) return;

  // Find this voucher's existing system line anywhere on this bank account,
  // not just in the newest reconciliation.
  //
  // The lookup used to be scoped to whichever reconciliation had the highest
  // id, which caused two distinct faults. Editing a receipt recorded during an
  // earlier reconciliation did not find its line, so a second one was created
  // and the voucher appeared twice. And unposting or deleting that receipt
  // deleted nothing, leaving an orphan system line that could never be matched
  // against anything on the statement.
  const existing = await tx.bankReconciliationTransaction.findFirst({
    where: { source: 'System', voucherNo, reconciliation: { bankAccount } },
    include: { reconciliation: true },
    orderBy: { id: 'desc' },
  });

  if (!isActive) {
    if (existing) await tx.bankReconciliationTransaction.delete({ where: { id: existing.id } });
    return;
  }

  // A completed reconciliation is a signed-off statement of a closed period.
  // Injecting a new line into it — which is what happened whenever the newest
  // reconciliation happened to be finished — silently restates work someone
  // has already agreed. New activity belongs in an open reconciliation.
  let recon = existing?.reconciliation
    ?? await tx.bankReconciliation.findFirst({
      where: { bankAccount, status: { not: 'Completed' } },
      orderBy: { id: 'desc' },
    });

  if (!recon) {
    recon = await tx.bankReconciliation.create({
      data: {
        bankAccount, statementDate: txnDate || new Date(), reconciliationDate: txnDate || new Date(),
        openingBalance: 0, status: 'In Progress',
      },
    });
  }

  // Never rewrite a line that has already been reconciled against the bank
  // statement; the underlying voucher changing after sign-off is an exception
  // a human has to look at, not something to paper over silently.
  if (existing && existing.status === 'Reconciled') return;

  const data = {
    source: 'System', txnDate: txnDate || null, description: description || null,
    voucherType: voucherType || null, voucherNo, type: type || null,
    amount: Number(amount) || 0, remarks: remarks || null,
  };
  if (existing) {
    await tx.bankReconciliationTransaction.update({ where: { id: existing.id }, data });
  } else {
    await tx.bankReconciliationTransaction.create({ data: { ...data, reconciliationId: recon.id, status: 'Unreconciled' } });
  }
}

// Bank Reconciliation -- a master/detail resource (BankReconciliation has
// many BankReconciliationTransaction rows), same bespoke-route pattern as
// Deposit Entry above. The page's Match/Unmatch/Auto Match actions persist
// by PUT-ing the whole transactions array back with updated statuses.
const bankReconciliationInclude = { transactions: { orderBy: [{ txnDate: 'asc' }, { id: 'asc' }] } };

function toReconciliationTxnData(txn) {
  return {
    source: txn.source || null,
    txnDate: txn.txnDate || null,
    description: txn.description || null,
    refNo: txn.refNo || null,
    voucherType: txn.voucherType || null,
    voucherNo: txn.voucherNo || null,
    type: txn.type || null,
    amount: txn.amount != null ? Number(txn.amount) : 0,
    remarks: txn.remarks || null,
    status: txn.status || 'Unreconciled',
  };
}

router.get('/banking/reconciliations', auth(), asyncHandler(async (req, res) => {
  const { q } = req.query;
  const where = q
    ? { OR: [{ bankAccount: { contains: q } }] }
    : undefined;
  const rows = await prisma.bankReconciliation.findMany({ where, include: bankReconciliationInclude, orderBy: { id: 'desc' } });
  res.json({ success: true, data: rows });
}));

router.get('/banking/reconciliations/:id', auth(), asyncHandler(async (req, res) => {
  const row = await prisma.bankReconciliation.findUnique({ where: { id: Number(req.params.id) }, include: bankReconciliationInclude });
  if (!row) return res.status(404).json({ success: false, message: 'Record not found' });
  res.json({ success: true, data: row });
}));

router.post('/banking/reconciliations', auth(), asyncHandler(async (req, res) => {
  const { transactions = [], ...header } = req.body;
  const row = await prisma.bankReconciliation.create({
    data: { ...header, transactions: { create: transactions.map(toReconciliationTxnData) } },
    include: bankReconciliationInclude,
  });
  res.status(201).json({ success: true, data: row });
}));

router.put('/banking/reconciliations/:id', auth(), asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  const { transactions = [], ...header } = req.body;
  // Replace the transaction set wholesale on every save -- simpler and
  // safer than diffing which rows were matched/unmatched client-side.
  const row = await prisma.$transaction(async (tx) => {
    await tx.bankReconciliationTransaction.deleteMany({ where: { reconciliationId: id } });
    return tx.bankReconciliation.update({
      where: { id },
      data: { ...header, transactions: { create: transactions.map(toReconciliationTxnData) } },
      include: bankReconciliationInclude,
    });
  });
  res.json({ success: true, data: row });
}));

router.delete('/banking/reconciliations/:id', auth(['admin']), asyncHandler(async (req, res) => {
  // BankReconciliationTransaction.reconciliation has onDelete: Cascade.
  await prisma.bankReconciliation.delete({ where: { id: Number(req.params.id) } });
  res.json({ success: true, message: 'Deleted successfully' });
}));
// Cheque Print -- a master/detail resource (Cheque has many
// ChequeInvoiceApplication rows), same bespoke-route pattern as the other
// banking resources above.
const chequeInclude = { invoiceApplications: { orderBy: { id: 'asc' } } };

// A cheque settles the invoices listed on it. Previously it recorded an
// amountToPay per invoice and then did nothing with it — paying a supplier by
// cheque left the debt standing in full.
//
// Settlement follows the instrument, not the keystroke: a cheque only clears
// the debt once it has actually been issued. While it is Pending it is a
// draft, and if it is Cancelled or Bounced the settlement is reversed and the
// supplier is owed the money again.
/**
 * The party a cheque pays, for settlement purposes.
 *
 * The Cheque Print form captures the payee as `payTo` and has no separate
 * supplier field, so `supplierName` arrived null on every cheque and the
 * ledger's "does this invoice belong to the party paying" check silently did
 * nothing — the same defect that was fixed for collections and payments, and
 * which would have been reintroduced here. Falling back to `payTo` restores
 * the guard without asking the user to key the party twice.
 *
 * `payTo` can name a customer as well as a supplier (a refund cheque). That is
 * fine: the settlement lookup simply finds no supplier invoice under that
 * name, and a cheque with no applications settles nothing either way.
 */
const chequeParty = (header) => header.supplierName || header.payTo || null;

const CHEQUE_SETTLING_STATUSES = ['Printed', 'Issued', 'Presented', 'Cleared'];
const chequeSettles = (status) => CHEQUE_SETTLING_STATUSES.includes(status);

// The ledger keys applications by amountApplied; the cheque model calls the
// same figure amountToPay.
const chequeApplicationsForLedger = (apps) =>
  (apps || []).map((a) => ({ invoiceNo: a.invoiceNo, amountApplied: Number(a.amountToPay) || 0 }));

function toChequeApplicationData(app) {
  return {
    invoiceNo: app.invoiceNo || null,
    invoiceDate: app.invoiceDate || null,
    dueDate: app.dueDate || null,
    totalAmount: app.totalAmount != null ? Number(app.totalAmount) : 0,
    outstanding: app.outstanding != null ? Number(app.outstanding) : 0,
    amountToPay: app.amountToPay != null ? Number(app.amountToPay) : 0,
  };
}

router.get('/banking/cheques', auth(), asyncHandler(async (req, res) => {
  const { q } = req.query;
  const where = q
    ? {
        OR: [
          { chequeNo: { contains: q } },
          { payTo: { contains: q } },
          { bankAccount: { contains: q } },
        ],
      }
    : undefined;
  const rows = await prisma.cheque.findMany({ where, include: chequeInclude, orderBy: { id: 'desc' } });
  res.json({ success: true, data: rows });
}));

router.get('/banking/cheques/:id', auth(), asyncHandler(async (req, res) => {
  const row = await prisma.cheque.findUnique({ where: { id: Number(req.params.id) }, include: chequeInclude });
  if (!row) return res.status(404).json({ success: false, message: 'Record not found' });
  res.json({ success: true, data: row });
}));

router.post('/banking/cheques', auth(), asyncHandler(async (req, res) => {
  const { invoiceApplications = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader, { allow: ['amount'] });  // `amount` is the face value typed on the cheque, not a computed
  // total — it is the one document where that field is user input.
  const row = await prisma.$transaction(async (tx) => {
    // chequeNo now comes from the configured CHQ numbering series rather
    // than free text — see resolveDocumentNumber above.
    const { documentNumber, syncManual } = await resolveDocumentNumber('CHQ', header.chequeNo, tx);
    const appData = invoiceApplications.map(toChequeApplicationData);
    const totalAppliedAmount = round2(appData.reduce((sum, a) => sum + (Number(a.amountToPay) || 0), 0));
    const created = await tx.cheque.create({
      data: {
        ...header, chequeNo: documentNumber, supplierName: chequeParty(header),
        totalAppliedAmount, invoiceApplications: { create: appData },
      },
      include: chequeInclude,
    });
    if (syncManual) await syncManual();
    if (chequeSettles(created.status)) {
      const ledgerApps = chequeApplicationsForLedger(appData);
      await supplierLedger.assertApplicationsValid(tx, ledgerApps, {
        paymentAmount: created.amount, partyName: created.supplierName,
      });
      await applyToSupplierOutstanding(tx, ledgerApps);
      for (const app of ledgerApps) {
        if (app.invoiceNo) await syncPurchaseInvoicePaymentStatus(tx, app.invoiceNo);
      }
    }
    // A cheque only actually leaves the bank account once it's been printed
    // and handed over — 'Pending' isn't a real bank-account movement yet.
    await syncBankReconciliationTxn(tx, {
      bankAccount: created.bankAccount, voucherType: 'Cheque', voucherNo: created.chequeNo,
      txnDate: created.chequeDate, type: 'Debit', amount: created.amount,
      description: `Cheque to ${created.payTo || 'payee'}`, remarks: created.narration,
      isActive: created.status === 'Printed',
    });
    return created;
  });
  res.status(201).json({ success: true, data: row });
}));

router.put('/banking/cheques/:id', auth(), asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  const { invoiceApplications = [], ...rawHeader } = req.body;
  const header = sanitizeHeader(rawHeader, { allow: ['amount'] });  // `amount` is the face value typed on the cheque, not a computed
  // total — it is the one document where that field is user input.
  // Replace the applied-invoice set wholesale on every save.
  const row = await prisma.$transaction(async (tx) => {
    // Reverse whatever the previous version of this cheque had settled,
    // before re-applying — otherwise re-saving double-settles the invoice.
    const previousCheque = await tx.cheque.findUnique({ where: { id }, include: chequeInclude });
    if (previousCheque && chequeSettles(previousCheque.status)) {
      await reverseSupplierOutstanding(tx, chequeApplicationsForLedger(previousCheque.invoiceApplications));
    }
    await tx.chequeInvoiceApplication.deleteMany({ where: { chequeId: id } });
    const appData = invoiceApplications.map(toChequeApplicationData);
    const totalAppliedAmount = round2(appData.reduce((sum, a) => sum + (Number(a.amountToPay) || 0), 0));
    const updated = await tx.cheque.update({
      where: { id },
      data: {
        ...header, supplierName: chequeParty(header),
        totalAppliedAmount, invoiceApplications: { create: appData },
      },
      include: chequeInclude,
    });
    if (chequeSettles(updated.status)) {
      const ledgerApps = chequeApplicationsForLedger(appData);
      await supplierLedger.assertApplicationsValid(tx, ledgerApps, {
        paymentAmount: updated.amount, partyName: updated.supplierName,
      });
      await applyToSupplierOutstanding(tx, ledgerApps);
    }
    // Sync every invoice touched by either the old or the new application
    // set — one dropped from this cheque needs its paymentStatus pulled back
    // down just as much as one newly added to it needs pushing up.
    const touchedInvoiceNos = new Set([
      ...chequeApplicationsForLedger(previousCheque?.invoiceApplications).map((a) => a.invoiceNo).filter(Boolean),
      ...appData.map((a) => a.invoiceNo).filter(Boolean),
    ]);
    for (const invoiceNo of touchedInvoiceNos) {
      await syncPurchaseInvoicePaymentStatus(tx, invoiceNo);
    }
    await syncBankReconciliationTxn(tx, {
      bankAccount: updated.bankAccount, voucherType: 'Cheque', voucherNo: updated.chequeNo,
      txnDate: updated.chequeDate, type: 'Debit', amount: updated.amount,
      description: `Cheque to ${updated.payTo || 'payee'}`, remarks: updated.narration,
      isActive: updated.status === 'Printed',
    });
    return updated;
  });
  res.json({ success: true, data: row });
}));

router.delete('/banking/cheques/:id', auth(['admin']), asyncHandler(async (req, res) => {
  // ChequeInvoiceApplication.cheque has onDelete: Cascade.
  await prisma.$transaction(async (tx) => {
    const existing = await tx.cheque.findUnique({ where: { id: Number(req.params.id) }, include: chequeInclude });
    if (existing && chequeSettles(existing.status)) {
      // Deleting a settling cheque puts the debt back on the supplier.
      await reverseSupplierOutstanding(tx, chequeApplicationsForLedger(existing.invoiceApplications));
    }
    if (existing) {
      await syncBankReconciliationTxn(tx, {
        bankAccount: existing.bankAccount, voucherNo: existing.chequeNo, isActive: false,
      });
    }
    await tx.cheque.delete({ where: { id: Number(req.params.id) } });
    if (existing && chequeSettles(existing.status)) {
      for (const app of chequeApplicationsForLedger(existing.invoiceApplications)) {
        if (app.invoiceNo) await syncPurchaseInvoicePaymentStatus(tx, app.invoiceNo);
      }
    }
  });
  res.json({ success: true, message: 'Deleted successfully' });
}));

// Cash Book report — bespoke aggregation endpoint for the
// Reports > Cash/Bank Position > Cash Book page. There is no generic
// Voucher/Journal/Expense ledger model anywhere in this schema, so this
// report is honestly scoped to the real cash movement that does exist:
// Collection (customer receipts) and SupplierPayment (supplier payments),
// each optionally matched to a specific HouseBank "Cash Account" via its
// free-text depositTo/payFromAccount field (HouseBank.accountType is also
// free text with no enum distinguishing "Cash" from "Bank" accounts, so
// every HouseBank record is offered as a candidate Cash Account rather
// than guessing at a convention). Line items like "Office Expenses",
// "Salaries Paid", "Miscellaneous Receipt", or "Interest Received" have no
// backing document type in this schema (no Expense/JournalVoucher/
// PettyCash model exists) and are never fabricated — every row here is a
// real, posted Collection or SupplierPayment. "Particulars" falls back to
// "Collection from {customer}" / "Payment to {supplier}" when the
// document's own notes/remarks are blank. "Branch", "Currency", and "Show
// Cancelled Transactions" are no-ops — no branch column exists, every
// amount is implicitly INR, and neither Collection nor SupplierPayment
// ever carries a "Cancelled" status (only Draft/Posted).
async function computeCashBalanceAsOf(prismaClient, asOfDate, accountFilter) {
  const houseBankWhere = {};
  if (accountFilter) {
    houseBankWhere.OR = [{ accountName: accountFilter }, { bankName: accountFilter }];
  }
  const [houseBanks, collections, payments] = await Promise.all([
    prismaClient.houseBank.findMany({ where: houseBankWhere, select: { openingBalance: true } }),
    prismaClient.collection.findMany({
      where: {
        status: 'Posted',
        receiptDate: { lte: asOfDate },
        ...(accountFilter ? { depositTo: accountFilter } : {}),
      },
      select: { paymentAmount: true, collectionNo: true },
    }),
    prismaClient.supplierPayment.findMany({
      where: {
        status: 'Posted',
        paymentDate: { lte: asOfDate },
        ...(accountFilter ? { payFromAccount: accountFilter } : {}),
      },
      select: { paymentAmount: true, instrumentNo: true },
    }),
  ]);
  // Cheques and bank deposits move money too, and were both missing — the
  // balance was house-bank opening plus collections minus supplier payments
  // and nothing else, so every cheque written and every deposit banked was
  // invisible to the Cash Book, Bank Book and Day Book.
  //
  // Both have to be de-duplicated against what is already counted:
  //
  //   - a cheque tied to a Payment Entry (its supplier and amount already
  //     recorded as a SupplierPayment) would otherwise debit the account
  //     twice, so only cheques with no matching payment voucher count;
  //   - a Bank Deposit that banks a receipt already credited to this account
  //     via the Collection's "Deposit To" would likewise double up, so only
  //     deposits received from something other than a posted collection count.
  const [cheques, deposits] = await Promise.all([
    prismaClient.cheque.findMany({
      where: {
        status: { in: ['Printed', 'Issued', 'Presented', 'Cleared'] },
        chequeDate: { lte: asOfDate },
        ...(accountFilter ? { bankAccount: accountFilter } : {}),
      },
      select: { amount: true, chequeNo: true, supplierName: true },
    }),
    prismaClient.bankDeposit.findMany({
      where: {
        status: 'Posted',
        depositDate: { lte: asOfDate },
        ...(accountFilter ? { depositTo: accountFilter } : {}),
      },
      select: { totalDepositAmount: true, receivedFrom: true },
    }),
  ]);

  // Payment vouchers already counted, keyed by the instrument number they
  // were issued against.
  const paidInstruments = new Set(
    payments.map((p) => (p.instrumentNo || '').trim()).filter(Boolean)
  );
  const collectionSources = new Set(
    collections.map((c) => (c.collectionNo || '').trim()).filter(Boolean)
  );

  const baseline = round2(houseBanks.reduce((sum, b) => sum + Number(b.openingBalance || 0), 0));
  const receiptsTotal = round2(collections.reduce((sum, c) => sum + Number(c.paymentAmount || 0), 0));
  const paymentsTotal = round2(payments.reduce((sum, p) => sum + Number(p.paymentAmount || 0), 0));

  const chequesTotal = round2(
    cheques
      .filter((c) => !paidInstruments.has((c.chequeNo || '').trim()))
      .reduce((sum, c) => sum + Number(c.amount || 0), 0)
  );
  const depositsTotal = round2(
    deposits
      .filter((d) => !collectionSources.has((d.receivedFrom || '').trim()))
      .reduce((sum, d) => sum + Number(d.totalDepositAmount || 0), 0)
  );

  return round2(baseline + receiptsTotal + depositsTotal - paymentsTotal - chequesTotal);
}

router.get('/banking/cash-book/report', auth(), asyncHandler(async (req, res) => {
  const {
    cashAccount, fromDate, toDate, include, voucherType, openingBalanceAsOn,
  } = req.query;

  const from = fromDate ? new Date(fromDate) : new Date(new Date().getFullYear(), new Date().getMonth(), 1);
  from.setHours(0, 0, 0, 0);
  const to = toDate ? new Date(toDate) : new Date();
  to.setHours(23, 59, 59, 999);
  const obAsOn = openingBalanceAsOn ? new Date(openingBalanceAsOn) : new Date(from.getTime() - 1);
  obAsOn.setHours(23, 59, 59, 999);

  const accountFilter = cashAccount || '';
  // Opening Balance is always the true historical cash position as of that
  // date (both receipts and payments), regardless of the "Include" filter
  // below — Include only scopes which transaction types populate the
  // ledger body/totals for this report run, it doesn't rewrite history.
  const openingBalance = await computeCashBalanceAsOf(prisma, obAsOn, accountFilter);

  const includeReceipts = include !== 'Payments Only';
  const includePayments = include !== 'Receipts Only';

  const [collections, supplierPayments] = await Promise.all([
    includeReceipts
      ? prisma.collection.findMany({
        where: {
          status: 'Posted',
          receiptDate: { gte: from, lte: to },
          ...(accountFilter ? { depositTo: accountFilter } : {}),
        },
        orderBy: { receiptDate: 'asc' },
      })
      : [],
    includePayments
      ? prisma.supplierPayment.findMany({
        where: {
          status: 'Posted',
          paymentDate: { gte: from, lte: to },
          ...(accountFilter ? { payFromAccount: accountFilter } : {}),
        },
        orderBy: { paymentDate: 'asc' },
      })
      : [],
  ]);

  const ledgerEntries = [
    ...collections.map((c) => ({
      date: c.receiptDate,
      voucherType: 'Receipt',
      voucherNo: c.collectionNo,
      particulars: c.notes || c.remarks || `Collection from ${c.customerName || 'Customer'}`,
      receipt: Number(c.paymentAmount || 0),
      payment: 0,
      referenceNo: c.instrumentNo || '—',
      remarks: c.remarks || '—',
    })),
    ...supplierPayments.map((p) => ({
      date: p.paymentDate,
      voucherType: 'Payment',
      voucherNo: p.paymentNo,
      particulars: p.notes || p.remarks || `Payment to ${p.supplierName || 'Supplier'}`,
      receipt: 0,
      payment: Number(p.paymentAmount || 0),
      referenceNo: p.instrumentNo || '—',
      remarks: p.remarks || '—',
    })),
  ].sort((a, b) => new Date(a.date) - new Date(b.date));

  // Running balance is computed over the FULL chronological ledger for the
  // period (never affected by the Voucher Type display filter below), so
  // the Balance column stays a true running total even if some voucher
  // types are hidden from view.
  let runningBalance = openingBalance;
  const fullRows = ledgerEntries.map((e) => {
    runningBalance += e.receipt - e.payment;
    return { ...e, balance: runningBalance };
  });

  const totalReceiptsFull = collections.reduce((sum, c) => sum + Number(c.paymentAmount || 0), 0);
  const totalPaymentsFull = supplierPayments.reduce((sum, p) => sum + Number(p.paymentAmount || 0), 0);
  const closingBalance = openingBalance + totalReceiptsFull - totalPaymentsFull;

  const openingRow = {
    date: from,
    voucherType: 'Opening Balance',
    voucherNo: `OB/${String(from.getDate()).padStart(2, '0')}/${String(from.getMonth() + 1).padStart(2, '0')}/${from.getFullYear()}`,
    particulars: 'Opening Balance',
    receipt: null,
    payment: null,
    referenceNo: '—',
    remarks: '—',
    balance: openingBalance,
  };

  // Voucher Type is a pure display filter over the fully-computed ledger —
  // it narrows which rows are shown, it does not recompute totals/balance.
  let rows = [openingRow, ...fullRows];
  if (voucherType && voucherType !== 'All') {
    rows = rows.filter((r) => r.voucherType === voucherType);
  }

  const totals = rows.reduce((acc, r) => ({
    receipt: acc.receipt + (r.receipt || 0),
    payment: acc.payment + (r.payment || 0),
  }), { receipt: 0, payment: 0 });

  // Receipt vs Payment donut, and Net Cash Inflow — always the true
  // period totals (independent of Voucher Type).
  const receiptVsPayment = [
    { name: 'Total Receipts', value: Math.round(totalReceiptsFull), percent: (totalReceiptsFull + totalPaymentsFull) > 0 ? Math.round((totalReceiptsFull / (totalReceiptsFull + totalPaymentsFull)) * 1000) / 10 : 0 },
    { name: 'Total Payments', value: Math.round(totalPaymentsFull), percent: (totalReceiptsFull + totalPaymentsFull) > 0 ? Math.round((totalPaymentsFull / (totalReceiptsFull + totalPaymentsFull)) * 1000) / 10 : 0 },
  ];

  // Cash Balance Trend (Last 7 Days) — a true balance snapshot for each of
  // the 7 calendar days ending at `to`, independent of Voucher Type/
  // Include, same "always the real underlying number" approach used for
  // Supplier Outstanding's 6-month trend.
  const trendDays = [];
  for (let i = 6; i >= 0; i -= 1) {
    const d = new Date(to);
    d.setDate(d.getDate() - i);
    d.setHours(23, 59, 59, 999);
    trendDays.push(d);
  }
  const pad2 = (n) => String(n).padStart(2, '0');
  const cashBalanceTrend = [];
  for (let i = 0; i < trendDays.length; i += 1) {
    const d = trendDays[i];
    // eslint-disable-next-line no-await-in-loop
    const balance = await computeCashBalanceAsOf(prisma, d, accountFilter);
    cashBalanceTrend.push({ name: `${pad2(d.getDate())}/${pad2(d.getMonth() + 1)}`, value: Math.round(balance) });
  }

  // Top Receipt Sources (customer-wise) — Collection has no ledger
  // "head"/category field (no Sales/Advance/Interest classification
  // exists), so the closest honest substitute is grouping by the paying
  // customer, same idea as Top 5 Customers by Collection on the
  // Collection Register report.
  const bySourceValue = {};
  collections.forEach((c) => {
    const name = c.customerName || 'Unknown';
    bySourceValue[name] = (bySourceValue[name] || 0) + Number(c.paymentAmount || 0);
  });
  const topReceiptSources = Object.entries(bySourceValue).sort((a, b) => b[1] - a[1]).slice(0, 5)
    .map(([name, value]) => ({ name, value: Math.round(value) }));

  res.json({
    success: true,
    data: {
      rows,
      totals,
      stats: {
        openingBalance,
        totalReceipts: totalReceiptsFull,
        totalPayments: totalPaymentsFull,
        closingBalance,
        noOfReceipts: collections.length,
        noOfPayments: supplierPayments.length,
      },
      receiptVsPayment,
      cashBalanceTrend,
      topReceiptSources,
    },
  });
}));

// Day Book report — bespoke aggregation endpoint for the
// Reports > Cash/Bank Position > Day Book page. Same real-data-only
// approach as Cash Book above (Collection + SupplierPayment, no fabricated
// Expense/Journal entries), but NOT restricted to a single Cash Account —
// it spans every account, real or generic, that ever appears in
// Collection.depositTo / SupplierPayment.payFromAccount (including
// placeholder labels like "Customer A/c"/"Vendor A/c" that aren't backed
// by a HouseBank record at all), and adds that raw account name as its own
// column. The optional "Account" filter matches literal depositTo/
// payFromAccount text rather than requiring a HouseBank match, since not
// every account name in use is a real HouseBank record.
router.get('/banking/day-book/report', auth(), asyncHandler(async (req, res) => {
  const {
    account, fromDate, toDate, include, voucherType, openingBalanceAsOn,
  } = req.query;

  const from = fromDate ? new Date(fromDate) : new Date(new Date().getFullYear(), new Date().getMonth(), 1);
  from.setHours(0, 0, 0, 0);
  const to = toDate ? new Date(toDate) : new Date();
  to.setHours(23, 59, 59, 999);
  const obAsOn = openingBalanceAsOn ? new Date(openingBalanceAsOn) : new Date(from.getTime() - 1);
  obAsOn.setHours(23, 59, 59, 999);

  const accountFilter = account || '';

  async function balanceAsOf(asOfDate) {
    // Baseline only applies when looking at the whole book — a specific
    // non-HouseBank account filter (e.g. "Customer A/c") has no opening
    // balance of its own to anchor to.
    const [houseBanks, collections, payments] = await Promise.all([
      accountFilter ? [] : prisma.houseBank.findMany({ select: { openingBalance: true } }),
      prisma.collection.findMany({
        where: {
          status: 'Posted',
          receiptDate: { lte: asOfDate },
          ...(accountFilter ? { depositTo: accountFilter } : {}),
        },
        select: { paymentAmount: true },
      }),
      prisma.supplierPayment.findMany({
        where: {
          status: 'Posted',
          paymentDate: { lte: asOfDate },
          ...(accountFilter ? { payFromAccount: accountFilter } : {}),
        },
        select: { paymentAmount: true },
      }),
    ]);
    const baseline = houseBanks.reduce((sum, b) => sum + Number(b.openingBalance || 0), 0);
    const receiptsTotal = collections.reduce((sum, c) => sum + Number(c.paymentAmount || 0), 0);
    const paymentsTotal = payments.reduce((sum, p) => sum + Number(p.paymentAmount || 0), 0);
    return baseline + receiptsTotal - paymentsTotal;
  }

  // Opening Balance is always the true historical position as of that
  // date, regardless of the "Include" filter (same reasoning as Cash Book).
  const openingBalance = await balanceAsOf(obAsOn);

  const includeReceipts = include !== 'Payments Only';
  const includePayments = include !== 'Receipts Only';

  const [collections, supplierPayments] = await Promise.all([
    includeReceipts
      ? prisma.collection.findMany({
        where: {
          status: 'Posted',
          receiptDate: { gte: from, lte: to },
          ...(accountFilter ? { depositTo: accountFilter } : {}),
        },
        orderBy: { receiptDate: 'asc' },
      })
      : [],
    includePayments
      ? prisma.supplierPayment.findMany({
        where: {
          status: 'Posted',
          paymentDate: { gte: from, lte: to },
          ...(accountFilter ? { payFromAccount: accountFilter } : {}),
        },
        orderBy: { paymentDate: 'asc' },
      })
      : [],
  ]);

  const ledgerEntries = [
    ...collections.map((c) => ({
      date: c.receiptDate,
      voucherType: 'Receipt',
      voucherNo: c.collectionNo,
      accountName: c.depositTo || '—',
      particulars: c.notes || c.remarks || `Collection from ${c.customerName || 'Customer'}`,
      receipt: Number(c.paymentAmount || 0),
      payment: 0,
      referenceNo: c.instrumentNo || '—',
      remarks: c.remarks || '—',
    })),
    ...supplierPayments.map((p) => ({
      date: p.paymentDate,
      voucherType: 'Payment',
      voucherNo: p.paymentNo,
      accountName: p.payFromAccount || '—',
      particulars: p.notes || p.remarks || `Payment to ${p.supplierName || 'Supplier'}`,
      receipt: 0,
      payment: Number(p.paymentAmount || 0),
      referenceNo: p.instrumentNo || '—',
      remarks: p.remarks || '—',
    })),
  ].sort((a, b) => new Date(a.date) - new Date(b.date));

  let runningBalance = openingBalance;
  const fullRows = ledgerEntries.map((e) => {
    runningBalance += e.receipt - e.payment;
    return { ...e, balance: runningBalance };
  });

  const totalReceiptsFull = collections.reduce((sum, c) => sum + Number(c.paymentAmount || 0), 0);
  const totalPaymentsFull = supplierPayments.reduce((sum, p) => sum + Number(p.paymentAmount || 0), 0);
  const closingBalance = openingBalance + totalReceiptsFull - totalPaymentsFull;

  const openingRow = {
    date: from,
    voucherType: 'Opening Balance',
    voucherNo: `OB/${String(from.getDate()).padStart(2, '0')}/${String(from.getMonth() + 1).padStart(2, '0')}/${from.getFullYear()}`,
    accountName: accountFilter || 'All Accounts',
    particulars: 'Opening Balance',
    receipt: null,
    payment: null,
    referenceNo: '—',
    remarks: '—',
    balance: openingBalance,
  };

  let rows = [openingRow, ...fullRows];
  if (voucherType && voucherType !== 'All') {
    rows = rows.filter((r) => r.voucherType === voucherType);
  }

  const totals = rows.reduce((acc, r) => ({
    receipt: acc.receipt + (r.receipt || 0),
    payment: acc.payment + (r.payment || 0),
  }), { receipt: 0, payment: 0 });

  const receiptVsPayment = [
    { name: 'Total Receipts', value: Math.round(totalReceiptsFull), percent: (totalReceiptsFull + totalPaymentsFull) > 0 ? Math.round((totalReceiptsFull / (totalReceiptsFull + totalPaymentsFull)) * 1000) / 10 : 0 },
    { name: 'Total Payments', value: Math.round(totalPaymentsFull), percent: (totalReceiptsFull + totalPaymentsFull) > 0 ? Math.round((totalPaymentsFull / (totalReceiptsFull + totalPaymentsFull)) * 1000) / 10 : 0 },
  ];

  const trendDays = [];
  for (let i = 6; i >= 0; i -= 1) {
    const d = new Date(to);
    d.setDate(d.getDate() - i);
    d.setHours(23, 59, 59, 999);
    trendDays.push(d);
  }
  const pad2 = (n) => String(n).padStart(2, '0');
  const dayBookTrend = [];
  for (let i = 0; i < trendDays.length; i += 1) {
    const d = trendDays[i];
    // eslint-disable-next-line no-await-in-loop
    const balance = await balanceAsOf(d);
    dayBookTrend.push({ name: `${pad2(d.getDate())}/${pad2(d.getMonth() + 1)}`, value: Math.round(balance) });
  }

  // Top 5 Accounts by Transactions — counts (not amounts) per account
  // name, across the full chronological ledger for the period.
  const byAccountCount = {};
  fullRows.forEach((r) => { byAccountCount[r.accountName] = (byAccountCount[r.accountName] || 0) + 1; });
  const top5AccountsByTransactions = Object.entries(byAccountCount).sort((a, b) => b[1] - a[1]).slice(0, 5)
    .map(([name, value]) => ({ name, value }));

  // Distinct account names in use, for the "Account" filter dropdown —
  // there's no single resource listing every depositTo/payFromAccount
  // value ever used (some are HouseBank records, some are free-text
  // placeholders), so it's derived here from the actual ledger data.
  const [allDepositAccounts, allPayFromAccounts] = await Promise.all([
    prisma.collection.findMany({ where: { depositTo: { not: null } }, select: { depositTo: true }, distinct: ['depositTo'] }),
    prisma.supplierPayment.findMany({ where: { payFromAccount: { not: null } }, select: { payFromAccount: true }, distinct: ['payFromAccount'] }),
  ]);
  const accountOptions = Array.from(new Set([
    ...allDepositAccounts.map((r) => r.depositTo).filter(Boolean),
    ...allPayFromAccounts.map((r) => r.payFromAccount).filter(Boolean),
  ])).sort();

  res.json({
    success: true,
    data: {
      rows,
      totals,
      accountOptions,
      stats: {
        totalVouchers: collections.length + supplierPayments.length,
        totalReceipts: totalReceiptsFull,
        totalPayments: totalPaymentsFull,
        closingBalance,
        openingBalance,
      },
      receiptVsPayment,
      dayBookTrend,
      top5AccountsByTransactions,
    },
  });
}));

// Bank Book report — bespoke aggregation endpoint for the
// Reports > Cash/Bank Position > Bank Book page. Same real-data-only
// ledger builder as Cash Book/Day Book (Collection + SupplierPayment, no
// fabricated Expense/Journal entries), scoped to a single HouseBank "Bank
// Account" the same way Cash Book scopes to a Cash Account — every
// HouseBank record is offered as a candidate, since accountType is free
// text with no enum distinguishing "Cash" from "Bank". "Cleared Status"
// is a real lookup against BankReconciliationTransaction (the one place
// in this schema that actually tracks reconciliation), matched by
// voucherNo for source='System' rows; a voucher with no matching
// reconciliation-transaction record, or one whose status isn't
// 'Reconciled', is treated as "Uncleared" — nothing here is fabricated,
// it just reflects whether that voucher has ever been reconciled.
router.get('/banking/bank-book/report', auth(), asyncHandler(async (req, res) => {
  const {
    bankAccount, fromDate, toDate, include, voucherType, openingBalanceAsOn, showClearedTransactions,
  } = req.query;

  const from = fromDate ? new Date(fromDate) : new Date(new Date().getFullYear(), new Date().getMonth(), 1);
  from.setHours(0, 0, 0, 0);
  const to = toDate ? new Date(toDate) : new Date();
  to.setHours(23, 59, 59, 999);
  const obAsOn = openingBalanceAsOn ? new Date(openingBalanceAsOn) : new Date(from.getTime() - 1);
  obAsOn.setHours(23, 59, 59, 999);

  const accountFilter = bankAccount || '';

  async function balanceAsOf(asOfDate) {
    const houseBankWhere = {};
    if (accountFilter) houseBankWhere.OR = [{ accountName: accountFilter }, { bankName: accountFilter }];
    const [houseBanks, collections, payments] = await Promise.all([
      prisma.houseBank.findMany({ where: houseBankWhere, select: { openingBalance: true } }),
      prisma.collection.findMany({
        where: {
          status: 'Posted',
          receiptDate: { lte: asOfDate },
          ...(accountFilter ? { depositTo: accountFilter } : {}),
        },
        select: { paymentAmount: true },
      }),
      prisma.supplierPayment.findMany({
        where: {
          status: 'Posted',
          paymentDate: { lte: asOfDate },
          ...(accountFilter ? { payFromAccount: accountFilter } : {}),
        },
        select: { paymentAmount: true },
      }),
    ]);
    const baseline = houseBanks.reduce((sum, b) => sum + Number(b.openingBalance || 0), 0);
    const receiptsTotal = collections.reduce((sum, c) => sum + Number(c.paymentAmount || 0), 0);
    const paymentsTotal = payments.reduce((sum, p) => sum + Number(p.paymentAmount || 0), 0);
    return baseline + receiptsTotal - paymentsTotal;
  }

  const openingBalance = await balanceAsOf(obAsOn);

  const includeReceipts = include !== 'Payments Only';
  const includePayments = include !== 'Receipts Only';

  const [collections, supplierPayments] = await Promise.all([
    includeReceipts
      ? prisma.collection.findMany({
        where: {
          status: 'Posted',
          receiptDate: { gte: from, lte: to },
          ...(accountFilter ? { depositTo: accountFilter } : {}),
        },
        orderBy: { receiptDate: 'asc' },
      })
      : [],
    includePayments
      ? prisma.supplierPayment.findMany({
        where: {
          status: 'Posted',
          paymentDate: { gte: from, lte: to },
          ...(accountFilter ? { payFromAccount: accountFilter } : {}),
        },
        orderBy: { paymentDate: 'asc' },
      })
      : [],
  ]);

  // Bulk cleared-status lookup: one query for every voucherNo this ledger
  // touches, rather than one query per row.
  const voucherNos = [...collections.map((c) => c.collectionNo), ...supplierPayments.map((p) => p.paymentNo)].filter(Boolean);
  const reconTxns = voucherNos.length
    ? await prisma.bankReconciliationTransaction.findMany({
      where: { source: 'System', voucherNo: { in: voucherNos } },
      select: { voucherNo: true, status: true },
    })
    : [];
  const clearedByVoucherNo = {};
  reconTxns.forEach((t) => {
    if (t.status === 'Reconciled') clearedByVoucherNo[t.voucherNo] = true;
  });

  const ledgerEntries = [
    ...collections.map((c) => ({
      date: c.receiptDate,
      voucherType: 'Receipt',
      voucherNo: c.collectionNo,
      particulars: c.notes || c.remarks || `Collection from ${c.customerName || 'Customer'}`,
      receipt: Number(c.paymentAmount || 0),
      payment: 0,
      chequeRefNo: c.instrumentNo || '—',
      clearedStatus: clearedByVoucherNo[c.collectionNo] ? 'Cleared' : 'Uncleared',
      remarks: c.remarks || '—',
    })),
    ...supplierPayments.map((p) => ({
      date: p.paymentDate,
      voucherType: 'Payment',
      voucherNo: p.paymentNo,
      particulars: p.notes || p.remarks || `Payment to ${p.supplierName || 'Supplier'}`,
      receipt: 0,
      payment: Number(p.paymentAmount || 0),
      chequeRefNo: p.instrumentNo || '—',
      clearedStatus: clearedByVoucherNo[p.paymentNo] ? 'Cleared' : 'Uncleared',
      remarks: p.remarks || '—',
    })),
  ].sort((a, b) => new Date(a.date) - new Date(b.date));

  let runningBalance = openingBalance;
  let unclearedNet = 0;
  const fullRows = ledgerEntries.map((e) => {
    runningBalance += e.receipt - e.payment;
    if (e.clearedStatus === 'Uncleared') unclearedNet += e.receipt - e.payment;
    return { ...e, balance: runningBalance };
  });

  const totalReceiptsFull = collections.reduce((sum, c) => sum + Number(c.paymentAmount || 0), 0);
  const totalPaymentsFull = supplierPayments.reduce((sum, p) => sum + Number(p.paymentAmount || 0), 0);
  const closingBalance = openingBalance + totalReceiptsFull - totalPaymentsFull;
  const unclearedBalance = unclearedNet;
  const clearedBalance = closingBalance - unclearedBalance;

  const openingRow = {
    date: from,
    voucherType: 'Opening Balance',
    voucherNo: `OB/${String(from.getDate()).padStart(2, '0')}/${String(from.getMonth() + 1).padStart(2, '0')}/${from.getFullYear()}`,
    particulars: 'Opening Balance',
    receipt: null,
    payment: null,
    chequeRefNo: '—',
    clearedStatus: 'Cleared',
    remarks: '—',
    balance: openingBalance,
  };

  // "Show Cleared Transactions": No narrows the ledger body down to only
  // still-pending (Uncleared) vouchers — a "what hasn't cleared yet" view
  // — Yes (the default) shows everything. This is independent of the
  // Voucher Type display filter below.
  let rows = [openingRow, ...fullRows];
  if (showClearedTransactions === 'No') {
    rows = rows.filter((r) => r.voucherType === 'Opening Balance' || r.clearedStatus === 'Uncleared');
  }
  if (voucherType && voucherType !== 'All') {
    rows = rows.filter((r) => r.voucherType === voucherType);
  }

  const totals = rows.reduce((acc, r) => ({
    receipt: acc.receipt + (r.receipt || 0),
    payment: acc.payment + (r.payment || 0),
  }), { receipt: 0, payment: 0 });

  const receiptVsPayment = [
    { name: 'Total Receipts', value: Math.round(totalReceiptsFull), percent: (totalReceiptsFull + totalPaymentsFull) > 0 ? Math.round((totalReceiptsFull / (totalReceiptsFull + totalPaymentsFull)) * 1000) / 10 : 0 },
    { name: 'Total Payments', value: Math.round(totalPaymentsFull), percent: (totalReceiptsFull + totalPaymentsFull) > 0 ? Math.round((totalPaymentsFull / (totalReceiptsFull + totalPaymentsFull)) * 1000) / 10 : 0 },
  ];

  const trendDays = [];
  for (let i = 6; i >= 0; i -= 1) {
    const d = new Date(to);
    d.setDate(d.getDate() - i);
    d.setHours(23, 59, 59, 999);
    trendDays.push(d);
  }
  const pad2 = (n) => String(n).padStart(2, '0');
  const bankBalanceTrend = [];
  for (let i = 0; i < trendDays.length; i += 1) {
    const d = trendDays[i];
    // eslint-disable-next-line no-await-in-loop
    const balance = await balanceAsOf(d);
    bankBalanceTrend.push({ name: `${pad2(d.getDate())}/${pad2(d.getMonth() + 1)}`, value: Math.round(balance) });
  }

  // Top 5 Transactions (by amount), across the full chronological ledger
  // for the period.
  const top5Transactions = [...fullRows].sort((a, b) => (b.receipt + b.payment) - (a.receipt + a.payment)).slice(0, 5)
    .map((r) => ({ name: r.particulars, value: Math.round(r.receipt + r.payment) }));

  res.json({
    success: true,
    data: {
      rows,
      totals,
      stats: {
        openingBalance,
        totalReceipts: totalReceiptsFull,
        totalPayments: totalPaymentsFull,
        closingBalance,
        noOfTransactions: collections.length + supplierPayments.length,
        clearedBalance,
        unclearedBalance,
      },
      receiptVsPayment,
      bankBalanceTrend,
      top5Transactions,
    },
  });
}));

// Deposit Register report — bespoke aggregation endpoint for the
// Reports > Cash/Bank Position > Deposit Register page. The mockup for
// this report was designed around Fixed/Recurring Deposit accounts. There
// is still no separate term-deposit/investment model in this schema — the
// only "Deposit" entity is BankDeposit/DepositItem, a deposit slip
// recording Cash/Cheque/Bank Transfer/Mixed amounts paid into a bank
// account — but interestRate/maturityDate/maturityAmount now exist as
// nullable fields on BankDeposit (captured in Deposit Entry), so the
// report shows them as real stored values. They are null on ordinary
// deposit slips and on everything recorded before those fields were added,
// and the page renders null as "—" rather than 0. Note "Deposit Type" here
// is still the slip's payment composition (Cash/Cheque/Bank
// Transfer/Mixed), not an FD/RD product type. "Branch",
// "Currency", and "Show Cancelled Deposits" are no-ops for the same
// reasons as the other reports (no branch column, single implicit
// currency, and BankDeposit only ever has Draft/Posted status).
//
// Opening/Closing Balance and Total Withdrawals are computed on this
// report's own cash-movement model so the five headline cards actually
// tie: Opening + Total Deposits - Total Withdrawals = Closing. Money in
// is BankDeposit (the deposit slips this report lists), money out is
// Posted SupplierPayment.payFromAccount — the only outflow against a bank
// account anywhere in this schema. The baseline is HouseBank.openingBalance
// for the account(s) in scope, same as Bank Book. Note this deliberately
// differs from Bank Book's ledger, which treats Collection as the inflow;
// counting both Collections and their BankDeposit slips would double-count
// the same money, and on this page the deposit slips are the subject.
// Withdrawals are always Posted-only — a Draft payment hasn't moved money —
// whereas deposits follow the Include filter, so a "Draft Only" view shows
// draft deposit volume against real withdrawals.
router.get('/banking/deposit-register/report', auth(), asyncHandler(async (req, res) => {
  const {
    account, depositType, fromDate, toDate, include,
  } = req.query;

  const from = fromDate ? new Date(fromDate) : new Date(new Date().getFullYear(), new Date().getMonth(), 1);
  from.setHours(0, 0, 0, 0);
  const to = toDate ? new Date(toDate) : new Date();
  to.setHours(23, 59, 59, 999);

  let statusWhere = { in: ['Posted', 'Draft'] };
  if (include === 'Posted Only') statusWhere = 'Posted';
  else if (include === 'Draft Only') statusWhere = 'Draft';

  const depositWhere = {
    depositDate: { gte: from, lte: to },
    status: statusWhere,
  };
  if (account) depositWhere.depositTo = account;
  if (depositType) depositWhere.depositType = depositType;

  const deposits = await prisma.bankDeposit.findMany({
    where: depositWhere,
    include: { items: true },
    orderBy: { depositDate: 'asc' },
  });

  const rows = deposits.map((d) => {
    const items = d.items || [];
    const referenceNo = items.map((i) => i.instrumentNo).filter(Boolean).join(', ') || '—';
    return {
      id: d.id,
      date: d.depositDate,
      depositNo: d.depositNo,
      accountName: d.depositTo || '—',
      depositType: d.depositType || '—',
      amount: Number(d.totalDepositAmount || 0),
      // Term-deposit fields — null on any deposit slip that isn't a
      // Fixed/Recurring Deposit, and on every slip recorded before these
      // fields existed. The page renders those as "—" rather than 0, so a
      // missing rate is never mistaken for a 0% one.
      interestRate: d.interestRate == null ? null : Number(d.interestRate),
      maturityDate: d.maturityDate,
      maturityAmount: d.maturityAmount == null ? null : Number(d.maturityAmount),
      referenceNo,
      receivedFrom: d.receivedFrom || '—',
      remarks: d.remarks || '—',
    };
  });

  const totals = rows.reduce((acc, r) => ({
    amount: acc.amount + r.amount,
    maturityAmount: acc.maturityAmount + (r.maturityAmount || 0),
  }), { amount: 0, maturityAmount: 0 });

  // Deposit Type Summary — donut over the exact depositType values in use.
  const byTypeValue = {};
  rows.forEach((r) => { byTypeValue[r.depositType] = (byTypeValue[r.depositType] || 0) + r.amount; });
  const typeGrandTotal = totals.amount || 1;
  const depositTypeSummary = Object.entries(byTypeValue).sort((a, b) => b[1] - a[1])
    .map(([name, value]) => ({ name, value: Math.round(value), percent: Math.round((value / typeGrandTotal) * 1000) / 10 }));

  const cashDeposits = byTypeValue.Cash || 0;
  const chequeDeposits = byTypeValue.Cheque || 0;
  const bankTransferDeposits = (byTypeValue['Bank Transfer'] || 0) + (byTypeValue.Mixed || 0);

  // Deposit Trend (Last 7 Days) — always the 7 calendar days ending at
  // `to`, regardless of the selected Period Range preset, queried
  // independently of `rows` so a short period range doesn't truncate it —
  // same approach as the other Cash/Bank Position reports.
  const trendDays = [];
  for (let i = 6; i >= 0; i -= 1) {
    const d = new Date(to);
    d.setDate(d.getDate() - i);
    d.setHours(0, 0, 0, 0);
    trendDays.push(d);
  }
  const trendFrom = trendDays[0];
  const trendWhere = { depositDate: { gte: trendFrom, lte: to }, status: statusWhere };
  if (account) trendWhere.depositTo = account;
  if (depositType) trendWhere.depositType = depositType;
  const trendDeposits = await prisma.bankDeposit.findMany({ where: trendWhere, select: { depositDate: true, totalDepositAmount: true } });
  const pad2 = (n) => String(n).padStart(2, '0');
  const depositTrend = trendDays.map((d) => {
    const dayTotal = trendDeposits
      .filter((r) => r.depositDate && new Date(r.depositDate).toDateString() === d.toDateString())
      .reduce((sum, r) => sum + Number(r.totalDepositAmount || 0), 0);
    return { name: `${pad2(d.getDate())}/${pad2(d.getMonth() + 1)}`, value: Math.round(dayTotal) };
  });

  // Top 5 Accounts by Deposit Amount.
  const byAccountValue = {};
  rows.forEach((r) => { byAccountValue[r.accountName] = (byAccountValue[r.accountName] || 0) + r.amount; });
  const top5AccountsByDeposit = Object.entries(byAccountValue).sort((a, b) => b[1] - a[1]).slice(0, 5)
    .map(([name, value]) => ({ name, value: Math.round(value) }));

  // Opening Balance — the account balance the instant before `from`:
  // the HouseBank baseline plus every deposit and minus every Posted
  // withdrawal dated on or before that point.
  const openingAsOf = new Date(from.getTime() - 1);
  const houseBankWhere = account ? { OR: [{ accountName: account }, { bankName: account }] } : {};
  const [houseBanks, priorDeposits, priorWithdrawals, periodWithdrawals] = await Promise.all([
    prisma.houseBank.findMany({ where: houseBankWhere, select: { openingBalance: true } }),
    prisma.bankDeposit.findMany({
      where: {
        depositDate: { lte: openingAsOf },
        status: statusWhere,
        ...(account ? { depositTo: account } : {}),
        ...(depositType ? { depositType } : {}),
      },
      select: { totalDepositAmount: true },
    }),
    prisma.supplierPayment.findMany({
      where: {
        status: 'Posted',
        paymentDate: { lte: openingAsOf },
        ...(account ? { payFromAccount: account } : {}),
      },
      select: { paymentAmount: true },
    }),
    prisma.supplierPayment.findMany({
      where: {
        status: 'Posted',
        paymentDate: { gte: from, lte: to },
        ...(account ? { payFromAccount: account } : {}),
      },
      select: { paymentAmount: true },
    }),
  ]);

  const baseline = houseBanks.reduce((sum, b) => sum + Number(b.openingBalance || 0), 0);
  const priorDepositTotal = priorDeposits.reduce((sum, d) => sum + Number(d.totalDepositAmount || 0), 0);
  const priorWithdrawalTotal = priorWithdrawals.reduce((sum, p) => sum + Number(p.paymentAmount || 0), 0);
  const openingBalance = baseline + priorDepositTotal - priorWithdrawalTotal;
  const totalWithdrawals = periodWithdrawals.reduce((sum, p) => sum + Number(p.paymentAmount || 0), 0);
  const closingBalance = openingBalance + totals.amount - totalWithdrawals;

  res.json({
    success: true,
    data: {
      rows,
      totals,
      stats: {
        openingBalance,
        totalDeposits: totals.amount,
        totalWithdrawals,
        closingBalance,
        noOfDeposits: rows.length,
        noOfWithdrawals: periodWithdrawals.length,
        cashDeposits,
        chequeDeposits,
        bankTransferDeposits,
      },
      depositTypeSummary,
      depositTrend,
      top5AccountsByDeposit,
    },
  });
}));

module.exports = router;
