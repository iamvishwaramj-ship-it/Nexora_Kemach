const router = require('express').Router();
const { body, validationResult } = require('express-validator');
const bcrypt = require('bcryptjs');
const prisma = require('../prisma/client');
const auth = require('../middleware/auth');
const asyncHandler = require('../utils/asyncHandler');
const { parseId } = require('../utils/crudFactory');

// User Management: list/create/update/delete AppUser accounts, each carrying
// its own menu-based permission grid (UserPermission rows, one per navConfig
// entry — see schema.prisma for why there is no separate Role table).
//
// Deliberately its own file rather than folded into the generic resources.js
// router (see the comment that used to sit on the read-only GET /users this
// replaces): password hashing and the nested permissions write need more
// control than createCrudController's generic shape gives a resource.

function checkValidation(req) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const err = new Error(errors.array()[0].msg);
    err.status = 400;
    err.errors = errors.array();
    throw err;
  }
}

// passwordHash must never reach a client response, not even for an admin
// managing other people's accounts.
function safeUser(user) {
  const { passwordHash, ...safe } = user;
  return safe;
}

// Normalizes the client's permissions[] into Prisma createMany rows for one
// user. Every flag is coerced to a plain boolean so a stray null/undefined
// can't slip past the column's NOT NULL default, and a row with no menuKey
// is dropped defensively (the frontend always sends one per navConfig entry).
function toPermissionRows(userId, permissions) {
  return (Array.isArray(permissions) ? permissions : [])
    .filter((p) => p && p.menuKey)
    .map((p) => ({
      userId,
      menuKey: String(p.menuKey),
      canView: !!p.canView,
      canAdd: !!p.canAdd,
      canEdit: !!p.canEdit,
      canDelete: !!p.canDelete,
    }));
}

// Shared across create and update — name/email/role required, and at least
// one permission row must carry at least one true flag (the same "Grant at
// least one section permission" rule the frontend grid enforces, checked
// again here since a form's client-side schema is never a substitute for
// the server rejecting a bad request directly).
const userFieldValidation = [
  body('name').trim().isLength({ min: 2 }).withMessage('Name must be at least 2 characters'),
  body('email').isEmail().withMessage('Enter a valid email address'),
  body('role').notEmpty().withMessage('Role is required'),
  body('permissions')
    .isArray({ min: 1 }).withMessage('Grant at least one section permission.')
    .custom((rows) => Array.isArray(rows) && rows.some((r) => r && (r.canView || r.canAdd || r.canEdit || r.canDelete)))
    .withMessage('Grant at least one section permission.'),
];

router.use(auth());

// GET / — every user account (minus passwordHash) with its permission rows.
// Open to any authenticated user, not just admins: this is the same endpoint
// pages like Collection Entry's "Received By" dropdown have always called
// via appUserApi.useList() for a plain id/name list: restricting it to
// admins would break every one of those. ?q= filters by name/email, matching
// every other list endpoint in the app.
router.get('/', asyncHandler(async (req, res) => {
  const { q } = req.query;
  const where = q
    ? { OR: [{ name: { contains: q } }, { email: { contains: q } }] }
    : undefined;
  const rows = await prisma.appUser.findMany({
    where,
    include: { permissions: true },
    orderBy: { name: 'asc' },
  });
  res.json({ success: true, data: rows.map(safeUser) });
}));

router.get('/:id', asyncHandler(async (req, res) => {
  const id = parseId(req.params.id);
  const row = await prisma.appUser.findUnique({ where: { id }, include: { permissions: true } });
  if (!row) return res.status(404).json({ success: false, message: 'User not found' });
  res.json({ success: true, data: safeUser(row) });
}));

// POST / — create a user and its permission grid in one transaction. Only an
// admin may create accounts and grant permissions to them — same gate
// crudRouter applies to deletes everywhere else in the app.
router.post(
  '/',
  auth(['admin']),
  [
    ...userFieldValidation,
    body('password')
      .isLength({ min: 8 }).withMessage('Password must be at least 8 characters')
      .matches(/[A-Z]/).withMessage('Password must contain an uppercase letter')
      .matches(/[0-9]/).withMessage('Password must contain a number'),
  ],
  asyncHandler(async (req, res) => {
    checkValidation(req);
    const { name, email, password, role, status, permissions } = req.body;
    const passwordHash = await bcrypt.hash(password, 10);

    const user = await prisma.$transaction(async (tx) => {
      const created = await tx.appUser.create({
        data: { name: name.trim(), email: email.trim(), passwordHash, role, status: status || 'Active' },
      });
      const rows = toPermissionRows(created.id, permissions);
      if (rows.length) await tx.userPermission.createMany({ data: rows });
      return tx.appUser.findUnique({ where: { id: created.id }, include: { permissions: true } });
    });

    res.status(201).json({ success: true, data: safeUser(user) });
  })
);

// PUT /:id — password is optional here: blank/omitted leaves the existing
// hash untouched, so editing someone's role or permissions doesn't force a
// password reset in the same request. Permissions are always a full
// replace, never a patch — the grid submits its complete current state on
// every save, so delete-then-recreate inside the same transaction as the
// row update is the simplest thing that's also always correct (no risk of a
// stale row from a menu item the client didn't send surviving the save).
router.put(
  '/:id',
  auth(['admin']),
  [
    ...userFieldValidation,
    body('password')
      .optional({ checkFalsy: true })
      .isLength({ min: 8 }).withMessage('Password must be at least 8 characters')
      .matches(/[A-Z]/).withMessage('Password must contain an uppercase letter')
      .matches(/[0-9]/).withMessage('Password must contain a number'),
  ],
  asyncHandler(async (req, res) => {
    checkValidation(req);
    const id = parseId(req.params.id);
    const { name, email, password, role, status, permissions } = req.body;

    const data = { name: name.trim(), email: email.trim(), role, status: status || 'Active' };
    if (password) data.passwordHash = await bcrypt.hash(password, 10);

    const user = await prisma.$transaction(async (tx) => {
      const updated = await tx.appUser.update({ where: { id }, data });
      await tx.userPermission.deleteMany({ where: { userId: id } });
      const rows = toPermissionRows(id, permissions);
      if (rows.length) await tx.userPermission.createMany({ data: rows });
      return tx.appUser.findUnique({ where: { id: updated.id }, include: { permissions: true } });
    });

    res.json({ success: true, data: safeUser(user) });
  })
);

// DELETE /:id — admin only. Refusing to let an admin delete their own
// account here isn't optional politeness: doing it mid-request would revoke
// req.user's own row while the very request proving they're an admin is
// still in flight, with no recovery path short of direct DB access.
router.delete('/:id', auth(['admin']), asyncHandler(async (req, res) => {
  const id = parseId(req.params.id);
  if (req.user.id === id) {
    return res.status(400).json({ success: false, message: 'You cannot delete your own account.' });
  }
  await prisma.appUser.delete({ where: { id } });
  res.json({ success: true, message: 'Deleted successfully' });
}));

module.exports = router;
