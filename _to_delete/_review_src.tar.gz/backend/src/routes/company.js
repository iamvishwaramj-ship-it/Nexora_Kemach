const router = require('express').Router();
const prisma = require('../prisma/client');
const auth = require('../middleware/auth');
const asyncHandler = require('../utils/asyncHandler');
const crudRouter = require('../utils/crudRouter');
const { resolveDocumentNumber } = require('../utils/documentNumber');

// Company Details — singleton (one row for the whole org), get/update only.
router.get('/details', auth(), asyncHandler(async (req, res) => {
  let details = await prisma.companyDetails.findFirst();
  if (!details) details = await prisma.companyDetails.create({ data: { currency: 'INR' } });
  res.json({ success: true, data: details });
}));

router.put('/details', auth(), asyncHandler(async (req, res) => {
  let details = await prisma.companyDetails.findFirst();
  if (!details) {
    details = await prisma.companyDetails.create({ data: req.body });
  } else {
    details = await prisma.companyDetails.update({ where: { id: details.id }, data: req.body });
  }
  res.json({ success: true, data: details });
}));

// ---------------------------------------------------------------------------
// Document Numbering Series
//
// SAP Business One-style numbering: one series per (document type, financial
// year), each with its own pattern, range and atomic counter. All the actual
// numbering logic — formatting, validation, allocation — lives in
// services/documentNumberService.js; these routes are thin plumbing over it.
//
// Route order matters: the literal sub-paths (/catalog, /reset, /preview,
// /next, /peek, /rollover) must be declared before '/:id' or Express will
// match them as an id.
// ---------------------------------------------------------------------------
const numbering = require('../services/documentNumberService');

// Defaults used by "Reset to Default". Mirrors the service catalog so a fresh
// install and a reset produce identical series — keep in sync with
// backend/src/prisma/seed/seed.js's seedDocumentNumbering.
const DEFAULT_SERIES_SHAPE = {
  separator: '-',
  includeFyInNumber: true,
  numberLength: 6,
  startNumber: 1,
  endNumber: 999999,
  resetEveryFy: true,
  autoGenerate: true,
  manualEntry: false,
  status: 'Active',
  suffix: null,
};

/** Coerce a request body into the field set the series table accepts. */
function toSeriesData(body, { fyCode, documentName, seriesName }) {
  const num = (v, fallback) => (v === undefined || v === null || v === '' ? fallback : Math.trunc(Number(v)));
  const bool = (v, fallback) => (v === undefined || v === null ? fallback : Boolean(v));
  const str = (v) => (v === undefined || v === null || String(v).trim() === '' ? null : String(v).trim());
  // Prefix and suffix are canonicalised to upper case here rather than only in
  // the form. They end up printed on statutory documents, so 'PO' and 'po'
  // must not be storable as two different series — the numbers they issue
  // would be indistinguishable on paper while the uniqueness checks treated
  // them as unrelated.
  const code = (v) => { const s = str(v); return s === null ? null : s.toUpperCase(); };

  const startNumber = num(body.startNumber, DEFAULT_SERIES_SHAPE.startNumber);
  return {
    documentCode: body.documentCode,
    documentName,
    seriesName,
    financialYearId: num(body.financialYearId, null),
    fyCode,
    prefix: code(body.prefix),
    suffix: code(body.suffix),
    separator: body.separator === undefined ? DEFAULT_SERIES_SHAPE.separator : String(body.separator),
    includeFyInNumber: bool(body.includeFyInNumber, DEFAULT_SERIES_SHAPE.includeFyInNumber),
    numberLength: num(body.numberLength, DEFAULT_SERIES_SHAPE.numberLength),
    startNumber,
    nextNumber: num(body.nextNumber, startNumber),
    endNumber: num(body.endNumber, DEFAULT_SERIES_SHAPE.endNumber),
    resetEveryFy: bool(body.resetEveryFy, DEFAULT_SERIES_SHAPE.resetEveryFy),
    autoGenerate: bool(body.autoGenerate, DEFAULT_SERIES_SHAPE.autoGenerate),
    manualEntry: bool(body.manualEntry, DEFAULT_SERIES_SHAPE.manualEntry),
    status: body.status || DEFAULT_SERIES_SHAPE.status,
  };
}

// `errors` can be a mix of plain strings (no specific field) and
// { field, message } objects — validateSeriesPayload returns the latter so
// the frontend can show each message under the input it actually belongs to,
// instead of only in a single toast.
const badRequest = (errors) => {
  const structured = errors.map((e) => (typeof e === 'string' ? { field: null, message: e } : e));
  const err = new Error(structured.map((e) => e.message).join('; '));
  err.status = 400;
  err.errors = structured;
  return err;
};

/** Every other series for the same document type and year — the set the
 *  name-collision and range-overlap checks run against. */
// Master-code series (customer, product, branch, ...) are perpetual and
// carry no financial year, so their siblings are the rows where
// financialYearId IS NULL. See DOCUMENT_CATALOG in documentNumberService.js
// for why a master must never be year-scoped.
function loadSiblings(documentCode, financialYearId) {
  return prisma.documentNumbering.findMany({
    where: {
      documentCode,
      financialYearId: numbering.isMasterScope(documentCode) ? null : Number(financialYearId),
    },
  });
}

// Static reference data for the Add/Edit form: document types, separators and
// length options. `seriesCount` tells the form how many series a document type
// already has in the selected year — nothing is filtered out, since a document
// type may legitimately have several.
router.get('/document-numbers/catalog', auth(), asyncHandler(async (req, res) => {
  const financialYearId = req.query.financialYearId ? Number(req.query.financialYearId) : null;

  const counts = new Map();
  // Masters are counted regardless of the selected year — they have none.
  const grouped = await prisma.documentNumbering.groupBy({
    by: ['documentCode'],
    where: financialYearId
      ? { OR: [{ financialYearId }, { financialYearId: null }] }
      : { financialYearId: null },
    _count: { _all: true },
  });
  grouped.forEach((g) => counts.set(g.documentCode, g._count._all));

  res.json({
    success: true,
    data: {
      // The 12 master-code documents (Branch, Tax Code, Sales Employee,
      // Product Group, Product Sub Group, Brand, Unit of Measure, Product,
      // Product Catalog, Customer, Supplier, Transporter) are excluded here —
      // they still auto-generate their codes via the same numbering engine
      // (see DocumentNoField on each master's own page), they're just not
      // offered on this screen for manual series configuration.
      documents: numbering.DOCUMENT_CATALOG
        .filter((d) => !d.hiddenFromNumberingUI)
        .map((d) => ({
          ...d,
          seriesCount: counts.get(d.code) || 0,
          configured: (counts.get(d.code) || 0) > 0,
        })),
      separators: numbering.SEPARATORS,
      numberLengths: numbering.NUMBER_LENGTH_OPTIONS,
    },
  });
}));

// Every series for one document type in one financial year — backs the
// "Existing Series for ..." table on the Add/Edit form. Also returns the
// suggested name and start point for the next series, so the form can
// pre-fill a non-overlapping range instead of making the user work it out.
router.get('/document-numbers/by-document/:documentCode', auth(), asyncHandler(async (req, res) => {
  const { documentCode } = req.params;
  const doc = numbering.CATALOG_BY_CODE.get(documentCode);
  if (!doc) throw badRequest([`Unknown document type "${documentCode}"`]);

  const isMaster = numbering.isMasterScope(documentCode);

  let fyId = req.query.financialYearId ? Number(req.query.financialYearId) : null;
  if (!isMaster && !fyId) {
    const fy = await numbering.getActiveFinancialYear();
    fyId = fy?.id ?? null;
  }
  // A master needs no financial year; a transaction cannot be numbered
  // without one.
  if (!isMaster && !fyId) return res.json({ success: true, data: { series: [], suggestion: null } });

  const rows = await prisma.documentNumbering.findMany({
    where: { documentCode, financialYearId: isMaster ? null : fyId },
    include: { financialYear: true },
    orderBy: [{ startNumber: 'asc' }, { id: 'asc' }],
  });

  // Next free block starts one past the highest End No. in use, so the
  // suggested range can't overlap anything that already exists.
  const highestEnd = rows.reduce((max, r) => Math.max(max, r.endNumber), 0);
  const template = rows.find((r) => r.isDefault) || rows[rows.length - 1] || null;

  const startNumber = rows.length ? highestEnd + 1 : DEFAULT_SERIES_SHAPE.startNumber;

  // Carry the template's range size forward from the new Start No., rather
  // than reusing its fixed End No. — otherwise the second series in a
  // document type would suggest a range that starts after it ends (e.g.
  // Start 1,000,000 with the default End No. still 999,999) and get rejected
  // on save every time the first series fills its default 1–999,999 block.
  const templateRangeSize = template ? (template.endNumber - template.startNumber + 1) : null;
  const rangeSize = templateRangeSize && templateRangeSize > 0
    ? templateRangeSize
    : (DEFAULT_SERIES_SHAPE.endNumber - DEFAULT_SERIES_SHAPE.startNumber + 1);
  let endNumber = startNumber + rangeSize - 1;

  // Widen the padding if the carried-forward range no longer fits the
  // template's digit count — e.g. rolling from 999,999 into 7-digit territory.
  let numberLength = template?.numberLength ?? DEFAULT_SERIES_SHAPE.numberLength;
  const neededLength = Math.min(numbering.MAX_NUMBER_LENGTH, String(endNumber).length);
  if (neededLength > numberLength) numberLength = neededLength;
  endNumber = Math.min(endNumber, numbering.maxValueForLength(numberLength));

  // A digit count can only be offered for the next series if a valid,
  // non-overlapping range still fits inside it: Start No. (one past the
  // highest End No. in use) plus the minimum gap must not exceed what that
  // many digits can hold. E.g. once a document's numbers have filled
  // 1-999, "3 Digits" can no longer host a next series — there's no room
  // left below 1,000 — so it's dropped from the list entirely.
  const nextStart = rows.length ? highestEnd + 1 : 0;
  const availableNumberLengths = numbering.NUMBER_LENGTH_OPTIONS.filter(
    (len) => numbering.maxValueForLength(len) >= nextStart + numbering.MIN_SERIES_RANGE_GAP
  );

  res.json({
    success: true,
    data: {
      series: rows.map(numbering.decorateSeries),
      availableNumberLengths,
      suggestion: {
        seriesName: numbering.suggestSeriesName(rows.map((r) => r.seriesName)),
        startNumber,
        endNumber,
        prefix: template?.prefix ?? doc.prefix,
        separator: template?.separator ?? DEFAULT_SERIES_SHAPE.separator,
        numberLength,
        includeFyInNumber: template?.includeFyInNumber ?? DEFAULT_SERIES_SHAPE.includeFyInNumber,
        // The first series for a document type has to be the default;
        // later ones are staged and promoted deliberately.
        isDefault: rows.length === 0,
      },
    },
  });
}));

// Promote a series to be the one its document type allocates from.
router.post('/document-numbers/:id/set-default', auth(), asyncHandler(async (req, res) => {
  const row = await numbering.setDefaultSeries(Number(req.params.id));
  res.json({ success: true, data: numbering.decorateSeries(row) });
}));

// Live preview for the form — no persistence, no side effects.
router.post('/document-numbers/preview', auth(), asyncHandler(async (req, res) => {
  const { financialYearId, prefix, suffix, separator, numberLength, startNumber, includeFyInNumber } = req.body;

  let fyCode = req.body.fyCode || null;
  if (!fyCode && financialYearId) {
    const fy = await prisma.financialYear.findUnique({ where: { id: Number(financialYearId) } });
    fyCode = numbering.deriveFyCode(fy);
  }

  const shape = {
    prefix, suffix, separator,
    numberLength: numberLength ?? DEFAULT_SERIES_SHAPE.numberLength,
    fyCode,
    includeFyInNumber: includeFyInNumber ?? true,
  };
  res.json({
    success: true,
    data: {
      fyCode,
      preview: numbering.buildDocumentNumber(shape, startNumber ?? DEFAULT_SERIES_SHAPE.startNumber),
      maxForLength: numbering.maxValueForLength(shape.numberLength),
    },
  });
}));

// Consume the next number for a document type. This is the endpoint every
// transaction route should call inside its own save transaction.
router.post('/document-numbers/next', auth(), asyncHandler(async (req, res) => {
  const { documentCode, financialYearId } = req.body;
  const result = await numbering.allocateDocumentNumber(documentCode, {
    financialYearId: financialYearId ? Number(financialYearId) : null,
  });
  res.json({ success: true, data: result });
}));

// Same lookup without burning the number — for showing it on a blank form.
router.post('/document-numbers/peek', auth(), asyncHandler(async (req, res) => {
  const { documentCode, financialYearId } = req.body;
  const result = await numbering.peekDocumentNumber(documentCode, {
    financialYearId: financialYearId ? Number(financialYearId) : null,
  });
  res.json({ success: true, data: result });
}));

// Copy this year's series into next year (respecting each series' Reset Every
// FY flag). Idempotent — re-running skips series that already exist.
router.post('/document-numbers/rollover', auth(), asyncHandler(async (req, res) => {
  const { targetFinancialYearId, sourceFinancialYearId } = req.body;
  if (!targetFinancialYearId) throw badRequest(['Target financial year is required']);
  const created = await numbering.rolloverToFinancialYear(Number(targetFinancialYearId), {
    sourceFinancialYearId: sourceFinancialYearId ? Number(sourceFinancialYearId) : null,
  });
  res.json({ success: true, data: created.map(numbering.decorateSeries), message: `${created.length} series created` });
}));

// Recreate the standard series set for a financial year. Series that have
// already issued numbers are left alone — resetting a live counter would
// re-issue numbers that are already printed on documents.
router.post('/document-numbers/reset', auth(), asyncHandler(async (req, res) => {
  let fyId = req.body?.financialYearId ? Number(req.body.financialYearId) : null;
  if (!fyId) {
    const fy = await numbering.getActiveFinancialYear();
    if (!fy) throw badRequest(['No financial year is configured. Create one under Company Setup → Financial Year first.']);
    fyId = fy.id;
  }
  const fy = await prisma.financialYear.findUnique({ where: { id: fyId } });
  if (!fy) throw badRequest(['Financial year not found']);
  const fyCode = numbering.deriveFyCode(fy);

  const skipped = [];
  // Only the year-scoped transaction documents are rebuilt here. Master-code
  // series (customer, product, branch, ...) are perpetual and carry no
  // financial year at all — creating an FY-scoped copy of one would give a
  // master two default series and reissue codes that records already hold.
  // They are seeded once by migration 20260809090000 and are not part of a
  // per-year reset.
  const resettable = numbering.DOCUMENT_CATALOG.filter((d) => !numbering.isMasterScope(d.code));
  for (const def of resettable) {
    const siblings = await loadSiblings(def.code, fyId);

    // Reset only rebuilds the series *this endpoint itself* created — the
    // one named 'Series 1' (or, for rows from before that naming convention
    // changed, the older 'Default'). Matching by name rather than the
    // isDefault flag is deliberate: a hand-made series that happens to be
    // the only one for its document type is also the default, but it is
    // still the admin's own series, not this endpoint's, and must not be
    // silently overwritten just because it holds that flag.
    //
    // Matching *only* 'Series 1' (the literal bug this comment used to
    // describe) breaks the moment a row still carries the pre-rename
    // 'Default' name: `existing` comes back undefined, so the overlap check
    // below sees that series' own 1-999999 range as a *foreign* "custom
    // series in range" and skips it entirely — Reset to Default silently did
    // nothing. Accepting both names is what a database that hasn't had the
    // rename migration (20260806090000_rename_default_series_to_series_n)
    // applied yet still needs.
    const existing = siblings.find((s) => s.seriesName === 'Series 1' || s.seriesName === 'Default');

    if (existing && numbering.isConsumed(existing)) {
      skipped.push(def.name);
      continue;
    }
    // A hand-made series may already occupy the default range; rewriting
    // 'Series 1' back to 1-999999 would overlap it.
    const others = siblings.filter((s) => s.id !== existing?.id);
    const wouldOverlap = others.some(
      (s) => DEFAULT_SERIES_SHAPE.startNumber <= s.endNumber && s.startNumber <= DEFAULT_SERIES_SHAPE.endNumber
    );
    if (wouldOverlap) {
      skipped.push(`${def.name} (custom series in range)`);
      continue;
    }

    const data = {
      ...DEFAULT_SERIES_SHAPE,
      documentCode: def.code,
      documentName: def.name,
      seriesName: 'Series 1',
      financialYearId: fyId,
      fyCode,
      prefix: def.prefix,
      nextNumber: DEFAULT_SERIES_SHAPE.startNumber,
      currentNumber: null,
      isDefault: true,
    };

    if (existing) {
      await prisma.documentNumbering.update({ where: { id: existing.id }, data });
    } else {
      // Demote whatever currently holds the default flag — the partial unique
      // index allows only one per document type and year.
      await prisma.documentNumbering.updateMany({
        where: { documentCode: def.code, financialYearId: fyId, isDefault: true },
        data: { isDefault: false },
      });
      await prisma.documentNumbering.create({ data });
    }
  }

  const rows = await prisma.documentNumbering.findMany({
    where: { financialYearId: fyId },
    include: { financialYear: true },
    orderBy: { id: 'asc' },
  });
  res.json({
    success: true,
    data: rows.map(numbering.decorateSeries),
    message: skipped.length
      ? `Reset complete. Skipped ${skipped.length} series that have already issued numbers: ${skipped.join(', ')}.`
      : 'Reset complete.',
  });
}));

router.get('/document-numbers', auth(), asyncHandler(async (req, res) => {
  const { financialYearId, documentCode, status, q } = req.query;

  const where = {};
  if (financialYearId) where.financialYearId = Number(financialYearId);
  if (documentCode) where.documentCode = documentCode;
  if (status) where.status = status;
  if (q) {
    where.OR = [
      { documentName: { contains: q } },
      { documentCode: { contains: q } },
      { prefix: { contains: q } },
      { seriesName: { contains: q } },
    ];
  }

  const rows = await prisma.documentNumbering.findMany({
    where,
    include: { financialYear: true },
    // Group a document type's series together and order them by range, so the
    // list reads as "PO: block 1, block 2, block 3" rather than by insert order.
    orderBy: [{ financialYearId: 'desc' }, { documentCode: 'asc' }, { startNumber: 'asc' }],
  });
  res.json({ success: true, data: rows.map(numbering.decorateSeries) });
}));

router.get('/document-numbers/:id', auth(), asyncHandler(async (req, res) => {
  const row = await prisma.documentNumbering.findUnique({
    where: { id: Number(req.params.id) },
    include: { financialYear: true },
  });
  if (!row) return res.status(404).json({ success: false, message: 'Numbering series not found' });
  res.json({ success: true, data: numbering.decorateSeries(row) });
}));

router.post('/document-numbers', auth(), asyncHandler(async (req, res) => {
  const doc = numbering.CATALOG_BY_CODE.get(req.body.documentCode);
  if (!doc) throw badRequest([`Unknown document type "${req.body.documentCode || ''}"`]);

  // A master series is perpetual: no financial year to select, no year
  // token in the pattern, and it must never reset — a code that restarts
  // each April would be reissued to a record that already holds it.
  const isMaster = numbering.isMasterScope(doc.code);
  const fyId = isMaster ? null : Number(req.body.financialYearId);
  const fy = fyId ? await prisma.financialYear.findUnique({ where: { id: fyId } }) : null;
  if (!isMaster && !fy) throw badRequest(['Select a valid financial year']);

  // A document type can hold several series in a year, so the name has to be
  // unique among its siblings. Auto-name when the client didn't supply one.
  const siblings = await loadSiblings(doc.code, fyId);
  const seriesName = String(req.body.seriesName ?? '').trim()
    || numbering.suggestSeriesName(siblings.map((s) => s.seriesName));

  const data = toSeriesData(req.body, {
    fyCode: fy ? numbering.deriveFyCode(fy) : null,
    documentName: doc.name,
    seriesName,
  });
  data.currentNumber = null; // a brand-new series has issued nothing
  if (isMaster) {
    data.financialYearId = null;
    data.fyCode = null;
    data.includeFyInNumber = false;
    data.resetEveryFy = false;
  }

  const errors = numbering.validateSeriesPayload(data, { siblings });
  if (errors.length) throw badRequest(errors);

  // The first series for a document type must be the default, or nothing
  // could ever be numbered. Beyond that, honour what the client asked for.
  const wantsDefault = siblings.length === 0 ? true : Boolean(req.body.isDefault);
  data.isDefault = wantsDefault;

  const row = await prisma.$transaction(async (tx) => {
    if (wantsDefault) {
      // At most one default per (document type, FY) — demote the incumbent
      // inside the same transaction so the partial unique index is never
      // momentarily violated.
      await tx.documentNumbering.updateMany({
        where: { documentCode: doc.code, financialYearId: fyId, isDefault: true },
        data: { isDefault: false },
      });
    }
    return tx.documentNumbering.create({ data, include: { financialYear: true } });
  });

  res.status(201).json({ success: true, data: numbering.decorateSeries(row) });
}));

router.put('/document-numbers/:id', auth(), asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  const existing = await prisma.documentNumbering.findUnique({ where: { id } });
  if (!existing) return res.status(404).json({ success: false, message: 'Numbering series not found' });

  const doc = numbering.CATALOG_BY_CODE.get(req.body.documentCode || existing.documentCode);
  if (!doc) throw badRequest([`Unknown document type "${req.body.documentCode}"`]);

  const fyId = Number(req.body.financialYearId || existing.financialYearId);
  const fy = await prisma.financialYear.findUnique({ where: { id: fyId } });
  if (!fy) throw badRequest(['Select a valid financial year']);

  const seriesName = String(req.body.seriesName ?? existing.seriesName ?? '').trim();

  const data = toSeriesData({ ...existing, ...req.body }, {
    fyCode: numbering.deriveFyCode(fy),
    documentName: doc.name,
    seriesName,
  });

  // currentNumber and nextNumber are owned by the allocator, never by the
  // client — accepting them from a PUT would let a stale form rewind a live
  // counter and re-issue numbers. The only exception is repositioning an
  // untouched series, which is handled by the startNumber branch below.
  delete data.currentNumber;
  if (!numbering.isConsumed(existing)) {
    data.nextNumber = data.startNumber;
  } else {
    data.nextNumber = existing.nextNumber;

    // Once numbers have gone out, the pattern is frozen — so don't write these
    // fields at all. Rebuilding them from the request would rewrite the stored
    // value even when the client never asked to change it: a row saved before
    // prefixes were canonicalised would silently jump from 'po' to 'PO'
    // mid-sequence, splitting one series across two visibly different formats.
    // validateSeriesPayload still rejects a *deliberate* change below.
    for (const field of numbering.LOCKED_ONCE_CONSUMED) delete data[field];
  }

  // isDefault moves only through the dedicated set-default endpoint, which
  // demotes the incumbent in the same transaction. Letting a plain PUT set it
  // would either violate the partial unique index or silently leave two
  // defaults' worth of intent with only one taking effect.
  delete data.isDefault;

  const siblings = await loadSiblings(doc.code, fyId);
  const errors = numbering.validateSeriesPayload({ ...req.body, ...data }, { existing, siblings });
  if (errors.length) throw badRequest(errors);

  const row = await prisma.documentNumbering.update({ where: { id }, data, include: { financialYear: true } });
  res.json({ success: true, data: numbering.decorateSeries(row) });
}));

// A series that has issued numbers is part of the audit trail — deleting it
// would orphan every document numbered from it. SAP blocks this too; the way
// to retire a series is to set it Inactive.
router.delete('/document-numbers/:id', auth(), asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  const existing = await prisma.documentNumbering.findUnique({ where: { id } });
  if (!existing) return res.status(404).json({ success: false, message: 'Numbering series not found' });

  if (numbering.isConsumed(existing)) {
    return res.status(409).json({
      success: false,
      message: `This series has already issued ${numbering.currentNumber(existing)}. It cannot be deleted — set its status to Inactive instead.`,
    });
  }

  // Deleting the default series leaves the document type unable to number
  // anything. If a sibling can take over, hand the flag to it rather than
  // making the user notice the breakage at posting time.
  const successor = existing.isDefault
    ? await prisma.documentNumbering.findFirst({
      where: {
        documentCode: existing.documentCode,
        financialYearId: existing.financialYearId,
        status: 'Active',
        id: { not: id },
      },
      orderBy: { startNumber: 'asc' },
    })
    : null;

  await prisma.$transaction(async (tx) => {
    await tx.documentNumbering.delete({ where: { id } });
    if (successor) {
      await tx.documentNumbering.update({ where: { id: successor.id }, data: { isDefault: true } });
    }
  });

  res.json({
    success: true,
    data: null,
    message: successor ? `Series deleted. "${successor.seriesName}" is now the default.` : 'Series deleted.',
  });
}));

// Tax Code — full CRUD (generic crudRouter below) plus a reset-to-default
// action. Defaults extend backend/src/prisma/seed/seed.js's seedTaxCodes
// (which only seeds the 3 GST slabs) with the full common Indian GST set —
// keep both lists in sync if either changes.
const DEFAULT_TAX_CODES = [
  { taxCode: 'GST5', taxName: 'GST 5%', taxType: 'GST', taxRate: 5.0, description: 'Goods and Services Tax 5%', status: 'Active' },
  { taxCode: 'GST12', taxName: 'GST 12%', taxType: 'GST', taxRate: 12.0, description: 'Goods and Services Tax 12%', status: 'Active' },
  { taxCode: 'GST18', taxName: 'GST 18%', taxType: 'GST', taxRate: 18.0, description: 'Goods and Services Tax 18%', status: 'Active' },
  { taxCode: 'GST28', taxName: 'GST 28%', taxType: 'GST', taxRate: 28.0, description: 'Goods and Services Tax 28%', status: 'Active' },
  { taxCode: 'IGST18', taxName: 'IGST 18%', taxType: 'IGST', taxRate: 18.0, description: 'Integrated GST 18%', status: 'Active' },
  { taxCode: 'CGST9', taxName: 'CGST 9%', taxType: 'CGST', taxRate: 9.0, description: 'Central GST 9%', status: 'Active' },
  { taxCode: 'SGST9', taxName: 'SGST 9%', taxType: 'SGST', taxRate: 9.0, description: 'State GST 9%', status: 'Active' },
];

// Restores the standard GST tax code set — used by the "Reset to Default"
// action on the page. taxCode is @unique, so upsert is safe here.
router.post('/tax-codes/reset', auth(), asyncHandler(async (req, res) => {
  for (const def of DEFAULT_TAX_CODES) {
    await prisma.taxCode.upsert({ where: { taxCode: def.taxCode }, update: def, create: def });
  }
  const rows = await prisma.taxCode.findMany({ orderBy: { id: 'asc' } });
  res.json({ success: true, data: rows });
}));

// "GST 12%" and "GST12%" read as the same tax code to a person, but the DB's
// unique index on taxCode only catches an exact byte-for-byte repeat — it
// would happily store both as two "different" rows. Collapsing whitespace
// and case before comparing is what actually matches how someone would
// eyeball the list and call it a duplicate.
const normaliseTaxLabel = (v) => String(v ?? '').replace(/\s+/g, '').toLowerCase();

// `client` defaults to the plain prisma singleton (used by PUT, which never
// touches the numbering series) but POST below passes its transaction's `tx`
// so the duplicate check reads the same in-flight connection it's about to
// insert on, rather than a second, separate connection.
async function findDuplicateTaxCode({ taxCode, taxName }, { ignoreId = null, client = prisma } = {}) {
  const normCode = normaliseTaxLabel(taxCode);
  const normName = normaliseTaxLabel(taxName);
  const rows = await client.taxCode.findMany({
    where: ignoreId ? { id: { not: Number(ignoreId) } } : undefined,
    select: { id: true, taxCode: true, taxName: true },
  });
  return rows.find(
    (r) => (normCode && normaliseTaxLabel(r.taxCode) === normCode)
        || (normName && normaliseTaxLabel(r.taxName) === normName)
  );
}

// Bespoke create/update in front of the generic crudRouter below (same
// pattern as /sales/enquiries in resources.js) — the duplicate check needs
// an async lookup crudFactory's plain pass-through create/update can't do.
// GET/DELETE still fall through to crudRouter unchanged.
router.post('/tax-codes', auth(), asyncHandler(async (req, res) => {
  // This bespoke handler sits in front of the generic crudRouter mount below
  // (registered later, purely for the duplicate check, which crudFactory's
  // plain pass-through create can't do) — but that means it, not crudRouter,
  // is what actually runs on every POST here, so it has to do crudRouter's
  // autoNumber step itself. Without this, taxCode was whatever the client
  // sent (the frontend's last *peeked* suggestion, which was only ever a
  // preview) and the TAX series' counter never advanced — every "Add Tax
  // Code" kept re-suggesting the same already-taken code. Same pattern as
  // resolveDocumentNumber('CAT', ...) on /product-catalogs.
  //
  // Allocating BEFORE the duplicate check (not after, as this used to read)
  // matters: with Auto Generate on, req.body.taxCode is that same stale
  // peeked preview — checking it for a code collision means checking a value
  // that was never going to be saved anyway, and since peek() never advances
  // the counter, that preview is *always* the code of the row created last,
  // so the save was rejected as "already exists" on literally every attempt.
  // Checking the code the transaction is actually about to write is the only
  // version of this check that means anything.
  const row = await prisma.$transaction(async (tx) => {
    const { documentNumber, syncManual } = await resolveDocumentNumber('TAX', req.body.taxCode, tx);
    const dupe = await findDuplicateTaxCode({ taxCode: documentNumber, taxName: req.body.taxName }, { client: tx });
    if (dupe) {
      throw badRequest([
        { field: dupe.taxCode && normaliseTaxLabel(dupe.taxCode) === normaliseTaxLabel(documentNumber) ? 'taxCode' : 'taxName',
          message: `"${dupe.taxCode} — ${dupe.taxName}" already covers this — differing only by spacing/case does not make it a new tax code` },
      ]);
    }
    const created = await tx.taxCode.create({ data: { ...req.body, taxCode: documentNumber } });
    if (syncManual) await syncManual();
    return created;
  });
  res.status(201).json({ success: true, data: row });
}));

router.put('/tax-codes/:id', auth(), asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  const dupe = await findDuplicateTaxCode(req.body, { ignoreId: id });
  if (dupe) {
    throw badRequest([
      { field: dupe.taxCode && normaliseTaxLabel(dupe.taxCode) === normaliseTaxLabel(req.body.taxCode) ? 'taxCode' : 'taxName',
        message: `"${dupe.taxCode} — ${dupe.taxName}" already covers this — differing only by spacing/case does not make it a new tax code` },
    ]);
  }
  const row = await prisma.taxCode.update({ where: { id }, data: req.body });
  res.json({ success: true, data: row });
}));

// Master codes are auto-generated from perpetual numbering series (no
// financial year, never reset) — see DOCUMENT_CATALOG in
// services/documentNumberService.js.
router.use('/branches', crudRouter(prisma.branch, {
  searchFields: ['branchCode', 'branchName', 'city'],
  autoNumber: { documentCode: 'BRN', field: 'branchCode', delegate: 'branch' },
  // At most one branch may be the Main Branch (Branch.isDefault, shown as the
  // "Default" column on the list). Promoting one demotes whoever held it
  // before — the tag MOVES rather than being duplicated.
  //
  // Enforced here, not in the form: the browser cannot make "promote B and
  // demote A" a single atomic step, so two people saving at once could
  // otherwise leave two branches both flagged, or leave none flagged if the
  // demote landed and the promote failed. Running inside the write's own
  // transaction (see afterWrite in utils/crudFactory.js) makes both halves
  // succeed or neither.
  //
  // Keyed off the row that was actually written rather than the request body,
  // so it is right whether isDefault was sent as a real boolean, omitted
  // entirely on an unrelated edit, or coerced by the client. That also makes
  // it self-healing: editing the current main branch's phone number re-runs
  // the demotion and clears any stray flag left by older data.
  afterWrite: async ({ tx, row }) => {
    if (!row.isDefault) return;
    await tx.branch.updateMany({
      where: { isDefault: true, id: { not: row.id } },
      data: { isDefault: false },
    });
  },
}));
router.use('/financial-years', crudRouter(prisma.financialYear, { searchFields: ['financialYearName'] }));
router.use('/tax-codes', crudRouter(prisma.taxCode, {
  searchFields: ['taxCode', 'taxName'],
  autoNumber: { documentCode: 'TAX', field: 'taxCode', delegate: 'taxCode' },
}));
router.use('/bank-names', crudRouter(prisma.bankName, { searchFields: ['bankName'] }));
router.use('/house-banks', crudRouter(prisma.houseBank, { searchFields: ['bankName', 'accountNumber', 'accountName'] }));
router.use('/sales-employees', crudRouter(prisma.salesEmployee, {
  searchFields: ['employeeCode', 'employeeName', 'email'],
  autoNumber: { documentCode: 'EMP', field: 'employeeCode', delegate: 'salesEmployee' },
}));

// Approval Flow — a master/detail resource (ApprovalFlow has many
// ApprovalFlowLevel rows), so it can't use the generic crudRouter, which
// only knows flat records. These bespoke routes mirror crudRouter's URL
// shape (GET /, GET /:id, POST /, PUT /:id, DELETE /:id) so the frontend
// can still use the generic createCrudApi hook-set against them.
const approvalFlowInclude = { levels: { orderBy: { levelOrder: 'asc' } } };

function toLevelData(level, index) {
  return {
    levelName: level.levelName || `Level ${index + 1}`,
    approverType: level.approverType || 'User',
    approver: level.approver,
    fromAmount: level.fromAmount ?? 0,
    toAmount: level.toAmount === '' || level.toAmount == null ? null : level.toAmount,
    requiredAction: level.requiredAction || 'Approve',
    levelOrder: index + 1,
  };
}

router.get('/approval-flows', auth(), asyncHandler(async (req, res) => {
  const { q } = req.query;
  const where = q ? { transactionName: { contains: q } } : undefined;
  const rows = await prisma.approvalFlow.findMany({ where, include: approvalFlowInclude, orderBy: { id: 'desc' } });
  res.json({ success: true, data: rows });
}));

router.get('/approval-flows/:id', auth(), asyncHandler(async (req, res) => {
  const row = await prisma.approvalFlow.findUnique({ where: { id: Number(req.params.id) }, include: approvalFlowInclude });
  if (!row) return res.status(404).json({ success: false, message: 'Record not found' });
  res.json({ success: true, data: row });
}));

router.post('/approval-flows', auth(), asyncHandler(async (req, res) => {
  const { levels = [], ...flow } = req.body;
  const row = await prisma.approvalFlow.create({
    data: {
      ...flow,
      levels: { create: levels.map(toLevelData) },
    },
    include: approvalFlowInclude,
  });
  res.status(201).json({ success: true, data: row });
}));

router.put('/approval-flows/:id', auth(), asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  const { levels = [], ...flow } = req.body;
  // Replace the level set wholesale on every save — simpler and safer than
  // diffing which rows were added/removed/reordered client-side.
  const row = await prisma.$transaction(async (tx) => {
    await tx.approvalFlowLevel.deleteMany({ where: { approvalFlowId: id } });
    return tx.approvalFlow.update({
      where: { id },
      data: {
        ...flow,
        levels: { create: levels.map(toLevelData) },
      },
      include: approvalFlowInclude,
    });
  });
  res.json({ success: true, data: row });
}));

router.delete('/approval-flows/:id', auth(), asyncHandler(async (req, res) => {
  // ApprovalFlowLevel.approvalFlow has onDelete: Cascade, so levels go with it.
  await prisma.approvalFlow.delete({ where: { id: Number(req.params.id) } });
  res.json({ success: true, message: 'Deleted successfully' });
}));

module.exports = router;
