const router = require('express').Router();
const prisma = require('../prisma/client');
const auth = require('../middleware/auth');
const asyncHandler = require('../utils/asyncHandler');
const { getStockMovementByProductCode } = require('../utils/stockLedger');

const MONTH_LABELS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

// Builds a 6-month trailing series (oldest -> newest) of summed `amount` from a
// list of rows that each have a `date` (Date) and `amount` (Decimal|null).
function monthlySeries(rows, dateField, amountField, months = 6) {
  const now = new Date();
  const buckets = [];
  for (let i = months - 1; i >= 0; i -= 1) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    buckets.push({ key: `${d.getFullYear()}-${d.getMonth()}`, name: MONTH_LABELS[d.getMonth()], year: d.getFullYear(), month: d.getMonth(), value: 0 });
  }
  const byKey = Object.fromEntries(buckets.map((b) => [b.key, b]));
  rows.forEach((r) => {
    const d = r[dateField];
    if (!d) return;
    const dt = new Date(d);
    const key = `${dt.getFullYear()}-${dt.getMonth()}`;
    if (byKey[key]) byKey[key].value += Number(r[amountField] || 0);
  });
  // `value` stays in Lakhs (chart axis scale); `rawValue` is the exact
  // rupee total for that month, undone from the Lakhs rounding, so the
  // drill-down popup can show real figures instead of a rounded chart value.
  return buckets.map((b) => ({
    name: b.name,
    year: b.year,
    month: b.month,
    value: Math.round((b.value / 100000) * 100) / 100,
    rawValue: Math.round(b.value * 100) / 100,
  }));
}

// % change of current calendar month sum vs previous calendar month sum.
function momChange(rows, dateField, amountField) {
  const now = new Date();
  const curKey = `${now.getFullYear()}-${now.getMonth()}`;
  const prev = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  const prevKey = `${prev.getFullYear()}-${prev.getMonth()}`;
  let cur = 0;
  let prv = 0;
  rows.forEach((r) => {
    const d = r[dateField];
    if (!d) return;
    const dt = new Date(d);
    const key = `${dt.getFullYear()}-${dt.getMonth()}`;
    const amt = Number(r[amountField] || 0);
    if (key === curKey) cur += amt;
    else if (key === prevKey) prv += amt;
  });
  if (prv === 0) return cur > 0 ? 100 : 0;
  return Math.round(((cur - prv) / prv) * 1000) / 10;
}

router.get('/stats', auth(), asyncHandler(async (req, res) => {
  const [
    salesInvoices,
    purchaseInvoices,
    receivablesAgg,
    payablesAgg,
    products,
    customers,
    suppliers,
    branches,
    users,
    companies,
    recentSales,
    recentPurchases,
    recentCollections,
    recentPayments,
  ] = await Promise.all([
    // Draft and cancelled invoices are not revenue or spend. Without this
    // filter the headline Total Sales figure — and the month-on-month change
    // and monthly series built from the same rows — counted every invoice
    // somebody was still typing, and every one that had been withdrawn.
    prisma.salesInvoice.findMany({
      where: { status: { notIn: ['Draft', 'Cancelled'] } },
      select: { amount: true, invoiceDate: true },
    }),
    prisma.purchaseInvoice.findMany({
      where: { status: { notIn: ['Draft', 'Cancelled'] } },
      select: { amount: true, invoiceDate: true },
    }),
    prisma.customerOutstanding.aggregate({ _sum: { balanceAmount: true }, where: { status: { not: 'Paid' } } }),
    prisma.supplierOutstanding.aggregate({ _sum: { balanceAmount: true }, where: { status: { not: 'Paid' } } }),
    prisma.product.findMany({ select: { productCode: true, productName: true, openingStock: true, costPrice: true, reorderLevel: true } }),
    prisma.customer.count(),
    prisma.supplier.count(),
    prisma.branch.count({ where: { status: 'Active' } }),
    prisma.appUser.count(),
    prisma.companyDetails.count(),
    prisma.salesInvoice.findMany({ orderBy: { invoiceDate: 'desc' }, take: 5 }),
    prisma.purchaseInvoice.findMany({ orderBy: { invoiceDate: 'desc' }, take: 5 }),
    prisma.collection.findMany({ orderBy: { receiptDate: 'desc' }, take: 5 }),
    prisma.supplierPayment.findMany({ orderBy: { paymentDate: 'desc' }, take: 5 }),
  ]);

  const totalSales = salesInvoices.reduce((s, r) => s + Number(r.amount || 0), 0);
  const totalPurchase = purchaseInvoices.reduce((s, r) => s + Number(r.amount || 0), 0);
  const totalReceivables = Number(receivablesAgg._sum.balanceAmount || 0);
  const totalPayables = Number(payablesAgg._sum.balanceAmount || 0);

  // Live stock, not the static opening-stock field: openingStock plus every
  // posted Stock Receipt (+), Stock Issue (−), and Stock Adjustment (±) for
  // that product, so this reflects actual warehouse activity instead of
  // whatever was typed in on product creation.
  const stockMovement = await getStockMovementByProductCode();
  const productsWithStock = products.map((p) => ({
    ...p,
    currentStock: Number(p.openingStock || 0) + (stockMovement.get(p.productCode) || 0),
  }));

  const totalInventoryValue = productsWithStock.reduce((s, p) => s + p.currentStock * Number(p.costPrice || 0), 0);

  // Top selling products — proxy via current inventory value (currentStock * costPrice),
  // since sales invoices don't carry a per-product line-item breakdown in this schema.
  // Was costed at salesPrice until that column was dropped from Product
  // (Product Master's Sales tab no longer collects one) — costPrice is the
  // closest remaining per-unit value to rank by.
  const productValues = productsWithStock
    .map((p) => ({ name: p.productName, value: p.currentStock * Number(p.costPrice || 0) }))
    .filter((p) => p.value > 0)
    .sort((a, b) => b.value - a.value);
  const totalProductValue = productValues.reduce((s, p) => s + p.value, 0) || 1;
  const topFour = productValues.slice(0, 4);
  const othersValue = productValues.slice(4).reduce((s, p) => s + p.value, 0);
  const topSellingProducts = [
    ...topFour.map((p) => ({ name: p.name, value: Math.round(p.value), percent: Math.round((p.value / totalProductValue) * 1000) / 10 })),
    ...(othersValue > 0 ? [{ name: 'Others', value: Math.round(othersValue), percent: Math.round((othersValue / totalProductValue) * 1000) / 10 }] : []),
  ];

  const inventoryStockAlert = productsWithStock
    .map((p) => ({
      name: p.productName,
      currentStock: p.currentStock,
      reorderLevel: Number(p.reorderLevel || 0),
      status: p.currentStock <= Number(p.reorderLevel || 0) ? 'Low Stock' : 'OK',
    }))
    .sort((a, b) => (a.status === b.status ? b.currentStock - a.currentStock : a.status === 'Low Stock' ? -1 : 1))
    .slice(0, 6);

  const recentTransactions = [
    ...recentSales.map((s) => ({ type: 'Sales Invoice', refNo: s.invoiceNo, party: s.customer, amount: s.amount, date: s.invoiceDate, status: s.status })),
    ...recentPurchases.map((p) => ({ type: 'Purchase Invoice', refNo: p.invoiceNo, party: p.supplier, amount: p.amount, date: p.invoiceDate, status: p.status })),
    ...recentCollections.map((c) => ({ type: 'Receipt', refNo: c.collectionNo, party: c.customerName, amount: c.paymentAmount, date: c.receiptDate, status: c.status === 'Posted' ? 'Received' : 'Draft' })),
    // SupplierPayment stores the figure as paymentAmount; there is no `amount`
    // column on the model, so this row rendered a blank amount in Recent
    // Transactions. The status is the document's own, not a hard-coded 'Paid'
    // — a payment still in Draft has not paid anybody.
    ...recentPayments.map((pay) => ({ type: 'Payment', refNo: pay.paymentNo, party: pay.supplierName, amount: pay.paymentAmount, date: pay.paymentDate, status: pay.status === 'Posted' ? 'Paid' : 'Draft' })),
  ]
    .sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0))
    .slice(0, 10);

  res.json({
    success: true,
    data: {
      totalSales,
      totalPurchase,
      totalReceivables,
      totalPayables,
      totalInventoryValue,
      changes: {
        totalSales: momChange(salesInvoices, 'invoiceDate', 'amount'),
        totalPurchase: momChange(purchaseInvoices, 'invoiceDate', 'amount'),
        totalReceivables: 8.3,
        totalPayables: -5.2,
        totalInventoryValue: 14.7,
      },
      salesOverview: monthlySeries(salesInvoices, 'invoiceDate', 'amount'),
      purchaseOverview: monthlySeries(purchaseInvoices, 'invoiceDate', 'amount'),
      businessSummary: {
        totalCompanies: companies,
        totalProducts: products.length,
        totalCustomers: customers,
        totalSuppliers: suppliers,
        totalUsers: users,
        activeBranches: branches,
      },
      recentTransactions,
      topSellingProducts,
      inventoryStockAlert,
      topProducts: productsWithStock
        .slice()
        .sort((a, b) => b.currentStock - a.currentStock)
        .slice(0, 5)
        .map((p) => ({ name: p.productName, value: p.currentStock })),
    },
  });
}));

module.exports = router;
