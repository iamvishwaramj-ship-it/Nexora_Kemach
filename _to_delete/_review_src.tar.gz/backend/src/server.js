const app = require('./app');
const prisma = require('./prisma/client');

const PORT = process.env.PORT || 5000;

const server = app.listen(PORT, () => console.log(`Nexora KEMACH API running on http://localhost:${PORT}`));

// Without this, every nodemon restart (and every Ctrl+C) leaves the old
// process's SQL Server connections open — on a low connection-limit plan
// that adds up fast across a dev session and eventually exhausts the pool.
// Release the Prisma connection pool before the process actually exits.
async function shutdown(signal) {
  console.log(`\n${signal} received: closing server and releasing DB connections...`);
  server.close(async () => {
    await prisma.$disconnect();
    process.exit(0);
  });
  // Fallback in case something hangs (e.g. a request never finishes).
  setTimeout(() => process.exit(1), 5000).unref();
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
// nodemon sends SIGUSR2 on restart in some configurations — handle it too.
process.once('SIGUSR2', async () => {
  await prisma.$disconnect();
  process.kill(process.pid, 'SIGUSR2');
});
