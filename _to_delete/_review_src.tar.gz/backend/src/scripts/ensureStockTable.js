// Creates [dbo].[Stock] — the inventory transaction journal — if it doesn't
// already exist, without needing a full `prisma migrate deploy`.
//
// The same guarded DDL lives in the baseline migration; this script exists so
// an already-running installation can get the table (and start journalling
// stock movements) without replaying migrations, matching how the master-data
// seed scripts create their own tables.
//
// Run with:  npm run stock_table:ensure

require('dotenv').config();
const prisma = require('../prisma/client');

// Mirrors backend/src/prisma/migrations/20260813120000_init_sqlserver/migration.sql's
// [Stock] table exactly, so a table this script creates and one a migration
// would have created are identical.
const CREATE_TABLE_SQL = `
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'Stock')
BEGIN
    CREATE TABLE [dbo].[Stock] (
        [DocEntry] BIGINT IDENTITY(1,1) NOT NULL,
        [ItemCode] NVARCHAR(50) NOT NULL,
        [ItemId] INT NOT NULL,
        [Dscription] NVARCHAR(200) NULL,
        [Warehouse] NVARCHAR(8) NULL,
        [InQty] DECIMAL(19,6) NOT NULL CONSTRAINT [DF_Stock_InQty] DEFAULT 0,
        [OutQty] DECIMAL(19,6) NOT NULL CONSTRAINT [DF_Stock_OutQty] DEFAULT 0,
        [Price] DECIMAL(19,6) NULL,
        [Currency] NVARCHAR(3) NULL,
        [TransValue] DECIMAL(19,6) NULL,
        [TransNum] INT NOT NULL,
        [TransType] NVARCHAR(50) NOT NULL CONSTRAINT [DF_Stock_TransType] DEFAULT N'Unknown',
        [FIFO] DECIMAL(19,6) NULL,
        [MAV] DECIMAL(19,6) NULL,
        [LineNum] INT NULL,
        [CreatedBy] INT NULL,
        [CreateDate] DATE NULL,
        [CreateTime] TIME NULL,
        CONSTRAINT [PK_OINM] PRIMARY KEY CLUSTERED ([DocEntry])
    );

    CREATE INDEX [IX_Stock_TransType_TransNum] ON [dbo].[Stock]([TransType], [TransNum]);
    CREATE INDEX [IX_Stock_ItemCode_Warehouse] ON [dbo].[Stock]([ItemCode], [Warehouse]);
END
`;

async function run() {
  const existedBefore = await prisma.$queryRawUnsafe(
    "SELECT COUNT(*) AS [count] FROM sys.tables WHERE name = 'Stock'"
  );
  const already = Number(existedBefore?.[0]?.count || 0) > 0;

  await prisma.$executeRawUnsafe(CREATE_TABLE_SQL);

  console.log(already
    ? '[dbo].[Stock] already exists — nothing to do.'
    : '[dbo].[Stock] created (with IX_Stock_TransType_TransNum and IX_Stock_ItemCode_Warehouse).');
}

if (require.main === module) {
  run()
    .catch((err) => {
      console.error('stock_table:ensure failed:', err);
      process.exitCode = 1;
    })
    .finally(() => prisma.$disconnect());
}

module.exports = { run };
