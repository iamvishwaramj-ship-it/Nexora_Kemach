/**
 * Product Master > Inventory tab — the aggregation behind it.
 *
 * Run with:  node --test src/tests/productInventory.test.js
 *
 * buildInventoryRows is deliberately pure (the I/O lives in the exported
 * async functions around it) so the arithmetic can be pinned here without a
 * database. What is being protected is not the code shape but the accounting:
 * a stock figure that is wrong by a rounding step, or that quietly absorbs
 * quantity it cannot attribute, is the kind of defect that is only noticed at
 * a stock count months later.
 */

const test = require('node:test');
const assert = require('node:assert/strict');

const { buildInventoryRows, journalKey } = require('../utils/productInventory');

// Shaped as getProductInventory hands them over: the Warehouse Master's
// whsCode/whsName mapped onto warehouseCode/warehouseName.
const WAREHOUSES = [
  { warehouseCode: 'WH-01', warehouseName: 'Main Warehouse', branch: 'Coimbatore' },
  { warehouseCode: 'WH-02', warehouseName: 'Service Van', branch: 'Palakkad' },
  { warehouseCode: 'WH-03', warehouseName: 'Spare Store', branch: null },
];

const build = (overrides = {}) => buildInventoryRows({
  warehouses: WAREHOUSES,
  movements: [],
  valuations: new Map(),
  openingStock: 0,
  ordered: 0,
  committed: 0,
  ...overrides,
});

// ---------------------------------------------------------------------------
// On-hand, per warehouse
// ---------------------------------------------------------------------------

test('nets inward and outward movements per warehouse', () => {
  const { rows } = build({
    movements: [
      { quantity: 100, warehouse: 'Main Warehouse' },
      { quantity: -30, warehouse: 'Main Warehouse' },
      { quantity: 12, warehouse: 'Service Van' },
    ],
  });
  assert.equal(rows.find((r) => r.warehouseCode === 'WH-01').onHand, 70);
  assert.equal(rows.find((r) => r.warehouseCode === 'WH-02').onHand, 12);
});

test('lists every active warehouse, including ones holding none of the product', () => {
  const { rows } = build({ movements: [{ quantity: 5, warehouse: 'Main Warehouse' }] });
  assert.equal(rows.length, 3);
  // A warehouse with no stock must still appear — otherwise a stocking level
  // cannot be set for somewhere the product has not reached yet, which is
  // exactly when you most want to set one.
  assert.equal(rows.find((r) => r.warehouseCode === 'WH-03').onHand, 0);
});

test('a movement for an unknown warehouse is not silently dropped into a known one', () => {
  const { rows, totals } = build({
    movements: [
      { quantity: 10, warehouse: 'Main Warehouse' },
      { quantity: 4, warehouse: 'Decommissioned Shed' },
    ],
  });
  assert.equal(rows.find((r) => r.warehouseCode === 'WH-01').onHand, 10);
  // It is not attributed anywhere, but it is still counted in the total: the
  // stock exists. Losing it would make the tab disagree with the stock ledger.
  assert.equal(totals.onHand, 14);
});

// ---------------------------------------------------------------------------
// Quantities that cannot be attributed to a warehouse
// ---------------------------------------------------------------------------

test('opening stock is reported as unassigned, not folded into a warehouse', () => {
  const { rows, totals } = build({
    openingStock: 25,
    movements: [{ quantity: 10, warehouse: 'Main Warehouse' }],
  });
  // Product.openingStock is a single product-wide number with no warehouse.
  // Adding it to the first row would make that warehouse overstate its holding
  // by the whole opening balance.
  assert.equal(rows.find((r) => r.warehouseCode === 'WH-01').onHand, 10);
  assert.equal(totals.unassignedOnHand, 25);
  assert.equal(totals.onHand, 35);
});

test('movements from documents that record no warehouse are unassigned too', () => {
  const { totals } = build({
    movements: [
      { quantity: 10, warehouse: 'Main Warehouse' },
      { quantity: 7, warehouse: null },
    ],
  });
  assert.equal(totals.unassignedOnHand, 7);
  assert.equal(totals.onHand, 17);
});

test('warehouse rows plus unassigned always reconcile to the total', () => {
  const { rows, totals } = build({
    openingStock: 25,
    movements: [
      { quantity: 100, warehouse: 'Main Warehouse' },
      { quantity: -30, warehouse: 'Main Warehouse' },
      { quantity: 12, warehouse: 'Service Van' },
      { quantity: 7, warehouse: null },
    ],
  });
  const summed = rows.reduce((s, r) => s + r.onHand, 0) + totals.unassignedOnHand;
  assert.equal(summed, totals.onHand);
});

// ---------------------------------------------------------------------------
// Available to promise
// ---------------------------------------------------------------------------

test('available is on hand less committed plus ordered', () => {
  const { totals } = build({
    movements: [{ quantity: 114, warehouse: 'Main Warehouse' }],
    ordered: 40,
    committed: 18,
  });
  assert.equal(totals.available, 136);
});

test('available can go negative when more is sold than held', () => {
  const { totals } = build({
    movements: [{ quantity: 5, warehouse: 'Main Warehouse' }],
    committed: 20,
  });
  // Clamping this to zero would hide an oversell, which is the one thing the
  // figure exists to reveal.
  assert.equal(totals.available, -15);
});

test('ordered and committed are never claimed per warehouse', () => {
  const { rows } = build({
    movements: [{ quantity: 10, warehouse: 'Main Warehouse' }],
    ordered: 40,
    committed: 18,
  });
  // Purchase and sales orders carry a branch but no warehouse, so there is
  // nothing to attribute them by. null, not 0 — the figure is unknown per
  // warehouse, not known to be nothing.
  for (const row of rows) {
    assert.equal(row.ordered, null);
    assert.equal(row.committed, null);
  }
});

// Levels tests removed — Min/Max Inventory Level (and the levels param
// buildInventoryRows used to take) was dropped; see migration
// 20260823210000_drop_product_warehouse_levels.

// ---------------------------------------------------------------------------
// Valuation
// ---------------------------------------------------------------------------

test('valuation is matched through the journal key, not the full warehouse name', () => {
  // Stock.Warehouse is NVARCHAR(8) and holds a clipped name, so a naive match
  // on the full name misses every warehouse called anything longer.
  assert.equal(journalKey('Main Warehouse'), 'Main War');

  const { rows } = build({
    valuations: new Map([[journalKey('Main Warehouse'), {
      itemCost: 350, fifoPrice: 340, movingAveragePrice: 347.5, averagePrice: 345,
    }]]),
  });
  const row = rows.find((r) => r.warehouseCode === 'WH-01');
  assert.equal(row.itemCost, 350);
  assert.equal(row.fifoPrice, 340);
  assert.equal(row.movingAveragePrice, 347.5);
  assert.equal(row.averagePrice, 345);
});

test('a warehouse with no journal history reports no cost rather than zero', () => {
  const { rows } = build({ movements: [{ quantity: 3, warehouse: 'Service Van' }] });
  const row = rows.find((r) => r.warehouseCode === 'WH-02');
  // Zero would assert the product cost nothing, which is a different claim
  // from "it has never moved here, so there is no cost to report".
  assert.equal(row.itemCost, null);
  assert.equal(row.averagePrice, null);
});

// ---------------------------------------------------------------------------
// Rounding
// ---------------------------------------------------------------------------

test('fractional movements do not accumulate binary float error', () => {
  const { rows, totals } = build({
    movements: Array.from({ length: 3 }, () => ({ quantity: 0.1, warehouse: 'Main Warehouse' })),
  });
  // 0.1 + 0.1 + 0.1 is 0.30000000000000004 in IEEE 754. A stock quantity that
  // reads 0.30000000000000004 fails a stock count for no real reason.
  assert.equal(rows.find((r) => r.warehouseCode === 'WH-01').onHand, 0.3);
  assert.equal(totals.onHand, 0.3);
});

// ---------------------------------------------------------------------------
// Code / legacy-name matching
//
// Documents now store the warehouse CODE. Everything posted before the
// Warehouse Master was wired up stored a NAME — often a branch name, or the
// literal 'Main Warehouse'. A warehouse's history spans both.
// ---------------------------------------------------------------------------

test('movements stored by code are attributed to their warehouse', () => {
  const { rows } = build({ movements: [{ quantity: 40, warehouse: 'WH-01' }] });
  assert.equal(rows.find((r) => r.warehouseCode === 'WH-01').onHand, 40);
});

test('movements stored under the old name still count, and add to the new ones', () => {
  const { rows, totals } = build({
    movements: [
      { quantity: 40, warehouse: 'WH-01' },           // posted since the change
      { quantity: 10, warehouse: 'Main Warehouse' },  // posted before it
    ],
  });
  // Taking one form and ignoring the other would drop real stock — the
  // warehouse existed on both sides of the change.
  assert.equal(rows.find((r) => r.warehouseCode === 'WH-01').onHand, 50);
  assert.equal(totals.unassignedOnHand, 0, 'neither form is left unattributed');
});

test('valuation falls back to the legacy name when nothing is keyed by code', () => {
  const { rows } = build({
    valuations: new Map([[journalKey('Main Warehouse'), { itemCost: 350 }]]),
  });
  assert.equal(rows.find((r) => r.warehouseCode === 'WH-01').itemCost, 350);
});

test('valuation keyed by code wins over the legacy name', () => {
  const { rows } = build({
    valuations: new Map([
      [journalKey('WH-01'), { itemCost: 400 }],
      [journalKey('Main Warehouse'), { itemCost: 350 }],
    ]),
  });
  // The code is what documents write today, so it is the more current figure.
  assert.equal(rows.find((r) => r.warehouseCode === 'WH-01').itemCost, 400);
});

test('a branch name nobody mapped to a warehouse stays unassigned, not lost', () => {
  const { rows, totals } = build({
    movements: [
      { quantity: 40, warehouse: 'WH-01' },
      { quantity: 6, warehouse: 'Coimbatore' },  // a branch name, not a warehouse
    ],
  });
  assert.equal(rows.find((r) => r.warehouseCode === 'WH-01').onHand, 40);
  assert.equal(totals.unassignedOnHand, 6);
  assert.equal(totals.onHand, 46);
});
