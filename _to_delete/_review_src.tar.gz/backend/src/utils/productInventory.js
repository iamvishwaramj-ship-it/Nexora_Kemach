/**
 * Per-warehouse inventory position for one product — what Product Master's
 * Inventory tab shows.
 *
 * Everything except the Min/Max levels is DERIVED at read time: on-hand comes
 * from the same movement ledger the rest of the app uses (utils/stockLedger),
 * the valuations come from the append-only stock journal (the Stock model), and
 * ordered/committed come from the open purchase and sales orders. Nothing is
 * cached. A cached per-warehouse quantity is precisely how an inventory figure
 * ends up disagreeing with the ledger that produced it, and reconciling the two
 * afterwards is far more expensive than recomputing.
 *
 * Two honest limits, surfaced rather than papered over:
 *
 *  1. ORDERED and COMMITTED are product-wide, not per warehouse. Purchase and
 *     sales orders record a branch but no warehouse — not on the header, not on
 *     the lines — so there is nothing to attribute them by. Splitting them
 *     across warehouses would require inventing an attribution rule, and a
 *     figure that looks precise but was guessed is worse than one plainly
 *     labelled as a total. They are returned in `totals` and the tab shows them
 *     on its total row.
 *
 *  2. OPENING STOCK has no warehouse either — Product.openingStock is a single
 *     product-wide number. It is reported under `unassignedOnHand` instead of
 *     being silently folded into the first warehouse's row, which would make
 *     that warehouse overstate its holding.
 *
 * Min/Max Inventory Level used to be stored per product+warehouse (the
 * ProductWarehouse model) and merged into these rows as the one non-derived
 * field. Removed on request — the table, the merge, and the save endpoint —
 * see migration 20260823210000_drop_product_warehouse_levels. Every row here
 * is now purely derived, no exceptions.
 */

const prisma = require('../prisma/client');
const { getStockMovements } = require('./stockLedger');
const { round2 } = require('./documentTotals');

// Statuses whose orders are not an outstanding commitment. Stated per document
// rather than as one shared list, because the two vocabularies genuinely differ
// (see PO_STATUS_OPTIONS and ORDER_STATUS_OPTIONS in the frontend's validation
// schemas) and a single list would quietly fail to match half of them.
//
// Draft is excluded from both: a draft is not a commitment to anyone. The
// terminal states are belt-and-braces — a fully received or fully delivered
// order already nets to zero on the quantity arithmetic below — but naming them
// means the intent survives someone later changing how the quantities are kept.
const CLOSED_PO_STATUSES = ['Draft', 'Cancelled', 'Closed', 'Received'];
const CLOSED_SO_STATUSES = ['Draft', 'Cancelled', 'Delivered'];

const num = (v) => Number(v) || 0;

/**
 * Stock.Warehouse is NVARCHAR(8) while the documents carry full warehouse
 * NAMES, so the journal stores a clipped version (see fitWarehouse in
 * utils/stockTable.js). Matching a journal row back to a warehouse therefore
 * has to compare on the same clipped form, or every lookup misses for any
 * warehouse whose name is longer than eight characters — which is most of them.
 *
 * Widening the column is the real fix; until then this keeps the two sides
 * agreeing on what counts as the same warehouse.
 */
function journalKey(warehouseName) {
  if (warehouseName == null) return null;
  const str = String(warehouseName).trim();
  if (str === '') return null;
  return str.length > 8 ? str.slice(0, 8) : str;
}

/**
 * Valuation per warehouse from the stock journal.
 *
 *  itemCost           the most recent unit price the product moved at
 *  movingAveragePrice the running Moving Average the journal recorded, latest
 *                     value — written only for products whose Calculation
 *                     Method is Moving Average, so null otherwise
 *  fifoPrice          same, for FIFO
 *  averagePrice       inward value divided by inward quantity: the plain
 *                     weighted average of what was actually paid. Distinct
 *                     from movingAveragePrice, which is a costing method's
 *                     running figure — this one is computed here and is always
 *                     available whatever the costing method.
 */
async function valuationByWarehouse(productCode) {
  // The Stock delegate only exists on a Prisma Client generated after the
  // Stock model was added. Treat its absence as "no journal yet" rather than
  // failing the whole tab — the quantities are still worth showing.
  if (!prisma.stock) return new Map();

  const rows = await prisma.stock.findMany({
    where: { itemCode: productCode },
    select: {
      warehouse: true, price: true, inQty: true, transValue: true,
      fifoCost: true, mavCost: true, docEntry: true,
    },
    orderBy: { docEntry: 'asc' },
  });

  const byWarehouse = new Map();
  for (const row of rows) {
    const key = row.warehouse || '';
    if (!byWarehouse.has(key)) {
      byWarehouse.set(key, {
        itemCost: null, fifoPrice: null, movingAveragePrice: null,
        inwardValue: 0, inwardQty: 0,
      });
    }
    const acc = byWarehouse.get(key);

    // Rows are in docEntry order, so a later row simply overwrites — the last
    // non-null wins and that is the current figure.
    if (row.price != null) acc.itemCost = num(row.price);
    if (row.fifoCost != null) acc.fifoPrice = num(row.fifoCost);
    if (row.mavCost != null) acc.movingAveragePrice = num(row.mavCost);

    const inQty = num(row.inQty);
    if (inQty > 0) {
      acc.inwardQty += inQty;
      // transValue when the journal recorded one, else price x quantity.
      acc.inwardValue += row.transValue != null ? num(row.transValue) : num(row.price) * inQty;
    }
  }

  const out = new Map();
  for (const [key, acc] of byWarehouse) {
    out.set(key, {
      itemCost: acc.itemCost,
      fifoPrice: acc.fifoPrice,
      movingAveragePrice: acc.movingAveragePrice,
      averagePrice: acc.inwardQty > 0 ? round2(acc.inwardValue / acc.inwardQty) : null,
    });
  }
  return out;
}

/** Open purchase-order quantity for a product: ordered but not yet received. */
async function openOrderedQty(productCode) {
  const items = await prisma.purchaseOrderItem.findMany({
    where: {
      productCode,
      order: { status: { notIn: CLOSED_PO_STATUSES } },
    },
    select: { quantity: true, receivedQuantity: true },
  });
  // Clamped at zero per line: over-receipt is a real occurrence, and letting a
  // negative line net off another line's genuine outstanding quantity would
  // understate what is still on order.
  return round2(items.reduce(
    (sum, i) => sum + Math.max(0, num(i.quantity) - num(i.receivedQuantity)), 0,
  ));
}

/** Open sales-order quantity for a product: sold but not yet delivered. */
async function openCommittedQty(productCode) {
  const items = await prisma.salesOrderItem.findMany({
    where: {
      productCode,
      order: { status: { notIn: CLOSED_SO_STATUSES } },
    },
    select: { quantity: true, deliveredQuantity: true },
  });
  return round2(items.reduce(
    (sum, i) => sum + Math.max(0, num(i.quantity) - num(i.deliveredQuantity)), 0,
  ));
}

/**
 * Pure aggregation, split out from the I/O above so it can be tested without a
 * database. Given the movements, the warehouse master, the stored levels and
 * the valuations, produce the rows the tab renders.
 */
function buildInventoryRows({
  warehouses, movements, valuations, openingStock, ordered, committed,
}) {
  const onHandByWarehouse = new Map();
  let unassignedOnHand = 0;
  for (const m of movements) {
    if (!m.warehouse) {
      // A movement from a document type that records no warehouse (see
      // SOURCES in stockLedger.js — the de-duplicating invoice sources).
      unassignedOnHand = round2(unassignedOnHand + m.quantity);
      continue;
    }
    onHandByWarehouse.set(m.warehouse, round2((onHandByWarehouse.get(m.warehouse) || 0) + m.quantity));
  }
  // Opening stock is product-wide, so it belongs to no warehouse either.
  unassignedOnHand = round2(unassignedOnHand + openingStock);

  const rows = warehouses.map((w) => {
    // Documents store the warehouse CODE now. Older ones stored a NAME — and
    // before the master was wired up, often a branch name or the literal
    // 'Main Warehouse'. Both forms are looked up so a warehouse's history does
    // not appear to begin on the day the codes were introduced.
    //
    // The two are ADDED rather than one taking precedence: a warehouse that
    // existed either side of the change legitimately has movements recorded
    // under both forms, and picking one would drop the other's stock.
    const onHand = round2(
      (onHandByWarehouse.get(w.warehouseCode) || 0)
      + (onHandByWarehouse.get(w.warehouseName) || 0),
    );
    const valuation = valuations.get(journalKey(w.warehouseCode))
      || valuations.get(journalKey(w.warehouseName))
      || {};
    return {
      warehouseCode: w.warehouseCode,
      warehouseName: w.warehouseName,
      branch: w.branch || null,
      onHand,
      // Per warehouse these stay null — see the note at the top of the file.
      ordered: null,
      committed: null,
      // With no per-warehouse ordered/committed to apply, a warehouse's
      // available quantity is simply what it holds. The meaningful
      // available-to-promise figure is on the totals row.
      available: onHand,
      itemCost: valuation.itemCost ?? null,
      movingAveragePrice: valuation.movingAveragePrice ?? null,
      averagePrice: valuation.averagePrice ?? null,
      fifoPrice: valuation.fifoPrice ?? null,
    };
  });

  // Stock recorded against a warehouse that is NOT in the list — one since
  // deactivated, renamed, or removed from the master. No row will claim it, so
  // without this it would simply disappear and the tab would report less stock
  // than the ledger holds. It is real quantity sitting somewhere; it just has
  // no current warehouse to sit under, which is the same situation as opening
  // stock, so it joins the unassigned figure rather than being lost.
  const claimed = new Set(warehouses.flatMap((w) => [w.warehouseCode, w.warehouseName]));
  for (const [key, quantity] of onHandByWarehouse) {
    if (claimed.has(key)) continue;
    unassignedOnHand = round2(unassignedOnHand + quantity);
  }

  const warehouseOnHand = rows.reduce((s, r) => s + r.onHand, 0);
  const totalOnHand = round2(warehouseOnHand + unassignedOnHand);

  return {
    rows,
    totals: {
      onHand: totalOnHand,
      ordered,
      committed,
      // SAP's definition: what is free to promise is what is held, less what is
      // already sold, plus what is already on its way in.
      available: round2(totalOnHand - committed + ordered),
      // Stock that exists but cannot be attributed to a warehouse: opening
      // stock, plus movements from documents that record no warehouse. Shown
      // separately so the warehouse rows and the total visibly reconcile
      // instead of appearing not to add up.
      unassignedOnHand,
    },
  };
}

/** The Inventory tab's payload for one product. */
async function getProductInventory(productCode) {
  const product = await prisma.product.findFirst({
    where: { productCode },
    select: { productCode: true, openingStock: true },
  });
  if (!product) {
    const err = new Error('Product not found');
    err.status = 404;
    throw err;
  }

  const [warehouses, movements, valuations, ordered, committed] = await Promise.all([
    // WarehouseMaster ([dbo].[warehouse]) is the single warehouse master the
    // whole application now reads from. The older Warehouse model
    // ([dbo].[warehouses]) is retired — see the note on it in schema.prisma.
    prisma.warehouseMaster.findMany({
      where: { status: 'Active' },
      orderBy: { whsCode: 'asc' },
      select: { whsCode: true, whsName: true, branch: true },
    }).then((rows) => rows.map((w) => ({
      warehouseCode: w.whsCode,
      warehouseName: w.whsName,
      branch: w.branch,
    }))),
    getStockMovements({ productCodes: [productCode] }),
    valuationByWarehouse(productCode),
    openOrderedQty(productCode),
    openCommittedQty(productCode),
  ]);

  return buildInventoryRows({
    warehouses,
    movements,
    valuations,
    openingStock: num(product.openingStock),
    ordered,
    committed,
  });
}

// saveProductInventoryLevels (and the ProductWarehouse model it wrote to)
// removed along with Min/Max Inventory Level — see migration
// 20260823210000_drop_product_warehouse_levels. Every figure this module
// returns is now derived, nothing is persisted here.

module.exports = {
  getProductInventory,
  buildInventoryRows,
  journalKey,
  CLOSED_PO_STATUSES,
  CLOSED_SO_STATUSES,
};
