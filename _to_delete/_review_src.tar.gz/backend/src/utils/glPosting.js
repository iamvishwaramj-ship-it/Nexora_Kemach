/**
 * Automatic G/L posting — the accounting document behind every business
 * document.
 *
 * Nothing generated the books before this. A sales invoice moved stock and
 * updated the customer's outstanding balance, but no debit ever reached
 * Revenue and no credit ever reached Accounts Receivable; the only way an
 * amount entered the ledger was somebody typing it into the Journal Entry
 * screen by hand. That is not a bookkeeping system, it is a stock system with
 * a notepad attached: the trial balance could never be produced from the
 * documents, and any figure in it was only as reliable as whoever remembered
 * to key it.
 *
 * SAP solves this with automatic account determination (OBYC / VKOA): a
 * logistics or financial document posts, and the system *derives* the
 * accounting document from it. The user never types those journal lines and
 * cannot get them wrong, because they were never a matter of opinion — the
 * accounts come from configuration and the amounts come from the document.
 * This module is that layer.
 *
 * ## Two kinds of journal entry now exist
 *
 *   Manual        — typed on the Journal Entry screen. transactionType is
 *                   always 'Manual', sourceType/sourceDocNo are null, and the
 *                   user owns every line. Adjustments, accruals, corrections.
 *
 *   System        — generated here. transactionType names the process
 *                   ('Sales Invoice', 'Purchase GRN', …), sourceType and
 *                   sourceDocNo point back at the document that caused it,
 *                   and it is READ-ONLY: editing the books behind a document's
 *                   back is exactly what an audit trail exists to prevent. It
 *                   is corrected by correcting (or cancelling) the source
 *                   document, which reverses and regenerates it.
 *
 * ## Exactly once, or the books double
 *
 * Every document route re-saves its whole record on edit. Without an
 * idempotency key, re-saving a posted invoice would post its journal entry a
 * second time and the ledger would quietly drift by the invoice amount, with
 * nothing on screen to show it had happened.
 *
 * (sourceType, sourceDocNo) is that key, enforced by a FILTERED unique index
 * — filtered so that manual entries, which carry NULL on both, stay exempt.
 * This is the same guarantee `hasPostedAlready(transType, transNum)` gives
 * the stock subledger in utils/stockTable.js, and it is deliberately the same
 * shape: the two subledgers are answering the same question about the same
 * documents, and they should be wrong or right together, never separately.
 *
 * ## Missing configuration parks the entry, it never blocks the document
 *
 * Account determination is configuration, and configuration has gaps —
 * a Product Group created last week with no Revenue account on it, a new
 * financial year whose determination row was never filled in. The choice
 * when that happens is between two failures:
 *
 *   - refuse the document (SAP ECC's behaviour): the books stay perfect and
 *     nobody can invoice until an administrator is found;
 *   - post the document and park the journal entry: invoicing continues, and
 *     the ledger carries a visible, named debt that has to be settled.
 *
 * This module does the second. A journal entry is still created — status
 * 'Pending G/L', no lines, and `glError` naming the exact account that is
 * missing — so the gap is a row somebody can see and act on rather than a
 * silent omission. Fixing the configuration and calling
 * POST /journal-entries/:id/post-to-gl generates the lines. Nothing is ever
 * skipped quietly, which is the property that actually matters: an unposted
 * entry you can list is recoverable, an entry that never existed is not.
 *
 * ## Perpetual inventory
 *
 * Goods movements hit the G/L the moment they happen — a delivery posts COGS
 * against Inventory, a goods receipt posts Inventory against Goods Clearing.
 * Inventory value in the books therefore always agrees with the stock ledger,
 * which is the whole point of running FIFO/Moving-Average costing (see
 * utils/stockValuation.js) rather than valuing stock once a quarter.
 */

const { round2, normaliseLine, isInterState } = require('./documentTotals');
const { NON_MOVING_STATUSES } = require('./stockTable');

/**
 * Every process that can produce a journal entry.
 *
 * The string values are what land in JournalEntry.transactionType and
 * JournalEntry.sourceType, and they are also the option list on the Journal
 * Entry screen — one list, so a value can never exist in the UI that the
 * engine does not understand, or vice versa.
 */
const JOURNAL_SOURCE_TYPES = {
  MANUAL: 'Manual',
  PURCHASE_GRN: 'Purchase GRN',
  PURCHASE_INVOICE: 'Purchase Invoice',
  PURCHASE_RETURN: 'Purchase Return',
  PURCHASE_CREDIT_MEMO: 'Purchase Credit Memo',
  DELIVERY_CHALLAN: 'Delivery Challan',
  SALES_INVOICE: 'Sales Invoice',
  SALES_RETURN: 'Sales Return',
  SALES_CREDIT_MEMO: 'Sales Credit Memo',
  STOCK_ISSUE: 'Stock Issue',
  STOCK_RETURN: 'Stock Return',
  PAYMENT_RECEIPT: 'Payment Receipt (Incoming Payment)',
  PAYMENT_VOUCHER: 'Payment Voucher (Outgoing Payment)',
  STOCK_TRANSFER: 'Stock Transfer',
};

/** Journal entry statuses. */
const JOURNAL_STATUS = {
  DRAFT: 'Draft',
  POSTED: 'Posted',
  PENDING_GL: 'Pending G/L',
};

/**
 * Does a document in this status belong in the ledger yet?
 *
 * Deliberately the same predicate as `movesStock` in utils/stockTable.js,
 * over the same status list, and that is a decision rather than an accident:
 * under perpetual inventory a movement of goods IS a movement of value, so a
 * document that posts stock must post value and one that does not must not.
 * Letting the two drift would produce the one bug this module exists to make
 * impossible — an inventory balance in the books that disagrees with the
 * warehouse.
 *
 * The list is an exclusion rather than an inclusion because each document
 * type has its own vocabulary for "live": a GRN is 'Open', a purchase invoice
 * is 'Posted', a sales invoice is 'Sent', a delivery challan is 'Pending'
 * until it is 'Open'. What they share is which statuses mean *not yet*.
 */
function postsToGl(status) {
  return !NON_MOVING_STATUSES.includes(status);
}

/**
 * Raised when account determination cannot supply an account the posting
 * needs. Carries the human-readable remedy, which is what ends up in
 * JournalEntry.glError and on the user's screen — "no account configured" is
 * useless, "no Revenue account for Product Group 'Electronics'" is a
 * five-second fix.
 */
class AccountDeterminationError extends Error {
  constructor(message) {
    super(message);
    this.name = 'AccountDeterminationError';
    this.isAccountDetermination = true;
  }
}

/**
 * ProductGroup / WarehouseMaster account column -> the GLAccountDetermination
 * column that backs it when neither master carries one.
 *
 * The two masters store account CODES (NVarChar) and the determination stores
 * FK IDS into ChartOfAccounts — an inconsistency that predates this module,
 * so resolution always ends by converting an id to a code.
 *
 * This mirrors PRODUCT_GROUP_ACCOUNT_MAP in frontend ProductGroup.jsx, which
 * uses the same pairing to pre-fill a new product group's accounting tab.
 */
const ROLE_TO_DETERMINATION = {
  expenseAccount: 'expenseAccountId',
  revenueAccount: 'revenueAccountId',
  inventoryAccount: 'inventoryAccountId',
  costOfGoodsSoldAccount: 'costOfGoodsSoldAccountId',
  allocationAccount: 'allocationAccountId',
  varianceAccount: 'varianceAccountId',
  priceDifferenceAccount: 'priceDifferenceAccountId',
  negativeInventoryAdjustmentAccount: 'negativeInventoryAdjAcctId',
  inventoryOffsetDecreaseAccount: 'inventoryOffsetDecrAcctId',
  inventoryOffsetIncreaseAccount: 'inventoryOffsetIncrAcctId',
  salesReturnsAccount: 'salesReturnsAccountId',
  purchaseAccount: 'purchaseAccountId',
  purchaseReturnAccount: 'purchaseReturnAccountId',
  costOfGoodsPurchasedAccount: 'costOfGoodsPurchasedAccountId',
  exchangeRateDifferencesAccount: 'exchangeRateDifferencesAccountId',
  goodsClearingAccount: 'goodsClearingAccountId',
  glDecreaseAccount: 'glDecreaseAccountId',
  glIncreaseAccount: 'glIncreaseAccountId',
  wipInventoryAccount: 'wipInventoryAccountId',
  wipInventoryVarianceAccount: 'wipInventoryVarianceAccountId',
  wipOffsetPnlAccount: 'wipOffsetPLAccountId',
  inventoryOffsetPnlAccount: 'inventoryOffsetPnlAccountId',
  expenseClearingAccount: 'expenseClearingAccountId',
  shippedGoodsAccount: 'shippedGoodsAccountId',
  salesCreditAccount: 'salesCreditAccountId',
  purchaseCreditAccount: 'purchaseCreditAccountId',
  purchaseBalanceAccount: 'purchaseBalanceAccountId',
  incomingCenvatAccount: 'incomingCenvatClearingActId',
  outgoingCenvatAccount: 'outgoingCenvatClearingActId',
};

/** Labels used in error messages, so a gap names itself in plain English. */
const ROLE_LABELS = {
  expenseAccount: 'Expense',
  revenueAccount: 'Revenue',
  inventoryAccount: 'Inventory',
  costOfGoodsSoldAccount: 'Cost of Goods Sold',
  goodsClearingAccount: 'Goods Clearing (GRNI)',
  salesReturnsAccount: 'Sales Returns',
  purchaseReturnAccount: 'Purchase Return',
  inventoryOffsetDecreaseAccount: 'Inventory Offset — Decrease',
  inventoryOffsetIncreaseAccount: 'Inventory Offset — Increase',
  varianceAccount: 'Variance',
  priceDifferenceAccount: 'Price Difference',
};

const roleLabel = (role) => ROLE_LABELS[role] || role;

// ---------------------------------------------------------------------------
// Determination context
// ---------------------------------------------------------------------------

/**
 * A per-posting cache over every master the resolver reads.
 *
 * A 40-line invoice would otherwise issue several hundred queries — a Product
 * lookup, a Warehouse or Product Group lookup and a ChartOfAccounts lookup
 * per line — inside the document's own transaction, holding its locks the
 * whole time. Everything here is read-only reference data that cannot change
 * during a single posting, so it is fetched once and memoised.
 */
function createDeterminationContext(tx) {
  const cache = {
    products: new Map(),
    warehouses: new Map(),
    productGroups: new Map(),
    accountsById: new Map(),
    accountsByCode: new Map(),
    customers: new Map(),
    suppliers: new Map(),
    determination: undefined,
  };

  return {
    tx,

    /**
     * The G/L Account Determination row for the open financial year.
     *
     * Determination is per financial year by design (accounts get restructured
     * between years), so the active year decides which row applies. When no
     * year is flagged active, fall back to whichever single row exists rather
     * than failing — a company that never set up financial years still needs
     * its books.
     */
    async determination() {
      if (cache.determination !== undefined) return cache.determination;
      let row = null;
      const activeFy = await tx.financialYear.findFirst({ where: { status: 'Active' } });
      if (activeFy) {
        row = await tx.glAccountDetermination.findFirst({ where: { financialYearId: activeFy.id } });
      }
      if (!row) row = await tx.glAccountDetermination.findFirst();
      cache.determination = row;
      return row;
    },

    async product(productCode) {
      if (!productCode) return null;
      if (cache.products.has(productCode)) return cache.products.get(productCode);
      const row = await tx.product.findFirst({ where: { productCode } });
      cache.products.set(productCode, row);
      return row;
    },

    /**
     * Warehouse master by name or code — documents store the warehouse
     * inconsistently (some screens write whsName, some whsCode), so both are
     * accepted rather than making the caller guess which one it holds.
     */
    async warehouse(nameOrCode) {
      if (!nameOrCode) return null;
      if (cache.warehouses.has(nameOrCode)) return cache.warehouses.get(nameOrCode);
      const row = await tx.warehouseMaster.findFirst({
        where: { OR: [{ whsName: nameOrCode }, { whsCode: nameOrCode }] },
      });
      cache.warehouses.set(nameOrCode, row);
      return row;
    },

    async productGroup(groupName) {
      if (!groupName) return null;
      if (cache.productGroups.has(groupName)) return cache.productGroups.get(groupName);
      const row = await tx.productGroup.findFirst({ where: { groupName } });
      cache.productGroups.set(groupName, row);
      return row;
    },

    async accountById(id) {
      if (!id) return null;
      if (cache.accountsById.has(id)) return cache.accountsById.get(id);
      const row = await tx.chartOfAccount.findUnique({ where: { id } });
      cache.accountsById.set(id, row);
      return row;
    },

    async accountByCode(accountCode) {
      if (!accountCode) return null;
      if (cache.accountsByCode.has(accountCode)) return cache.accountsByCode.get(accountCode);
      const row = await tx.chartOfAccount.findFirst({ where: { accountCode } });
      cache.accountsByCode.set(accountCode, row);
      return row;
    },

    async customer(name) {
      if (!name) return null;
      if (cache.customers.has(name)) return cache.customers.get(name);
      const row = await tx.customer.findFirst({
        where: { OR: [{ customerName: name }, { customerCode: name }] },
      });
      cache.customers.set(name, row);
      return row;
    },

    async supplier(name) {
      if (!name) return null;
      if (cache.suppliers.has(name)) return cache.suppliers.get(name);
      const row = await tx.supplier.findFirst({
        where: { OR: [{ supplierName: name }, { supplierCode: name }] },
      });
      cache.suppliers.set(name, row);
      return row;
    },
  };
}

// ---------------------------------------------------------------------------
// Account determination
// ---------------------------------------------------------------------------

/**
 * Resolve an item-level account (Inventory, Revenue, COGS, Expense, …) for
 * one document line, following SAP B1's determination hierarchy.
 *
 * The hierarchy is a real business rule, not a fallback chain of
 * convenience. `Product.glAccountsBy` — "Set G/L Accounts By" on the product
 * master — says which dimension owns this product's accounts:
 *
 *   'Warehouse'     — accounts follow WHERE the stock is. Used when different
 *                     sites must be reported separately (a bonded warehouse,
 *                     a branch with its own inventory account).
 *   'Product Group' — accounts follow WHAT the item is. The common case:
 *                     electronics revenue and consumables revenue land in
 *                     different accounts regardless of which shed they sit in.
 *
 * Whichever dimension owns it is asked first. Only when that master leaves
 * the column blank does the company-wide G/L Account Determination answer,
 * which is exactly the role it plays on the Product Group screen, where it
 * pre-fills a new group's accounting tab.
 *
 * Throws AccountDeterminationError naming the specific gap when nothing
 * answers — that message reaches the user, so it names the master and the
 * account rather than saying something failed.
 */
async function resolveItemAccount(ctx, { productCode, warehouse, role }) {
  const product = await ctx.product(productCode);

  // A line whose product is not in the master at all cannot be determined by
  // product group or warehouse — fall straight through to the company
  // default rather than pretending to know more than we do.
  const by = product?.glAccountsBy || 'Warehouse';

  let code = null;
  let searchedIn = null;

  if (by === 'Product Group') {
    const group = await ctx.productGroup(product?.productGroup);
    code = group?.[role] || null;
    searchedIn = product?.productGroup
      ? `Product Group "${product.productGroup}"`
      : `Product Group (product "${productCode}" has no group set)`;
  } else {
    const whs = await ctx.warehouse(warehouse);
    code = whs?.[role] || null;
    searchedIn = warehouse ? `Warehouse "${warehouse}"` : 'Warehouse (none on the document)';
  }

  if (code) return resolveAccountByCode(ctx, code, role, searchedIn);

  // Company-wide default.
  return resolveDeterminationAccount(ctx, role, {
    extraContext: `neither ${searchedIn} nor G/L Account Determination supplies it`,
  });
}

/** Turn an account code held on a master into a real ChartOfAccounts row. */
async function resolveAccountByCode(ctx, accountCode, role, searchedIn) {
  const account = await ctx.accountByCode(accountCode);
  if (!account) {
    throw new AccountDeterminationError(
      `${searchedIn} names "${accountCode}" as its ${roleLabel(role)} account, but no such account exists in the Chart Of Accounts.`
    );
  }
  assertPostable(account, role);
  return account;
}

/** Resolve a role straight from the company-wide G/L Account Determination. */
async function resolveDeterminationAccount(ctx, role, { extraContext = null } = {}) {
  const determination = await ctx.determination();
  if (!determination) {
    throw new AccountDeterminationError(
      'No G/L Account Determination has been set up. Configure it under Accounting > G/L Account Determination before documents can post to the ledger.'
    );
  }

  const field = ROLE_TO_DETERMINATION[role] || role;
  const id = determination[field];
  if (!id) {
    throw new AccountDeterminationError(
      `No ${roleLabel(role)} account is configured${extraContext ? ` — ${extraContext}` : ''}. Set it under Accounting > G/L Account Determination.`
    );
  }

  const account = await ctx.accountById(id);
  if (!account) {
    throw new AccountDeterminationError(
      `The ${roleLabel(role)} account configured in G/L Account Determination no longer exists in the Chart Of Accounts.`
    );
  }
  assertPostable(account, role);
  return account;
}

/**
 * A Title account is a heading in the chart, not somewhere value can sit, and
 * an inactive account has been deliberately retired. Posting to either
 * produces a balance nobody is looking at, so both are refused here rather
 * than discovered later in a reconciliation.
 */
function assertPostable(account, role) {
  if (account.accountNature === 'T') {
    throw new AccountDeterminationError(
      `"${account.accountName}" (${account.accountCode}) is configured as the ${roleLabel(role)} account, but it is a Title account. Titles group other accounts and cannot be posted to — point this at an Active Account.`
    );
  }
  if (account.status === 'I') {
    throw new AccountDeterminationError(
      `"${account.accountName}" (${account.accountCode}) is configured as the ${roleLabel(role)} account, but it is inactive.`
    );
  }
}

/**
 * The customer's Accounts Receivable control account.
 *
 * A customer may carry its own (an overseas customer reporting into Foreign
 * AR, a group company into an inter-company account); otherwise the company
 * default applies. Same shape on the supplier side below.
 */
async function resolveArAccount(ctx, customerName) {
  const customer = await ctx.customer(customerName);
  if (customer?.accountsReceivable) {
    return resolveAccountByCode(ctx, customer.accountsReceivable, 'accountsReceivable', `Customer "${customerName}"`);
  }
  const determination = await ctx.determination();
  const id = determination?.domesticAccountsReceivableId || determination?.accountsReceivableId;
  if (!id) {
    throw new AccountDeterminationError(
      'No Accounts Receivable control account is configured. Set Domestic Accounts Receivable under Accounting > G/L Account Determination, or give this customer its own on the Customer Master.'
    );
  }
  const account = await ctx.accountById(id);
  if (!account) {
    throw new AccountDeterminationError('The configured Accounts Receivable account no longer exists in the Chart Of Accounts.');
  }
  assertPostable(account, 'accountsReceivable');
  return account;
}

/**
 * The supplier's Accounts Payable control account.
 *
 * Note the column on the Supplier master is called `accountsReceivable` —
 * the migration that added it reused the customer-side name. It holds the
 * supplier's control account regardless of what it is called, and renaming a
 * live column is not worth the migration risk, so it is read as-is here and
 * the oddity is documented rather than propagated into new names.
 */
async function resolveApAccount(ctx, supplierName) {
  const supplier = await ctx.supplier(supplierName);
  if (supplier?.accountsReceivable) {
    return resolveAccountByCode(ctx, supplier.accountsReceivable, 'accountsPayable', `Supplier "${supplierName}"`);
  }
  const determination = await ctx.determination();
  const id = determination?.domesticAccountsPayableId;
  if (!id) {
    throw new AccountDeterminationError(
      'No Accounts Payable control account is configured. Set Domestic Accounts Payable under Accounting > G/L Account Determination, or give this supplier its own on the Supplier Master.'
    );
  }
  const account = await ctx.accountById(id);
  if (!account) {
    throw new AccountDeterminationError('The configured Accounts Payable account no longer exists in the Chart Of Accounts.');
  }
  assertPostable(account, 'accountsPayable');
  return account;
}

/** The cash/bank account money physically moves through. */
async function resolveCashAccount(ctx) {
  return resolveDeterminationAccount(ctx, 'cashOnHandId');
}

const GST_FIELDS = {
  output: { cgst: 'outputCgstPayableId', sgst: 'outputSgstPayableId', igst: 'outputIgstPayableId' },
  input: { cgst: 'inputCgstReceivableId', sgst: 'inputSgstReceivableId', igst: 'inputIgstReceivableId' },
};

const GST_LABELS = {
  output: { cgst: 'Output CGST Payable', sgst: 'Output SGST Payable', igst: 'Output IGST Payable' },
  input: { cgst: 'Input CGST Receivable', sgst: 'Input SGST Receivable', igst: 'Input IGST Receivable' },
};

/**
 * Resolve the GST account for one component, on the given side.
 *
 * Only called for components that actually carry an amount — an intra-state
 * document has no IGST, so it must not demand an IGST account be configured
 * before it can post.
 */
async function resolveGstAccount(ctx, side, component) {
  const determination = await ctx.determination();
  const id = determination?.[GST_FIELDS[side][component]];
  if (!id) {
    throw new AccountDeterminationError(
      `No ${GST_LABELS[side][component]} account is configured. Set it under Accounting > G/L Account Determination.`
    );
  }
  const account = await ctx.accountById(id);
  if (!account) {
    throw new AccountDeterminationError(`The configured ${GST_LABELS[side][component]} account no longer exists in the Chart Of Accounts.`);
  }
  assertPostable(account, GST_LABELS[side][component]);
  return account;
}

// ---------------------------------------------------------------------------
// Line building
// ---------------------------------------------------------------------------

/**
 * A posting under construction. Lines are accumulated per account and side,
 * then consolidated — a 40-line invoice whose items all share one revenue
 * account produces one Revenue credit, not forty identical ones. SAP calls
 * this summarised posting; the per-item detail already lives on the document
 * itself, and repeating it in the ledger only makes the ledger harder to read.
 */
function createPosting(branch) {
  const entries = [];
  return {
    debit(account, amount, description) {
      const value = round2(amount);
      if (value === 0) return;
      // A negative debit is a credit. Amounts arrive from documents that
      // allow negative lines (a discount line, a corrective quantity), and
      // silently dropping the sign would unbalance the entry.
      if (value < 0) entries.push({ account, description, debit: 0, credit: -value });
      else entries.push({ account, description, debit: value, credit: 0 });
    },
    credit(account, amount, description) {
      const value = round2(amount);
      if (value === 0) return;
      if (value < 0) entries.push({ account, description, debit: -value, credit: 0 });
      else entries.push({ account, description, debit: 0, credit: value });
    },
    build() {
      const merged = new Map();
      for (const e of entries) {
        const key = `${e.account.accountCode}|${e.debit > 0 ? 'D' : 'C'}`;
        const existing = merged.get(key);
        if (existing) {
          existing.debit = round2(existing.debit + e.debit);
          existing.credit = round2(existing.credit + e.credit);
        } else {
          merged.set(key, { ...e });
        }
      }
      return [...merged.values()].map((e, i) => ({
        lineNo: i + 1,
        accountCode: e.account.accountCode,
        accountName: e.account.accountName,
        description: e.description || null,
        branch: branch || null,
        debit: e.debit,
        credit: e.credit,
      }));
    },
  };
}

/**
 * The taxable (post-discount, pre-tax) value of one document line.
 *
 * Reuses normaliseLine from documentTotals.js — the same function that
 * computed the document's own totals — so a line's contribution to the
 * ledger and its contribution to the invoice total can never be computed two
 * different ways and disagree.
 */
function lineTaxableValue(item, quantityField) {
  return normaliseLine(item, { quantityField }).amount;
}

/** Cost value of a line, for the inventory/COGS side of a goods movement. */
function lineCostValue(item, quantityField, { costField = 'costPrice' } = {}) {
  const qty = Number(item[quantityField]) || 0;
  const cost = Number(item[costField]);
  // Returns and credit memos carry no stamped cost, so the transaction price
  // stands in — the same fallback postStockEntries uses when it values a
  // movement, so stock value and ledger value stay consistent.
  const unit = Number.isFinite(cost) && cost > 0 ? cost : (Number(item.unitPrice) || 0);
  return round2(qty * unit);
}

/**
 * Post each line's inventory value to its own determined account.
 * Returns the total posted, so the caller can put the balancing figure on the
 * offsetting account without recomputing it and risking a rounding drift.
 */
async function postPerLine(ctx, posting, { items, quantityField, warehouse, role, side, description, valuer }) {
  let total = 0;
  for (const item of items) {
    if (!item.productCode) continue;
    const value = valuer(item, quantityField);
    if (round2(value) === 0) continue;
    const account = await resolveItemAccount(ctx, {
      productCode: item.productCode,
      warehouse: item.warehouse || warehouse,
      role,
    });
    posting[side](account, value, description);
    total = round2(total + value);
  }
  return total;
}

/** Post the CGST/SGST/IGST split. Returns the total tax posted. */
async function postGst(ctx, posting, doc, sideOfBooks, entrySide, description) {
  let total = 0;
  for (const component of ['cgst', 'sgst', 'igst']) {
    const amount = round2(Number(doc[`${component}Amount`]) || 0);
    if (amount === 0) continue;
    const account = await resolveGstAccount(ctx, sideOfBooks, component);
    posting[entrySide](account, amount, description);
    total = round2(total + amount);
  }
  return total;
}

/**
 * Absorb the document's round-off into the rounding account.
 *
 * computeTotals produces `amount = taxableAmount + totalTax + roundOff`, so
 * the round-off is a real component of what the customer pays and needs a
 * home of its own — folding it into revenue would misstate revenue by a few
 * paise on every document, which compounds into a figure nobody can explain.
 */
async function postRoundOff(ctx, posting, roundOff, side) {
  const value = round2(Number(roundOff) || 0);
  if (value === 0) return 0;
  const account = await resolveDeterminationAccount(ctx, 'roundingAccountId');
  posting[side](account, value, 'Rounding difference');
  return value;
}

// ---------------------------------------------------------------------------
// Posting schemas — one per document type
// ---------------------------------------------------------------------------

/**
 * Each builder receives the document (with its items) and returns nothing,
 * having pushed its lines onto `posting`. Every one of them is a standard
 * double-entry schema; the comments state the accounting reasoning rather
 * than restating the code, because the reasoning is the part that has to be
 * checked by someone who knows accounting rather than JavaScript.
 */
const POSTING_SCHEMAS = {
  /**
   * Purchase GRN — goods received, not yet invoiced.
   *
   *   Dr  Inventory              (per line, at purchase value)
   *     Cr  Goods Clearing (GRNI)
   *
   * Goods Clearing is the classic goods-received-not-invoiced liability: the
   * stock is ours and on the books the moment it arrives, but the supplier's
   * invoice has not been received, so the credit cannot go to Accounts
   * Payable yet. The purchase invoice later clears this account against AP.
   * Tax is deliberately NOT posted here — input GST is recoverable against
   * the supplier's tax invoice, which is a document that does not exist yet.
   */
  async [JOURNAL_SOURCE_TYPES.PURCHASE_GRN](ctx, posting, doc) {
    const inventoryTotal = await postPerLine(ctx, posting, {
      items: doc.items || [],
      quantityField: 'receivedQuantity',
      warehouse: doc.warehouse,
      role: 'inventoryAccount',
      side: 'debit',
      description: `Goods received — ${doc.grnNo}`,
      valuer: (item, qf) => lineTaxableValue(item, qf),
    });
    if (inventoryTotal === 0) return;

    const clearing = await resolveItemAccountForDocument(ctx, doc, 'goodsClearingAccount');
    posting.credit(clearing, inventoryTotal, `Goods received not invoiced — ${doc.grnNo}`);
  },

  /**
   * Purchase Invoice — the supplier's bill.
   *
   * With a GRN behind it (the two-step flow):
   *   Dr  Goods Clearing (GRNI)   clears what the receipt parked there
   *   Dr  Input CGST/SGST/IGST    recoverable tax
   *     Cr  Accounts Payable      what we now owe, inclusive of tax
   *
   * Direct invoice (no GRN — see isDirectInvoice in resources.js, the same
   * test the stock ledger uses to decide whether this invoice moves stock):
   *   Dr  Inventory / Expense     per line; the goods never passed through a
   *   Dr  Input CGST/SGST/IGST    receipt, so this document books them
   *     Cr  Accounts Payable
   *
   * The Inventory-vs-Expense split follows Product.inventoryItem: a stocked
   * item becomes an asset, a service or consumable becomes an expense
   * immediately. Booking a service to Inventory would leave a balance that
   * can never be relieved because there is nothing to issue.
   */
  async [JOURNAL_SOURCE_TYPES.PURCHASE_INVOICE](ctx, posting, doc) {
    let goodsTotal;

    if (doc.grnNo) {
      goodsTotal = round2(Number(doc.taxableAmount) || 0);
      if (goodsTotal !== 0) {
        const clearing = await resolveItemAccountForDocument(ctx, doc, 'goodsClearingAccount');
        posting.debit(clearing, goodsTotal, `Invoice against GRN ${doc.grnNo}`);
      }
    } else {
      goodsTotal = 0;
      for (const item of doc.items || []) {
        if (!item.productCode) continue;
        const value = lineTaxableValue(item, 'quantity');
        if (round2(value) === 0) continue;
        const product = await ctx.product(item.productCode);
        const role = product && product.inventoryItem === false ? 'expenseAccount' : 'inventoryAccount';
        const account = await resolveItemAccount(ctx, {
          productCode: item.productCode,
          warehouse: doc.warehouse,
          role,
        });
        posting.debit(account, value, `Purchase — ${doc.invoiceNo}`);
        goodsTotal = round2(goodsTotal + value);
      }
    }

    const tax = await postGst(ctx, posting, doc, 'input', 'debit', `Input GST — ${doc.invoiceNo}`);
    const rounding = await postRoundOff(ctx, posting, doc.roundOff, 'debit');

    const payable = round2(goodsTotal + tax + rounding);
    if (payable === 0) return;
    const ap = await resolveApAccount(ctx, doc.supplier);
    posting.credit(ap, payable, `${doc.supplier || 'Supplier'} — ${doc.invoiceNo}`);
  },

  /**
   * Purchase Return — goods sent back to the supplier.
   *
   *   Dr  Goods Clearing (GRNI)
   *     Cr  Inventory             (per line)
   *
   * The mirror image of the receipt. It reverses the goods side only: the
   * financial claim against the supplier is raised by a Purchase Credit Memo,
   * which is a separate document precisely because returning goods and being
   * credited for them are separate events that can happen days apart.
   */
  async [JOURNAL_SOURCE_TYPES.PURCHASE_RETURN](ctx, posting, doc) {
    const inventoryTotal = await postPerLine(ctx, posting, {
      items: doc.items || [],
      quantityField: 'returnQuantity',
      warehouse: doc.warehouse,
      role: 'inventoryAccount',
      side: 'credit',
      description: `Goods returned — ${doc.returnNo}`,
      valuer: (item, qf) => lineTaxableValue(item, qf),
    });
    if (inventoryTotal === 0) return;

    const clearing = await resolveItemAccountForDocument(ctx, doc, 'goodsClearingAccount');
    posting.debit(clearing, inventoryTotal, `Return to supplier — ${doc.returnNo}`);
  },

  /**
   * Purchase Credit Memo — the supplier credits us.
   *
   *   Dr  Accounts Payable        we owe less
   *     Cr  Inventory             (per line) stock value comes back out
   *     Cr  Input CGST/SGST/IGST  the tax we reclaimed is reversed with it
   */
  async [JOURNAL_SOURCE_TYPES.PURCHASE_CREDIT_MEMO](ctx, posting, doc) {
    const goodsTotal = await postPerLine(ctx, posting, {
      items: doc.items || [],
      quantityField: 'quantity',
      warehouse: doc.warehouse,
      role: 'inventoryAccount',
      side: 'credit',
      description: `Credit memo — ${doc.creditNo}`,
      valuer: (item, qf) => lineTaxableValue(item, qf),
    });

    const tax = await postGst(ctx, posting, doc, 'input', 'credit', `Input GST reversed — ${doc.creditNo}`);
    const rounding = await postRoundOff(ctx, posting, doc.roundOff, 'credit');

    const total = round2(goodsTotal + tax + rounding);
    if (total === 0) return;
    const ap = await resolveApAccount(ctx, doc.supplierName);
    posting.debit(ap, total, `${doc.supplierName || 'Supplier'} — ${doc.creditNo}`);
  },

  /**
   * Delivery Challan — goods despatched to the customer.
   *
   *   Dr  Cost of Goods Sold      at COST, not at selling price
   *     Cr  Inventory
   *
   * This is the perpetual-inventory posting and the reason costPrice is
   * stamped on every challan line at save time (stampCostPrices in
   * resources.js). No revenue and no receivable appear here: the customer has
   * the goods but has not been billed, and recognising revenue on despatch
   * rather than on invoice would overstate it for anything delivered and
   * never invoiced. The invoice books the revenue side.
   */
  async [JOURNAL_SOURCE_TYPES.DELIVERY_CHALLAN](ctx, posting, doc) {
    const cogsTotal = await postPerLine(ctx, posting, {
      items: doc.items || [],
      quantityField: 'quantity',
      warehouse: doc.fromWarehouse,
      role: 'inventoryAccount',
      side: 'credit',
      description: `Goods despatched — ${doc.challanNo}`,
      valuer: (item, qf) => lineCostValue(item, qf),
    });
    if (cogsTotal === 0) return;

    const cogs = await resolveItemAccountForDocument(ctx, doc, 'costOfGoodsSoldAccount', doc.fromWarehouse);
    posting.debit(cogs, cogsTotal, `Cost of goods sold — ${doc.challanNo}`);
  },

  /**
   * Sales Invoice — the customer is billed.
   *
   *   Dr  Accounts Receivable     gross, inclusive of tax
   *     Cr  Revenue               (per line, net of tax and discount)
   *     Cr  Output CGST/SGST/IGST tax collected on the government's behalf
   *
   * Plus, when the invoice was raised directly with no delivery challan
   * behind it, the goods side that the challan would otherwise have posted:
   *
   *   Dr  Cost of Goods Sold
   *     Cr  Inventory
   *
   * The isDirectInvoice test is the same one the stock ledger uses to decide
   * whether this invoice moves stock — so stock and value are always booked
   * by the same document, and never twice.
   */
  async [JOURNAL_SOURCE_TYPES.SALES_INVOICE](ctx, posting, doc) {
    const revenueTotal = await postPerLine(ctx, posting, {
      items: doc.items || [],
      quantityField: 'quantity',
      warehouse: doc.warehouse,
      role: 'revenueAccount',
      side: 'credit',
      description: `Sales — ${doc.invoiceNo}`,
      valuer: (item, qf) => lineTaxableValue(item, qf),
    });

    const tax = await postGst(ctx, posting, doc, 'output', 'credit', `Output GST — ${doc.invoiceNo}`);
    const rounding = await postRoundOff(ctx, posting, doc.roundOff, 'credit');

    const receivable = round2(revenueTotal + tax + rounding);
    if (receivable !== 0) {
      const ar = await resolveArAccount(ctx, doc.customer);
      posting.debit(ar, receivable, `${doc.customer || 'Customer'} — ${doc.invoiceNo}`);
    }

    // Direct invoice: no challan despatched these goods, so this document
    // carries the cost side too.
    if (!doc.deliveryChallanNo) {
      const cogsTotal = await postPerLine(ctx, posting, {
        items: doc.items || [],
        quantityField: 'quantity',
        warehouse: doc.warehouse,
        role: 'inventoryAccount',
        side: 'credit',
        description: `Goods sold — ${doc.invoiceNo}`,
        valuer: (item, qf) => lineCostValue(item, qf),
      });
      if (cogsTotal !== 0) {
        const cogs = await resolveItemAccountForDocument(ctx, doc, 'costOfGoodsSoldAccount');
        posting.debit(cogs, cogsTotal, `Cost of goods sold — ${doc.invoiceNo}`);
      }
    }
  },

  /**
   * Sales Return — goods come back from the customer.
   *
   *   Dr  Inventory               (per line, at cost)
   *     Cr  Cost of Goods Sold
   *
   * Goods side only, mirroring the delivery challan. The customer's account
   * is credited by a Sales Credit Memo — again a separate event: goods can be
   * returned and inspected before anyone agrees what credit is due.
   */
  async [JOURNAL_SOURCE_TYPES.SALES_RETURN](ctx, posting, doc) {
    const costTotal = await postPerLine(ctx, posting, {
      items: doc.items || [],
      quantityField: 'returnQuantity',
      warehouse: doc.warehouse,
      role: 'inventoryAccount',
      side: 'debit',
      description: `Goods returned — ${doc.returnNo}`,
      valuer: (item, qf) => lineCostValue(item, qf),
    });
    if (costTotal === 0) return;

    const cogs = await resolveItemAccountForDocument(ctx, doc, 'costOfGoodsSoldAccount');
    posting.credit(cogs, costTotal, `Cost of goods returned — ${doc.returnNo}`);
  },

  /**
   * Sales Credit Memo — the customer is credited.
   *
   *   Dr  Sales Returns           a contra-revenue account, NOT a debit to
   *   Dr  Output CGST/SGST/IGST   Revenue itself: gross sales and returns are
   *     Cr  Accounts Receivable   separate figures on the P&L, and netting
   *                               them off hides the return rate entirely
   *
   * Plus the goods side when stock physically comes back with it:
   *   Dr  Inventory
   *     Cr  Cost of Goods Sold
   */
  async [JOURNAL_SOURCE_TYPES.SALES_CREDIT_MEMO](ctx, posting, doc) {
    const returnsTotal = await postPerLine(ctx, posting, {
      items: doc.items || [],
      quantityField: 'quantity',
      warehouse: doc.warehouse,
      role: 'salesReturnsAccount',
      side: 'debit',
      description: `Credit memo — ${doc.creditNo}`,
      valuer: (item, qf) => lineTaxableValue(item, qf),
    });

    const tax = await postGst(ctx, posting, doc, 'output', 'debit', `Output GST reversed — ${doc.creditNo}`);
    const rounding = await postRoundOff(ctx, posting, doc.roundOff, 'debit');

    const total = round2(returnsTotal + tax + rounding);
    if (total !== 0) {
      const ar = await resolveArAccount(ctx, doc.customerName);
      posting.credit(ar, total, `${doc.customerName || 'Customer'} — ${doc.creditNo}`);
    }

    const costTotal = await postPerLine(ctx, posting, {
      items: doc.items || [],
      quantityField: 'quantity',
      warehouse: doc.warehouse,
      role: 'inventoryAccount',
      side: 'debit',
      description: `Goods returned — ${doc.creditNo}`,
      valuer: (item, qf) => lineCostValue(item, qf),
    });
    if (costTotal !== 0) {
      const cogs = await resolveItemAccountForDocument(ctx, doc, 'costOfGoodsSoldAccount');
      posting.credit(cogs, costTotal, `Cost of goods returned — ${doc.creditNo}`);
    }
  },

  /**
   * Stock Issue — stock consumed internally (production, samples, scrap).
   *
   *   Dr  Inventory Offset — Decrease
   *     Cr  Inventory
   *
   * The offset account is where value goes when stock leaves for a reason
   * that is not a sale. Keeping it out of COGS matters: COGS is compared
   * against revenue to produce gross margin, and consumption that earned no
   * revenue would distort that comparison.
   */
  async [JOURNAL_SOURCE_TYPES.STOCK_ISSUE](ctx, posting, doc) {
    const total = await postPerLine(ctx, posting, {
      items: doc.items || [],
      quantityField: 'quantity',
      warehouse: doc.toWarehouse,
      role: 'inventoryAccount',
      side: 'credit',
      description: `Stock issued — ${doc.issueNo}`,
      valuer: (item, qf) => lineCostValue(item, qf),
    });
    if (total === 0) return;

    const offset = await resolveItemAccountForDocument(ctx, doc, 'inventoryOffsetDecreaseAccount', doc.toWarehouse);
    posting.debit(offset, total, `Stock issued — ${doc.issueNo}`);
  },

  /**
   * Stock Return — stock coming back in without a purchase behind it
   * (unused issue returned to store, production output, found stock).
   * Backed by the Stock Receipt document.
   *
   *   Dr  Inventory
   *     Cr  Inventory Offset — Increase
   */
  async [JOURNAL_SOURCE_TYPES.STOCK_RETURN](ctx, posting, doc) {
    const total = await postPerLine(ctx, posting, {
      items: doc.items || [],
      quantityField: 'quantity',
      warehouse: doc.warehouse,
      role: 'inventoryAccount',
      side: 'debit',
      description: `Stock received — ${doc.receiptNo}`,
      valuer: (item, qf) => lineCostValue(item, qf),
    });
    if (total === 0) return;

    const offset = await resolveItemAccountForDocument(ctx, doc, 'inventoryOffsetIncreaseAccount');
    posting.credit(offset, total, `Stock received — ${doc.receiptNo}`);
  },

  /**
   * Stock Transfer — stock moves between warehouses.
   *
   *   Dr  Inventory (destination warehouse)
   *     Cr  Inventory (source warehouse)
   *
   * Worth posting only when the two warehouses determine to DIFFERENT
   * inventory accounts — which happens when products are set to
   * "G/L Accounts By: Warehouse". When both sides land on the same account
   * the entry is a debit and a credit to one account for the same amount:
   * arithmetically nothing, and noise in the ledger. `createPosting` merges
   * by account and side, so those cancel to an empty entry and the posting is
   * skipped as a no-op.
   */
  async [JOURNAL_SOURCE_TYPES.STOCK_TRANSFER](ctx, posting, doc) {
    for (const item of doc.items || []) {
      if (!item.productCode) continue;
      const value = lineCostValue(item, 'quantity');
      if (round2(value) === 0) continue;

      const from = await resolveItemAccount(ctx, {
        productCode: item.productCode,
        warehouse: item.fromWarehouse || doc.fromWarehouse,
        role: 'inventoryAccount',
      });
      const to = await resolveItemAccount(ctx, {
        productCode: item.productCode,
        warehouse: item.toWarehouse || doc.toWarehouse,
        role: 'inventoryAccount',
      });
      if (from.accountCode === to.accountCode) continue;

      posting.credit(from, value, `Transfer out — ${doc.transferNo}`);
      posting.debit(to, value, `Transfer in — ${doc.transferNo}`);
    }
  },

  /**
   * Payment Receipt (Incoming Payment) — money in.
   *
   *   Dr  Cash / Bank
   *     Cr  Accounts Receivable   (Customer — settles what they owed)
   *     Cr  Accounts Payable      (Vendor — a refund from a supplier)
   *     Cr  the nominated account (Account — a receipt with no business partner)
   *
   * Valued at appliedAmount rather than totalAmountDue: the applied figure is
   * what actually settled against the ledger, which is the amount that moved.
   */
  async [JOURNAL_SOURCE_TYPES.PAYMENT_RECEIPT](ctx, posting, doc) {
    const amount = round2(Number(doc.appliedAmount) || 0);
    if (amount === 0) return;

    const cash = await resolveCashAccount(ctx);
    posting.debit(cash, amount, `Receipt — ${doc.paymentReceiptNo}`);

    const contra = await resolvePartyContraAccount(ctx, doc.partyType, doc.partyCode, doc.partyName);
    posting.credit(contra, amount, `${doc.partyName || 'Party'} — ${doc.paymentReceiptNo}`);
  },

  /**
   * Payment Voucher (Outgoing Payment) — money out.
   *
   *   Dr  Accounts Payable        (Vendor — settles what we owed)
   *   Dr  the nominated account   (Account — a payment with no business partner)
   *     Cr  Cash / Bank
   */
  async [JOURNAL_SOURCE_TYPES.PAYMENT_VOUCHER](ctx, posting, doc) {
    const amount = round2(Number(doc.appliedAmount) || 0);
    if (amount === 0) return;

    const contra = await resolvePartyContraAccount(ctx, doc.partyType, doc.partyCode, doc.partyName);
    posting.debit(contra, amount, `${doc.partyName || 'Party'} — ${doc.paymentVoucherNo}`);

    const cash = await resolveCashAccount(ctx);
    posting.credit(cash, amount, `Payment — ${doc.paymentVoucherNo}`);
  },
};

/**
 * The account on the other side of a payment, chosen by the party type the
 * user picked on the voucher.
 *
 * 'Account' means the user nominated a G/L account directly — the party code
 * IS the account code, so it is used as given rather than determined.
 */
async function resolvePartyContraAccount(ctx, partyType, partyCode, partyName) {
  if (partyType === 'Account') {
    const account = await ctx.accountByCode(partyCode);
    if (!account) {
      throw new AccountDeterminationError(
        `This payment posts against account "${partyCode}", which does not exist in the Chart Of Accounts.`
      );
    }
    assertPostable(account, 'payment account');
    return account;
  }
  if (partyType === 'Vendor') return resolveApAccount(ctx, partyName);
  return resolveArAccount(ctx, partyName);
}

/**
 * A document-level (rather than line-level) account — the offsetting side of
 * a posting, where there is one account for the whole document.
 *
 * Determined from the document's first item so that a company running
 * "G/L Accounts By: Product Group" still gets the group's own COGS or
 * clearing account rather than only the company default. With no items to go
 * on, the company-wide determination answers.
 */
async function resolveItemAccountForDocument(ctx, doc, role, warehouseOverride) {
  const firstItem = (doc.items || []).find((i) => i.productCode);
  if (!firstItem) return resolveDeterminationAccount(ctx, role);
  return resolveItemAccount(ctx, {
    productCode: firstItem.productCode,
    warehouse: warehouseOverride || doc.warehouse || firstItem.warehouse,
    role,
  });
}

// ---------------------------------------------------------------------------
// Posting
// ---------------------------------------------------------------------------

/**
 * The last line of defence: an entry that does not balance never reaches the
 * database.
 *
 * A residual of a paisa or two is real — every schema above rounds each line
 * to two decimals independently, and the roundings do not have to cancel. It
 * is absorbed onto the rounding account, which is what that account is for.
 *
 * Anything larger is not a rounding artefact, it is a defect in a posting
 * schema, and the correct response is to refuse rather than to force it
 * balanced with a plug. A plug would hide the bug in an account nobody reads
 * and leave the books arithmetically correct but meaningless.
 */
const ROUNDING_TOLERANCE = 0.02;

async function balanceLines(ctx, lines) {
  const totalDebit = round2(lines.reduce((s, l) => s + l.debit, 0));
  const totalCredit = round2(lines.reduce((s, l) => s + l.credit, 0));
  const difference = round2(totalDebit - totalCredit);

  if (difference === 0) return { lines, totalDebit, totalCredit };

  if (Math.abs(difference) > ROUNDING_TOLERANCE) {
    throw new Error(
      `Journal entry does not balance: debit ${totalDebit.toFixed(2)} vs credit ${totalCredit.toFixed(2)}. This is a defect in the posting schema, not a configuration problem.`
    );
  }

  const account = await resolveDeterminationAccount(ctx, 'roundingAccountId');
  lines.push({
    lineNo: lines.length + 1,
    accountCode: account.accountCode,
    accountName: account.accountName,
    description: 'Rounding difference',
    branch: lines[0]?.branch || null,
    debit: difference < 0 ? -difference : 0,
    credit: difference > 0 ? difference : 0,
  });

  return {
    lines,
    totalDebit: round2(lines.reduce((s, l) => s + l.debit, 0)),
    totalCredit: round2(lines.reduce((s, l) => s + l.credit, 0)),
  };
}

/**
 * Generate and store the accounting document for one business document.
 *
 * MUST be called with the transaction the document itself was written in.
 * Enlisting in the caller's transaction is what makes the document and its
 * journal entry atomic: a save that fails after posting rolls the entry back
 * with it, and there is never a ledger entry for a document that does not
 * exist. This is the same contract postStockEntries declares.
 *
 * @returns {{ posted: boolean, journalEntryNo: string|null, skipped: string|null }}
 */
async function postJournalEntry(tx, { sourceType, sourceDocNo, status, doc }) {
  if (!POSTING_SCHEMAS[sourceType]) return { posted: false, journalEntryNo: null, skipped: 'no-schema' };
  if (!sourceDocNo) return { posted: false, journalEntryNo: null, skipped: 'no-document-number' };
  if (!postsToGl(status)) return { posted: false, journalEntryNo: null, skipped: 'not-posted' };

  // Idempotency. The filtered unique index is the real guarantee; this check
  // exists so a re-save returns quietly instead of surfacing a constraint
  // violation to the user, who did nothing wrong by pressing Save twice.
  const existing = await tx.journalEntry.findFirst({ where: { sourceType, sourceDocNo } });
  if (existing) {
    return { posted: false, journalEntryNo: existing.journalEntryNo, skipped: 'already-posted' };
  }

  const ctx = createDeterminationContext(tx);
  const branch = doc.branch || null;
  const posting = createPosting(branch);

  let lines = [];
  let totals = { totalDebit: 0, totalCredit: 0 };
  let glError = null;

  try {
    await POSTING_SCHEMAS[sourceType](ctx, posting, doc);
    const built = posting.build();
    // A schema that legitimately produced nothing — an uncosted goods
    // movement, a transfer within one inventory account — is not an error and
    // must not leave a parked entry behind for someone to chase.
    if (!built.length) return { posted: false, journalEntryNo: null, skipped: 'no-postable-lines' };
    const balanced = await balanceLines(ctx, built);
    lines = balanced.lines;
    totals = { totalDebit: balanced.totalDebit, totalCredit: balanced.totalCredit };
  } catch (err) {
    // Configuration gaps park the entry. Anything else is a real fault and
    // must take the document down with it rather than being written off as a
    // configuration problem.
    if (!err.isAccountDetermination) throw err;
    glError = err.message;
    lines = [];
    totals = { totalDebit: 0, totalCredit: 0 };
  }

  const { resolveDocumentNumber } = require('./documentNumber');
  const { documentNumber, syncManual } = await resolveDocumentNumber('JE', null, tx);

  const created = await tx.journalEntry.create({
    data: {
      journalEntryNo: documentNumber,
      branch,
      transactionType: sourceType,
      sourceType,
      sourceDocNo,
      postingDate: doc.postingDate || doc.date || doc.documentDate || null,
      documentDate: doc.documentDate || doc.date || doc.postingDate || null,
      referenceNo: sourceDocNo,
      currency: doc.currency || 'INR',
      exchangeRate: doc.exchangeRate != null ? doc.exchangeRate : 1,
      remarks: `Automatically generated from ${sourceType} ${sourceDocNo}`,
      totalDebit: totals.totalDebit,
      totalCredit: totals.totalCredit,
      status: glError ? JOURNAL_STATUS.PENDING_GL : JOURNAL_STATUS.POSTED,
      glError,
      lines: { create: lines },
    },
  });
  if (syncManual) await syncManual();

  return {
    posted: !glError,
    journalEntryNo: created.journalEntryNo,
    skipped: glError ? 'pending-gl' : null,
  };
}

/**
 * Retry a parked entry after its configuration gap has been closed.
 *
 * Reloads the source document rather than trusting anything cached on the
 * parked row: time has passed, and the document may have been edited since.
 * The entry keeps its number — it is the same accounting document, finally
 * completed, and renumbering it would break any reference already made to it.
 */
async function repostJournalEntry(tx, journalEntryId, loadSourceDocument) {
  const entry = await tx.journalEntry.findUnique({ where: { id: journalEntryId } });
  if (!entry) {
    const err = new Error('Journal entry not found');
    err.status = 404;
    throw err;
  }
  if (entry.status !== JOURNAL_STATUS.PENDING_GL) {
    const err = new Error('Only an entry awaiting G/L posting can be posted this way.');
    err.status = 400;
    throw err;
  }

  const doc = await loadSourceDocument(tx, entry.sourceType, entry.sourceDocNo);
  if (!doc) {
    const err = new Error(`The source document ${entry.sourceType} ${entry.sourceDocNo} no longer exists.`);
    err.status = 400;
    throw err;
  }

  const ctx = createDeterminationContext(tx);
  const posting = createPosting(entry.branch);

  try {
    await POSTING_SCHEMAS[entry.sourceType](ctx, posting, doc);
    const built = posting.build();
    if (!built.length) {
      const err = new Error('This document produces no postable journal lines.');
      err.status = 400;
      throw err;
    }
    const balanced = await balanceLines(ctx, built);

    await tx.journalEntryLine.deleteMany({ where: { journalEntryId: entry.id } });
    return await tx.journalEntry.update({
      where: { id: entry.id },
      data: {
        totalDebit: balanced.totalDebit,
        totalCredit: balanced.totalCredit,
        status: JOURNAL_STATUS.POSTED,
        glError: null,
        lines: { create: balanced.lines },
      },
      include: { lines: { orderBy: { id: 'asc' } } },
    });
  } catch (err) {
    if (!err.isAccountDetermination) throw err;
    // Still not configured. Update the message — the gap may be a different
    // one now that the first was closed — and leave it parked.
    await tx.journalEntry.update({ where: { id: entry.id }, data: { glError: err.message } });
    const parked = new Error(err.message);
    parked.status = 400;
    throw parked;
  }
}

/**
 * Remove the accounting document behind a business document.
 *
 * Called when the source is deleted, or when it moves back to a status that
 * does not post (a posted invoice returned to Draft). Deleting rather than
 * reversing is the right call for THIS system: nothing in the app has a
 * period-close or a lock date, so there is no closed period a deletion could
 * corrupt, and a delete-and-regenerate keeps the ledger agreeing with the
 * document. The moment period locking exists, this should become a reversing
 * entry instead — the source-document key is already here to support that.
 */
async function reverseJournalEntry(tx, sourceType, sourceDocNo) {
  if (!sourceType || !sourceDocNo) return { removed: 0 };
  const existing = await tx.journalEntry.findFirst({ where: { sourceType, sourceDocNo } });
  if (!existing) return { removed: 0 };
  // JournalEntryLine.journalEntry is onDelete: Cascade, so lines go with it.
  await tx.journalEntry.delete({ where: { id: existing.id } });
  return { removed: 1 };
}

/**
 * The whole lifecycle in one call, for a document route's POST/PUT.
 *
 * Re-saving a document must be able to CHANGE its journal entry, not only
 * create one: an invoice whose lines were corrected has different accounting,
 * and an invoice pulled back to Draft should have no accounting at all. So an
 * existing entry is dropped and rebuilt from what the document now says,
 * which also means a document that was saved while its configuration was
 * incomplete heals itself the next time it is saved.
 */
async function syncJournalEntry(tx, { sourceType, sourceDocNo, status, doc }) {
  await reverseJournalEntry(tx, sourceType, sourceDocNo);
  return postJournalEntry(tx, { sourceType, sourceDocNo, status, doc });
}

module.exports = {
  JOURNAL_SOURCE_TYPES,
  JOURNAL_STATUS,
  POSTING_SCHEMAS,
  AccountDeterminationError,
  ROLE_TO_DETERMINATION,
  postsToGl,
  postJournalEntry,
  syncJournalEntry,
  repostJournalEntry,
  reverseJournalEntry,
  createDeterminationContext,
  resolveItemAccount,
  resolveDeterminationAccount,
};
