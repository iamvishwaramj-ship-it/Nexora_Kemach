const router = require('express').Router;
const auth = require('../middleware/auth');
const createCrudController = require('./crudFactory');

/**
 * Generic CRUD router built on top of createCrudController. Mounts:
 *   GET    /            list (supports ?q= search and ?page=/?limit= paging)
 *   GET    /:id         get one
 *   POST   /            create
 *   PUT    /:id         update
 *   DELETE /:id         delete
 *
 * Every route requires a valid JWT. Deletes additionally require the admin
 * role: previously any authenticated user could remove any master record or
 * transaction, which for an ERP is an unacceptable control gap — the
 * middleware supported roles from the start and nothing ever used them.
 *
 * @param {object} options
 *   deleteRoles: string[] — roles allowed to delete (default: admin only)
 *   writeRoles:  string[] — roles allowed to create/update (default: any user)
 *   guard: {
 *     beforeDelete: async (id, req) => void — throw to block the delete
 *     beforeUpdate: async (id, req) => void
 *     afterUpdate:  async (id, req, previous) => void
 *   }
 */
function crudRouter(delegate, options = {}) {
  const {
    deleteRoles = ['admin'],
    writeRoles = [],
    guard = {},
    autoNumber = null,
    ...controllerOptions
  } = options;

  const { list, getOne, create, update, remove } = createCrudController(delegate, {
    ...controllerOptions,
    guard,
    autoNumber,
  });

  const r = router();
  r.use(auth());
  r.get('/', list);
  r.get('/:id', getOne);
  r.post('/', auth(writeRoles), create);
  r.put('/:id', auth(writeRoles), update);
  r.delete('/:id', auth(deleteRoles), remove);
  return r;
}

module.exports = crudRouter;
