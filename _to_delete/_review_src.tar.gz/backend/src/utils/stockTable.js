// Posting logic for [dbo].[Stock] — the append-only inventory transaction
// journal (see the Stock model in schema.prisma).
//
// This sits alongside, not instead of, utils/stockLedger.js. That module
// derives on-hand quantity by reading the source documents live and covers
// all seven document types that move stock; this one writes a durable row
// per line at the moment a stock document is posted, so there is a permanent
// record of the movement independent of whatever the documents later say.
//
// Deliberate design constraints, chosen when this was specced:
//
//  * Insert-only. Rows are never updated or deleted. Editing a posted
//    document or deleting it outright leaves its existing Stock rows in
//    place — the journal records what was posted at the time, not the
//    document's current state.
//  * Posted-only. A document contributes rows when its status is 'Posted'.
//    Drafts and cancelled documents post nothing.
//
// Those two together mean a document posts its rows exactly once, the first
// time it is saved in Posted status — hasPostedAlready() below is what
// enforces the "once", since without it re-saving an already-posted document
// (a remark typo, a status round-trip) would duplicate every line.

const { isCosted, loadState, costMovement } = require('./stockValuation');

// Stored as text in Stock.TransType, so a row identifies its source document
// without a lookup table.
const TRANS_TYPES = {
  STOCK_RECEIPT: 'Stock Receipt',
  STOCK_ISSUE: 'Stock Issue',
  STOCK_ADJUSTMENT: 'Stock Adjustment',
  PURCHASE_GRN: 'Purchase GRN',
  DELIVERY_CHALLAN: 'Delivery Challan',
  // A Stock Transfer posts two rows per line under ONE document id — an
  // outbound leg at the from-warehouse and an inbound leg at the
  // to-warehouse — so it needs two distinct TransType values sharing one
  // TransNum. hasPostedAlready() keys off (transType, transNum), so calling
  // postStockEntries() twice with two different types here is what lets both
  // legs actually get written instead of the second call being silently
  // skipped as "already posted".
  STOCK_TRANSFER_OUT: 'Stock Transfer Out',
  STOCK_TRANSFER_IN: 'Stock Transfer In',
  // Goods going back OUT to a supplier — same direction as Delivery Challan.
  PURCHASE_RETURN: 'Purchase Return',
  PURCHASE_CREDIT_MEMO: 'Purchase Credit Memo',
  // Goods coming back IN from a customer — same direction as a GRN.
  SALES_RETURN: 'Sales Return',
  SALES_CREDIT_MEMO: 'Sales Credit Memo',
  // A DIRECT invoice — billed straight off the order with no GRN or delivery
  // challan behind it — is itself the document that moves the goods, so it
  // journals them. An invoice raised against a GRN or a challan posts NOTHING
  // here: that document already did, and posting again would count one
  // movement twice. The caller decides which case applies; see
  // postDirectInvoiceStock in routes/resources.js, which tests exactly the
  // condition utils/stockLedger.js filters on, so the journal and the derived
  // on-hand quantity cannot disagree about the same invoice.
  PURCHASE_INVOICE: 'Purchase Invoice',
  SALES_INVOICE: 'Sales Invoice',
};

// Which statuses mean "this movement has not actually happened". Stated as an
// exclusion rather than a list of good statuses because the vocabulary differs
// per document: a stock document is 'Posted', a GRN is 'Received' or
// 'Partially Received', a challan is 'Dispatched'/'Partially
// Delivered'/'Delivered'. Listing the positive values would silently miss any
// new one added to the frontend's option lists later.
//
// This is deliberately the same rule the derived ledger uses (see
// NON_MOVING_STATUSES in stockLedger.js) so the two never disagree about
// whether a given document moved stock.
const NON_MOVING_STATUSES = ['Draft', 'Cancelled', 'Pending'];

function movesStock(status) {
  return !NON_MOVING_STATUSES.includes(status);
}

/**
 * Warehouse is NVARCHAR(8) in the agreed table definition, but the warehouse
 * values these documents carry are display names ('Main Warehouse', a branch
 * name), not short codes — so they have to be clipped to fit rather than
 * failing the insert. Widening the column is the better long-term fix; until
 * then this keeps the journal writable.
 */
function fitWarehouse(value) {
  if (value == null) return null;
  const str = String(value).trim();
  if (str === '') return null;
  return str.length > 8 ? str.slice(0, 8) : str;
}

/**
 * The Stock delegate only exists on a Prisma Client generated after the Stock
 * model was added to schema.prisma. Without this check the first call fails
 * with a bare "Cannot read properties of undefined (reading 'findFirst')",
 * which says nothing about the actual cause.
 */
function stockDelegate(tx) {
  if (!tx.stock) {
    const err = new Error(
      'Prisma Client is out of date — it has no Stock model. '
      + 'Run `npm run prisma:generate` in backend/ and restart the server.'
    );
    err.status = 500;
    throw err;
  }
  return tx.stock;
}

/** Has this document already written its rows? Keeps posting idempotent. */
async function hasPostedAlready(tx, transType, transNum) {
  const existing = await stockDelegate(tx).findFirst({
    where: { transType, transNum },
    select: { docEntry: true },
  });
  return Boolean(existing);
}

/**
 * Resolves product codes to Product.id, because Stock.ItemId is NOT NULL.
 * A line naming a product that isn't in the master can't be journalled, and
 * silently dropping it would leave the journal quietly disagreeing with the
 * document, so this refuses the whole posting instead.
 */
async function resolveItemIds(tx, productCodes) {
  const codes = [...new Set(productCodes.filter(Boolean))];
  if (!codes.length) return new Map();
  const products = await tx.product.findMany({
    where: { productCode: { in: codes } },
    // calculationMethod rides along because costing needs it per line and this
    // is already the one lookup that touches every product on the document.
    select: { id: true, productCode: true, calculationMethod: true },
  });
  const byCode = new Map(products.map((p) => [p.productCode, p]));
  const missing = codes.filter((c) => !byCode.has(c));
  if (missing.length) {
    const err = new Error(
      `Cannot post to the stock journal — no product master record for: ${missing.join(', ')}.`
    );
    err.status = 400;
    throw err;
  }
  return byCode;
}

/**
 * Writes one Stock row per movement line.
 *
 * @param tx             Prisma transaction client (posting must share the
 *                       document's transaction, so a failed save posts nothing)
 * @param transType      one of TRANS_TYPES
 * @param transNum       the source document's primary key
 * @param status         the document's status — a non-moving one is a no-op
 * @param warehouse      document-level warehouse, used for any line that does
 *                       not carry its own (see `line.warehouse` below)
 * @param lines          [{ productCode, productName, quantity, unitPrice, direction, warehouse }]
 *                       direction: 'in' adds to InQty, 'out' adds to OutQty.
 *                       `warehouse`, when present on a line, overrides the
 *                       document-level `warehouse` for that line only — this
 *                       is what lets Stock Transfer post each item against its
 *                       own From/To Warehouse instead of one pair for the
 *                       whole document. Every other caller leaves it unset and
 *                       gets the prior all-lines-share-one-warehouse behavior.
 * @param userId         req.user.id, recorded as CreatedBy
 * @param currency       ISO code stored against the line's price
 */
async function postStockEntries(tx, {
  transType, transNum, status, warehouse, lines = [], userId = null, currency = 'INR',
}) {
  if (!movesStock(status)) return { posted: 0, skipped: 'not-posted' };
  if (!transNum) return { posted: 0, skipped: 'no-document-id' };
  if (await hasPostedAlready(tx, transType, transNum)) {
    return { posted: 0, skipped: 'already-posted' };
  }

  const movements = lines.filter((l) => l && l.productCode && Number(l.quantity));
  if (!movements.length) return { posted: 0, skipped: 'no-movement-lines' };

  const productByCode = await resolveItemIds(tx, movements.map((l) => l.productCode));

  // CreateDate and CreateTime split the same instant across the table's
  // separate DATE and TIME columns, so both describe the moment of posting.
  const now = new Date();
  const documentWarehouse = fitWarehouse(warehouse);

  // Costing state, keyed by item+warehouse rather than item alone — a product
  // can sit at a different cost in different warehouses (see loadState in
  // stockValuation.js), which only matters once lines are allowed to name
  // their own warehouse. Loaded once per pair and then carried across the
  // document's own lines that share it.
  const stateByKey = new Map();
  const stateFor = async (itemCode, warehouseValue) => {
    const key = `${itemCode}::${warehouseValue || ''}`;
    if (!stateByKey.has(key)) {
      stateByKey.set(key, await loadState(tx, { itemCode, warehouse: warehouseValue }));
    }
    return stateByKey.get(key);
  };

  const data = [];
  for (let i = 0; i < movements.length; i += 1) {
    const line = movements[i];
    const quantity = Math.abs(Number(line.quantity) || 0);
    const price = line.unitPrice == null ? null : Number(line.unitPrice) || 0;
    const isOut = line.direction === 'out';
    const product = productByCode.get(line.productCode);
    const method = product.calculationMethod;
    const lineWarehouse = fitWarehouse(line.warehouse != null && line.warehouse !== '' ? line.warehouse : documentWarehouse);

    // Only products set to FIFO or Moving Average are costed at all; for the
    // rest this is skipped entirely and both columns stay NULL.
    let fifoCost = null;
    let mavCost = null;
    if (isCosted(method)) {
      const state = await stateFor(line.productCode, lineWarehouse);
      ({ fifoCost, mavCost } = costMovement(state, {
        direction: line.direction, quantity, unitPrice: price, method,
      }));
    }

    data.push({
      itemCode: line.productCode,
      itemId: product.id,
      dscription: line.productName || null,
      warehouse: lineWarehouse,
      inQty: isOut ? 0 : quantity,
      outQty: isOut ? quantity : 0,
      price,
      currency,
      transValue: price == null ? null : quantity * price,
      transNum,
      transType,
      fifoCost,
      mavCost,
      lineNum: i + 1,
      createdBy: userId ?? null,
      createDate: now,
      createTime: now,
    });
  }

  await stockDelegate(tx).createMany({ data });
  return { posted: data.length, skipped: null };
}

/** Stock Receipt lines all move stock inward. */
function receiptLines(items) {
  return (items || []).map((i) => ({ ...i, direction: 'in' }));
}

/** Stock Issue lines all move stock outward. */
function issueLines(items) {
  return (items || []).map((i) => ({ ...i, direction: 'out' }));
}

/**
 * Stock Adjustment lines go either way per line — an Increase behaves like a
 * receipt, a Decrease like an issue. `quantity` is stored unsigned on the
 * document with the direction in itemAdjustmentType, which maps cleanly onto
 * the journal's InQty/OutQty split.
 */
function adjustmentLines(items) {
  return (items || []).map((i) => ({
    ...i,
    direction: i.itemAdjustmentType === 'Decrease' ? 'out' : 'in',
  }));
}

/**
 * Goods Received Note lines move stock inward. The moved quantity is
 * `receivedQuantity` — what actually arrived — not the ordered `poQuantity`,
 * which is what a partial receipt is measured against.
 */
function grnLines(items) {
  return (items || []).map((i) => ({
    ...i,
    quantity: i.receivedQuantity,
    direction: 'in',
  }));
}

/** Delivery Challan lines move stock outward — goods despatched to a customer. */
function challanLines(items) {
  return (items || []).map((i) => ({ ...i, direction: 'out' }));
}

/**
 * A Stock Transfer's outbound leg — each line leaves its OWN From Warehouse,
 * which the item table lets differ line to line, not necessarily the header's.
 * `warehouse` here is what postStockEntries' per-line override reads; the
 * header's fromWarehouse is passed alongside as the document-level fallback
 * for any line that somehow has none.
 */
function transferOutLines(items) {
  return (items || []).map((i) => ({ ...i, direction: 'out', warehouse: i.fromWarehouse || undefined }));
}

/** A Stock Transfer's inbound leg — each line arrives at its OWN To Warehouse. */
function transferInLines(items) {
  return (items || []).map((i) => ({ ...i, direction: 'in', warehouse: i.toWarehouse || undefined }));
}

/**
 * Purchase Return lines move stock outward — goods going back to the
 * supplier. The moved quantity is `returnQuantity`, not `receivedQuantity`
 * (what the original GRN brought in).
 */
function purchaseReturnLines(items) {
  return (items || []).map((i) => ({ ...i, quantity: i.returnQuantity, direction: 'out' }));
}

/** Purchase Credit Memo lines move stock outward — same direction as a Purchase Return. */
function purchaseCreditMemoLines(items) {
  return (items || []).map((i) => ({ ...i, direction: 'out' }));
}

/**
 * Sales Return lines move stock inward — goods coming back from a customer.
 * The moved quantity is `returnQuantity`, not `deliveredQuantity` (what the
 * original challan despatched).
 */
function salesReturnLines(items) {
  return (items || []).map((i) => ({ ...i, quantity: i.returnQuantity, direction: 'in' }));
}

/** Sales Credit Memo lines move stock inward — same direction as a Sales Return. */
function salesCreditMemoLines(items) {
  return (items || []).map((i) => ({ ...i, direction: 'in' }));
}

/**
 * Direct Purchase Invoice lines move stock inward — the goods are received by
 * the invoice itself because no GRN received them first. Same direction and
 * same `quantity` field as a GRN line; only the document differs.
 *
 * Called ONLY for an invoice with no grnNo. See postDirectInvoiceStock.
 */
function purchaseInvoiceLines(items) {
  return (items || []).map((i) => ({ ...i, direction: 'in' }));
}

/**
 * Direct Sales Invoice lines move stock outward — the goods are despatched by
 * the invoice itself because no delivery challan despatched them first.
 *
 * Called ONLY for an invoice with no deliveryChallanNo.
 */
function salesInvoiceLines(items) {
  return (items || []).map((i) => ({ ...i, direction: 'out' }));
}

module.exports = {
  TRANS_TYPES,
  NON_MOVING_STATUSES,
  movesStock,
  postStockEntries,
  receiptLines,
  issueLines,
  adjustmentLines,
  grnLines,
  challanLines,
  transferOutLines,
  transferInLines,
  purchaseReturnLines,
  purchaseCreditMemoLines,
  salesReturnLines,
  salesCreditMemoLines,
  purchaseInvoiceLines,
  salesInvoiceLines,
};
