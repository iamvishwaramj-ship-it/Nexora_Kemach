const asyncHandler = require('./asyncHandler');

/**
 * Generic Prisma-backed CRUD controller factory. Every simple master/
 * transaction-header resource in the app (30+ of them) shares the exact
 * same list/get/create/update/delete shape, so we generate the handlers
 * once instead of hand-rolling per-module boilerplate.
 *
 * @param {object} delegate - a Prisma model delegate, e.g. prisma.customer
 * @param {object} options
 *   searchFields: string[] — fields included in the ?q= search filter
 *   orderBy: object — default sort
 *   transform: (body) => data — maps request body to Prisma create/update data
 *   maxPageSize: number — hard cap on how many rows one request can return
 *   autoNumber: { documentCode, field, delegate } — generate the code column
 *     from a numbering series instead of trusting what the client typed
 */

/** Columns a client must never be able to set through a generic CRUD route. */
const PROTECTED_FIELDS = new Set(['id', 'createdAt', 'updatedAt', 'created_at', 'updated_at']);

/**
 * Parse and validate a route :id.
 *
 * This used to be a bare `Number(req.params.id)`, so GET /customers/abc
 * reached Prisma as NaN and came back as an opaque 500 from the query engine
 * instead of a 400 saying what was wrong. Floats and negative ids behaved the
 * same way.
 */
function parseId(raw) {
  const id = Number(raw);
  if (!Number.isInteger(id) || id <= 0) {
    const err = new Error('Invalid record id');
    err.status = 400;
    throw err;
  }
  return id;
}

/**
 * Strip fields the caller is not allowed to set, so a POST carrying
 * `{"id": 1}` cannot repoint a record's primary key and a PUT cannot forge
 * the audit timestamps on a row.
 */
function sanitize(body) {
  const clean = {};
  for (const [key, value] of Object.entries(body || {})) {
    if (PROTECTED_FIELDS.has(key)) continue;
    if (value === undefined) continue;
    clean[key] = value;
  }
  return clean;
}

function createCrudController(delegate, options = {}) {
  const {
    searchFields = [],
    orderBy = { id: 'desc' },
    transform = (body) => body,
    maxPageSize = 500,
    // { documentCode, field, delegate } — makes this resource's code column
    // auto-generated from the numbering series of that document code.
    // `delegate` is the Prisma model name, needed because the allocation runs
    // inside a transaction and the captured delegate is not transaction-bound.
    autoNumber = null,
    // Hooks that let a resource enforce rules the generic factory cannot know
    // about — chiefly refusing to delete a master record that transactions
    // still reference, and carrying a rename across that history.
    guard = {},
    // async ({ data, id, delegate }) => data | void — runs on every create and
    // update, before the row is written. `id` is null on create.
    //
    // `transform` can't do this job: it's synchronous, so it can't look
    // anything up. A rule like "the parent account must be a Title in the same
    // group, and the resulting depth must not exceed 5" needs the database,
    // which is exactly the class of rule that must not be left to the client.
    // Returning an object replaces the data being written (used to overwrite
    // client-supplied derived columns with server-computed ones); returning
    // nothing keeps it as-is. Throw an Error with `.status = 400` to reject.
    validate = null,
    // async ({ tx, row, data, id }) => void — runs INSIDE the same transaction
    // as the create/update that triggered it, immediately after the row is
    // written. `id` is null on create.
    //
    // For rules whose consequence lands on OTHER rows: "exactly one branch may
    // be the Main Branch", where promoting one has to demote whoever held it
    // before. Doing that here rather than as a follow-up request is what stops
    // two rows both claiming an exclusive flag when two saves land at once,
    // and stops a failed save from demoting the incumbent without promoting
    // its replacement.
    afterWrite = null,
    // The Prisma model property name (e.g. 'branch'). Needed only when
    // `afterWrite` is set: the `delegate` captured above is not bound to a
    // transaction, so the write itself has to go through `tx[delegateName]`.
    // autoNumber already carries the same name, so it is reused when present.
    delegateName = null,
  } = options;

  // Resolved once — see delegateName above.
  const txDelegateName = delegateName || (autoNumber && autoNumber.delegate) || null;
  if (afterWrite && !txDelegateName) {
    throw new Error('crudFactory: afterWrite requires delegateName (or autoNumber.delegate)');
  }

  const list = asyncHandler(async (req, res) => {
    const { q, page, limit } = req.query;
    const where = q && searchFields.length
      ? { OR: searchFields.map((f) => ({ [f]: { contains: q } })) }
      : undefined;

    // An unbounded findMany is fine on demo data and not fine on a real
    // ledger — a couple of years of invoices is tens of thousands of rows and
    // times the request out. Paging is opt-in so existing callers that expect
    // the whole list keep working, but the result set is always capped.
    const wantsPaging = page !== undefined || limit !== undefined;

    if (!wantsPaging) {
      const rows = await delegate.findMany({ where, orderBy, take: maxPageSize });
      return res.json({ success: true, data: rows });
    }

    const take = Math.min(Math.max(Number(limit) || maxPageSize, 1), maxPageSize);
    const pageNo = Math.max(Number(page) || 1, 1);
    const [rows, total] = await Promise.all([
      delegate.findMany({ where, orderBy, skip: (pageNo - 1) * take, take }),
      delegate.count({ where }),
    ]);
    res.json({
      success: true,
      data: rows,
      meta: { page: pageNo, limit: take, total, pages: Math.ceil(total / take) },
    });
  });

  const getOne = asyncHandler(async (req, res) => {
    const row = await delegate.findUnique({ where: { id: parseId(req.params.id) } });
    if (!row) return res.status(404).json({ success: false, message: 'Record not found' });
    res.json({ success: true, data: row });
  });

  const create = asyncHandler(async (req, res) => {
    let data = transform(sanitize(req.body));
    if (validate) data = (await validate({ data, id: null, delegate })) || data;

    // Master records (customer, product, branch, ...) draw their code from the
    // same numbering engine the transaction documents use. The allocation runs
    // inside the same transaction as the insert, so a save that fails
    // validation rolls back the number it consumed rather than burning a
    // permanent gap in the sequence.
    if (autoNumber) {
      const prisma = require('../prisma/client');
      const { resolveDocumentNumber } = require('./documentNumber');

      const row = await prisma.$transaction(async (tx) => {
        const { documentNumber, syncManual } = await resolveDocumentNumber(
          autoNumber.documentCode,
          data[autoNumber.field],
          tx
        );
        const created = await tx[autoNumber.delegate].create({
          data: { ...data, [autoNumber.field]: documentNumber },
        });
        if (syncManual) await syncManual();
        if (afterWrite) await afterWrite({ tx, row: created, data, id: null });
        return created;
      });
      return res.status(201).json({ success: true, data: row });
    }

    // Same transaction as the insert, so a consequence that lands on other
    // rows can never half-apply — see afterWrite above.
    if (afterWrite) {
      const prisma = require('../prisma/client');
      const row = await prisma.$transaction(async (tx) => {
        const created = await tx[txDelegateName].create({ data });
        await afterWrite({ tx, row: created, data, id: null });
        return created;
      });
      return res.status(201).json({ success: true, data: row });
    }

    const row = await delegate.create({ data });
    res.status(201).json({ success: true, data: row });
  });

  const update = asyncHandler(async (req, res) => {
    const id = parseId(req.params.id);
    let data = transform(sanitize(req.body));
    if (validate) data = (await validate({ data, id, delegate })) || data;

    if (guard.onUpdate) {
      // Runs inside the same transaction as the write, so a rename and the
      // history it cascades to either both land or neither does.
      const row = await guard.onUpdate({ id, data, delegate });
      return res.json({ success: true, data: row });
    }

    // Same transaction as the update — see afterWrite above.
    if (afterWrite) {
      const prisma = require('../prisma/client');
      const row = await prisma.$transaction(async (tx) => {
        const updated = await tx[txDelegateName].update({ where: { id }, data });
        await afterWrite({ tx, row: updated, data, id });
        return updated;
      });
      return res.json({ success: true, data: row });
    }

    const row = await delegate.update({ where: { id }, data });
    res.json({ success: true, data: row });
  });

  const remove = asyncHandler(async (req, res) => {
    const id = parseId(req.params.id);
    if (guard.onDelete) {
      await guard.onDelete({ id, delegate });
    } else {
      await delegate.delete({ where: { id } });
    }
    res.json({ success: true, message: 'Deleted successfully' });
  });

  return { list, getOne, create, update, remove };
}

module.exports = createCrudController;
module.exports.parseId = parseId;
module.exports.sanitize = sanitize;
