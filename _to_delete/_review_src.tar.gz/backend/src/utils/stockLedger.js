const { round2 } = require('./documentTotals');

/**
 * The shared Prisma client, resolved lazily rather than required at module
 * load. Constructing it eagerly means merely importing this file spins up a
 * database client — which a caller passing its own client never wanted, and
 * which makes the module impossible to exercise without a live query engine.
 */
let sharedPrisma = null;
function defaultClient() {
  if (!sharedPrisma) sharedPrisma = require('../prisma/client');
  return sharedPrisma;
}

/**
 * The stock ledger — every document in the application that moves inventory.
 *
 * This module previously derived on-hand quantity from only three documents:
 *
 *   openingStock + Stock Receipts − Stock Issues ± Stock Adjustments
 *
 * Goods Received Notes, Delivery Challans and invoices were absent. Inventory
 * was therefore completely decoupled from procure-to-pay and order-to-cash:
 * goods could be received against a purchase order and sold to a customer all
 * day without on-hand stock changing by a single unit, and the only way to
 * correct it was to key a manual stock document duplicating a movement the
 * system already knew about. Every downstream report — stock summary,
 * valuation, low stock, slow moving, dead stock, reorder level — inherited the
 * error, as did the dashboard's inventory alerts.
 *
 * Seven document types now post here.
 *
 * ## Avoiding double counting
 *
 * The same physical movement can be described by two documents. Goods arriving
 * are recorded on a GRN and then again on the Purchase Invoice raised from it;
 * goods leaving are recorded on a Delivery Challan and then again on the Sales
 * Invoice. Counting both would double the movement.
 *
 * SAP resolves this by having the delivery move stock while the invoice
 * carries only the financial posting. This application does not require a
 * delivery — an invoice can legitimately be raised on its own — so the rule
 * here is:
 *
 *   an invoice moves stock only when no delivery document is linked to it.
 *
 * A Purchase Invoice with a `grnNo` is financial only; one without is treated
 * as the receipt itself. A Sales Invoice with a `deliveryChallanNo` is
 * financial only; one without is treated as the issue. That covers both the
 * two-step and the one-step flow without ever counting a movement twice.
 *
 * ## Which documents count
 *
 * A document moves stock once it is no longer a draft and has not been
 * cancelled. The status vocabulary differs per document (a GRN is 'Received',
 * a challan is 'Delivered', a stock document is 'Posted'), so rather than
 * listing the positive values — and silently missing any new one added to the
 * frontend's option lists later — each source excludes the statuses meaning
 * "this has not happened yet" or "this was undone".
 */

/** Statuses that mean a document has not actually moved anything. */
const NON_MOVING_STATUSES = ['Draft', 'Cancelled', 'Pending'];

/**
 * One entry per document type that moves stock.
 *
 * quantityField  — the column holding the moved quantity
 * direction      — +1 inward, -1 outward, 0 signed (the value carries its sign)
 * warehouseField — where the movement happened, for warehouse-filtered reports
 * dateField      — the effective date, for as-on-date reports
 * headerFilter   — extra header conditions (used for the invoice de-duplication)
 */
const SOURCES = [
  {
    key: 'stockReceipt',
    label: 'Stock Receipt',
    itemDelegate: (c) => c.stockReceiptItem,
    headerRelation: 'receipt',
    quantityField: 'quantity',
    direction: +1,
    warehouseField: 'warehouse',
    dateField: 'date',
  },
  {
    key: 'stockIssue',
    label: 'Stock Issue',
    itemDelegate: (c) => c.stockIssueItem,
    headerRelation: 'issue',
    quantityField: 'quantity',
    direction: -1,
    warehouseField: 'toWarehouse',
    dateField: 'date',
  },
  {
    key: 'stockAdjustment',
    label: 'Stock Adjustment',
    itemDelegate: (c) => c.stockAdjustmentItem,
    headerRelation: 'adjustment',
    quantityField: 'differenceQuantity',
    direction: 0, // already signed: positive is a surplus, negative a shortfall
    warehouseField: 'warehouse',
    dateField: 'date',
  },
  // A Stock Transfer is two entries sharing one item table (see
  // StockTransferItem in schema.prisma) — an outbound leg at the header's
  // fromWarehouse and an inbound leg at toWarehouse. Company-wide these
  // cancel exactly to zero net movement (as a transfer must — nothing enters
  // or leaves the business), which is what keeps every existing
  // product-wide "current stock" figure (Product Master, low-stock/dead-
  // stock/reorder reports, the negative-stock guard) correct without any
  // changes; only warehouse-scoped queries (Stock Summary/Valuation filtered
  // to one warehouse) actually see the transfer as a movement, on the
  // correct side.
  {
    key: 'stockTransferOut',
    label: 'Stock Transfer',
    itemDelegate: (c) => c.stockTransferItem,
    headerRelation: 'transfer',
    quantityField: 'quantity',
    direction: -1,
    warehouseField: 'fromWarehouse',
    // Each line can name its own From/To Warehouse, independent of the
    // header's — see StockTransferItem.fromWarehouse/toWarehouse. Every other
    // source's warehouseField lives on the header, reached through
    // headerRelation; `warehouseScope: 'item'` tells buildWhere/
    // getStockMovements below to read and filter on the ITEM's own column
    // instead, so a warehouse-filtered report (or this line's contribution to
    // current stock) attributes to the warehouse the line actually moved
    // against, not whatever the header happened to default to.
    warehouseScope: 'item',
    dateField: 'requestDate',
  },
  {
    key: 'stockTransferIn',
    label: 'Stock Transfer',
    itemDelegate: (c) => c.stockTransferItem,
    headerRelation: 'transfer',
    quantityField: 'quantity',
    direction: +1,
    warehouseField: 'toWarehouse',
    warehouseScope: 'item',
    dateField: 'requestDate',
  },
  {
    key: 'goodsReceivedNote',
    label: 'Goods Received Note',
    itemDelegate: (c) => c.goodsReceivedNoteItem,
    headerRelation: 'grn',
    quantityField: 'receivedQuantity',
    direction: +1,
    warehouseField: 'warehouse',
    dateField: 'receivedDate',
  },
  {
    key: 'deliveryChallan',
    label: 'Delivery Challan',
    itemDelegate: (c) => c.deliveryChallanItem,
    headerRelation: 'challan',
    quantityField: 'quantity',
    direction: -1,
    warehouseField: 'fromWarehouse',
    dateField: 'challanDate',
  },
  {
    key: 'purchaseInvoice',
    label: 'Purchase Invoice',
    itemDelegate: (c) => c.purchaseInvoiceItem,
    headerRelation: 'invoice',
    quantityField: 'quantity',
    direction: +1,
    warehouseField: null,
    dateField: 'invoiceDate',
    // Only when the goods were not already received on a GRN.
    headerFilter: { OR: [{ grnNo: null }, { grnNo: '' }] },
  },
  {
    key: 'salesInvoice',
    label: 'Sales Invoice',
    itemDelegate: (c) => c.salesInvoiceItem,
    headerRelation: 'invoice',
    quantityField: 'quantity',
    direction: -1,
    warehouseField: null,
    dateField: 'invoiceDate',
    // Only when the goods were not already despatched on a delivery challan.
    headerFilter: { OR: [{ deliveryChallanNo: null }, { deliveryChallanNo: '' }] },
  },
  // Purchase Return / Purchase Credit Memo — goods going back OUT to a
  // supplier, same direction as a Delivery Challan. Newly wired into the
  // stock ledger (see the schema.prisma comments on PurchaseReturn/
  // PurchaseCreditMemo.warehouse) — previously these were financial-only
  // documents with no stock effect at all.
  {
    key: 'purchaseReturn',
    label: 'Purchase Return',
    itemDelegate: (c) => c.purchaseReturnItem,
    headerRelation: 'purchaseReturn',
    quantityField: 'returnQuantity',
    direction: -1,
    warehouseField: 'warehouse',
    dateField: 'postingDate',
  },
  {
    key: 'purchaseCreditMemo',
    label: 'Purchase Credit Memo',
    itemDelegate: (c) => c.purchaseCreditMemoItem,
    headerRelation: 'creditMemo',
    quantityField: 'quantity',
    direction: -1,
    warehouseField: 'warehouse',
    dateField: 'postingDate',
  },
  // Sales Return / Sales Credit Memo — goods coming back IN from a customer,
  // same direction as a Goods Received Note ("Restock" — see
  // BatchSerialRestockDialog.jsx and the businessRules.js functions of the
  // same name). Newly wired into the stock ledger for the same reason as the
  // purchase side above.
  {
    key: 'salesReturn',
    label: 'Sales Return',
    itemDelegate: (c) => c.salesReturnItem,
    headerRelation: 'salesReturn',
    quantityField: 'returnQuantity',
    direction: +1,
    warehouseField: 'warehouse',
    dateField: 'postingDate',
  },
  {
    key: 'salesCreditMemo',
    label: 'Sales Credit Memo',
    itemDelegate: (c) => c.salesCreditMemoItem,
    headerRelation: 'creditMemo',
    quantityField: 'quantity',
    direction: +1,
    warehouseField: 'warehouse',
    dateField: 'postingDate',
  },
];

/** Build the Prisma `where` for one source, or null if it cannot contribute. */
function buildWhere(source, { asOn, warehouse, productCodes }) {
  const itemLevelWarehouse = source.warehouseScope === 'item';

  const header = {
    status: { notIn: NON_MOVING_STATUSES },
    ...(source.headerFilter || {}),
  };
  if (asOn) header[source.dateField] = { lte: asOn };
  if (warehouse && !itemLevelWarehouse) {
    // A source with no warehouse column cannot satisfy a warehouse filter, and
    // must contribute nothing rather than everything.
    if (!source.warehouseField) return null;
    header[source.warehouseField] = warehouse;
  }

  const where = { [source.headerRelation]: header };
  if (productCodes && productCodes.length) where.productCode = { in: productCodes };
  if (warehouse && itemLevelWarehouse) where[source.warehouseField] = warehouse;
  return where;
}

/**
 * Read every stock movement, optionally scoped by date, warehouse and product.
 *
 * Returns a flat list of `{ productCode, quantity, source, warehouse }` where
 * `quantity` is signed: positive is inward, negative outward.
 */
async function getStockMovements({ asOn = null, warehouse = null, productCodes = null, client = null } = {}) {
  const db = client || defaultClient();
  const queries = SOURCES.map((source) => {
    const where = buildWhere(source, { asOn, warehouse, productCodes });
    if (!where) return Promise.resolve({ source, rows: [] });

    const itemLevelWarehouse = source.warehouseScope === 'item';
    return source
      .itemDelegate(db)
      .findMany({
        where,
        select: {
          productCode: true,
          [source.quantityField]: true,
          ...(itemLevelWarehouse && source.warehouseField ? { [source.warehouseField]: true } : {}),
          [source.headerRelation]: {
            select: itemLevelWarehouse || !source.warehouseField ? { id: true } : { [source.warehouseField]: true },
          },
        },
      })
      .then((rows) => ({ source, rows }));
  });

  const results = await Promise.all(queries);

  const movements = [];
  for (const { source, rows } of results) {
    const itemLevelWarehouse = source.warehouseScope === 'item';
    for (const row of rows) {
      if (!row.productCode) continue;
      const raw = Number(row[source.quantityField]) || 0;
      if (raw === 0) continue;
      movements.push({
        productCode: row.productCode,
        quantity: source.direction === 0 ? raw : raw * source.direction,
        source: source.label,
        warehouse: source.warehouseField
          ? (itemLevelWarehouse ? row[source.warehouseField] : row[source.headerRelation]?.[source.warehouseField]) || null
          : null,
      });
    }
  }
  return movements;
}

/**
 * Net movement per product code, as a Map.
 *
 * Excludes openingStock so callers can add it to whatever they already loaded.
 */
async function getStockMovementByProductCode(options = {}) {
  const movements = await getStockMovements(options);
  const net = new Map();
  for (const m of movements) {
    net.set(m.productCode, round2((net.get(m.productCode) || 0) + m.quantity));
  }
  return net;
}

/**
 * Inward and outward totals per product code, kept separate.
 *
 * The stock summary report needs both sides, and a stock adjustment has to
 * land on whichever side its sign implies — a shortfall is outward movement,
 * not negative inward movement.
 */
async function getInwardOutwardByProductCode(options = {}) {
  const movements = await getStockMovements(options);
  const inward = new Map();
  const outward = new Map();
  for (const m of movements) {
    if (m.quantity >= 0) inward.set(m.productCode, round2((inward.get(m.productCode) || 0) + m.quantity));
    else outward.set(m.productCode, round2((outward.get(m.productCode) || 0) + Math.abs(m.quantity)));
  }
  return { inward, outward };
}

/**
 * Given products (each needing productCode + openingStock), attach live stock.
 */
async function attachCurrentStock(products, options = {}) {
  const movement = await getStockMovementByProductCode(options);
  return products.map((p) => ({
    ...p,
    currentStock: round2((Number(p.openingStock) || 0) + (movement.get(p.productCode) || 0)),
  }));
}

/** Live stock for a single product code. */
async function getCurrentStockFor(productCode, { client = null } = {}) {
  const db = client || defaultClient();
  const [product, movement] = await Promise.all([
    db.product.findFirst({ where: { productCode }, select: { openingStock: true } }),
    getStockMovementByProductCode({ productCodes: [productCode], client: db }),
  ]);
  if (!product) return 0;
  return round2((Number(product.openingStock) || 0) + (movement.get(productCode) || 0));
}

/**
 * Live stock for many product codes at once, as a Map.
 *
 * Used by the negative-stock guard, which has to check a whole document's
 * lines without issuing one query per line.
 */
async function getCurrentStockForMany(productCodes, { client = null } = {}) {
  const codes = [...new Set((productCodes || []).filter(Boolean))];
  if (!codes.length) return new Map();

  const db = client || defaultClient();
  const [products, movement] = await Promise.all([
    db.product.findMany({
      where: { productCode: { in: codes } },
      select: { productCode: true, openingStock: true },
    }),
    getStockMovementByProductCode({ productCodes: codes, client: db }),
  ]);

  const stock = new Map();
  for (const p of products) {
    stock.set(p.productCode, round2((Number(p.openingStock) || 0) + (movement.get(p.productCode) || 0)));
  }
  return stock;
}

/**
 * Live stock for many (productCode, warehouse) pairs at once, scoped to each
 * pair's own warehouse — as opposed to getCurrentStockForMany, which is
 * company-wide.
 *
 * Stock Transfer needs this: a product can show plenty of stock company-wide
 * (getCurrentStockForMany) while the specific From Warehouse a line names
 * holds none of it, because the rest sits in a different warehouse. Checking
 * only the company-wide figure lets a transfer drain a warehouse to a
 * negative position that no report can show as anything but wrong.
 *
 * Opening stock is deliberately excluded — Product.openingStock is a single
 * product-wide figure with no warehouse of its own (see the same design
 * decision, and the reasoning for it, in utils/productInventory.js's
 * `unassignedOnHand`), so folding it into one warehouse's figure here would
 * overstate that warehouse and understate every other one.
 *
 * Returns a Map keyed by `${productCode}::${warehouse}`.
 */
async function getCurrentStockByWarehouseForMany(pairs, { client = null } = {}) {
  const db = client || defaultClient();
  const uniquePairs = [...new Map(
    (pairs || [])
      .filter((p) => p && p.productCode && p.warehouse)
      .map((p) => [`${p.productCode}::${p.warehouse}`, p])
  ).values()];
  if (!uniquePairs.length) return new Map();

  const warehouses = [...new Set(uniquePairs.map((p) => p.warehouse))];
  const productCodes = [...new Set(uniquePairs.map((p) => p.productCode))];

  const stock = new Map();
  // One query per distinct warehouse rather than per line — the same
  // "batch, don't loop per row" shape as getCurrentStockForMany.
  for (const warehouse of warehouses) {
    const movement = await getStockMovementByProductCode({ warehouse, productCodes, client: db });
    for (const { productCode } of uniquePairs) {
      if (!movement.has(productCode)) continue;
      stock.set(`${productCode}::${warehouse}`, movement.get(productCode));
    }
  }
  // Pairs the ledger has no movement for at all still resolve to zero rather
  // than being absent from the Map, so a caller checking `onHand.get(key) ?? 0`
  // and one checking `.has(key)` agree.
  for (const { productCode, warehouse } of uniquePairs) {
    const key = `${productCode}::${warehouse}`;
    if (!stock.has(key)) stock.set(key, 0);
  }
  return stock;
}

module.exports = {
  getStockMovements,
  getStockMovementByProductCode,
  getInwardOutwardByProductCode,
  attachCurrentStock,
  getCurrentStockFor,
  getCurrentStockForMany,
  getCurrentStockByWarehouseForMany,
  NON_MOVING_STATUSES,
  SOURCES,
};
