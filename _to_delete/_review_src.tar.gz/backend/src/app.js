const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
require('dotenv').config();

const { notFoundHandler, errorHandler } = require('./middleware/errorHandler');
const { permissionGuard } = require('./middleware/permission');

const app = express();

// CORS whitelist — allow Vite dev server + any FRONTEND_URL set in .env
const allowedOrigins = [
  process.env.FRONTEND_URL,
  'http://localhost:5173',
  'http://localhost:3000',
  'http://localhost:3101',
].filter(Boolean);

const corsOptions = {
  origin: (origin, callback) => {
    if (!origin || allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error(`CORS blocked: origin ${origin} not allowed`));
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
};

app.use(helmet());
app.use(cors(corsOptions));
app.options('*', cors(corsOptions));
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Menu-permission enforcement for every mutating request under /api. Mounted
// here, ahead of the module routers, so one map governs all of them instead of
// each route re-deriving its own rule (and forgetting to). Reads and unmapped
// paths fall straight through — see middleware/permission.js.
app.use('/api', permissionGuard());

// --- Prisma-backed modules ---
app.use('/api/health', require('./routes/health'));
app.use('/api/auth', require('./routes/auth'));
app.use('/api/company', require('./routes/company'));
app.use('/api/dashboard', require('./routes/dashboard'));
app.use('/api/profile', require('./routes/profile'));
// User accounts + their menu-based permission grid — ahead of the generic
// resources router below so this bespoke handling of /api/users (password
// hashing, nested permissions writes) is what actually answers it.
app.use('/api/users', require('./routes/users'));
// Every other resource (products, customers, suppliers, purchase, sales,
// inventory, receivables, payables, banking) shares the generic CRUD shape
// and is mounted in one place — see routes/resources.js.
app.use('/api', require('./routes/resources'));

app.use(notFoundHandler);
app.use(errorHandler);

module.exports = app;
