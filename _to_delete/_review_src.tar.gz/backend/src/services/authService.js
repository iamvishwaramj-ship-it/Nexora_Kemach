const bcrypt = require('bcryptjs');
const prisma = require('../prisma/client');
const { signAccessToken, signRefreshToken, verifyRefreshToken, refreshExpiryDate } = require('../utils/jwt');

// The permission rows the frontend needs to hide menus and action buttons.
// Only granted ones are sent: User Management writes a row per menu item
// (~95 of them, mostly all-false), and shipping the whole grid on every login
// would bloat the response and its localStorage copy for no gain — a menu key
// the client never sees is treated as "no access" anyway.
async function grantedPermissions(userId) {
  return prisma.userPermission.findMany({
    where: {
      userId,
      OR: [{ canView: true }, { canAdd: true }, { canEdit: true }, { canDelete: true }],
    },
    select: { menuKey: true, canView: true, canAdd: true, canEdit: true, canDelete: true },
  });
}

async function login(email, password) {
  const user = await prisma.appUser.findUnique({ where: { email } });
  if (!user) {
    const err = new Error('Invalid email or password');
    err.status = 401;
    throw err;
  }
  if (user.status !== 'Active') {
    const err = new Error('This account is inactive. Contact your administrator.');
    err.status = 403;
    throw err;
  }

  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) {
    const err = new Error('Invalid email or password');
    err.status = 401;
    throw err;
  }

  const payload = { id: user.id, email: user.email, role: user.role, name: user.name };
  const accessToken = signAccessToken(payload);
  const refreshToken = signRefreshToken({ id: user.id });

  await prisma.refreshToken.create({
    data: { token: refreshToken, userId: user.id, expiresAt: refreshExpiryDate() },
  });

  return {
    accessToken,
    refreshToken,
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      status: user.status,
      profilePhotoUrl: user.profilePhotoUrl,
      permissions: await grantedPermissions(user.id),
    },
  };
}

async function refresh(token) {
  if (!token) {
    const err = new Error('No refresh token provided');
    err.status = 401;
    throw err;
  }

  let decoded;
  try {
    decoded = verifyRefreshToken(token);
  } catch {
    const err = new Error('Invalid or expired refresh token');
    err.status = 401;
    throw err;
  }

  const stored = await prisma.refreshToken.findUnique({ where: { token } });
  if (!stored || stored.revoked || stored.expiresAt < new Date()) {
    const err = new Error('Refresh token is no longer valid');
    err.status = 401;
    throw err;
  }

  const user = await prisma.appUser.findUnique({ where: { id: decoded.id } });
  if (!user || user.status !== 'Active') {
    const err = new Error('User not found or inactive');
    err.status = 401;
    throw err;
  }

  const payload = { id: user.id, email: user.email, role: user.role, name: user.name };
  const accessToken = signAccessToken(payload);

  return { accessToken };
}

async function logout(token) {
  if (!token) return;
  await prisma.refreshToken.updateMany({ where: { token }, data: { revoked: true } });
}

async function resetPassword(userId, currentPassword, newPassword) {
  const user = await prisma.appUser.findUnique({ where: { id: userId } });
  if (!user) {
    const err = new Error('User not found');
    err.status = 404;
    throw err;
  }
  const valid = await bcrypt.compare(currentPassword, user.passwordHash);
  if (!valid) {
    const err = new Error('Current password is incorrect');
    err.status = 400;
    throw err;
  }
  const passwordHash = await bcrypt.hash(newPassword, 10);
  await prisma.appUser.update({ where: { id: userId }, data: { passwordHash } });
  // Invalidate all outstanding refresh tokens on password change
  await prisma.refreshToken.updateMany({ where: { userId }, data: { revoked: true } });
}

module.exports = { login, refresh, logout, resetPassword, grantedPermissions };
