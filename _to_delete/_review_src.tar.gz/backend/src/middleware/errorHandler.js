const { Prisma } = require('@prisma/client');

function notFoundHandler(req, res) {
  res.status(404).json({ success: false, message: 'Route not found' });
}

// Centralized error handler — normalizes Prisma errors, validation errors, and generic errors
// into a consistent { success, message } shape. Never leaks stack traces in production.
function errorHandler(err, req, res, next) {
  console.error(err);

  if (err instanceof Prisma.PrismaClientKnownRequestError) {
    if (err.code === 'P2002') {
      const field = err.meta?.target?.join(', ') || 'field';
      return res.status(409).json({ success: false, message: `A record with this ${field} already exists.` });
    }
    if (err.code === 'P2025') {
      return res.status(404).json({ success: false, message: 'Record not found.' });
    }
    if (err.code === 'P2003') {
      return res.status(409).json({ success: false, message: 'This record is referenced by other data and cannot be modified.' });
    }
  }

  const status = err.status || err.statusCode || 500;
  const message = status === 500 && process.env.NODE_ENV === 'production'
    ? 'Internal Server Error'
    : (err.message || 'Internal Server Error');

  res.status(status).json({
    success: false,
    message,
    // Field-tagged validation messages (see badRequest in routes/company.js)
    // so a form can show each error under the input it belongs to, not just
    // as one combined toast.
    ...(Array.isArray(err.errors) ? { errors: err.errors } : {}),
    ...(process.env.NODE_ENV !== 'production' ? { stack: err.stack } : {}),
  });
}

module.exports = { notFoundHandler, errorHandler };
