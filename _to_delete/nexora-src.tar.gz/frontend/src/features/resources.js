// One CRUD hook-set per resource, generated from the shared factory.
// Import from here in pages instead of writing bespoke RTK Query code.
import { createCrudApi } from '../lib/createCrudApi';
import { baseApi } from '../store/baseApi';

// Company Setup
export const branchApi = createCrudApi({ resourcePath: 'company/branches', tagType: 'Branch' });
export const financialYearApi = createCrudApi({ resourcePath: 'company/financial-years', tagType: 'FinancialYear' });
export const taxCodeApi = createCrudApi({ resourcePath: 'company/tax-codes', tagType: 'TaxCode' });
export const bankNameApi = createCrudApi({ resourcePath: 'company/bank-names', tagType: 'BankName' });
export const houseBankApi = createCrudApi({ resourcePath: 'company/house-banks', tagType: 'HouseBank' });
export const salesEmployeeApi = createCrudApi({ resourcePath: 'company/sales-employees', tagType: 'SalesEmployee' });
export const approvalFlowApi = createCrudApi({ resourcePath: 'company/approval-flows', tagType: 'ApprovalFlow' });

// Accounting
export const accountGroupApi = createCrudApi({ resourcePath: 'account-groups', tagType: 'AccountGroup' });
export const accountTypeApi = createCrudApi({ resourcePath: 'account-types', tagType: 'AccountType' });
export const chartOfAccountApi = createCrudApi({ resourcePath: 'chart-of-accounts', tagType: 'ChartOfAccount' });

// Product Setup
export const productGroupApi = createCrudApi({ resourcePath: 'product-groups', tagType: 'ProductGroup' });
export const productSubGroupApi = createCrudApi({ resourcePath: 'product-sub-groups', tagType: 'ProductSubGroup' });
export const brandApi = createCrudApi({ resourcePath: 'brands', tagType: 'Brand' });
export const uomApi = createCrudApi({ resourcePath: 'uoms', tagType: 'Uom' });
export const productApi = createCrudApi({ resourcePath: 'products', tagType: 'Product' });

// Live current stock per product (openingStock plus every posted Stock
// Receipt/Issue/Adjustment movement) — separate from the CRUD product record
// since it's computed, not stored. Tagged 'Product' so it refetches whenever
// a product or stock-movement mutation invalidates the product list.
const productStockApi = baseApi.injectEndpoints({
  endpoints: (builder) => ({
    getProductCurrentStock: builder.query({
      query: () => '/products/current-stock',
      transformResponse: (response) => response.data,
      providesTags: [{ type: 'Product', id: 'CURRENT_STOCK' }],
    }),
  }),
  overrideExisting: false,
});
export const useGetProductCurrentStockQuery = productStockApi.useGetProductCurrentStockQuery;

// Product Master > Inventory tab — the per-warehouse position for one product.
// Its own endpoint rather than fields on the product record because everything
// it shows except the Min/Max levels is derived from stock movements and open
// orders at read time (see backend utils/productInventory.js).
//
// Tagged per product code, so saving one product's levels refetches that
// product's inventory and leaves every other cached product alone.
const productInventoryApi = baseApi.injectEndpoints({
  endpoints: (builder) => ({
    getProductInventory: builder.query({
      query: (productCode) => `/products/${encodeURIComponent(productCode)}/inventory`,
      transformResponse: (response) => response.data,
      providesTags: (result, error, productCode) => [
        { type: 'Product', id: `INVENTORY_${productCode}` },
      ],
    }),
    saveProductInventory: builder.mutation({
      query: ({ productCode, rows }) => ({
        url: `/products/${encodeURIComponent(productCode)}/inventory`,
        method: 'PUT',
        body: { rows },
      }),
      invalidatesTags: (result, error, { productCode }) => [
        { type: 'Product', id: `INVENTORY_${productCode}` },
      ],
    }),
  }),
  overrideExisting: false,
});
export const useGetProductInventoryQuery = productInventoryApi.useGetProductInventoryQuery;
export const useSaveProductInventoryMutation = productInventoryApi.useSaveProductInventoryMutation;

export const productCatalogApi = createCrudApi({ resourcePath: 'product-catalogs', tagType: 'ProductCatalog' });
export const purchasePriceApi = createCrudApi({ resourcePath: 'purchase-prices', tagType: 'PurchasePrice' });
export const salesPriceApi = createCrudApi({ resourcePath: 'sales-prices', tagType: 'SalesPrice' });
export const customerDiscountApi = createCrudApi({ resourcePath: 'customer-discounts', tagType: 'CustomerDiscount' });

// Business Partner
export const customerApi = createCrudApi({ resourcePath: 'customers', tagType: 'Customer' });
export const supplierApi = createCrudApi({ resourcePath: 'suppliers', tagType: 'Supplier' });
export const transportApi = createCrudApi({ resourcePath: 'transporters', tagType: 'Transport' });
export const warehouseApi = createCrudApi({ resourcePath: 'warehouses', tagType: 'Warehouse' });
export const locationApi  = createCrudApi({ resourcePath: 'locations',  tagType: 'Location' });

// Rich Warehouse/Location masters imported from Master Data.xlsx — separate
// from warehouseApi/locationApi above (see the model comments in
// schema.prisma). warehouseMasterApi backs Opening Balance's Warehouse
// dropdown.
export const warehouseMasterApi = createCrudApi({ resourcePath: 'warehouse-master', tagType: 'WarehouseMaster' });
export const locationMasterApi  = createCrudApi({ resourcePath: 'location-master',  tagType: 'LocationMaster' });
export const openingBalanceApi  = createCrudApi({ resourcePath: 'opening-balance',  tagType: 'OpeningBalance' });

// Bulk "Import from Excel" for Opening Balance — a multipart upload rather
// than the generic create/update JSON shape, so it's hand-injected here
// instead of coming from createCrudApi. `body: formData` is passed straight
// through: fetchBaseQuery skips JSON.stringify-ing FormData and lets the
// browser set the multipart Content-Type/boundary itself.
const openingBalanceImportApi = baseApi.injectEndpoints({
  endpoints: (builder) => ({
    importOpeningBalanceXlsx: builder.mutation({
      query: (formData) => ({ url: '/opening-balance/import-xlsx', method: 'POST', body: formData }),
      invalidatesTags: [{ type: 'OpeningBalance', id: 'LIST' }],
    }),
  }),
  overrideExisting: false,
});
export const useImportOpeningBalanceXlsxMutation = openingBalanceImportApi.useImportOpeningBalanceXlsxMutation;
// Full CRUD, backed by routes/users.js (not the generic crudRouter — see that
// file for why: password hashing and each user's nested permission grid).
// useList is also what every "assigned to"/"received by" style dropdown
// elsewhere in the app (Collection Entry, etc.) calls.
export const salesReturnApi = createCrudApi({ resourcePath: 'sales/returns', tagType: 'SalesReturn' });

export const salesCreditMemoApi = createCrudApi({ resourcePath: 'sales/credit-memos', tagType: 'SalesCreditMemo' });

export const purchaseCreditMemoApi = createCrudApi({ resourcePath: 'purchase/credit-memos', tagType: 'PurchaseCreditMemo' });

export const purchaseReturnApi = createCrudApi({ resourcePath: 'purchase/returns', tagType: 'PurchaseReturn' });

export const appUserApi = createCrudApi({ resourcePath: 'users', tagType: 'AppUser' });

// Purchase
export const purchaseQuotationApi = createCrudApi({ resourcePath: 'purchase/quotations', tagType: 'PurchaseQuotation' });
export const purchaseOrderApi = createCrudApi({ resourcePath: 'purchase/orders', tagType: 'PurchaseOrder' });
export const goodsReceivedNoteApi = createCrudApi({ resourcePath: 'purchase/grn', tagType: 'GoodsReceivedNote' });
export const purchaseInvoiceApi = createCrudApi({ resourcePath: 'purchase/invoices', tagType: 'PurchaseInvoice' });

// Sales
export const salesQuotationApi = createCrudApi({ resourcePath: 'sales/quotations', tagType: 'SalesQuotation' });
export const salesOrderApi = createCrudApi({ resourcePath: 'sales/orders', tagType: 'SalesOrder' });
export const deliveryChallanApi = createCrudApi({ resourcePath: 'sales/delivery-challans', tagType: 'DeliveryChallan' });
export const salesInvoiceApi = createCrudApi({ resourcePath: 'sales/invoices', tagType: 'SalesInvoice' });
export const enquiryApi = createCrudApi({ resourcePath: 'sales/enquiries', tagType: 'Enquiry' });
export const followUpApi = createCrudApi({ resourcePath: 'sales/follow-ups', tagType: 'FollowUp' });

// Inventory
export const stockReceiptApi = createCrudApi({ resourcePath: 'inventory/stock-receipts', tagType: 'StockReceipt' });
export const stockIssueApi = createCrudApi({ resourcePath: 'inventory/stock-issues', tagType: 'StockIssue' });
export const stockAdjustmentApi = createCrudApi({ resourcePath: 'inventory/stock-adjustments', tagType: 'StockAdjustment' });
export const stockTransferApi = createCrudApi({ resourcePath: 'inventory/stock-transfers', tagType: 'StockTransfer' });

// Receivables
export const customerOutstandingApi = createCrudApi({ resourcePath: 'receivables/outstanding', tagType: 'CustomerOutstanding' });
// Saving/deleting a collection makes the backend silently upsert/remove a
// matching BankReconciliationTransaction row (syncBankReconciliationTxn) —
// invalidate BankReconciliation's list too, or the Bank Reconciliation page
// keeps showing stale System Transactions until a manual refresh.
export const collectionApi = createCrudApi({ resourcePath: 'receivables/collections', tagType: 'Collection', extraInvalidateTags: [{ type: 'BankReconciliation', id: 'LIST' }] });

// Payables
export const supplierOutstandingApi = createCrudApi({ resourcePath: 'payables/outstanding', tagType: 'SupplierOutstanding' });
// Same reasoning as collectionApi above — supplier payments sync a
// BankReconciliationTransaction row server-side.
export const supplierPaymentApi = createCrudApi({ resourcePath: 'payables/payments', tagType: 'SupplierPayment', extraInvalidateTags: [{ type: 'BankReconciliation', id: 'LIST' }] });

// Banking
// Same reasoning as collectionApi/supplierPaymentApi above — bank deposits
// and cheques both sync a BankReconciliationTransaction row server-side.
export const bankDepositApi = createCrudApi({ resourcePath: 'banking/deposits', tagType: 'BankDeposit', extraInvalidateTags: [{ type: 'BankReconciliation', id: 'LIST' }] });
export const bankReconciliationApi = createCrudApi({ resourcePath: 'banking/reconciliations', tagType: 'BankReconciliation' });
export const chequeApi = createCrudApi({ resourcePath: 'banking/cheques', tagType: 'Cheque', extraInvalidateTags: [{ type: 'BankReconciliation', id: 'LIST' }] });
// Payment Receipt ("Incoming Payment") -- posts against a Customer, Vendor,
// or raw Account. Unlike the deposit/cheque/collection/payment resources
// above, it has no bank-account field of its own to sync a
// BankReconciliationTransaction against, so it carries no extraInvalidateTags.
export const paymentReceiptApi = createCrudApi({ resourcePath: 'banking/payment-receipts', tagType: 'PaymentReceipt' });
// Payment Voucher ("Outgoing Payment") -- same no-bank-reconciliation-sync
// reasoning as paymentReceiptApi above.
export const paymentVoucherApi = createCrudApi({ resourcePath: 'banking/payment-vouchers', tagType: 'PaymentVoucher' });
