import React from 'react';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import { store } from './store/store';
import { AppThemeProvider } from './context/ThemeContext';
import { NotificationProvider } from './components/feedback/NotificationProvider';
import { ConfirmProvider } from './components/feedback/ConfirmationDialog';
import AppRouter from './router/AppRouter';
import './i18n/config';

const App = () => (
  <Provider store={store}>
    <AppThemeProvider>
      <NotificationProvider>
        <ConfirmProvider>
          <BrowserRouter>
            <AppRouter />
          </BrowserRouter>
        </ConfirmProvider>
      </NotificationProvider>
    </AppThemeProvider>
  </Provider>
);

export default App;
