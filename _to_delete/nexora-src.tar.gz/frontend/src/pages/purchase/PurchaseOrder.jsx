import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Box, Typography, Button, Card, CardContent, Stack, TextField, InputAdornment, Table,
  TableBody, TableCell, TableContainer, TableHead, TableRow, Chip, IconButton, Menu, MenuItem,
  ListItemIcon, ListItemText, Checkbox, Autocomplete, Popover, Grid, Tooltip,
  Collapse,
} from '@mui/material';
import { useFieldArray } from 'react-hook-form';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import dayjs from 'dayjs';
import ShoppingBagOutlinedIcon from '@mui/icons-material/ShoppingBagOutlined';
import AddIcon from '@mui/icons-material/Add';
import CloseIcon from '@mui/icons-material/Close';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import SearchIcon from '@mui/icons-material/Search';
import FilterListIcon from '@mui/icons-material/FilterList';
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import PrintOutlinedIcon from '@mui/icons-material/PrintOutlined';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import EditIcon from '@mui/icons-material/EditOutlined';
import DeleteIcon from '@mui/icons-material/DeleteOutline';
import EventIcon from '@mui/icons-material/Event';
import UploadFileIcon from '@mui/icons-material/UploadFile';
import ContentCopyOutlinedIcon from '@mui/icons-material/ContentCopyOutlined';
import AppForm, { FormGrid, FormSubmitButton } from '../../components/form/AppForm';
import FormTextField from '../../components/form/FormTextField';
import FormSelect from '../../components/form/FormSelect';
import FormDatePicker from '../../components/form/FormDatePicker';
import DocumentNoField, { peekNextDocumentNumber } from '../../components/form/DocumentNoField';
import EntityHeaderCard from '../../components/common/EntityHeaderCard';
import CompanyBadge from '../../components/common/CompanyBadge';
import EntityListPagination from '../../components/data-display/EntityListPagination';
import FilterAutocomplete from '../../components/data-display/FilterAutocomplete';
import MobileRecordCard from '../../components/data-display/MobileRecordCard';
import MobileItemCard from '../../components/data-display/MobileItemCard';
import { useIsMobileListView } from '../../components/data-display/useIsMobileListView';
import useDragScroll from '../../components/data-display/useDragScroll';
import { useNotify } from '../../components/feedback/NotificationProvider';
import { applyServerErrors } from '../../lib/formErrors';
import { useConfirm } from '../../components/feedback/ConfirmationDialog';
import { purchaseOrderSchema, PO_STATUS_OPTIONS } from '../../lib/validation/purchaseSchemas';
import { buildDocument, round2, isInterState } from '../../lib/documentTotals';
import DocumentTotalsPanel from '../../components/form/DocumentTotalsPanel';
import { CURRENCY_OPTIONS, SUPPLIER_PAYMENT_TERMS_OPTIONS } from '../../lib/validation/partnerSchemas';
import { purchaseOrderApi, purchaseQuotationApi, supplierApi, productApi, branchApi, houseBankApi, taxCodeApi } from '../../features/resources';
import { buildTaxPercentOptions } from '../../lib/taxCodeOptions';
import { useGetCompanyDetailsQuery, usePeekDocumentNumberMutation } from '../../features/company/companyDetailsApi';
import PurchaseOrderPrintable from '../../components/print/PurchaseOrderPrintable';
import useTableFeatures from '../../components/data-display/useTableFeatures';
import TableSearchFilter from '../../components/data-display/TableSearchFilter';
import SortableHeaderCell from '../../components/data-display/SortableHeaderCell';
import ScrollableTableContainer, { dragScrollbarSx } from '../../components/data-display/ScrollableTableContainer';

import { CanAdd, CanEdit, CanDelete } from '../../components/common/PermissionGate';
import TableFilterPanel from '../../components/data-display/TableFilterPanel';
const TRANSPORT_MODE_OPTIONS = ['Road', 'Rail', 'Air', 'Sea', 'Courier'].map((v) => ({ label: v, value: v }));

const emptyItem = { productCode: '', productName: '', description: '', hsnCode: '', uom: '', quantity: 1, unitPrice: 0, taxPercent: 18 };

const DEFAULT_TERMS = [
  '1. Goods once sold will not be taken back.',
  '2. Delivery as per agreed schedule.',
  '3. Payment within the stipulated credit period.',
  '4. Subject to Bangalore jurisdiction.',
].join('\n');

function getEmptyValues() {
  return {
    poNo: '', branch: '', supplier: '', contactPerson: '', phone: '', email: '',
    poDate: new Date(), validUpto: null, referenceNo: '',
    currency: 'INR', paymentTerms: '', deliveryDate: null, shipTo: '',
    termsConditions: DEFAULT_TERMS, attachmentName: '', discountPercent: 0, status: 'Open',
    buyingBranch: '', department: '', placeOfSupply: '', transportMode: '',
    eWayBillNo: '', eWayBillDate: null, packingForwarding: '', loadingUnloading: '',
    inspection: '', warranty: '', remarks: '', bankAccount: '',
    preparedBy: '', checkedBy: '', approvedBy: '',
    items: [{ ...emptyItem }],
  };
}

// Totals come from the shared engine in lib/documentTotals.js, which the
// backend mirrors exactly — the figures shown here while editing are the
// figures that get saved. Each page used to carry its own copy of this
// arithmetic and the copies had drifted apart; this document in particular
// used to hard-code CGST and SGST at 9% each regardless of what the goods
// actually attract.
//
// `grandTotal` and `discount` are kept in the returned shape because the
// totals panel below reads those names.
// `interState` must be passed through rather than defaulted: the server
// decides CGST/SGST vs IGST by comparing this document's Place of Supply
// against the company's registered state, and for a long time no page passed
// the flag at all — so an inter-state document displayed a CGST/SGST split
// while the record it saved held IGST.
//
function computeTotals(items, discountPercent, interState = false) {
  const { totals } = buildDocument(items, discountPercent, {
    interState,
    roundOff: true,
  });
  return {
    ...totals,
    discount: round2(totals.subtotal - totals.taxableAmount),
    grandTotal: totals.amount,
  };
}

function rowToFormValues(row) {
  return {
    poNo: row.poNo, branch: row.branch || '', supplier: row.supplier || '', contactPerson: row.contactPerson || '',
    phone: row.phone || '', email: row.email || '',
    poDate: row.poDate, validUpto: row.validUpto, referenceNo: row.referenceNo || '',
    currency: row.currency || 'INR', paymentTerms: row.paymentTerms || '', deliveryDate: row.deliveryDate,
    shipTo: row.shipTo || '', termsConditions: row.termsConditions || '', attachmentName: row.attachmentName || '',
    discountPercent: row.discountPercent != null ? Number(row.discountPercent) : 0, status: row.status || 'Open',
    buyingBranch: row.buyingBranch || '', department: row.department || '', placeOfSupply: row.placeOfSupply || '',
    transportMode: row.transportMode || '', eWayBillNo: row.eWayBillNo || '', eWayBillDate: row.eWayBillDate || null,
    packingForwarding: row.packingForwarding || '', loadingUnloading: row.loadingUnloading || '',
    inspection: row.inspection || '', warranty: row.warranty || '', remarks: row.remarks || '',
    bankAccount: row.bankAccount || '', preparedBy: row.preparedBy || '', checkedBy: row.checkedBy || '',
    approvedBy: row.approvedBy || '',
    items: (row.items && row.items.length ? row.items : [{ ...emptyItem }]).map((i) => ({
      productCode: i.productCode || '', productName: i.productName || '', description: i.description || '',
      hsnCode: i.hsnCode || '', uom: i.uom || '',
      quantity: i.quantity != null ? Number(i.quantity) : 1,
      unitPrice: i.unitPrice != null ? Number(i.unitPrice) : 0,
      taxPercent: i.taxPercent != null ? Number(i.taxPercent) : 18,
    })),
  };
}

const PAGE_SIZE = 10;
const STATUS_FILTERS = ['All Status', ...PO_STATUS_OPTIONS];
const VALID_UPTO_FILTERS = ['All', 'Valid', 'Expired'];

const STATUS_COLORS = {
  Draft: 'default', Open: 'success', 'Partially Received': 'info', Received: 'success',
  'Partially Invoiced': 'warning', Closed: 'default', Cancelled: 'error',
};

export default function PurchaseOrder() {
  const notify = useNotify();
  const confirmDialog = useConfirm();
  const isMobile = useIsMobileListView();
  const itemScrollRef = useDragScroll();
  const { data: orders, isLoading } = purchaseOrderApi.useList();
  const { data: quotations } = purchaseQuotationApi.useList();
  const { data: suppliers } = supplierApi.useList();
  const { data: products } = productApi.useList();
  const { data: branches } = branchApi.useList();
  const { data: houseBanks } = houseBankApi.useList();
  const { data: taxCodes } = taxCodeApi.useList();
  const taxPercentOptions = useMemo(() => buildTaxPercentOptions(taxCodes), [taxCodes]);
  const { data: company } = useGetCompanyDetailsQuery();
  const [create, { isLoading: creating }] = purchaseOrderApi.useCreate();
  const [update, { isLoading: updating }] = purchaseOrderApi.useUpdate();
  const [remove] = purchaseOrderApi.useDelete();
  const [peekDocumentNumber] = usePeekDocumentNumberMutation();

  const supplierOptions = (suppliers || []).map((s) => ({ label: s.supplierName, value: s.supplierName }));
  const productCodeOptions = (products || []).map((p) => ({ label: p.productCode, value: p.productCode }));
  const productNameOptions = (products || []).map((p) => ({ label: p.productName, value: p.productCode }));
  const quotationOptions = (quotations || []).map((q) => ({ label: q.quotationNo, value: q.quotationNo }));
  const shipToOptions = useMemo(() => [
    ...(company?.companyName ? [{ label: `${company.companyName} - Head Office`, value: `${company.companyName} - Head Office` }] : []),
    ...(branches || []).map((b) => ({ label: b.branchName, value: b.branchName })),
  ], [company, branches]);
  const buyingBranchOptions = useMemo(() => (branches || []).map((b) => ({ label: b.branchName, value: b.branchName })), [branches]);
  const bankAccountOptions = useMemo(
    () => (houseBanks || []).map((b) => ({ label: `${b.bankName} - ${b.accountNumber}`, value: `${b.bankName} - ${b.accountNumber}` })),
    [houseBanks]
  );

  // View toggles between the order list and the full-page Create/Edit form —
  // same page, no dialog/popup, per the standard CRUD page template.
  const [view, setView] = useState('list');
  const [editingRow, setEditingRow] = useState(null);
  const [readOnly, setReadOnly] = useState(false);
  const [formKey, setFormKey] = useState(0);
  const [search, setSearch] = useState('');
  const [supplierFilter, setSupplierFilter] = useState(null);
  const [statusFilter, setStatusFilter] = useState('All Status');
  const [validUptoFilter, setValidUptoFilter] = useState('All');
  const [refFilter, setRefFilter] = useState('');
  const [dateFrom, setDateFrom] = useState(null);
  const [dateTo, setDateTo] = useState(null);
  const [dateAnchor, setDateAnchor] = useState(null);
  const [showFilters, setShowFilters] = useState(true);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(PAGE_SIZE);
  const [checkedIds, setCheckedIds] = useState([]);
  const [rowMenuAnchor, setRowMenuAnchor] = useState(null);
  const [rowMenuTarget, setRowMenuTarget] = useState(null);
  const pendingStatusRef = useRef('Open');

  const rows = orders || [];

  const baseTableRows = useMemo(() => {
    const q = '';
    const ref = refFilter.trim().toLowerCase();
    return rows.filter((r) => {
      const matchesSearch = !q || [r.poNo, r.supplier, r.referenceNo].some((v) => String(v || '').toLowerCase().includes(q));
      const matchesSupplier = !supplierFilter || r.supplier === supplierFilter.value;
      const matchesStatus = statusFilter === 'All Status' || r.status === statusFilter;
      const matchesRef = !ref || String(r.referenceNo || '').toLowerCase().includes(ref);
      const validUpto = r.validUpto ? dayjs(r.validUpto) : null;
      const isExpired = validUpto ? validUpto.isBefore(dayjs(), 'day') : false;
      const matchesValidUpto = validUptoFilter === 'All'
        || (validUptoFilter === 'Expired' && isExpired)
        || (validUptoFilter === 'Valid' && !isExpired);
      const pd = r.poDate ? dayjs(r.poDate) : null;
      const matchesFrom = !dateFrom || (pd && !pd.isBefore(dateFrom, 'day'));
      const matchesTo = !dateTo || (pd && !pd.isAfter(dateTo, 'day'));
      return matchesSearch && matchesSupplier && matchesStatus && matchesRef && matchesValidUpto && matchesFrom && matchesTo;
    });
  }, [rows, supplierFilter, statusFilter, refFilter, validUptoFilter, dateFrom, dateTo]);

  // Column definitions drive the global search, the sort icons and the filter
  // popover — see components/data-display/useTableFeatures.js.
  const tableColumns = useMemo(() => ([
    { field: 'id', headerName: 'Select', filter: false, searchable: false },
    { field: 'poNo', headerName: 'PO No.', filter: 'text' },
    { field: 'supplier', headerName: 'Supplier', filter: 'text' },
    { field: 'poDate', headerName: 'PO Date', filter: 'dateRange', sortValue: (row) => (row.poDate ? new Date(row.poDate).getTime() : null) },
    { field: 'deliveryDate', headerName: 'Delivery Date', filter: 'dateRange', sortValue: (row) => (row.deliveryDate ? new Date(row.deliveryDate).getTime() : null) },
    { field: 'amount', headerName: 'Amount (₹)', filter: 'numberRange', sortValue: (row) => (row.amount == null || row.amount === '' ? null : Number(row.amount)) },
    { field: 'status', headerName: 'Status', filter: 'select' },
    { field: 'referenceNo', headerName: 'Reference (Quotation No.)', filter: 'text' },
  ]), []);
  const table = useTableFeatures(baseTableRows, tableColumns, { onChange: setPage });
  const filteredRows = table.rows;

  const pagedRows = useMemo(
    () => filteredRows.slice(page * pageSize, page * pageSize + pageSize),
    [filteredRows, page, pageSize]
  );

  const openCreate = () => {
    setEditingRow(null);
    setReadOnly(false);
    setFormKey((k) => k + 1);
    setView('form');
  };

  const backToList = () => {
    setView('list');
    setEditingRow(null);
    setReadOnly(false);
  };

  const handleView = (row) => {
    setEditingRow(row);
    setReadOnly(true);
    setFormKey((k) => k + 1);
    setView('form');
  };

  const handleEdit = (row) => {
    setEditingRow(row);
    setReadOnly(false);
    setFormKey((k) => k + 1);
    setView('form');
    setRowMenuAnchor(null);
  };

  const handlePrint = (row) => {
    setRowMenuAnchor(null);
    handleView(row);
    setTimeout(() => window.print(), 300);
  };

  const handleDuplicate = async (row) => {
    const poNo = await peekNextDocumentNumber(peekDocumentNumber, 'PO', notify);
    const payload = { ...rowToFormValues(row), poNo, status: 'Open' };
    try {
      await create(payload).unwrap();
      notify.success('Purchase order duplicated as a new draft');
    } catch (err) {
      notify.error(err?.data?.message || 'Duplicate failed');
    }
  };

  const handleDelete = async (row) => {
    setRowMenuAnchor(null);
    const ok = await confirmDialog({
      title: 'Delete purchase order',
      message: `Are you sure you want to delete "${row.poNo}"? This cannot be undone.`,
      confirmLabel: 'Delete',
      severity: 'error',
    });
    if (!ok) return;
    try {
      await remove(row.id).unwrap();
      notify.success('Purchase order deleted');
    } catch (err) {
      notify.error(err?.data?.message || 'Delete failed');
    }
  };

  const removeSelected = async () => {
    const ok = await confirmDialog({
      title: 'Delete selected purchase orders',
      message: `Delete ${checkedIds.length} selected purchase order${checkedIds.length > 1 ? 's' : ''}? This cannot be undone.`,
      confirmLabel: 'Delete',
      severity: 'error',
    });
    if (!ok) return;
    try {
      await Promise.all(checkedIds.map((id) => remove(id).unwrap()));
      notify.success('Selected purchase orders deleted');
      setCheckedIds([]);
    } catch (err) {
      notify.error(err?.data?.message || 'Delete failed');
    }
  };

  const handleSubmit = async (values, formMethods) => {
    const payload = { ...values, status: pendingStatusRef.current };
    try {
      if (editingRow) {
        await update({ id: editingRow.id, ...payload }).unwrap();
        notify.success('Purchase order updated');
      } else {
        await create(payload).unwrap();
        notify.success('Purchase order saved');
      }
      backToList();
    } catch (err) {
      notify.error(applyServerErrors(err, formMethods.setError));
    }
  };

  const dateRangeLabel = dateFrom && dateTo
    ? `${dateFrom.format('DD/MM/YYYY')} - ${dateTo.format('DD/MM/YYYY')}`
    : 'Select date range';

  return (
    <Box>
      <EntityHeaderCard
        icon={<ShoppingBagOutlinedIcon />}
        title="Purchase Order"
        subtitle={view === 'form' ? 'Create a new purchase order.' : 'Manage and track all purchase orders.'}
        rightContent={<CompanyBadge />}
      />

      {view === 'form' ? (
        <AppForm
          key={formKey}
          schema={purchaseOrderSchema}
          defaultValues={editingRow ? rowToFormValues(editingRow) : getEmptyValues()}
          onSubmit={handleSubmit}
        >
          {(methods) => {
            const { control, watch, setValue } = methods;
            const { fields, append, remove: removeItem, replace: replaceItems } = useFieldArray({ control, name: 'items' });
            const watchedItems = watch('items') || [];
            const discountPercent = watch('discountPercent');
            // Inter-state supplies are taxed wholly as IGST. The server works
            // this out by comparing Place of Supply against the company's
            // registered state; passing the same flag here is what stops the
            // panel showing a CGST/SGST split for a record saved as IGST.
            const interState = isInterState(watch('placeOfSupply'), company?.state);
            const totals = computeTotals(watchedItems, discountPercent, interState);

            const allValues = watch();
            const printSupplierRecord = (suppliers || []).find((s) => s.supplierName === allValues.supplier);
            const printBranchRecord = (branches || []).find((b) => b.branchName === allValues.shipTo);
            const printBuyingBranchRecord = (branches || []).find((b) => b.branchName === allValues.buyingBranch);
            const printHouseBankRecord = (houseBanks || []).find((b) => `${b.bankName} - ${b.accountNumber}` === allValues.bankAccount);
            const printOrder = { ...allValues, status: editingRow?.status || 'Open' };

            const supplierValue = watch('supplier');
            const prevSupplier = useRef(editingRow ? editingRow.supplier : null);
            useEffect(() => {
              if (supplierValue !== prevSupplier.current) {
                const found = (suppliers || []).find((s) => s.supplierName === supplierValue);
                if (found) {
                  setValue('contactPerson', found.contactPerson || '', { shouldValidate: true });
                  setValue('phone', found.phone || '', { shouldValidate: true });
                  setValue('email', found.email || '', { shouldValidate: true });
                }
                prevSupplier.current = supplierValue;
              }
              // eslint-disable-next-line react-hooks/exhaustive-deps
            }, [supplierValue]);

            // Picking a Reference (Quotation No.) pulls every other field
            // across from that quotation onto the PO — supplier, contact
            // info, currency, payment terms, delivery/valid-upto dates, ship
            // to, terms & conditions, discount and items — so PO No. and PO
            // Date are the only fields the user actually fills in themselves,
            // the rest come straight from the quotation being converted.
            // Only fires on an actual user change, not on initial load of an
            // existing PO.
            const referenceValue = watch('referenceNo');
            const prevReference = useRef(editingRow ? editingRow.referenceNo : null);
            useEffect(() => {
              if (referenceValue !== prevReference.current) {
                const found = (quotations || []).find((q) => q.quotationNo === referenceValue);
                if (found) {
                  setValue('supplier', found.supplier || '', { shouldValidate: true });
                  // Also sync the supplier-effect's own "previous value" ref
                  // so it doesn't think the user just picked a new supplier
                  // and re-fire on the next render — that effect looks up
                  // Contact Person/Phone/Email fresh from Supplier Master,
                  // which is frequently blank there, and was overwriting the
                  // values just set from the quotation's snapshot below with
                  // '' immediately after (why Contact Person appeared to
                  // never "fetch": it was set correctly, then wiped a beat
                  // later by the other effect).
                  prevSupplier.current = found.supplier || '';
                  setValue('contactPerson', found.contactPerson || '', { shouldValidate: true });
                  setValue('phone', found.phone || '', { shouldValidate: true });
                  setValue('email', found.email || '', { shouldValidate: true });
                  setValue('currency', found.currency || 'INR', { shouldValidate: true });
                  setValue('paymentTerms', found.paymentTerms || '', { shouldValidate: true });
                  setValue('deliveryDate', found.deliveryDate || null, { shouldValidate: true });
                  setValue('shipTo', found.shipTo || '', { shouldValidate: true });
                  setValue('validUpto', found.validUpto || null, { shouldValidate: true });
                  setValue('termsConditions', found.termsConditions || '', { shouldValidate: true });
                  setValue('discountPercent', found.discountPercent != null ? Number(found.discountPercent) : 0, { shouldValidate: true });
                  if (found.items && found.items.length) {
                    // replaceItems(), not setValue('items', ...) — see the
                    // same fix on Delivery Challan's order-fetch effect.
                    // replace() (useFieldArray's own API) gives every row a
                    // fresh field id, remounting each ProductCell instead of
                    // reusing the old one — reused cells saw productCode
                    // change from '' to the quotation's value, read that as a
                    // user picking a product, and overwrote the tax rate/unit
                    // price just set here with the *product master's*
                    // defaults instead of the quotation's.
                    replaceItems(found.items.map((i) => ({
                      productCode: i.productCode || '', productName: i.productName || '', description: i.description || '',
                      hsnCode: i.hsnCode || '', uom: i.uom || '',
                      quantity: i.quantity != null ? Number(i.quantity) : 1,
                      unitPrice: i.unitPrice != null ? Number(i.unitPrice) : 0,
                      taxPercent: i.taxPercent != null ? Number(i.taxPercent) : 18,
                    })));
                  }
                } else if (!referenceValue && prevReference.current) {
                  // Reference quotation cleared via the Autocomplete's × button —
                  // undo the pre-fill above rather than leaving the stale
                  // quotation's values sitting in fields that now claim no
                  // quotation is referenced. Only fires when a quotation was
                  // actually applied before (prevReference.current truthy), so
                  // plain page load with an empty referenceNo doesn't blank out
                  // an existing PO's own saved values.
                  setValue('supplier', '', { shouldValidate: true });
                  prevSupplier.current = '';
                  setValue('contactPerson', '', { shouldValidate: true });
                  setValue('phone', '', { shouldValidate: true });
                  setValue('email', '', { shouldValidate: true });
                  setValue('currency', 'INR', { shouldValidate: true });
                  setValue('paymentTerms', '', { shouldValidate: true });
                  setValue('deliveryDate', null, { shouldValidate: true });
                  setValue('shipTo', '', { shouldValidate: true });
                  setValue('validUpto', null, { shouldValidate: true });
                  setValue('termsConditions', '', { shouldValidate: true });
                  setValue('discountPercent', 0, { shouldValidate: true });
                  replaceItems([{ ...emptyItem }]);
                }
                prevReference.current = referenceValue;
              }
              // eslint-disable-next-line react-hooks/exhaustive-deps
            }, [referenceValue]);

            const handleFile = (file) => {
              if (file) setValue('attachmentName', file.name, { shouldValidate: true });
            };

            return (
              // minWidth: 0 is required — fieldsets default to min-width: min-content,
              // which lets the wide item table blow out the page width on mobile.
              // The Back to List / Cancel buttons are kept outside the fieldset(s)
              // so they stay clickable in read-only (view) mode -- a native
              // <fieldset disabled> disables every descendant control, buttons
              // included.
              <>
              <PurchaseOrderPrintable
                order={printOrder}
                company={company}
                supplierRecord={printSupplierRecord}
                branchRecord={printBranchRecord}
                buyingBranchRecord={printBuyingBranchRecord}
                houseBankRecord={printHouseBankRecord}
              />
              <Card variant="outlined" sx={{ mb: 2 }}>
                <CardContent sx={{ p: { xs: 2, sm: 3 } }}>
                  <Stack direction="row" alignItems="center" justifyContent="space-between" flexWrap="wrap" gap={1.5} sx={{ mb: 2 }}>
                    <Typography variant="subtitle1" fontWeight={700}>
                      {readOnly ? 'Supplier & Document Details (View Only)' : 'Supplier & Document Details'}
                    </Typography>
                    <Button type="button" variant="outlined" color="inherit" startIcon={<ArrowBackIcon />} onClick={backToList}>
                      Back to List
                    </Button>
                  </Stack>

                  <fieldset disabled={readOnly} style={{ border: 0, padding: 0, margin: 0, minWidth: 0, width: '100%', display: 'block' }}>
                    <FormGrid columns={4} singleColumnOnMobile>
                      <DocumentNoField documentCode="PO" name="poNo" label="PO No. *" placeholder="Enter PO number" isCreate={!editingRow} />
                      <FormSelect name="branch" label="Branch *" placeholder="Select branch" options={buyingBranchOptions} />
                      <FormDatePicker name="poDate" label="PO Date *" />
                      <FormSelect name="referenceNo" label="Reference (Quotation No.)" placeholder="Select quotation" options={quotationOptions} />
                      <FormSelect name="supplier" label="Supplier *" placeholder="Select supplier" options={supplierOptions} />

                      <FormTextField name="contactPerson" label="Contact Person" placeholder="Auto-filled from supplier" disabled />
                      <FormTextField name="email" label="Email" placeholder="Auto-filled from supplier" disabled />
                      <FormTextField name="phone" label="Phone No." placeholder="Auto-filled from supplier" digitsOnly maxLength={10} disabled />
                      <FormSelect name="paymentTerms" label="Payment Terms" placeholder="Select payment terms" options={SUPPLIER_PAYMENT_TERMS_OPTIONS} />

                      <FormSelect name="currency" label="Currency *" options={CURRENCY_OPTIONS} disabled />
                      <FormDatePicker name="deliveryDate" label="Delivery Date *" disabled />
                      <FormSelect name="shipTo" label="Ship To" placeholder="Select ship-to location" options={shipToOptions} />
                      <FormDatePicker name="validUpto" label="Valid Upto" disabled />
                    </FormGrid>
                  </fieldset>
                </CardContent>
              </Card>

              <Card variant="outlined" sx={{ mb: 2 }}>
                <CardContent sx={{ p: { xs: 2, sm: 3 } }}>
                  <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 2 }}>Other Details</Typography>
                  <fieldset disabled={readOnly} style={{ border: 0, padding: 0, margin: 0, minWidth: 0, width: '100%', display: 'block' }}>
                    <FormGrid columns={4} singleColumnOnMobile>
                      <FormSelect name="buyingBranch" label="Buying Branch" placeholder="Select buying branch" options={buyingBranchOptions} />
                      <FormTextField name="department" label="Department" placeholder="e.g. Purchase" />
                      <FormTextField name="placeOfSupply" label="Place of Supply" placeholder="e.g. Tamil Nadu (33)" />
                      <FormSelect name="transportMode" label="Transport Mode" placeholder="Select transport mode" options={TRANSPORT_MODE_OPTIONS} />

                      <FormTextField name="eWayBillNo" label="E-Way Bill No." placeholder="Enter e-way bill number" />
                      <FormDatePicker name="eWayBillDate" label="E-Way Bill Date" />
                      <FormTextField name="packingForwarding" label="Packing & Forwarding" placeholder="e.g. Extra" />
                      <FormTextField name="loadingUnloading" label="Loading / Unloading" placeholder="e.g. Supplier Scope" />

                      <FormTextField name="inspection" label="Inspection" placeholder="e.g. At Our Works" />
                      <FormTextField name="warranty" label="Warranty" placeholder="e.g. 12 Months from the date of supply" />
                      <FormSelect name="bankAccount" label="Bank Account (for NEFT/RTGS)" placeholder="Select bank account" options={bankAccountOptions} />
                      <FormTextField name="remarks" label="Remarks" placeholder="Subject to terms & conditions mentioned below" />

                      <FormTextField name="preparedBy" label="Prepared By" placeholder="Name of preparer" />
                      <FormTextField name="checkedBy" label="Checked By" placeholder="Name of checker" />
                      <FormTextField name="approvedBy" label="Approved By" placeholder="Name of approver" />
                    </FormGrid>
                  </fieldset>
                </CardContent>
              </Card>

              <fieldset disabled={readOnly} style={{ border: 0, padding: 0, margin: 0, minWidth: 0, width: '100%', display: 'block' }}>
                <Card variant="outlined" sx={{ mb: 2 }}>
                  <CardContent sx={{ p: { xs: 2, sm: 3 } }}>
                    <Stack direction="row" alignItems="center" justifyContent="space-between" flexWrap="wrap" gap={1.5} sx={{ mb: 2 }}>
                      <Typography variant="subtitle1" fontWeight={700}>Item Details</Typography>
                      <Button type="button" variant="outlined" size="small" startIcon={<AddIcon />} onClick={() => append({ ...emptyItem })}>
                        Add Item
                      </Button>
                    </Stack>

                    {isMobile ? (
                      <Box>
                        {fields.map((field, index) => {
                          const qty = Number(watch(`items.${index}.quantity`)) || 0;
                          const price = Number(watch(`items.${index}.unitPrice`)) || 0;
                          const rowAmount = qty * price;
                          return (
                            <MobileItemCard
                              key={field.id}
                              index={index}
                              amount={rowAmount.toFixed(2)}
                              onRemove={() => removeItem(index)}
                              removeDisabled={fields.length <= 1}
                            >
                              <ProductCell index={index} methods={methods} options={productCodeOptions} products={products} label="Product Code *" placeholder="Select product code" />
                              <ProductCell index={index} methods={methods} options={productNameOptions} products={products} label="Product Name" placeholder="Select product name" />
                              <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', columnGap: 1.5, rowGap: 1.5 }}>
                                <FormTextField name={`items.${index}.hsnCode`} label="HSN/SAC" placeholder="HSN/SAC" digitsOnly maxLength={8} />
                                <FormTextField name={`items.${index}.uom`} label="Unit" placeholder="Unit" />
                                <FormTextField name={`items.${index}.quantity`} label="Quantity *" type="number" />
                                <FormTextField name={`items.${index}.unitPrice`} label="Unit Price (₹) *" type="number" />
                                <FormSelect name={`items.${index}.taxPercent`} label="Tax (%)" options={taxPercentOptions} />
                              </Box>
                            </MobileItemCard>
                          );
                        })}
                      </Box>
                    ) : (
                    <TableContainer ref={itemScrollRef} sx={{ overflowX: 'auto', WebkitOverflowScrolling: 'touch', cursor: 'grab', ...dragScrollbarSx }}>
                      <Table size="small" sx={{ '& tbody .MuiFormHelperText-root': { display: 'none' } }}>
                        <TableHead>
                          <TableRow>
                            <TableCell width={40}>#</TableCell>
                            <TableCell sx={{ minWidth: 220 }}>Product Code *</TableCell>
                            <TableCell sx={{ minWidth: 260 }}>Product Name</TableCell>
                            <TableCell sx={{ minWidth: 140 }}>HSN/SAC</TableCell>
                            <TableCell sx={{ minWidth: 110 }}>Unit</TableCell>
                            <TableCell sx={{ minWidth: 110 }}>Quantity *</TableCell>
                            <TableCell sx={{ minWidth: 150 }}>Unit Price (₹) *</TableCell>
                            <TableCell sx={{ minWidth: 120 }}>Tax (%)</TableCell>
                            <TableCell sx={{ minWidth: 110 }}>Amount (₹)</TableCell>
                            <TableCell width={48} />
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {fields.map((field, index) => {
                            const qty = Number(watch(`items.${index}.quantity`)) || 0;
                            const price = Number(watch(`items.${index}.unitPrice`)) || 0;
                            const rowAmount = qty * price;
                            return (
                              <TableRow key={field.id} sx={{ '& > td': { verticalAlign: 'middle' } }}>
                                <TableCell>{index + 1}</TableCell>
                                <TableCell>
                                  <ProductCell index={index} methods={methods} options={productCodeOptions} products={products} placeholder="Select product code" sx={{ minWidth: 200 }} />
                                </TableCell>
                                <TableCell>
                                  <ProductCell index={index} methods={methods} options={productNameOptions} products={products} placeholder="Select product name" sx={{ minWidth: 240 }} />
                                </TableCell>
                                <TableCell>
                                  <FormTextField name={`items.${index}.hsnCode`} label="" placeholder="HSN/SAC" digitsOnly maxLength={8} />
                                </TableCell>
                                <TableCell>
                                  <FormTextField name={`items.${index}.uom`} label="" placeholder="Unit" />
                                </TableCell>
                                <TableCell>
                                  <FormTextField name={`items.${index}.quantity`} label="" type="number" />
                                </TableCell>
                                <TableCell>
                                  <FormTextField name={`items.${index}.unitPrice`} label="" type="number" />
                                </TableCell>
                                <TableCell>
                                  <FormSelect name={`items.${index}.taxPercent`} label="" options={taxPercentOptions} disableClearable sx={{ minWidth: 96 }} />
                                </TableCell>
                                <TableCell sx={{ whiteSpace: 'nowrap' }}>{rowAmount.toFixed(2)}</TableCell>
                                <TableCell>
                                  <IconButton
                                    type="button"
                                    size="small"
                                    color="error"
                                    onClick={() => removeItem(index)}
                                    disabled={fields.length <= 1}
                                    aria-label="remove item"
                                  >
                                    <DeleteIcon fontSize="small" />
                                  </IconButton>
                                </TableCell>
                              </TableRow>
                            );
                          })}
                        </TableBody>
                      </Table>
                    </TableContainer>
                    )}
                  </CardContent>
                </Card>
              </fieldset>

              <Card variant="outlined">
                <CardContent sx={{ p: { xs: 2, sm: 3 } }}>
                  <fieldset disabled={readOnly} style={{ border: 0, padding: 0, margin: 0, minWidth: 0, width: '100%', display: 'block' }}>
                    <Grid container spacing={3}>
                      <Grid item xs={12} md={4}>
                        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1 }}>Terms & Conditions</Typography>
                        <FormTextField name="termsConditions" label="" placeholder="Enter terms and conditions" multiline rows={6} />
                      </Grid>

                      <Grid item xs={12} md={4}>
                        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1 }}>Attachments</Typography>
                        <Box
                          onDragOver={(e) => e.preventDefault()}
                          onDrop={(e) => { e.preventDefault(); handleFile(e.dataTransfer.files?.[0]); }}
                          sx={{
                            border: '1px dashed', borderColor: 'divider', borderRadius: 1.5,
                            p: 3, textAlign: 'center', color: 'text.secondary',
                          }}
                        >
                          <UploadFileIcon sx={{ mb: 1 }} />
                          <Typography variant="body2" sx={{ mb: 1 }}>Drag and drop files here</Typography>
                          <Typography variant="body2" sx={{ mb: 1 }}>or</Typography>
                          <Button component="label" variant="outlined" size="small">
                            Browse Files
                            <input type="file" hidden onChange={(e) => handleFile(e.target.files?.[0])} />
                          </Button>
                          <Typography variant="caption" display="block" sx={{ mt: 1 }}>Supported formats: PDF, JPG, PNG (Max. 5MB)</Typography>
                          {watch('attachmentName') && (
                            <Chip
                              sx={{ mt: 1.5 }}
                              size="small"
                              label={watch('attachmentName')}
                              onDelete={() => setValue('attachmentName', '')}
                            />
                          )}
                        </Box>
                      </Grid>

                      <Grid item xs={12} md={4}>
                        <DocumentTotalsPanel totals={totals} interState={interState} subtotalLabel="Subtotal" showRoundOff={false} />
                      </Grid>
                    </Grid>
                  </fieldset>

                    <Stack
                      direction={{ xs: 'column', sm: 'row' }}
                      spacing={1.5}
                      justifyContent={{ xs: 'stretch', sm: 'flex-end' }}
                      sx={{ mt: 3 }}
                    >
                      <Button fullWidth={isMobile} type="button" variant="outlined" color="inherit" startIcon={<CloseIcon />} onClick={backToList} disabled={creating || updating}>
                        Cancel
                      </Button>
                      <Button fullWidth={isMobile} type="button" variant="outlined" startIcon={<PrintOutlinedIcon />} onClick={() => window.print()}>
                        Print
                      </Button>
                      {!readOnly && (
                        <>
                          <FormSubmitButton
                            fullWidth={isMobile}
                            variant="outlined"
                            onClick={() => { pendingStatusRef.current = 'Draft'; }}
                            disabled={creating || updating}
                          >
                            Save as Draft
                          </FormSubmitButton>
                          <FormSubmitButton
                            fullWidth={isMobile}
                            onClick={() => { pendingStatusRef.current = 'Open'; }}
                            disabled={creating || updating}
                          >
                            {editingRow ? 'Update Purchase Order' : 'Save Purchase Order'}
                          </FormSubmitButton>
                        </>
                      )}
                    </Stack>
                  </CardContent>
                </Card>
              </>
            );
          }}
        </AppForm>
      ) : (
        <Card variant="outlined">
          <CardContent sx={{ p: 0 }}>
            <Stack
              direction={{ xs: 'column', md: 'row' }}
              alignItems={{ xs: 'stretch', md: 'center' }}
              justifyContent="space-between"
              flexWrap="wrap"
              gap={1.5}
              sx={{ px: { xs: 2, sm: 3 }, pt: 2.5, pb: 1.5 }}
            >
              <Typography variant="subtitle1" fontWeight={700}>Purchase Order List</Typography>
              <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.5} flexWrap="wrap" useFlexGap sx={{ width: { xs: '100%', md: 'auto' } }}>
                <TableSearchFilter table={table} placeholder="Search by PO no., supplier, reference..." showFilter={false} />
                <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.5} flexWrap="wrap" useFlexGap>
                  <Button
                    variant="outlined"
                    color="inherit"
                    startIcon={<FilterListIcon />}
                    onClick={() => setShowFilters((v) => !v)}
                    sx={{ width: { xs: '100%', sm: 'auto' }, height: 40, whiteSpace: 'nowrap' }}
                  >
                    Filter
                  </Button>
                  <CanAdd>
                    <Button
                      variant="contained"
                      startIcon={<AddIcon />}
                      endIcon={<ArrowDropDownIcon />}
                      onClick={openCreate}
                      sx={{ width: { xs: '100%', sm: 'auto' }, height: 40, whiteSpace: 'nowrap' }}
                    >
                      Create Purchase Order
                    </Button>
                  </CanAdd>
                </Stack>
              </Stack>
            </Stack>

            <Collapse in={showFilters} unmountOnExit>
            <Box sx={{ px: { xs: 2, sm: 3 }, pb: 2 }}>
              <FormGrid columns={5} singleColumnOnMobile>
                <FilterAutocomplete
                  label="Supplier"
                  allLabel="All Suppliers"
                  options={supplierOptions}
                  value={supplierFilter}
                  onChange={(v) => { setSupplierFilter(v); setPage(0); }}
                />
                <Autocomplete
                  size="small"
                  options={STATUS_FILTERS}
                  value={statusFilter}
                  onChange={(_e, v) => { setStatusFilter(v || 'All Status'); setPage(0); }}
                  disableClearable
                  renderInput={(params) => <TextField {...params} label="Status" InputLabelProps={{ shrink: true }} />}
                />
                <TextField
                  size="small"
                  fullWidth
                  label="Date Range"
                  value={dateRangeLabel}
                  onClick={(e) => setDateAnchor(e.currentTarget)}
                  InputProps={{
                    readOnly: true,
                    startAdornment: <InputAdornment position="start"><EventIcon fontSize="small" /></InputAdornment>,
                    endAdornment: (dateFrom || dateTo) ? (
                      <InputAdornment position="end">
                        <IconButton size="small" onClick={(e) => { e.stopPropagation(); setDateFrom(null); setDateTo(null); setPage(0); }}>
                          <CloseIcon fontSize="small" />
                        </IconButton>
                      </InputAdornment>
                    ) : null,
                  }}
                  InputLabelProps={{ shrink: true }}
                  sx={{ cursor: 'pointer' }}
                />
                <Autocomplete
                  size="small"
                  options={VALID_UPTO_FILTERS}
                  value={validUptoFilter}
                  onChange={(_e, v) => { setValidUptoFilter(v || 'All'); setPage(0); }}
                  disableClearable
                  renderInput={(params) => <TextField {...params} label="Valid Upto" InputLabelProps={{ shrink: true }} />}
                />
                <TextField
                  size="small"
                  fullWidth
                  label="Reference (Quotation No.)"
                  value={refFilter}
                  onChange={(e) => { setRefFilter(e.target.value); setPage(0); }}
                  placeholder="Enter quotation no."
                  InputLabelProps={{ shrink: true }}
                />
              </FormGrid>

              <Popover
                open={!!dateAnchor}
                anchorEl={dateAnchor}
                onClose={() => setDateAnchor(null)}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
              >
                <Stack direction="row" spacing={2} sx={{ p: 2 }}>
                  <DatePicker label="From" value={dateFrom} onChange={(v) => { setDateFrom(v); setPage(0); }} slotProps={{ textField: { size: 'small' } }} />
                  <DatePicker label="To" value={dateTo} onChange={(v) => { setDateTo(v); setPage(0); }} slotProps={{ textField: { size: 'small' } }} />
                </Stack>
              </Popover>
              <TableFilterPanel table={table} embedded open />
            </Box>
            </Collapse>

            {checkedIds.length > 0 && (
              <Box sx={{ px: { xs: 2, sm: 3 }, pb: 1.5 }}>
                <Button variant="outlined" color="error" size="small" startIcon={<DeleteIcon />} onClick={removeSelected}>
                  Delete Selected ({checkedIds.length})
                </Button>
              </Box>
            )}

            {isMobile ? (
              <Box sx={{ px: 2, pb: 1 }}>
                {!isLoading && pagedRows.map((row) => (
                  <MobileRecordCard
                    key={row.id}
                    title={row.poNo}
                    statusChip={<Chip size="small" label={row.status} color={STATUS_COLORS[row.status] || 'default'} variant="outlined" />}
                    fields={[
                      { label: 'Supplier', value: row.supplier || '—' },
                      { label: 'PO Date', value: row.poDate ? dayjs(row.poDate).format('DD/MM/YYYY') : '—' },
                      { label: 'Delivery Date', value: row.deliveryDate ? dayjs(row.deliveryDate).format('DD/MM/YYYY') : '—' },
                      { label: 'Amount', value: `₹${Number(row.amount).toFixed(2)}` },
                      { label: 'Reference (Quotation No.)', value: row.referenceNo || '—' },
                    ]}
                    onEdit={() => handleEdit(row)}
                    onDelete={() => handleDelete(row)}
                  />
                ))}
                {!isLoading && filteredRows.length === 0 && (
                  <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>No purchase orders found</Typography>
                )}
              </Box>
            ) : (
              <ScrollableTableContainer>
                <Table size="small" stickyHeader>
                  <TableHead>
                    <TableRow>
                      <SortableHeaderCell field="id" sort={table.sort} onSort={table.toggleSort} padding="checkbox">
                        <Checkbox
                          size="small"
                          checked={pagedRows.length > 0 && pagedRows.every((r) => checkedIds.includes(r.id))}
                          indeterminate={pagedRows.some((r) => checkedIds.includes(r.id)) && !pagedRows.every((r) => checkedIds.includes(r.id))}
                          onChange={(e) => {
                            const ids = pagedRows.map((r) => r.id);
                            setCheckedIds((prev) => e.target.checked
                              ? Array.from(new Set([...prev, ...ids]))
                              : prev.filter((c) => !ids.includes(c)));
                          }}
                        />
                      </SortableHeaderCell>
                      <TableCell width={40}>#</TableCell>
                      <SortableHeaderCell field="poNo" sort={table.sort} onSort={table.toggleSort}>PO No.</SortableHeaderCell>
                      <SortableHeaderCell field="supplier" sort={table.sort} onSort={table.toggleSort}>Supplier</SortableHeaderCell>
                      <SortableHeaderCell field="poDate" sort={table.sort} onSort={table.toggleSort}>PO Date</SortableHeaderCell>
                      <SortableHeaderCell field="deliveryDate" sort={table.sort} onSort={table.toggleSort}>Delivery Date</SortableHeaderCell>
                      <SortableHeaderCell field="amount" sort={table.sort} onSort={table.toggleSort}>Amount (₹)</SortableHeaderCell>
                      <SortableHeaderCell field="status" sort={table.sort} onSort={table.toggleSort}>Status</SortableHeaderCell>
                      <SortableHeaderCell field="referenceNo" sort={table.sort} onSort={table.toggleSort}>Reference (Quotation No.)</SortableHeaderCell>
                      <TableCell align="right">Action</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {!isLoading && pagedRows.map((row, i) => (
                      <TableRow key={row.id} hover>
                        <TableCell padding="checkbox">
                          <Checkbox
                            size="small"
                            checked={checkedIds.includes(row.id)}
                            onChange={() => setCheckedIds((prev) => prev.includes(row.id) ? prev.filter((c) => c !== row.id) : [...prev, row.id])}
                          />
                        </TableCell>
                        <TableCell>{page * pageSize + i + 1}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.poNo}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.supplier || '—'}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.poDate ? dayjs(row.poDate).format('DD/MM/YYYY') : '—'}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.deliveryDate ? dayjs(row.deliveryDate).format('DD/MM/YYYY') : '—'}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{Number(row.amount).toFixed(2)}</TableCell>
                        <TableCell>
                          <Chip size="small" label={row.status} color={STATUS_COLORS[row.status] || 'default'} variant="outlined" />
                        </TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.referenceNo || '-'}</TableCell>
                        <TableCell align="right">
                          <Stack direction="row" spacing={0.5} justifyContent="flex-end">
                            <Tooltip title="View">
                              <IconButton size="small" onClick={() => handleView(row)} aria-label="view">
                                <VisibilityOutlinedIcon fontSize="small" />
                              </IconButton>
                            </Tooltip>
                            <Tooltip title="Print">
                              <IconButton size="small" onClick={() => handlePrint(row)} aria-label="print">
                                <PrintOutlinedIcon fontSize="small" />
                              </IconButton>
                            </Tooltip>
                            <IconButton
                              size="small"
                              onClick={(e) => { setRowMenuAnchor(e.currentTarget); setRowMenuTarget(row); }}
                              aria-label="more actions"
                            >
                              <MoreVertIcon fontSize="small" />
                            </IconButton>
                          </Stack>
                        </TableCell>
                      </TableRow>
                    ))}
                    {!isLoading && filteredRows.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={10}>
                          <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>No purchase orders found</Typography>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </ScrollableTableContainer>
            )}

            <Menu anchorEl={rowMenuAnchor} open={!!rowMenuAnchor} onClose={() => setRowMenuAnchor(null)}>
              <CanEdit>
                <MenuItem onClick={() => handleEdit(rowMenuTarget)}>
                  <ListItemIcon><EditIcon fontSize="small" /></ListItemIcon>
                  <ListItemText>Edit</ListItemText>
                </MenuItem>
              </CanEdit>
              <MenuItem onClick={() => handleDuplicate(rowMenuTarget)}>
                <ListItemIcon><ContentCopyOutlinedIcon fontSize="small" /></ListItemIcon>
                <ListItemText>Duplicate</ListItemText>
              </MenuItem>
              <CanDelete>
                <MenuItem onClick={() => handleDelete(rowMenuTarget)}>
                  <ListItemIcon><DeleteIcon fontSize="small" color="error" /></ListItemIcon>
                  <ListItemText>Delete</ListItemText>
                </MenuItem>
              </CanDelete>
            </Menu>

            <EntityListPagination total={filteredRows.length} page={page} onChange={setPage} pageSize={pageSize} onPageSizeChange={(v) => { setPageSize(v); setPage(0); }} />
          </CardContent>
        </Card>
      )}
    </Box>
  );
}

// Isolated so the per-row product-select auto-fill effect only re-runs for
// the row whose product actually changed, not every row on every keystroke.
// Both the Product Code and Product Name columns are selects over the same
// underlying items.{index}.productCode field — Product Code lists codes,
// Product Name lists names, but selecting either one sets the same value, so
// whichever the user picks from, the row's product identity (and therefore
// the auto-filled HSN/UOM/price below) stays in sync.
function ProductCell({ index, methods, options, products, label = '', placeholder = 'Select product', sx }) {
  const { watch, setValue } = methods;
  const productCodeValue = watch(`items.${index}.productCode`);
  const prevValue = useRef(productCodeValue);

  useEffect(() => {
    if (productCodeValue !== prevValue.current) {
      const found = (products || []).find((p) => p.productCode === productCodeValue);
      if (found) {
        setValue(`items.${index}.productName`, found.productName, { shouldValidate: true });
        setValue(`items.${index}.description`, found.productName, { shouldValidate: true });
        setValue(`items.${index}.hsnCode`, found.hsnCode || '', { shouldValidate: true });
        setValue(`items.${index}.uom`, found.uom || '', { shouldValidate: true });
        setValue(`items.${index}.unitPrice`, found.costPrice != null ? Number(found.costPrice) : 0, { shouldValidate: true });
      }
      prevValue.current = productCodeValue;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [productCodeValue]);

  return <FormSelect name={`items.${index}.productCode`} label={label} placeholder={placeholder} options={options} sx={sx} />;
}
