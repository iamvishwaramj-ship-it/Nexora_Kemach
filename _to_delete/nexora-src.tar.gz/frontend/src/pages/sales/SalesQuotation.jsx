import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Box, Typography, Button, Card, CardContent, Stack, TextField, InputAdornment, Table,
  TableBody, TableCell, TableContainer, TableHead, TableRow, Chip, IconButton, Menu, MenuItem,
  ListItemIcon, ListItemText, Checkbox, Autocomplete, Popover, Grid, Tooltip,
  Collapse,
} from '@mui/material';
import { useFieldArray } from 'react-hook-form';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import dayjs from 'dayjs';
import RequestQuoteOutlinedIcon from '@mui/icons-material/RequestQuoteOutlined';
import AddIcon from '@mui/icons-material/Add';
import CloseIcon from '@mui/icons-material/Close';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import SearchIcon from '@mui/icons-material/Search';
import FilterListIcon from '@mui/icons-material/FilterList';
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import ContentCopyOutlinedIcon from '@mui/icons-material/ContentCopyOutlined';
import PrintOutlinedIcon from '@mui/icons-material/PrintOutlined';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import EditIcon from '@mui/icons-material/EditOutlined';
import DeleteIcon from '@mui/icons-material/DeleteOutline';
import EventIcon from '@mui/icons-material/Event';
import UploadFileIcon from '@mui/icons-material/UploadFile';
import AppForm, { FormGrid, FormSubmitButton } from '../../components/form/AppForm';
import FormTextField from '../../components/form/FormTextField';
import FormSelect from '../../components/form/FormSelect';
import FormDatePicker from '../../components/form/FormDatePicker';
import EntityHeaderCard from '../../components/common/EntityHeaderCard';
import CompanyBadge from '../../components/common/CompanyBadge';
import EntityListPagination from '../../components/data-display/EntityListPagination';
import FilterAutocomplete from '../../components/data-display/FilterAutocomplete';
import MobileRecordCard from '../../components/data-display/MobileRecordCard';
import MobileItemCard from '../../components/data-display/MobileItemCard';
import { useIsMobileListView } from '../../components/data-display/useIsMobileListView';
import useDragScroll from '../../components/data-display/useDragScroll';
import { useNotify } from '../../components/feedback/NotificationProvider';
import { applyServerErrors } from '../../lib/formErrors';
import { useConfirm } from '../../components/feedback/ConfirmationDialog';
import { salesQuotationSchema, QUOTATION_STATUS_OPTIONS } from '../../lib/validation/salesSchemas';
import { buildDocument, round2, isInterState } from '../../lib/documentTotals';
import DocumentTotalsPanel from '../../components/form/DocumentTotalsPanel';
import { CURRENCY_OPTIONS, PRICE_LIST_OPTIONS } from '../../lib/validation/partnerSchemas';
import { salesQuotationApi, customerApi, productApi, branchApi, taxCodeApi } from '../../features/resources';
import { buildTaxPercentOptions } from '../../lib/taxCodeOptions';
import { useGetCompanyDetailsQuery, usePeekDocumentNumberMutation } from '../../features/company/companyDetailsApi';
import DocumentNoField, { peekNextDocumentNumber } from '../../components/form/DocumentNoField';
import SalesQuotationPrintable from '../../components/print/SalesQuotationPrintable';
import useTableFeatures from '../../components/data-display/useTableFeatures';
import TableSearchFilter from '../../components/data-display/TableSearchFilter';
import SortableHeaderCell from '../../components/data-display/SortableHeaderCell';
import ScrollableTableContainer, { dragScrollbarSx } from '../../components/data-display/ScrollableTableContainer';


import { CanAdd, CanEdit, CanDelete } from '../../components/common/PermissionGate';
import TableFilterPanel from '../../components/data-display/TableFilterPanel';
const emptyItem = { productCode: '', productName: '', description: '', hsnCode: '', uom: '', quantity: 1, unitPrice: 0, discountPercent: 0, taxPercent: 18 };

function getEmptyValues() {
  return {
    quotationNo: '', branch: '', customer: '', contactPerson: '', phone: '', email: '',
    // Valid Till defaults to 10 days out from today, same rule as every
    // other "valid till" field (Purchase Quotation's Valid Upto included) —
    // computed here (inside the function, not a module-level constant) so
    // each new quotation gets it relative to the day it's actually created.
    quotationDate: new Date(), expiryDate: dayjs().add(10, 'day').toDate(), referenceNo: '',
    currency: 'INR', priceList: '', billingAddress: '', shippingAddress: '',
    termsConditions: '', notes: '', attachmentName: '', discountPercent: 0, status: 'Draft',
    items: [{ ...emptyItem }],
  };
}

// Totals come from the shared engine in lib/documentTotals.js, which the
// backend mirrors exactly — the figures shown here while editing are the
// figures that get saved. Each page used to carry its own copy of this
// arithmetic and the copies had drifted apart; this document in particular
// used to hard-code CGST and SGST at 9% each regardless of what the goods
// actually attract.
//
// `grandTotal` and `discount` are kept in the returned shape because the
// totals panel below reads those names.
// `interState` must be passed through rather than defaulted: the server
// decides CGST/SGST vs IGST by comparing this document's Place of Supply
// against the company's registered state, and for a long time no page passed
// the flag at all — so an inter-state document displayed a CGST/SGST split
// while the record it saved held IGST.
//
function computeTotals(items, discountPercent, interState = false) {
  const { totals } = buildDocument(items, discountPercent, {
    interState,
    roundOff: true,
  });
  return {
    ...totals,
    discount: round2(totals.subtotal - totals.taxableAmount),
    grandTotal: totals.amount,
  };
}

function rowToFormValues(row) {
  return {
    quotationNo: row.quotationNo, branch: row.branch || '', customer: row.customer || '', contactPerson: row.contactPerson || '',
    phone: row.phone || '', email: row.email || '',
    quotationDate: row.quotationDate, expiryDate: row.expiryDate, referenceNo: row.referenceNo || '',
    currency: row.currency || 'INR', priceList: row.priceList || '',
    billingAddress: row.billingAddress || '', shippingAddress: row.shippingAddress || '',
    termsConditions: row.termsConditions || '', notes: row.notes || '', attachmentName: row.attachmentName || '',
    discountPercent: row.discountPercent != null ? Number(row.discountPercent) : 0, status: row.status || 'Draft',
    items: (row.items && row.items.length ? row.items : [{ ...emptyItem }]).map((i) => ({
      productCode: i.productCode || '', productName: i.productName || '', description: i.description || '',
      hsnCode: i.hsnCode || '', uom: i.uom || '',
      quantity: i.quantity != null ? Number(i.quantity) : 1,
      unitPrice: i.unitPrice != null ? Number(i.unitPrice) : 0,
      discountPercent: i.discountPercent != null ? Number(i.discountPercent) : 0,
      taxPercent: i.taxPercent != null ? Number(i.taxPercent) : 18,
    })),
  };
}

const PAGE_SIZE = 10;
const STATUS_FILTERS = ['All Status', ...QUOTATION_STATUS_OPTIONS];

const STATUS_COLORS = { Draft: 'default', Sent: 'info', Pending: 'warning', Accepted: 'success', Rejected: 'error', Expired: 'error' };

export default function SalesQuotation() {
  const notify = useNotify();
  const confirmDialog = useConfirm();
  const isMobile = useIsMobileListView();
  const itemScrollRef = useDragScroll();
  const { data: quotations, isLoading } = salesQuotationApi.useList();
  const { data: customers } = customerApi.useList();
  const { data: products } = productApi.useList();
  const { data: branches } = branchApi.useList();
  const { data: taxCodes } = taxCodeApi.useList();
  const taxPercentOptions = useMemo(() => buildTaxPercentOptions(taxCodes), [taxCodes]);
  const { data: company } = useGetCompanyDetailsQuery();
  const [create, { isLoading: creating }] = salesQuotationApi.useCreate();
  const [update, { isLoading: updating }] = salesQuotationApi.useUpdate();
  const [remove] = salesQuotationApi.useDelete();
  const [peekDocumentNumber] = usePeekDocumentNumberMutation();

  const customerOptions = (customers || []).map((c) => ({ label: c.customerName, value: c.customerName }));
  const productCodeOptions = (products || []).map((p) => ({ label: p.productCode, value: p.productCode }));
  const productNameOptions = (products || []).map((p) => ({ label: p.productName, value: p.productCode }));
  const branchOptions = (branches || []).map((b) => ({ label: b.branchName, value: b.branchName }));

  // View toggles between the quotation list and the full-page Create/Edit
  // form — same page, no dialog/popup, per the standard CRUD page template.
  const [view, setView] = useState('list');
  const [editingRow, setEditingRow] = useState(null);
  const [readOnly, setReadOnly] = useState(false);
  const [formKey, setFormKey] = useState(0);
  const [search, setSearch] = useState('');
  const [customerFilter, setCustomerFilter] = useState(null);
  const [statusFilter, setStatusFilter] = useState('All Status');
  const [dateFrom, setDateFrom] = useState(null);
  const [dateTo, setDateTo] = useState(null);
  const [dateAnchor, setDateAnchor] = useState(null);
  const [showFilters, setShowFilters] = useState(true);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(PAGE_SIZE);
  const [checkedIds, setCheckedIds] = useState([]);
  const [rowMenuAnchor, setRowMenuAnchor] = useState(null);
  const [rowMenuTarget, setRowMenuTarget] = useState(null);
  const pendingStatusRef = useRef('Draft');

  const rows = quotations || [];

  const baseTableRows = useMemo(() => {
    const q = '';
    return rows.filter((r) => {
      const matchesSearch = !q || [r.quotationNo, r.customer].some((v) => String(v || '').toLowerCase().includes(q));
      const matchesCustomer = !customerFilter || r.customer === customerFilter.value;
      const matchesStatus = statusFilter === 'All Status' || r.status === statusFilter;
      const qd = r.quotationDate ? dayjs(r.quotationDate) : null;
      const matchesFrom = !dateFrom || (qd && !qd.isBefore(dateFrom, 'day'));
      const matchesTo = !dateTo || (qd && !qd.isAfter(dateTo, 'day'));
      return matchesSearch && matchesCustomer && matchesStatus && matchesFrom && matchesTo;
    });
  }, [rows, customerFilter, statusFilter, dateFrom, dateTo]);

  // Column definitions drive the global search, the sort icons and the filter
  // popover — see components/data-display/useTableFeatures.js.
  const tableColumns = useMemo(() => ([
    { field: 'id', headerName: 'Select', filter: false, searchable: false },
    { field: 'quotationNo', headerName: 'Quotation No.', filter: 'text' },
    { field: 'customer', headerName: 'Customer', filter: 'text' },
    { field: 'quotationDate', headerName: 'Quotation Date', filter: 'dateRange', sortValue: (row) => (row.quotationDate ? new Date(row.quotationDate).getTime() : null) },
    { field: 'expiryDate', headerName: 'Valid Till', filter: 'dateRange', sortValue: (row) => (row.expiryDate ? new Date(row.expiryDate).getTime() : null) },
    { field: 'amount', headerName: 'Amount (₹)', filter: 'numberRange', sortValue: (row) => (row.amount == null || row.amount === '' ? null : Number(row.amount)) },
    { field: 'status', headerName: 'Status', filter: 'select' },
  ]), []);
  const table = useTableFeatures(baseTableRows, tableColumns, { onChange: setPage });
  const filteredRows = table.rows;

  const pagedRows = useMemo(
    () => filteredRows.slice(page * pageSize, page * pageSize + pageSize),
    [filteredRows, page, pageSize]
  );

  const openCreate = () => {
    setEditingRow(null);
    setReadOnly(false);
    setFormKey((k) => k + 1);
    setView('form');
  };

  const backToList = () => {
    setView('list');
    setEditingRow(null);
    setReadOnly(false);
  };

  const handleView = (row) => {
    setEditingRow(row);
    setReadOnly(true);
    setFormKey((k) => k + 1);
    setView('form');
  };

  const handleEdit = (row) => {
    setEditingRow(row);
    setReadOnly(false);
    setFormKey((k) => k + 1);
    setView('form');
    setRowMenuAnchor(null);
  };

  const handlePrint = (row) => {
    setRowMenuAnchor(null);
    handleView(row);
    setTimeout(() => window.print(), 300);
  };

  const handleDuplicate = async (row) => {
    const quotationNo = await peekNextDocumentNumber(peekDocumentNumber, 'SQ', notify);
    const payload = { ...rowToFormValues(row), quotationNo, status: 'Draft' };
    try {
      await create(payload).unwrap();
      notify.success('Quotation duplicated as a new draft');
    } catch (err) {
      notify.error(err?.data?.message || 'Duplicate failed');
    }
  };

  const handleDelete = async (row) => {
    setRowMenuAnchor(null);
    const ok = await confirmDialog({
      title: 'Delete quotation',
      message: `Are you sure you want to delete "${row.quotationNo}"? This cannot be undone.`,
      confirmLabel: 'Delete',
      severity: 'error',
    });
    if (!ok) return;
    try {
      await remove(row.id).unwrap();
      notify.success('Quotation deleted');
    } catch (err) {
      notify.error(err?.data?.message || 'Delete failed');
    }
  };

  const removeSelected = async () => {
    const ok = await confirmDialog({
      title: 'Delete selected quotations',
      message: `Delete ${checkedIds.length} selected quotation${checkedIds.length > 1 ? 's' : ''}? This cannot be undone.`,
      confirmLabel: 'Delete',
      severity: 'error',
    });
    if (!ok) return;
    try {
      await Promise.all(checkedIds.map((id) => remove(id).unwrap()));
      notify.success('Selected quotations deleted');
      setCheckedIds([]);
    } catch (err) {
      notify.error(err?.data?.message || 'Delete failed');
    }
  };

  const handleSubmit = async (values, formMethods) => {
    const payload = { ...values, status: pendingStatusRef.current };
    try {
      if (editingRow) {
        await update({ id: editingRow.id, ...payload }).unwrap();
        notify.success('Quotation updated');
      } else {
        await create(payload).unwrap();
        notify.success('Quotation saved');
      }
      backToList();
    } catch (err) {
      notify.error(applyServerErrors(err, formMethods.setError));
    }
  };

  const dateRangeLabel = dateFrom && dateTo
    ? `${dateFrom.format('DD/MM/YYYY')} - ${dateTo.format('DD/MM/YYYY')}`
    : 'Select date range';

  return (
    <Box>
      <EntityHeaderCard
        icon={<RequestQuoteOutlinedIcon />}
        title="Sales Quotation"
        subtitle={view === 'form' ? 'Create a new sales quotation.' : 'Manage and track all sales quotations.'}
        rightContent={<CompanyBadge />}
      />

      {view === 'form' ? (
        <AppForm
          key={formKey}
          schema={salesQuotationSchema}
          defaultValues={editingRow ? rowToFormValues(editingRow) : getEmptyValues()}
          onSubmit={handleSubmit}
        >
          {(methods) => {
            const { control, watch, setValue } = methods;
            const { fields, append, remove: removeItem } = useFieldArray({ control, name: 'items' });
            const watchedItems = watch('items') || [];
            // The Discount % box in the totals panel is a mirror of the item
            // row's Discount %, not a second deduction — the line's discount
            // is already baked into its Amount (and therefore the Subtotal)
            // above, so computeTotals is always called with 0 here to avoid
            // subtracting the same discount twice. Which row "wins" when
            // there's more than one item is whichever the user edited most
            // recently (see the sync effect below).
            // Discount % in the totals panel is a header-level discount taken
            // off the sum of the (already line-discounted) item amounts —
            // exactly what the server does with the `discountPercent` it
            // receives.
            //
            // It used to be a read-only mirror of whichever item row was
            // edited last, and computeTotals was called with a hard-coded 0
            // so the mirrored figure wouldn't deduct the line discount twice
            // on screen. But the mirrored figure was still posted, and the
            // server had no way to know it was only meant for display: it
            // applied that percentage on top of line amounts that already had
            // it baked in, saving a total below the one the user approved.
            const discountPercent = watch('discountPercent');
            // Inter-state supplies are taxed wholly as IGST. The server works
            // this out by comparing Place of Supply against the company's
            // registered state; passing the same flag here is what stops the
            // panel showing a CGST/SGST split for a record saved as IGST.
            const interState = isInterState(watch('placeOfSupply'), company?.state);
            const totals = computeTotals(watchedItems, discountPercent, interState);

            const allValues = watch();
            const printCustomerRecord = (customers || []).find((c) => c.customerName === allValues.customer);
            const printOrder = { ...allValues, status: editingRow?.status || 'Draft' };

            const customerValue = watch('customer');
            const prevCustomer = useRef(editingRow ? editingRow.customer : null);
            useEffect(() => {
              if (customerValue !== prevCustomer.current) {
                const found = (customers || []).find((c) => c.customerName === customerValue);
                if (found) {
                  setValue('contactPerson', found.salesPerson || '', { shouldValidate: true });
                  setValue('phone', found.phone || '', { shouldValidate: true });
                  setValue('email', found.email || '', { shouldValidate: true });
                  setValue('billingAddress', found.billingAddress || '', { shouldValidate: true });
                  setValue('shippingAddress', found.shippingAddress || '', { shouldValidate: true });
                  setValue('priceList', found.priceList || '', { shouldValidate: true });
                  setValue('discountPercent', found.discountPercent != null ? Number(found.discountPercent) : 0, { shouldValidate: true });
                }
                prevCustomer.current = customerValue;
              }
              // eslint-disable-next-line react-hooks/exhaustive-deps
            }, [customerValue]);

            const handleFile = (file) => {
              if (file) setValue('attachmentName', file.name, { shouldValidate: true });
            };

            return (
              // minWidth: 0 is required — fieldsets default to min-width: min-content,
              // which lets the wide item table blow out the page width on mobile.
              // The Back to List / Cancel buttons are kept outside the fieldset(s)
              // so they stay clickable in read-only (view) mode -- a native
              // <fieldset disabled> disables every descendant control, buttons
              // included.
              <>
              <SalesQuotationPrintable
                order={printOrder}
                company={company}
                customerRecord={printCustomerRecord}
              />
              <Card variant="outlined" sx={{ mb: 2 }}>
                <CardContent sx={{ p: { xs: 2, sm: 3 } }}>
                  <Stack direction="row" alignItems="center" justifyContent="space-between" flexWrap="wrap" gap={1.5} sx={{ mb: 2 }}>
                    <Typography variant="subtitle1" fontWeight={700}>
                      {readOnly ? 'Customer & Document Details (View Only)' : 'Customer & Document Details'}
                    </Typography>
                    <Button type="button" variant="outlined" color="inherit" startIcon={<ArrowBackIcon />} onClick={backToList}>
                      Back to List
                    </Button>
                  </Stack>

                  <fieldset disabled={readOnly} style={{ border: 0, padding: 0, margin: 0, minWidth: 0, width: '100%', display: 'block' }}>
                    <FormGrid columns={4}>
                      <DocumentNoField documentCode="SQ" name="quotationNo" label="Quotation No. *" placeholder="Enter quotation number" isCreate={!editingRow} />
                      <FormSelect name="branch" label="Branch *" placeholder="Select branch" options={branchOptions} />

                      <FormDatePicker name="quotationDate" label="Quotation Date *" />
                      <FormSelect name="customer" label="Customer *" placeholder="Select customer" options={customerOptions} />
                      <FormTextField name="contactPerson" label="Contact Person" placeholder="Auto-filled from customer" />
                      <FormTextField name="email" label="Email" placeholder="Auto-filled from customer" />
                      <FormTextField name="phone" label="Phone No." placeholder="Auto-filled from customer" digitsOnly maxLength={10} />

                      <FormTextField name="shippingAddress" label="Shipping Address" placeholder="Auto-filled from customer" />
                      <FormTextField name="billingAddress" label="Address" placeholder="Auto-filled from customer" />
                      <FormSelect name="currency" label="Currency *" options={CURRENCY_OPTIONS} />
                      <FormDatePicker name="expiryDate" label="Valid Till *" />
                      <FormSelect name="priceList" label="Price List" placeholder="Select price list" options={PRICE_LIST_OPTIONS} />
                      <FormTextField name="referenceNo" label="Reference No." placeholder="Enter reference number" />
                    </FormGrid>
                  </fieldset>
                </CardContent>
              </Card>

              <fieldset disabled={readOnly} style={{ border: 0, padding: 0, margin: 0, minWidth: 0, width: '100%', display: 'block' }}>
                <Card variant="outlined" sx={{ mb: 2 }}>
                  <CardContent sx={{ p: { xs: 2, sm: 3 } }}>
                    <Stack direction="row" alignItems="center" justifyContent="space-between" flexWrap="wrap" gap={1.5} sx={{ mb: 2 }}>
                      <Typography variant="subtitle1" fontWeight={700}>Item Details</Typography>
                      <Button type="button" variant="outlined" size="small" startIcon={<AddIcon />} onClick={() => append({ ...emptyItem })}>
                        Add Item
                      </Button>
                    </Stack>

                    {isMobile ? (
                      <Box>
                        {fields.map((field, index) => {
                          const qty = Number(watch(`items.${index}.quantity`)) || 0;
                          const price = Number(watch(`items.${index}.unitPrice`)) || 0;
                          const disc = Number(watch(`items.${index}.discountPercent`)) || 0;
                          const gross = qty * price;
                          const rowAmount = gross - gross * (disc / 100);
                          return (
                            <MobileItemCard
                              key={field.id}
                              index={index}
                              amount={rowAmount.toFixed(2)}
                              onRemove={() => removeItem(index)}
                              removeDisabled={fields.length <= 1}
                            >
                              <ProductCell index={index} methods={methods} options={productCodeOptions} products={products} label="Product Code *" placeholder="Select product code" />
                              <ProductCell index={index} methods={methods} options={productNameOptions} products={products} label="Product Name" placeholder="Select product name" />
                              <FormTextField name={`items.${index}.description`} label="Description" placeholder="Description" />
                              <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', columnGap: 1.5, rowGap: 1.5 }}>
                                <FormTextField name={`items.${index}.hsnCode`} label="HSN/SAC" placeholder="HSN/SAC" digitsOnly maxLength={8} />
                                <FormTextField name={`items.${index}.uom`} label="Unit" placeholder="Unit" />
                                <FormTextField name={`items.${index}.quantity`} label="Quantity *" type="number" />
                                <FormTextField name={`items.${index}.unitPrice`} label="Rate (₹) *" type="number" />
                                <FormTextField name={`items.${index}.discountPercent`} label="Discount (%)" type="number" />
                                <FormSelect name={`items.${index}.taxPercent`} label="Tax (%)" options={taxPercentOptions} />
                              </Box>
                            </MobileItemCard>
                          );
                        })}
                      </Box>
                    ) : (
                    <TableContainer ref={itemScrollRef} sx={{ overflowX: 'auto', WebkitOverflowScrolling: 'touch', cursor: 'grab', ...dragScrollbarSx }}>
                      <Table size="small" sx={{ '& tbody .MuiFormHelperText-root': { display: 'none' } }}>
                        <TableHead>
                          <TableRow>
                            <TableCell width={40}>#</TableCell>
                            <TableCell sx={{ minWidth: 200 }}>Product Code *</TableCell>
                            <TableCell sx={{ minWidth: 220 }}>Product Name</TableCell>
                            <TableCell sx={{ minWidth: 140 }}>HSN/SAC</TableCell>
                            <TableCell sx={{ minWidth: 110 }}>Unit</TableCell>
                            <TableCell sx={{ minWidth: 110 }}>Quantity *</TableCell>
                            <TableCell sx={{ minWidth: 150 }}>Rate (₹) *</TableCell>
                            <TableCell sx={{ minWidth: 100 }}>Discount (%)</TableCell>
                            <TableCell sx={{ minWidth: 120 }}>Tax (%)</TableCell>
                            <TableCell sx={{ minWidth: 110 }}>Amount (₹)</TableCell>
                            <TableCell width={48} />
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {fields.map((field, index) => {
                            const qty = Number(watch(`items.${index}.quantity`)) || 0;
                            const price = Number(watch(`items.${index}.unitPrice`)) || 0;
                            const disc = Number(watch(`items.${index}.discountPercent`)) || 0;
                            const gross = qty * price;
                            const rowAmount = gross - gross * (disc / 100);
                            return (
                              <TableRow key={field.id} sx={{ '& > td': { verticalAlign: 'middle' } }}>
                                <TableCell>{index + 1}</TableCell>
                                <TableCell>
                                  <ProductCell index={index} methods={methods} options={productCodeOptions} products={products} placeholder="Select product code" sx={{ minWidth: 200 }} />
                                </TableCell>
                                <TableCell>
                                  <ProductCell index={index} methods={methods} options={productNameOptions} products={products} placeholder="Select product name" sx={{ minWidth: 240 }} />
                                </TableCell>
                                <TableCell>
                                  <FormTextField name={`items.${index}.hsnCode`} label="" placeholder="HSN/SAC" digitsOnly maxLength={8} />
                                </TableCell>
                                <TableCell>
                                  <FormTextField name={`items.${index}.uom`} label="" placeholder="Unit" />
                                </TableCell>
                                <TableCell>
                                  <FormTextField name={`items.${index}.quantity`} label="" type="number" />
                                </TableCell>
                                <TableCell>
                                  <FormTextField name={`items.${index}.unitPrice`} label="" type="number" />
                                </TableCell>
                                <TableCell>
                                  <FormTextField name={`items.${index}.discountPercent`} label="" type="number" />
                                </TableCell>
                                <TableCell>
                                  <FormSelect name={`items.${index}.taxPercent`} label="" options={taxPercentOptions} />
                                </TableCell>
                                <TableCell sx={{ whiteSpace: 'nowrap' }}>{rowAmount.toFixed(2)}</TableCell>
                                <TableCell>
                                  <IconButton
                                    type="button"
                                    size="small"
                                    color="error"
                                    onClick={() => removeItem(index)}
                                    disabled={fields.length <= 1}
                                    aria-label="remove item"
                                  >
                                    <DeleteIcon fontSize="small" />
                                  </IconButton>
                                </TableCell>
                              </TableRow>
                            );
                          })}
                        </TableBody>
                      </Table>
                    </TableContainer>
                    )}
                  </CardContent>
                </Card>
              </fieldset>

              <Card variant="outlined">
                <CardContent sx={{ p: { xs: 2, sm: 3 } }}>
                  <fieldset disabled={readOnly} style={{ border: 0, padding: 0, margin: 0, minWidth: 0, width: '100%', display: 'block' }}>
                    <Grid container spacing={3}>
                      <Grid item xs={12} md={4}>
                        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1 }}>Terms & Conditions / Notes</Typography>
                        <FormTextField name="termsConditions" label="" placeholder="Enter terms and conditions" multiline rows={3} />
                        <Box sx={{ mt: 1.5 }}>
                          <FormTextField name="notes" label="" placeholder="Enter notes" multiline rows={2} />
                        </Box>
                      </Grid>

                      <Grid item xs={12} md={4}>
                        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1 }}>Attachments</Typography>
                        <Box
                          onDragOver={(e) => e.preventDefault()}
                          onDrop={(e) => { e.preventDefault(); handleFile(e.dataTransfer.files?.[0]); }}
                          sx={{
                            border: '1px dashed', borderColor: 'divider', borderRadius: 1.5,
                            p: 3, textAlign: 'center', color: 'text.secondary',
                          }}
                        >
                          <UploadFileIcon sx={{ mb: 1 }} />
                          <Typography variant="body2" sx={{ mb: 1 }}>Drag and drop files here</Typography>
                          <Typography variant="body2" sx={{ mb: 1 }}>or</Typography>
                          <Button component="label" variant="outlined" size="small">
                            Browse Files
                            <input type="file" hidden onChange={(e) => handleFile(e.target.files?.[0])} />
                          </Button>
                          <Typography variant="caption" display="block" sx={{ mt: 1 }}>Supported formats: PDF, JPG, PNG (Max. 5MB)</Typography>
                          {watch('attachmentName') && (
                            <Chip
                              sx={{ mt: 1.5 }}
                              size="small"
                              label={watch('attachmentName')}
                              onDelete={() => setValue('attachmentName', '')}
                            />
                          )}
                        </Box>
                      </Grid>

                      <Grid item xs={12} md={4}>
                        <DocumentTotalsPanel totals={totals} interState={interState} />
                      </Grid>
                    </Grid>
                  </fieldset>

                    <Stack
                      direction={{ xs: 'column', sm: 'row' }}
                      spacing={1.5}
                      justifyContent={{ xs: 'stretch', sm: 'flex-end' }}
                      sx={{ mt: 3 }}
                    >
                      <Button fullWidth={isMobile} type="button" variant="outlined" color="inherit" startIcon={<CloseIcon />} onClick={backToList} disabled={creating || updating}>
                        Cancel
                      </Button>
                      <Button fullWidth={isMobile} type="button" variant="outlined" startIcon={<PrintOutlinedIcon />} onClick={() => window.print()}>
                        Print
                      </Button>
                      {!readOnly && (
                        <>
                          <FormSubmitButton
                            fullWidth={isMobile}
                            variant="outlined"
                            onClick={() => { pendingStatusRef.current = 'Draft'; }}
                            disabled={creating || updating}
                          >
                            Save as Draft
                          </FormSubmitButton>
                          <FormSubmitButton
                            fullWidth={isMobile}
                            onClick={() => { pendingStatusRef.current = 'Sent'; }}
                            disabled={creating || updating}
                          >
                            {editingRow ? 'Update Quotation' : 'Save & Send Quotation'}
                          </FormSubmitButton>
                        </>
                      )}
                    </Stack>
                  </CardContent>
                </Card>
              </>
            );
          }}
        </AppForm>
      ) : (
        <Card variant="outlined">
          <CardContent sx={{ p: 0 }}>
            <Stack
              direction={{ xs: 'column', sm: 'row' }}
              alignItems={{ xs: 'stretch', sm: 'center' }}
              justifyContent="space-between"
              flexWrap="wrap"
              gap={1.5}
              sx={{ px: { xs: 2, sm: 3 }, pt: 2.5, pb: 1.5 }}
            >
              <Typography variant="subtitle1" fontWeight={700}>Quotation List</Typography>
              <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.5} flexWrap="wrap" useFlexGap sx={{ width: { xs: '100%', sm: 'auto' } }}>
                <TableSearchFilter table={table} placeholder="Search by quotation no, customer..." showFilter={false} />
                <Stack direction="row" spacing={1.5}>
                  <Button size="small" variant="outlined" color="inherit" startIcon={<FilterListIcon />} onClick={() => setShowFilters((v) => !v)} sx={{ whiteSpace: 'nowrap', flexShrink: 0 }}>
                    Filter
                  </Button>
                  <CanAdd>
                    <Button size="small" variant="contained" startIcon={<AddIcon />} onClick={openCreate} sx={{ whiteSpace: 'nowrap', flexShrink: 0 }}>
                      Create Quotation
                    </Button>
                  </CanAdd>
                </Stack>
              </Stack>
            </Stack>

            <Collapse in={showFilters} unmountOnExit>
            <Box sx={{ px: { xs: 2, sm: 3 }, pb: 2 }}>
              <FormGrid columns={3}>
                <FilterAutocomplete
                  label="Customer"
                  allLabel="All Customers"
                  options={customerOptions}
                  value={customerFilter}
                  onChange={(v) => { setCustomerFilter(v); setPage(0); }}
                />
                <Autocomplete
                  size="small"
                  options={STATUS_FILTERS}
                  value={statusFilter}
                  onChange={(_e, v) => { setStatusFilter(v || 'All Status'); setPage(0); }}
                  disableClearable
                  renderInput={(params) => <TextField {...params} label="Status" InputLabelProps={{ shrink: true }} />}
                />
                <TextField
                  size="small"
                  fullWidth
                  label="Date Range"
                  value={dateRangeLabel}
                  onClick={(e) => setDateAnchor(e.currentTarget)}
                  InputProps={{
                    readOnly: true,
                    startAdornment: <InputAdornment position="start"><EventIcon fontSize="small" /></InputAdornment>,
                    endAdornment: (dateFrom || dateTo) ? (
                      <InputAdornment position="end">
                        <IconButton size="small" onClick={(e) => { e.stopPropagation(); setDateFrom(null); setDateTo(null); setPage(0); }}>
                          <CloseIcon fontSize="small" />
                        </IconButton>
                      </InputAdornment>
                    ) : null,
                  }}
                  InputLabelProps={{ shrink: true }}
                  sx={{ cursor: 'pointer' }}
                />
              </FormGrid>

              <Popover
                open={!!dateAnchor}
                anchorEl={dateAnchor}
                onClose={() => setDateAnchor(null)}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
              >
                <Stack direction="row" spacing={2} sx={{ p: 2 }}>
                  <DatePicker label="From" value={dateFrom} onChange={(v) => { setDateFrom(v); setPage(0); }} slotProps={{ textField: { size: 'small' } }} />
                  <DatePicker label="To" value={dateTo} onChange={(v) => { setDateTo(v); setPage(0); }} slotProps={{ textField: { size: 'small' } }} />
                </Stack>
              </Popover>
              <TableFilterPanel table={table} embedded open />
            </Box>
            </Collapse>

            {checkedIds.length > 0 && (
              <Box sx={{ px: { xs: 2, sm: 3 }, pb: 1.5 }}>
                <Button variant="outlined" color="error" size="small" startIcon={<DeleteIcon />} onClick={removeSelected}>
                  Delete Selected ({checkedIds.length})
                </Button>
              </Box>
            )}

            {isMobile ? (
              <Box sx={{ px: 2, pb: 1 }}>
                {!isLoading && pagedRows.map((row) => (
                  <MobileRecordCard
                    key={row.id}
                    title={row.quotationNo}
                    statusChip={<Chip size="small" label={row.status} color={STATUS_COLORS[row.status] || 'default'} variant="outlined" />}
                    fields={[
                      { label: 'Customer', value: row.customer || '—' },
                      { label: 'Quotation Date', value: row.quotationDate ? dayjs(row.quotationDate).format('DD/MM/YYYY') : '—' },
                      { label: 'Valid Till', value: row.expiryDate ? dayjs(row.expiryDate).format('DD/MM/YYYY') : '—' },
                      { label: 'Amount', value: `₹${Number(row.amount).toFixed(2)}` },
                    ]}
                    onEdit={() => handleEdit(row)}
                    onDelete={() => handleDelete(row)}
                  />
                ))}
                {!isLoading && filteredRows.length === 0 && (
                  <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>No quotations found</Typography>
                )}
              </Box>
            ) : (
              <ScrollableTableContainer>
                <Table size="small" stickyHeader>
                  <TableHead>
                    <TableRow>
                      <SortableHeaderCell field="id" sort={table.sort} onSort={table.toggleSort} padding="checkbox">
                        <Checkbox
                          size="small"
                          checked={pagedRows.length > 0 && pagedRows.every((r) => checkedIds.includes(r.id))}
                          indeterminate={pagedRows.some((r) => checkedIds.includes(r.id)) && !pagedRows.every((r) => checkedIds.includes(r.id))}
                          onChange={(e) => {
                            const ids = pagedRows.map((r) => r.id);
                            setCheckedIds((prev) => e.target.checked
                              ? Array.from(new Set([...prev, ...ids]))
                              : prev.filter((c) => !ids.includes(c)));
                          }}
                        />
                      </SortableHeaderCell>
                      <TableCell width={40}>#</TableCell>
                      <SortableHeaderCell field="quotationNo" sort={table.sort} onSort={table.toggleSort}>Quotation No.</SortableHeaderCell>
                      <SortableHeaderCell field="customer" sort={table.sort} onSort={table.toggleSort}>Customer</SortableHeaderCell>
                      <SortableHeaderCell field="quotationDate" sort={table.sort} onSort={table.toggleSort}>Quotation Date</SortableHeaderCell>
                      <SortableHeaderCell field="expiryDate" sort={table.sort} onSort={table.toggleSort}>Valid Till</SortableHeaderCell>
                      <SortableHeaderCell field="amount" sort={table.sort} onSort={table.toggleSort}>Amount (₹)</SortableHeaderCell>
                      <SortableHeaderCell field="status" sort={table.sort} onSort={table.toggleSort}>Status</SortableHeaderCell>
                      <TableCell align="right">Action</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {!isLoading && pagedRows.map((row, i) => (
                      <TableRow key={row.id} hover>
                        <TableCell padding="checkbox">
                          <Checkbox
                            size="small"
                            checked={checkedIds.includes(row.id)}
                            onChange={() => setCheckedIds((prev) => prev.includes(row.id) ? prev.filter((c) => c !== row.id) : [...prev, row.id])}
                          />
                        </TableCell>
                        <TableCell>{page * pageSize + i + 1}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.quotationNo}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.customer || '—'}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.quotationDate ? dayjs(row.quotationDate).format('DD/MM/YYYY') : '—'}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.expiryDate ? dayjs(row.expiryDate).format('DD/MM/YYYY') : '—'}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{Number(row.amount).toFixed(2)}</TableCell>
                        <TableCell>
                          <Chip size="small" label={row.status} color={STATUS_COLORS[row.status] || 'default'} variant="outlined" />
                        </TableCell>
                        <TableCell align="right">
                          <Stack direction="row" spacing={0.5} justifyContent="flex-end">
                            <Tooltip title="View">
                              <IconButton size="small" onClick={() => handleView(row)} aria-label="view">
                                <VisibilityOutlinedIcon fontSize="small" />
                              </IconButton>
                            </Tooltip>
                            <Tooltip title="Duplicate">
                              <IconButton size="small" onClick={() => handleDuplicate(row)} aria-label="duplicate">
                                <ContentCopyOutlinedIcon fontSize="small" />
                              </IconButton>
                            </Tooltip>
                            <Tooltip title="Print">
                              <IconButton size="small" onClick={() => handlePrint(row)} aria-label="print">
                                <PrintOutlinedIcon fontSize="small" />
                              </IconButton>
                            </Tooltip>
                            <IconButton
                              size="small"
                              onClick={(e) => { setRowMenuAnchor(e.currentTarget); setRowMenuTarget(row); }}
                              aria-label="more actions"
                            >
                              <MoreVertIcon fontSize="small" />
                            </IconButton>
                          </Stack>
                        </TableCell>
                      </TableRow>
                    ))}
                    {!isLoading && filteredRows.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={9}>
                          <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>No quotations found</Typography>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </ScrollableTableContainer>
            )}

            <Menu anchorEl={rowMenuAnchor} open={!!rowMenuAnchor} onClose={() => setRowMenuAnchor(null)}>
              <CanEdit>
                <MenuItem onClick={() => handleEdit(rowMenuTarget)}>
                  <ListItemIcon><EditIcon fontSize="small" /></ListItemIcon>
                  <ListItemText>Edit</ListItemText>
                </MenuItem>
              </CanEdit>
              <CanDelete>
                <MenuItem onClick={() => handleDelete(rowMenuTarget)}>
                  <ListItemIcon><DeleteIcon fontSize="small" color="error" /></ListItemIcon>
                  <ListItemText>Delete</ListItemText>
                </MenuItem>
              </CanDelete>
            </Menu>

            <EntityListPagination total={filteredRows.length} page={page} onChange={setPage} pageSize={pageSize} onPageSizeChange={(v) => { setPageSize(v); setPage(0); }} />
          </CardContent>
        </Card>
      )}
    </Box>
  );
}

// Isolated so the per-row product-select auto-fill effect only re-runs for
// the row whose product actually changed, not every row on every keystroke.
// Both the Product Code and Product Name columns are selects over the same
// underlying items.{index}.productCode field — Product Code lists codes,
// Product Name lists names, but selecting either one sets the same value, so
// whichever the user picks from, the row's product identity (and therefore
// the auto-filled HSN/UOM/price below) stays in sync.
function ProductCell({ index, methods, options, products, label = '', placeholder = 'Select product', sx }) {
  const { watch, setValue } = methods;
  const productCodeValue = watch(`items.${index}.productCode`);
  const prevValue = useRef(productCodeValue);

  useEffect(() => {
    if (productCodeValue !== prevValue.current) {
      const found = (products || []).find((p) => p.productCode === productCodeValue);
      if (found) {
        setValue(`items.${index}.productName`, found.productName, { shouldValidate: true });
        setValue(`items.${index}.description`, found.productName, { shouldValidate: true });
        setValue(`items.${index}.hsnCode`, found.hsnCode || '', { shouldValidate: true });
        setValue(`items.${index}.uom`, found.uom || '', { shouldValidate: true });
        setValue(`items.${index}.unitPrice`, found.salesPrice != null ? Number(found.salesPrice) : 0, { shouldValidate: true });
      }
      prevValue.current = productCodeValue;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [productCodeValue]);

  return <FormSelect name={`items.${index}.productCode`} label={label} placeholder={placeholder} options={options} sx={sx} />;
}
