import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Box, Typography, Button, Card, CardContent, Stack, Table, TableBody, TableCell,
  TableHead, TableRow, Chip, IconButton, Menu, MenuItem, ListItemIcon, ListItemText, Grid,
} from '@mui/material';
import { useFieldArray } from 'react-hook-form';
import dayjs from 'dayjs';
import ReceiptLongOutlinedIcon from '@mui/icons-material/ReceiptLongOutlined';
import AddIcon from '@mui/icons-material/Add';
import CloseIcon from '@mui/icons-material/Close';
import PrintOutlinedIcon from '@mui/icons-material/PrintOutlined';
import UploadFileIcon from '@mui/icons-material/UploadFile';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import EditIcon from '@mui/icons-material/EditOutlined';
import DeleteIcon from '@mui/icons-material/DeleteOutline';
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import AppForm, { FormGrid, FormSubmitButton } from '../../components/form/AppForm';
import FormTextField from '../../components/form/FormTextField';
import FormSelect from '../../components/form/FormSelect';
import FormDatePicker from '../../components/form/FormDatePicker';
import DocumentNoField from '../../components/form/DocumentNoField';
import EntityHeaderCard from '../../components/common/EntityHeaderCard';
import CompanyBadge from '../../components/common/CompanyBadge';
import { CanAdd, CanEdit, CanDelete } from '../../components/common/PermissionGate';
import EntityListPagination from '../../components/data-display/EntityListPagination';
import MobileRecordCard from '../../components/data-display/MobileRecordCard';
import { useIsMobileListView } from '../../components/data-display/useIsMobileListView';
import { useNotify } from '../../components/feedback/NotificationProvider';
import { useConfirm } from '../../components/feedback/ConfirmationDialog';
import { applyServerErrors } from '../../lib/formErrors';
import { salesCreditMemoSchema, SALES_CREDIT_MEMO_STATUS_OPTIONS } from '../../lib/validation/salesSchemas';
import { buildDocument, round2, isInterState } from '../../lib/documentTotals';
import DocumentTotalsPanel from '../../components/form/DocumentTotalsPanel';
import { useGetCompanyDetailsQuery } from '../../features/company/companyDetailsApi';
import { buildTaxPercentOptions } from '../../lib/taxCodeOptions';
import { taxCodeApi } from '../../features/resources';
import { PAYMENT_TERMS_OPTIONS } from '../../lib/validation/partnerSchemas';
import { salesCreditMemoApi, salesInvoiceApi, customerApi, branchApi } from '../../features/resources';
import useTableFeatures from '../../components/data-display/useTableFeatures';
import TableSearchFilter from '../../components/data-display/TableSearchFilter';
import TableFilterPanel from '../../components/data-display/TableFilterPanel';
import SortableHeaderCell from '../../components/data-display/SortableHeaderCell';
import ScrollableTableContainer from '../../components/data-display/ScrollableTableContainer';

const PAGE_SIZE = 10;

// Same default wording the other sales documents open with, so a credit memo
// printed alongside them reads consistently.
const DEFAULT_TERMS = [
  '1. Goods once sold will not be taken back.',
  '2. Delivery as per agreed schedule.',
  '3. Payment within the stipulated credit period.',
  '4. Subject to Bangalore jurisdiction.',
].join('\n');

const emptyItem = {
  productCode: '', productName: '', description: '', hsnCode: '', uom: '',
  invoicedQuantity: 0, quantity: 1, unitPrice: 0,
  discountPercent: 0, taxPercent: 0,
};

// Built fresh per "Add" click rather than held in a module constant, so the
// dates are today's whenever the form opens instead of whenever the JS module
// first loaded — the same reason the other transaction pages do this.
function getEmptyValues() {
  const today = new Date();
  return {
    creditNo: '', status: 'Open', invoiceNo: '', customer: '', customerName: '',
    contactPerson: '', customerRefNo: '', branch: '',
    reason: '', narration: '',
    documentDate: today, postingDate: today, dueDate: null,
    paymentTerms: '', comments: '',
    placeOfSupply: '', discountPercent: 0,
    termsConditions: DEFAULT_TERMS, attachmentName: '',
    items: [{ ...emptyItem }],
  };
}

// DocumentTotalsPanel reads `discount` and `grandTotal`, which the shared
// engine does not return — every other document derives them in a
// wrapper exactly like this one. Passing buildDocument's raw totals straight
// to the panel is what made it crash on totals.grandTotal.toFixed().
function computeMemoTotals(items, discountPercent, interState) {
  const { totals } = buildDocument(items, discountPercent, {
    quantityField: 'quantity',
    interState,
    roundOff: true,
  });
  return {
    ...totals,
    discount: round2(totals.subtotal - totals.taxableAmount),
    grandTotal: totals.amount,
  };
}

const money = (v) => (Number(v) || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

function rowToFormValues(row) {
  const toDate = (v) => (v ? new Date(v) : null);
  return {
    ...getEmptyValues(),
    ...row,
    documentDate: toDate(row.documentDate),
    postingDate: toDate(row.postingDate),
    dueDate: toDate(row.dueDate),
    items: (row.items?.length ? row.items : [{ ...emptyItem }]).map((i) => ({
      productCode: i.productCode || '',
      productName: i.productName || '',
      description: i.description || '',
      hsnCode: i.hsnCode || '',
      uom: i.uom || '',
      invoicedQuantity: Number(i.invoicedQuantity) || 0,
      quantity: Number(i.quantity) || 0,
      unitPrice: Number(i.unitPrice) || 0,
      discountPercent: Number(i.discountPercent) || 0,
      taxPercent: Number(i.taxPercent) || 0,
    })),
  };
}

/**
 * Sales Credit Memo — a credit issued to a customer, raised against a
 * Sales Invoice.
 *
 * Totals, including the CGST/SGST vs IGST split, are computed by the shared
 * document engine and recomputed identically on the server, so the panel can
 * never disagree with what gets stored. The memo posts no receivables adjustment:
 * it records the credit's value only.
 */
export default function SalesCreditMemo() {
  const notify = useNotify();
  const confirmDialog = useConfirm();
  const isMobile = useIsMobileListView();

  const { data: rows, isLoading } = salesCreditMemoApi.useList();
  const [create, { isLoading: creating }] = salesCreditMemoApi.useCreate();
  const [update, { isLoading: updating }] = salesCreditMemoApi.useUpdate();
  const [remove] = salesCreditMemoApi.useDelete();
  const { data: invoices } = salesInvoiceApi.useList();
  const { data: customers } = customerApi.useList();
  const { data: branches } = branchApi.useList();
  const { data: taxCodes } = taxCodeApi.useList();
  const { data: company } = useGetCompanyDetailsQuery();
  const taxPercentOptions = useMemo(() => buildTaxPercentOptions(taxCodes), [taxCodes]);

  const [view, setView] = useState('list');
  const [editingRow, setEditingRow] = useState(null);
  const [readOnly, setReadOnly] = useState(false);
  const [formKey, setFormKey] = useState(0);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(PAGE_SIZE);
  const [rowMenuAnchor, setRowMenuAnchor] = useState(null);
  const [rowMenuTarget, setRowMenuTarget] = useState(null);
  // Which of the two save buttons was pressed. A ref, not state: the click
  // handler has to record it before submit reads it, and setting state there
  // would re-render in the middle of the click.
  const pendingStatusRef = useRef('Open');

  const invoiceOptions = useMemo(
    () => (invoices || []).map((i) => ({ label: i.invoiceNo, value: i.invoiceNo })),
    [invoices]
  );
  const customerOptions = useMemo(
    () => (customers || []).map((c) => ({ label: c.customerName, value: c.customerName })),
    [customers]
  );
  const branchOptions = useMemo(
    () => (branches || []).map((b) => ({ label: b.branchName, value: b.branchName })),
    [branches]
  );

  const tableColumns = useMemo(() => ([
    { field: 'creditNo', headerName: 'Credit No', filter: 'text' },
    { field: 'invoiceNo', headerName: 'Invoice No.', filter: 'text' },
    { field: 'customer', headerName: 'Customer', filter: 'select' },
    {
      field: 'documentDate',
      headerName: 'Document Date',
      filter: 'dateRange',
      sortValue: (r) => (r.documentDate ? new Date(r.documentDate).getTime() : null),
      searchValue: (r) => (r.documentDate ? dayjs(r.documentDate).format('DD MMM YYYY') : ''),
    },
    { field: 'totalItems', headerName: 'Items', filter: 'numberRange' },
    { field: 'amount', headerName: 'Amount', filter: 'numberRange', sortValue: (r) => Number(r.amount) || 0 },
    { field: 'status', headerName: 'Status', filter: 'select' },
  ]), []);

  const table = useTableFeatures(rows || [], tableColumns, { onChange: setPage });
  const visibleRows = table.rows;
  const pagedRows = useMemo(
    () => visibleRows.slice(page * pageSize, page * pageSize + pageSize),
    [visibleRows, page, pageSize]
  );

  const backToList = () => { setView('list'); setEditingRow(null); setReadOnly(false); };

  const openCreate = () => {
    setEditingRow(null); setReadOnly(false); setFormKey((k) => k + 1); setView('form');
  };
  const handleEdit = (row) => {
    setEditingRow(row); setReadOnly(false); setFormKey((k) => k + 1);
    setView('form'); setRowMenuAnchor(null);
  };
  const handleView = (row) => {
    setEditingRow(row); setReadOnly(true); setFormKey((k) => k + 1);
    setView('form'); setRowMenuAnchor(null);
  };

  const handleDelete = async (row) => {
    setRowMenuAnchor(null);
    const ok = await confirmDialog({
      title: 'Delete sales credit memo',
      message: `Are you sure you want to delete "${row.creditNo}"? This cannot be undone.`,
      confirmLabel: 'Delete',
      severity: 'error',
    });
    if (!ok) return;
    try {
      await remove(row.id).unwrap();
      notify.success('Sales credit memo deleted');
    } catch (err) {
      notify.error(err?.data?.message || 'Delete failed');
    }
  };

  const handleSubmit = async (values, methods) => {
    // Save as Draft and Save both submit the same form; the button that was
    // clicked decides the status the document is stored with.
    const payload = { ...values, status: pendingStatusRef.current || values.status };
    try {
      if (editingRow) {
        await update({ id: editingRow.id, ...payload }).unwrap();
        notify.success('Sales credit memo updated');
      } else {
        await create(payload).unwrap();
        notify.success('Sales credit memo created');
      }
      backToList();
    } catch (err) {
      notify.error(applyServerErrors(err, methods.setError));
    }
  };

  return (
    <Box>
      <EntityHeaderCard
        icon={<ReceiptLongOutlinedIcon />}
        title="Sales Credit Memo"
        subtitle={view === 'form'
          ? 'Record a credit issued to a customer against a sales invoice.'
          : 'Manage credits issued to customers.'}
        rightContent={<CompanyBadge />}
      />

      {view === 'form' ? (
        <AppForm
          key={formKey}
          readOnly={readOnly}
          schema={salesCreditMemoSchema}
          defaultValues={editingRow ? rowToFormValues(editingRow) : getEmptyValues()}
          onSubmit={handleSubmit}
        >
          {(methods) => {
            const { control, watch, setValue } = methods;
            const { fields, append, remove: removeItem, replace: replaceItems } = useFieldArray({ control, name: 'items' });
            const watchedItems = watch('items') || [];
            const invoiceNo = watch('invoiceNo');

            // Pulling an invoice in fills the customer block and replaces the
            // lines with what it billed. Guarded by a ref so it fires only on
            // a real change of Invoice No. — without it, every keystroke elsewhere
            // in the form would re-run and wipe edits made to the lines.
            const prevInvoiceNo = useRef(editingRow ? editingRow.invoiceNo : '');
            useEffect(() => {
              if (invoiceNo === prevInvoiceNo.current) return;
              prevInvoiceNo.current = invoiceNo;

              if (!invoiceNo) {
                // Clearing the invoice clears everything it filled in, rather than
                // leaving a stale customer and lines from a document that is no
                // longer referenced.
                setValue('customer', '');
                setValue('customerName', '');
                setValue('branch', '');
                replaceItems([{ ...emptyItem }]);
                return;
              }

              const invoice = (invoices || []).find((g) => g.invoiceNo === invoiceNo);
              if (!invoice) return;
              setValue('customer', invoice.customer || '');
              setValue('customerName', invoice.customer || '');
              setValue('branch', invoice.branch || '');
              // replace(), never setValue('items', ...) — the field array has to
              // remount so each row's inputs pick up the new values.
              replaceItems(
                (invoice.items || []).map((i) => ({
                  productCode: i.productCode || '',
                  productName: i.productName || '',
                  description: i.description || '',
                  hsnCode: i.hsnCode || '',
                  uom: i.uom || '',
                  invoicedQuantity: Number(i.invoicedQuantity) || 0,
                  quantity: Number(i.invoicedQuantity) || 0,
                  unitPrice: Number(i.unitPrice) || 0,
                  discountPercent: Number(i.discountPercent) || 0,
                  taxPercent: Number(i.taxPercent) || 0,
                }))
              );
            }, [invoiceNo, invoices, setValue, replaceItems]);

            // Totals come from the shared document engine, given the same
            // inputs the server uses, so what the panel shows is what gets
            // saved. interState must be passed through explicitly — defaulting
            // it would show a CGST/SGST split on a document stored as IGST.
            const handleFile = (file) => {
              if (file) setValue('attachmentName', file.name, { shouldValidate: true });
            };

            const interState = isInterState(watch('placeOfSupply'), company?.state);
            const totals = computeMemoTotals(watchedItems, watch('discountPercent'), interState);

            return (
              <>
                <Card variant="outlined" sx={{ mb: 2 }}>
                  <CardContent>
                    <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 2 }}>
                      {readOnly ? 'View Sales Credit Memo' : editingRow ? 'Edit Sales Credit Memo' : 'Add Sales Credit Memo'}
                    </Typography>

                    <FormGrid columns={3}>
                      <DocumentNoField documentCode="SCM" name="creditNo" label="Credit No *" isCreate={!editingRow} />
                      <FormSelect
                        name="status"
                        label="Status *"
                        options={SALES_CREDIT_MEMO_STATUS_OPTIONS.map((v) => ({ label: v, value: v }))}
                      />
                      <FormSelect name="invoiceNo" label="Invoice No. *" placeholder="Select invoice" options={invoiceOptions} />

                      <FormSelect name="customer" label="Customer *" placeholder="Select customer" options={customerOptions} />
                      <FormTextField name="customerName" label="Name" placeholder="Customer name" />
                      <FormTextField name="contactPerson" label="Contact Person" placeholder="Enter contact person" />

                      <FormTextField name="customerRefNo" label="Customer Ref No." placeholder="Enter customer ref no." />
                      <FormSelect name="branch" label="Branch *" placeholder="Select branch" options={branchOptions} />
                      <FormSelect
                        name="paymentTerms"
                        label="Payment Terms"
                        placeholder="Select payment terms"
                        options={PAYMENT_TERMS_OPTIONS}
                      />

                      <FormDatePicker name="documentDate" label="Document Date *" />
                      <FormDatePicker name="postingDate" label="Posting Date" />
                      <FormDatePicker name="dueDate" label="Due Date" />

                      <FormTextField name="reason" label="Reason" placeholder="Reason for the credit" />
                      <FormTextField name="narration" label="Narration" placeholder="Enter narration" />
                      <FormTextField name="comments" label="Comments" placeholder="Enter comments" />
                    </FormGrid>
                  </CardContent>
                </Card>

                <Card variant="outlined" sx={{ mb: 2 }}>
                  <CardContent>
                    <Stack direction="row" alignItems="center" justifyContent="space-between" sx={{ mb: 1.5 }}>
                      <Typography variant="subtitle1" fontWeight={700}>Items</Typography>
                      {!readOnly && (
                        <Button size="small" startIcon={<AddIcon />} onClick={() => append({ ...emptyItem })}>
                          Add Row
                        </Button>
                      )}
                    </Stack>

                    <ScrollableTableContainer>
                      <Table size="small">
                        <TableHead>
                          <TableRow>
                            <TableCell width={48}>#</TableCell>
                            <TableCell>Product Code</TableCell>
                            <TableCell>Product Name</TableCell>
                            <TableCell>UOM</TableCell>
                            <TableCell align="right">Invoiced Qty</TableCell>
                            <TableCell align="right">Qty</TableCell>
                            <TableCell align="right">Unit Price</TableCell>
                            <TableCell align="right">Disc %</TableCell>
                            <TableCell align="right">Tax %</TableCell>
                            <TableCell align="right">Amount</TableCell>
                            {!readOnly && <TableCell align="right">Action</TableCell>}
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {fields.map((field, index) => {
                            const qty = Number(watch(`items.${index}.quantity`)) || 0;
                            const price = Number(watch(`items.${index}.unitPrice`)) || 0;
                            const disc = Number(watch(`items.${index}.discountPercent`)) || 0;
                            const lineAmount = qty * price * (1 - disc / 100);
                            return (
                              <TableRow key={field.id}>
                                <TableCell>{index + 1}</TableCell>
                                <TableCell sx={{ minWidth: 160 }}>
                                  <FormTextField name={`items.${index}.productCode`} label="" placeholder="Product code" />
                                </TableCell>
                                <TableCell sx={{ minWidth: 200 }}>
                                  <FormTextField name={`items.${index}.productName`} label="" placeholder="Product name" />
                                </TableCell>
                                <TableCell sx={{ minWidth: 100 }}>
                                  <FormTextField name={`items.${index}.uom`} label="" placeholder="UOM" />
                                </TableCell>
                                <TableCell sx={{ minWidth: 120 }}>
                                  <FormTextField name={`items.${index}.invoicedQuantity`} label="" type="number" disabled />
                                </TableCell>
                                <TableCell sx={{ minWidth: 120 }}>
                                  <FormTextField name={`items.${index}.quantity`} label="" type="number" />
                                </TableCell>
                                <TableCell sx={{ minWidth: 130 }}>
                                  <FormTextField name={`items.${index}.unitPrice`} label="" type="number" />
                                </TableCell>
                                <TableCell sx={{ minWidth: 100 }}>
                                  <FormTextField name={`items.${index}.discountPercent`} label="" type="number" />
                                </TableCell>
                                <TableCell sx={{ minWidth: 110 }}>
                                  <FormSelect name={`items.${index}.taxPercent`} label="" options={taxPercentOptions} />
                                </TableCell>
                                <TableCell align="right" sx={{ whiteSpace: 'nowrap' }}>
                                  {money(lineAmount)}
                                </TableCell>
                                {!readOnly && (
                                  <TableCell align="right">
                                    <IconButton
                                      size="small"
                                      color="error"
                                      aria-label="remove row"
                                      disabled={fields.length === 1}
                                      onClick={() => removeItem(index)}
                                    >
                                      <DeleteIcon fontSize="small" />
                                    </IconButton>
                                  </TableCell>
                                )}
                              </TableRow>
                            );
                          })}
                        </TableBody>
                      </Table>
                    </ScrollableTableContainer>

                  </CardContent>
                </Card>

                {/* Terms, attachments and the money panel — the same footer the
                    other sales documents carry, so a credit memo reads and prints
                    consistently beside them. */}
                <Card variant="outlined" sx={{ mb: 2 }}>
                  <CardContent sx={{ p: { xs: 2, sm: 3 } }}>
                    <Grid container spacing={3}>
                      <Grid item xs={12} md={4}>
                        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1 }}>Terms &amp; Conditions</Typography>
                        <FormTextField name="termsConditions" label="" placeholder="Enter terms and conditions" multiline rows={6} />
                      </Grid>

                      <Grid item xs={12} md={4}>
                        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1 }}>Attachments</Typography>
                        <Box
                          onDragOver={(e) => e.preventDefault()}
                          onDrop={(e) => { e.preventDefault(); handleFile(e.dataTransfer.files?.[0]); }}
                          sx={{
                            border: '1px dashed', borderColor: 'divider', borderRadius: 1.5,
                            p: 3, textAlign: 'center', color: 'text.secondary',
                          }}
                        >
                          <UploadFileIcon sx={{ mb: 1 }} />
                          <Typography variant="body2" sx={{ mb: 1 }}>Drag and drop files here</Typography>
                          <Typography variant="body2" sx={{ mb: 1 }}>or</Typography>
                          <Button component="label" variant="outlined" size="small" disabled={readOnly}>
                            Browse Files
                            <input type="file" hidden onChange={(e) => handleFile(e.target.files?.[0])} />
                          </Button>
                          <Typography variant="caption" display="block" sx={{ mt: 1 }}>
                            Supported formats: PDF, JPG, PNG (Max. 5MB)
                          </Typography>
                          {watch('attachmentName') && (
                            <Chip
                              sx={{ mt: 1.5 }}
                              size="small"
                              label={watch('attachmentName')}
                              onDelete={readOnly ? undefined : () => setValue('attachmentName', '')}
                            />
                          )}
                        </Box>
                      </Grid>

                      <Grid item xs={12} md={4}>
                        <DocumentTotalsPanel totals={totals} interState={interState} subtotalLabel="Subtotal" showRoundOff={false} />
                      </Grid>
                    </Grid>

                    <Stack
                      direction={{ xs: 'column', sm: 'row' }}
                      spacing={1.5}
                      justifyContent={{ xs: 'stretch', sm: 'flex-end' }}
                      sx={{ mt: 3 }}
                    >
                      <Button fullWidth={isMobile} type="button" variant="outlined" color={readOnly ? 'error' : 'inherit'} startIcon={<CloseIcon />} onClick={backToList} disabled={creating || updating}>
                        {readOnly ? 'Close' : 'Cancel'}
                      </Button>
                      <Button fullWidth={isMobile} type="button" variant="outlined" startIcon={<PrintOutlinedIcon />} onClick={() => window.print()}>
                        Print
                      </Button>
                      {/* pendingStatusRef, not setValue: the click has to record
                          which button was pressed before submit reads it, and a
                          setValue here would re-render mid-click. */}
                      <FormSubmitButton
                        fullWidth={isMobile}
                        variant="outlined"
                        onClick={() => { pendingStatusRef.current = 'Draft'; }}
                        disabled={creating || updating}
                      >
                        Save as Draft
                      </FormSubmitButton>
                      <FormSubmitButton
                        fullWidth={isMobile}
                        onClick={() => { pendingStatusRef.current = 'Open'; }}
                        disabled={creating || updating}
                      >
                        {editingRow ? 'Update Credit Memo' : 'Save Credit Memo'}
                      </FormSubmitButton>
                    </Stack>
                  </CardContent>
                </Card>

              </>
            );
          }}
        </AppForm>
      ) : (
        <Card variant="outlined">
          <CardContent sx={{ p: 0 }}>
            <Stack direction="row" alignItems="center" justifyContent="space-between" flexWrap="wrap" gap={1.5} sx={{ px: 3, pt: 2.5, pb: 1.5 }}>
              <Typography variant="subtitle1" fontWeight={700}>Sales Credit Memo List</Typography>
              <Stack direction="row" spacing={1.5} flexWrap="wrap" useFlexGap alignItems="center">
                <TableSearchFilter table={table} placeholder="Search by credit no., invoice, customer..." />
                <CanAdd>
                  <Button variant="contained" startIcon={<AddIcon />} onClick={openCreate} sx={{ whiteSpace: 'nowrap' }}>
                    Add Credit Memo
                  </Button>
                </CanAdd>
              </Stack>
            </Stack>

            <TableFilterPanel table={table} />

            {isMobile ? (
              <Box sx={{ px: 2, pb: 1 }}>
                {!isLoading && pagedRows.map((row) => (
                  <MobileRecordCard
                    key={row.id}
                    title={row.creditNo}
                    statusChip={<Chip size="small" label={row.status} variant="outlined" />}
                    fields={[
                      { label: 'Invoice No.', value: row.invoiceNo },
                      { label: 'Customer', value: row.customer },
                      { label: 'Amount', value: money(row.amount) },
                    ]}
                    onView={() => handleView(row)}
                    onEdit={() => handleEdit(row)}
                    onDelete={() => handleDelete(row)}
                  />
                ))}
                {!isLoading && visibleRows.length === 0 && (
                  <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>
                    {table.isFiltering ? 'No credit memos match your search' : 'No credit memos yet'}
                  </Typography>
                )}
              </Box>
            ) : (
              <ScrollableTableContainer>
                <Table size="small" stickyHeader>
                  <TableHead>
                    <TableRow>
                      <TableCell width={48}>#</TableCell>
                      <SortableHeaderCell field="creditNo" sort={table.sort} onSort={table.toggleSort}>Credit No</SortableHeaderCell>
                      <SortableHeaderCell field="invoiceNo" sort={table.sort} onSort={table.toggleSort}>Invoice No.</SortableHeaderCell>
                      <SortableHeaderCell field="customer" sort={table.sort} onSort={table.toggleSort}>Customer</SortableHeaderCell>
                      <SortableHeaderCell field="documentDate" sort={table.sort} onSort={table.toggleSort}>Document Date</SortableHeaderCell>
                      <SortableHeaderCell field="totalItems" sort={table.sort} onSort={table.toggleSort}>Items</SortableHeaderCell>
                      <SortableHeaderCell field="amount" sort={table.sort} onSort={table.toggleSort}>Amount</SortableHeaderCell>
                      <SortableHeaderCell field="status" sort={table.sort} onSort={table.toggleSort}>Status</SortableHeaderCell>
                      <TableCell align="right">Action</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {!isLoading && pagedRows.map((row, i) => (
                      <TableRow key={row.id} hover>
                        <TableCell>{page * pageSize + i + 1}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.creditNo}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.invoiceNo || '—'}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.customer || '—'}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>
                          {row.documentDate ? dayjs(row.documentDate).format('DD MMM YYYY') : '—'}
                        </TableCell>
                        <TableCell>{row.totalItems}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{money(row.amount)}</TableCell>
                        <TableCell>
                          <Chip size="small" label={row.status} variant="outlined" />
                        </TableCell>
                        <TableCell align="right">
                          <IconButton size="small" onClick={() => handleView(row)} aria-label="view">
                            <VisibilityOutlinedIcon fontSize="small" />
                          </IconButton>
                          <IconButton
                            size="small"
                            aria-label="more actions"
                            onClick={(e) => { setRowMenuAnchor(e.currentTarget); setRowMenuTarget(row); }}
                          >
                            <MoreVertIcon fontSize="small" />
                          </IconButton>
                        </TableCell>
                      </TableRow>
                    ))}
                    {!isLoading && visibleRows.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={9}>
                          <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>
                            {table.isFiltering ? 'No credit memos match your search' : 'No credit memos yet'}
                          </Typography>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </ScrollableTableContainer>
            )}

            <Menu anchorEl={rowMenuAnchor} open={!!rowMenuAnchor} onClose={() => setRowMenuAnchor(null)}>
              <CanEdit>
                <MenuItem onClick={() => handleEdit(rowMenuTarget)}>
                  <ListItemIcon><EditIcon fontSize="small" /></ListItemIcon>
                  <ListItemText>Edit</ListItemText>
                </MenuItem>
              </CanEdit>
              <CanDelete>
                <MenuItem onClick={() => handleDelete(rowMenuTarget)}>
                  <ListItemIcon><DeleteIcon fontSize="small" color="error" /></ListItemIcon>
                  <ListItemText>Delete</ListItemText>
                </MenuItem>
              </CanDelete>
            </Menu>

            <EntityListPagination
              total={visibleRows.length}
              page={page}
              onChange={setPage}
              pageSize={pageSize}
              onPageSizeChange={(v) => { setPageSize(v); setPage(0); }}
            />
          </CardContent>
        </Card>
      )}
    </Box>
  );
}
