import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Box, Typography, Button, Card, CardContent, Stack, TextField, InputAdornment, Table,
  TableBody, TableCell, TableContainer, TableHead, TableRow, Chip, IconButton, Menu, MenuItem,
  ListItemIcon, ListItemText, Checkbox, Autocomplete, Popover, Grid, Tooltip, Collapse, Tabs, Tab,
} from '@mui/material';
import { useFieldArray } from 'react-hook-form';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import dayjs from 'dayjs';
import SwapHorizOutlinedIcon from '@mui/icons-material/SwapHorizOutlined';
import AddIcon from '@mui/icons-material/Add';
import CloseIcon from '@mui/icons-material/Close';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import FilterListIcon from '@mui/icons-material/FilterList';
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import PrintOutlinedIcon from '@mui/icons-material/PrintOutlined';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import EditIcon from '@mui/icons-material/EditOutlined';
import DeleteIcon from '@mui/icons-material/DeleteOutline';
import EventIcon from '@mui/icons-material/Event';
import AppForm, { FormGrid, FormSubmitButton } from '../../components/form/AppForm';
import FormTextField from '../../components/form/FormTextField';
import FormSelect from '../../components/form/FormSelect';
import FormDatePicker from '../../components/form/FormDatePicker';
import DocumentNoField from '../../components/form/DocumentNoField';
import EntityHeaderCard from '../../components/common/EntityHeaderCard';
import CompanyBadge from '../../components/common/CompanyBadge';
import EntityListPagination from '../../components/data-display/EntityListPagination';
import FilterAutocomplete from '../../components/data-display/FilterAutocomplete';
import MobileRecordCard from '../../components/data-display/MobileRecordCard';
import MobileItemCard from '../../components/data-display/MobileItemCard';
import { useIsMobileListView } from '../../components/data-display/useIsMobileListView';
import useDragScroll from '../../components/data-display/useDragScroll';
import { useNotify } from '../../components/feedback/NotificationProvider';
import { applyServerErrors } from '../../lib/formErrors';
import { useConfirm } from '../../components/feedback/ConfirmationDialog';
import { round2 } from '../../lib/documentTotals';
import { stockTransferSchema, TRANSFER_TYPE_OPTIONS, STOCK_TRANSFER_STATUS_OPTIONS } from '../../lib/validation/inventorySchemas';
import {
  stockTransferApi, productApi, branchApi, customerApi, supplierApi, chartOfAccountApi, appUserApi,
  useGetProductInventoryQuery,
} from '../../features/resources';
import { useWarehouseOptions, useWarehouseLabeller, warehouseLabel as formatWarehouseLabel } from '../../lib/useWarehouseOptions';
import useTableFeatures from '../../components/data-display/useTableFeatures';
import TableSearchFilter from '../../components/data-display/TableSearchFilter';
import SortableHeaderCell from '../../components/data-display/SortableHeaderCell';
import ScrollableTableContainer, { dragScrollbarSx } from '../../components/data-display/ScrollableTableContainer';

import { CanAdd, CanEdit, CanDelete } from '../../components/common/PermissionGate';
import TableFilterPanel from '../../components/data-display/TableFilterPanel';

const emptyItem = {
  productCode: '', productName: '', fromWarehouse: '', toWarehouse: '', totalStock: 0, uom: '',
  quantity: '', unitPrice: 0, itemCost: 0, accountCode: '', project: '', remarks: '',
};

function getEmptyValues() {
  const today = new Date();
  return {
    transferNo: '', branch: '', transferType: 'Stock Transfer', status: 'Draft',
    partyCode: '', partyName: '', contactPerson: '', shipTo: '', priceList: '', project: '',
    requestDate: today, documentDate: today, fromWarehouse: '', toWarehouse: '',
    preparedBy: '', journalRemarks: 'Material Transfer - ', remarks: '', attachmentName: '',
    items: [{ ...emptyItem }],
  };
}

// Mirrors the backend's toStockTransferItemData/computeStockTransferTotals —
// each line's amount is simply quantity x unit price.
function computeTotals(items) {
  const amount = (items || []).reduce((sum, i) => sum + round2((Number(i.quantity) || 0) * (Number(i.unitPrice) || 0)), 0);
  return { amount: round2(amount) };
}

function rowToFormValues(row) {
  return {
    transferNo: row.transferNo, branch: row.branch || '', transferType: row.transferType || 'Stock Transfer',
    status: row.status || 'Draft',
    partyCode: row.partyCode || '', partyName: row.partyName || '', contactPerson: row.contactPerson || '',
    shipTo: row.shipTo || '', priceList: row.priceList || '', project: row.project || '',
    requestDate: row.requestDate, documentDate: row.documentDate,
    fromWarehouse: row.fromWarehouse || '', toWarehouse: row.toWarehouse || '',
    preparedBy: row.preparedBy || '', journalRemarks: row.journalRemarks || '', remarks: row.remarks || '',
    attachmentName: row.attachmentName || '',
    items: (row.items && row.items.length ? row.items : [{ ...emptyItem }]).map((i) => ({
      productCode: i.productCode || '', productName: i.productName || '',
      fromWarehouse: i.fromWarehouse || row.fromWarehouse || '',
      toWarehouse: i.toWarehouse || row.toWarehouse || '',
      totalStock: i.totalStock != null ? Number(i.totalStock) : 0,
      uom: i.uom || '', quantity: i.quantity != null ? Number(i.quantity) : 0,
      unitPrice: i.unitPrice != null ? Number(i.unitPrice) : 0,
      itemCost: i.itemCost != null ? Number(i.itemCost) : 0,
      accountCode: i.accountCode || '', project: i.project || '', remarks: i.remarks || '',
    })),
  };
}

// Both header and per-row From/To Warehouse read from this same list — a
// warehouse belongs to a Branch (WarehouseMaster.branch), so once Branch is
// picked, every warehouse dropdown on the document (there is no directional
// split; From and To simply must differ from each other, enforced by the
// schema's refine) is scoped to that branch's warehouses only. Mirrors
// useWarehouseOptions' own "keep the record's legacy value selectable even if
// it's not in the current list" behavior, since this bypasses that hook to
// add the branch filter.
function warehouseOptionsForBranch(warehouses, branchName, currentValue) {
  const rows = (warehouses || [])
    .filter((w) => w.status === 'Active' && (!branchName || w.branch === branchName))
    .slice()
    .sort((a, b) => String(a.whsCode || '').localeCompare(String(b.whsCode || ''), undefined, { numeric: true }));
  const out = rows.map((w) => ({ label: formatWarehouseLabel(w), value: w.whsCode }));
  const current = currentValue == null ? '' : String(currentValue);
  if (current !== '' && !out.some((o) => o.value === current)) {
    const known = (warehouses || []).find((w) => w.whsCode === current);
    out.unshift({
      label: known ? formatWarehouseLabel(known) : `${current} (not in Warehouse Master)`,
      value: current,
    });
  }
  return out;
}

const PAGE_SIZE = 10;
const STATUS_FILTERS = ['All Status', ...STOCK_TRANSFER_STATUS_OPTIONS];
const TYPE_FILTERS = ['All Types', ...TRANSFER_TYPE_OPTIONS];
const STATUS_COLORS = { Draft: 'default', Posted: 'success', Cancelled: 'error' };

export default function StockTransfer() {
  const notify = useNotify();
  const confirmDialog = useConfirm();
  const isMobile = useIsMobileListView();
  const itemScrollRef = useDragScroll();
  const { data: transfers, isLoading } = stockTransferApi.useList();
  const { data: products } = productApi.useList();
  const { data: branches } = branchApi.useList();
  const { data: customers } = customerApi.useList();
  const { data: suppliers } = supplierApi.useList();
  const { data: chartOfAccounts } = chartOfAccountApi.useList();
  const { data: appUsers } = appUserApi.useList();
  const [create, { isLoading: creating }] = stockTransferApi.useCreate();
  const [update, { isLoading: updating }] = stockTransferApi.useUpdate();
  const [remove] = stockTransferApi.useDelete();
  const warehouseLabel = useWarehouseLabeller();

  const productCodeOptions = (products || []).map((p) => ({ label: p.productCode, value: p.productCode }));
  const productNameOptions = (products || []).map((p) => ({ label: p.productName, value: p.productCode }));
  const branchOptions = (branches || []).map((b) => ({ label: b.branchName, value: b.branchName }));
  const accountOptions = useMemo(
    () => (chartOfAccounts || []).filter((a) => a.accountNature === 'A' && a.status !== 'I').map((a) => ({ label: `${a.accountName} (${a.accountCode})`, value: a.accountCode })),
    [chartOfAccounts]
  );
  const preparedByOptions = useMemo(
    () => (appUsers || []).map((u) => ({ label: u.name || u.email, value: u.name || u.email })),
    [appUsers]
  );

  // Business Partner is informational on a Stock Transfer (no ledger settles
  // against it — see businessRules.js, where this field is deliberately not
  // registered in REFERENCE_MAP), so it searches both masters as one list
  // rather than gating behind a Customer/Vendor radio like Payment
  // Receipt/Voucher do.
  const customerPartyOptions = useMemo(
    () => (customers || []).filter((c) => c.status !== 'Inactive').map((c) => ({ label: `${c.customerName} (${c.customerCode})`, value: c.customerCode })),
    [customers]
  );
  const supplierPartyOptions = useMemo(
    () => (suppliers || []).filter((s) => s.status !== 'Inactive').map((s) => ({ label: `${s.supplierName} (${s.supplierCode})`, value: s.supplierCode })),
    [suppliers]
  );
  const partyCodeOptions = useMemo(() => [...customerPartyOptions, ...supplierPartyOptions], [customerPartyOptions, supplierPartyOptions]);

  // View toggles between the transfer list and the full-page Create/Edit
  // form — same page, no dialog/popup, matching Stock Issue/Stock Adjustment.
  const [view, setView] = useState('list');
  const [editingRow, setEditingRow] = useState(null);

  // Unfiltered — used for the list view's Warehouse filter, which should
  // still search across every warehouse regardless of branch.
  const { options: allWarehouseOptions, warehouses: allWarehouses } = useWarehouseOptions({});
  const [readOnly, setReadOnly] = useState(false);
  const [formKey, setFormKey] = useState(0);
  const [typeFilter, setTypeFilter] = useState('All Types');
  const [statusFilter, setStatusFilter] = useState('All Status');
  const [warehouseFilter, setWarehouseFilter] = useState(null);
  const [dateFrom, setDateFrom] = useState(null);
  const [dateTo, setDateTo] = useState(null);
  const [dateAnchor, setDateAnchor] = useState(null);
  const [showFilters, setShowFilters] = useState(true);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(PAGE_SIZE);
  const [checkedIds, setCheckedIds] = useState([]);
  const [rowMenuAnchor, setRowMenuAnchor] = useState(null);
  const [rowMenuTarget, setRowMenuTarget] = useState(null);
  const pendingStatusRef = useRef('Draft');

  const rows = transfers || [];

  const baseTableRows = useMemo(() => {
    return rows.filter((r) => {
      const matchesType = typeFilter === 'All Types' || r.transferType === typeFilter;
      const matchesStatus = statusFilter === 'All Status' || r.status === statusFilter;
      const matchesWarehouse = !warehouseFilter || r.fromWarehouse === warehouseFilter.value || r.toWarehouse === warehouseFilter.value;
      const rd = r.requestDate ? dayjs(r.requestDate) : null;
      const matchesFrom = !dateFrom || (rd && !rd.isBefore(dateFrom, 'day'));
      const matchesTo = !dateTo || (rd && !rd.isAfter(dateTo, 'day'));
      return matchesType && matchesStatus && matchesWarehouse && matchesFrom && matchesTo;
    });
  }, [rows, typeFilter, statusFilter, warehouseFilter, dateFrom, dateTo]);

  const tableColumns = useMemo(() => ([
    { field: 'id', headerName: 'Select', filter: false, searchable: false },
    { field: 'transferNo', headerName: 'Material Transfer No.', filter: 'text' },
    { field: 'transferType', headerName: 'Type', filter: 'text' },
    { field: 'requestDate', headerName: 'Request Date', filter: 'dateRange', sortValue: (row) => (row.requestDate ? new Date(row.requestDate).getTime() : null) },
    { field: 'fromWarehouse', headerName: 'From Warehouse', filter: 'text', searchValue: (r) => warehouseLabel(r.fromWarehouse) },
    { field: 'toWarehouse', headerName: 'To Warehouse', filter: 'text', searchValue: (r) => warehouseLabel(r.toWarehouse) },
    { field: 'amount', headerName: 'Amount (₹)', filter: 'numberRange', sortValue: (row) => (row.amount == null || row.amount === '' ? null : Number(row.amount)) },
    { field: 'status', headerName: 'Status', filter: 'select' },
  ]), [warehouseLabel]);
  const table = useTableFeatures(baseTableRows, tableColumns, { onChange: setPage });
  const filteredRows = table.rows;

  const pagedRows = useMemo(
    () => filteredRows.slice(page * pageSize, page * pageSize + pageSize),
    [filteredRows, page, pageSize]
  );

  const openCreate = () => {
    setEditingRow(null);
    setReadOnly(false);
    setFormKey((k) => k + 1);
    setView('form');
  };

  const backToList = () => {
    setView('list');
    setEditingRow(null);
    setReadOnly(false);
  };

  const handleView = (row) => {
    setEditingRow(row);
    setReadOnly(true);
    setFormKey((k) => k + 1);
    setView('form');
  };

  const handleEdit = (row) => {
    setEditingRow(row);
    setReadOnly(false);
    setFormKey((k) => k + 1);
    setView('form');
    setRowMenuAnchor(null);
  };

  const handlePrint = (row) => {
    setRowMenuAnchor(null);
    handleView(row);
    setTimeout(() => window.print(), 300);
  };

  const handleDelete = async (row) => {
    setRowMenuAnchor(null);
    const ok = await confirmDialog({
      title: 'Delete stock transfer',
      message: `Are you sure you want to delete "${row.transferNo}"? This cannot be undone.`,
      confirmLabel: 'Delete',
      severity: 'error',
    });
    if (!ok) return;
    try {
      await remove(row.id).unwrap();
      notify.success('Stock transfer deleted');
    } catch (err) {
      notify.error(err?.data?.message || 'Delete failed');
    }
  };

  const removeSelected = async () => {
    const ok = await confirmDialog({
      title: 'Delete selected transfers',
      message: `Delete ${checkedIds.length} selected transfer${checkedIds.length > 1 ? 's' : ''}? This cannot be undone.`,
      confirmLabel: 'Delete',
      severity: 'error',
    });
    if (!ok) return;
    try {
      await Promise.all(checkedIds.map((id) => remove(id).unwrap()));
      notify.success('Selected transfers deleted');
      setCheckedIds([]);
    } catch (err) {
      notify.error(err?.data?.message || 'Delete failed');
    }
  };

  const handleSubmit = async (values, formMethods) => {
    const payload = { ...values, status: pendingStatusRef.current };
    try {
      if (editingRow) {
        await update({ id: editingRow.id, ...payload }).unwrap();
        notify.success('Stock transfer updated');
      } else {
        await create(payload).unwrap();
        notify.success('Stock transfer saved');
      }
      backToList();
    } catch (err) {
      notify.error(applyServerErrors(err, formMethods.setError));
    }
  };

  const dateRangeLabel = dateFrom && dateTo
    ? `${dateFrom.format('DD/MM/YYYY')} - ${dateTo.format('DD/MM/YYYY')}`
    : 'Select date range';

  return (
    <Box>
      <EntityHeaderCard
        icon={<SwapHorizOutlinedIcon />}
        title="Stock Transfer"
        subtitle={view === 'form' ? 'Move stock from one warehouse to another.' : 'Manage and track all stock transfers.'}
        rightContent={<CompanyBadge />}
      />

      {view === 'form' ? (
        <AppForm
          key={formKey}
          schema={stockTransferSchema}
          defaultValues={editingRow ? rowToFormValues(editingRow) : getEmptyValues()}
          onSubmit={handleSubmit}
        >
          {(methods) => {
            const { control, watch, setValue } = methods;
            const { fields, append, remove: removeItem } = useFieldArray({ control, name: 'items' });
            const watchedItems = watch('items') || [];
            const totals = computeTotals(watchedItems);
            const partyCode = watch('partyCode');
            const branch = watch('branch');
            const fromWarehouse = watch('fromWarehouse');
            const toWarehouse = watch('toWarehouse');
            const [tab, setTab] = useState(0);

            // Every warehouse dropdown on this document — header From/To and
            // each item row's own From/To — draws from the same branch-scoped
            // list. With no branch chosen yet there is nothing to offer.
            const branchWarehouseOptions = useMemo(
              () => warehouseOptionsForBranch(allWarehouses, branch, null),
              [allWarehouses, branch]
            );

            const handleFile = (file) => {
              if (file) setValue('attachmentName', file.name, { shouldValidate: true });
            };

            // Switching Branch invalidates any warehouse choice — header or
            // per-row — that doesn't belong to the new branch; a warehouse
            // picked under one branch has no meaning under another. Skipped on
            // the very first render so loading an existing record for
            // edit/view doesn't wipe values it just loaded.
            const prevBranchRef = useRef(branch);
            useEffect(() => {
              if (prevBranchRef.current === branch) return;
              prevBranchRef.current = branch;
              const allowed = new Set(
                (allWarehouses || []).filter((w) => !branch || w.branch === branch).map((w) => w.whsCode)
              );
              if (watch('fromWarehouse') && !allowed.has(watch('fromWarehouse'))) setValue('fromWarehouse', '');
              if (watch('toWarehouse') && !allowed.has(watch('toWarehouse'))) setValue('toWarehouse', '');
              (watch('items') || []).forEach((it, idx) => {
                if (it.fromWarehouse && !allowed.has(it.fromWarehouse)) setValue(`items.${idx}.fromWarehouse`, '');
                if (it.toWarehouse && !allowed.has(it.toWarehouse)) setValue(`items.${idx}.toWarehouse`, '');
              });
              // eslint-disable-next-line react-hooks/exhaustive-deps
            }, [branch]);

            // Picking a Business Partner code auto-fills Name / Ship To (and
            // Contact Person, only carried on the Supplier master) — same
            // lookup shape as PaymentReceipt.jsx, just unioned across both
            // masters instead of gated behind a type radio.
            useEffect(() => {
              if (!partyCode) return;
              const c = (customers || []).find((x) => x.customerCode === partyCode);
              if (c) {
                setValue('partyName', c.customerName, { shouldValidate: true });
                setValue('shipTo', c.shippingAddress || '');
                setValue('contactPerson', '');
                return;
              }
              const s = (suppliers || []).find((x) => x.supplierCode === partyCode);
              if (s) {
                setValue('partyName', s.supplierName, { shouldValidate: true });
                setValue('shipTo', s.shippingAddress || '');
                setValue('contactPerson', s.contactPerson || '');
              }
              // eslint-disable-next-line react-hooks/exhaustive-deps
            }, [partyCode]);

            return (
              <>
              <Card variant="outlined" sx={{ mb: 2 }}>
                <CardContent sx={{ p: { xs: 2, sm: 3 } }}>
                  <Stack direction="row" alignItems="center" justifyContent="space-between" flexWrap="wrap" gap={1.5} sx={{ mb: 2 }}>
                    <Typography variant="subtitle1" fontWeight={700}>
                      {readOnly ? 'Business Partner (View Only)' : 'Business Partner'}
                    </Typography>
                    <Button type="button" variant="outlined" color="inherit" startIcon={<ArrowBackIcon />} onClick={backToList}>
                      Back to List
                    </Button>
                  </Stack>

                  <fieldset disabled={readOnly} style={{ border: 0, padding: 0, margin: 0, minWidth: 0, width: '100%', display: 'block' }}>
                    <FormGrid columns={3}>
                      <FormSelect name="partyCode" label="Business Partner" placeholder="Search…" options={partyCodeOptions} />
                      <FormTextField name="partyName" label="Name" disabled />
                      <FormTextField name="contactPerson" label="Contact Person" />
                      <FormTextField name="shipTo" label="Ship To" />
                      <FormTextField name="priceList" label="Price List" />
                      <FormTextField name="project" label="Project" />
                      <FormSelect name="branch" label="Branch *" placeholder="Select branch" options={branchOptions} />
                    </FormGrid>
                  </fieldset>
                </CardContent>
              </Card>

              <Card variant="outlined" sx={{ mb: 2 }}>
                <CardContent sx={{ p: { xs: 2, sm: 3 } }}>
                  <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 2 }}>Transfer Details</Typography>
                  <fieldset disabled={readOnly} style={{ border: 0, padding: 0, margin: 0, minWidth: 0, width: '100%', display: 'block' }}>
                    <FormGrid columns={2}>
                      <FormSelect name="transferType" label="Type *" options={TRANSFER_TYPE_OPTIONS.map((t) => ({ label: t, value: t }))} />
                      <DocumentNoField documentCode="MT" name="transferNo" label="Material Transfer No. *" placeholder="Enter transfer number" isCreate={!editingRow} />
                      <FormDatePicker name="requestDate" label="Request Date *" />
                      <FormDatePicker name="documentDate" label="Document Date *" />
                      <FormSelect
                        name="fromWarehouse"
                        label="From Warehouse *"
                        placeholder={branch ? 'Select warehouse' : 'Select a branch first'}
                        options={branchWarehouseOptions}
                        disabled={!branch}
                      />
                      <FormSelect
                        name="toWarehouse"
                        label="To Warehouse *"
                        placeholder={branch ? 'Select warehouse' : 'Select a branch first'}
                        options={branchWarehouseOptions}
                        disabled={!branch}
                      />
                      <FormSelect name="status" label="Status *" disabled options={STOCK_TRANSFER_STATUS_OPTIONS.map((s) => ({ label: s, value: s }))} />

                    </FormGrid>
                  </fieldset>
                </CardContent>
              </Card>

              <fieldset disabled={readOnly} style={{ border: 0, padding: 0, margin: 0, minWidth: 0, width: '100%', display: 'block' }}>
                <Card variant="outlined" sx={{ mb: 2 }}>
                  <CardContent sx={{ p: { xs: 2, sm: 3 } }}>
                    <Tabs value={tab} onChange={(_e, v) => setTab(v)} sx={{ mb: 2, borderBottom: 1, borderColor: 'divider' }}>
                      <Tab label="Contents" />
                      <Tab label="Attachments" />
                    </Tabs>

                    {tab === 0 && (
                      <>
                        <Stack direction="row" alignItems="center" justifyContent="space-between" sx={{ mb: 2 }}>
                          <Typography variant="subtitle1" fontWeight={700}>Item Details</Typography>
                          <Button
                            type="button"
                            variant="outlined"
                            size="small"
                            startIcon={<AddIcon />}
                            onClick={() => append({ ...emptyItem, fromWarehouse, toWarehouse })}
                          >
                            Add Item
                          </Button>
                        </Stack>

                        {isMobile ? (
                          <Box>
                            {fields.map((field, index) => {
                              const qty = Number(watch(`items.${index}.quantity`)) || 0;
                              const price = Number(watch(`items.${index}.unitPrice`)) || 0;
                              return (
                                <MobileItemCard
                                  key={field.id}
                                  index={index}
                                  amount={round2(qty * price).toFixed(2)}
                                  onRemove={() => removeItem(index)}
                                  removeDisabled={fields.length <= 1}
                                >
                                  <ProductCell index={index} methods={methods} options={productCodeOptions} products={products} label="Item No. *" placeholder="Select item" />
                                  <ProductCell index={index} methods={methods} options={productNameOptions} products={products} label="Name *" placeholder="Select item" />
                                  <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', columnGap: 1.5, rowGap: 1.5 }}>
                                    <FormSelect name={`items.${index}.fromWarehouse`} label="From Whse *" placeholder={branch ? 'Select' : 'Select branch first'} options={branchWarehouseOptions} disabled={!branch} />
                                    <FormSelect name={`items.${index}.toWarehouse`} label="To Whse *" placeholder={branch ? 'Select' : 'Select branch first'} options={branchWarehouseOptions} disabled={!branch} />
                                    <TotalStockCell index={index} methods={methods} label="Total Stock" />
                                    <FormTextField name={`items.${index}.uom`} label="UoM Code *" placeholder="UoM" />
                                    <FormTextField name={`items.${index}.quantity`} label="Quantity *" type="number" />
                                    <FormTextField name={`items.${index}.unitPrice`} label="Unit Price" type="number" />
                                    <FormTextField name={`items.${index}.itemCost`} label="Item Cost" type="number" />
                                    <FormSelect name={`items.${index}.accountCode`} label="Account Code" placeholder="Select account" options={accountOptions} />
                                    <FormTextField name={`items.${index}.project`} label="Project" />
                                    <Box sx={{ gridColumn: '1 / -1' }}>
                                      <FormTextField name={`items.${index}.remarks`} label="Remarks" placeholder="Enter remarks" />
                                    </Box>
                                  </Box>
                                </MobileItemCard>
                              );
                            })}
                          </Box>
                        ) : (
                        <TableContainer ref={itemScrollRef} sx={{ overflowX: 'auto', WebkitOverflowScrolling: 'touch', cursor: 'grab', ...dragScrollbarSx }}>
                          <Table size="small" sx={{ '& tbody .MuiFormHelperText-root': { display: 'none' } }}>
                            <TableHead>
                              <TableRow>
                                <TableCell width={40}>#</TableCell>
                                <TableCell sx={{ minWidth: 180 }}>Item No. *</TableCell>
                                <TableCell sx={{ minWidth: 200 }}>Name *</TableCell>
                                <TableCell sx={{ minWidth: 150 }}>From Whse *</TableCell>
                                <TableCell sx={{ minWidth: 150 }}>To Whse *</TableCell>
                                <TableCell sx={{ minWidth: 110 }}>Total Stock</TableCell>
                                <TableCell sx={{ minWidth: 110 }}>Quantity *</TableCell>
                                <TableCell sx={{ minWidth: 110 }}>UoM Code *</TableCell>
                                <TableCell sx={{ minWidth: 110 }}>Unit Price</TableCell>
                                <TableCell sx={{ minWidth: 110 }}>Item Cost</TableCell>
                                <TableCell sx={{ minWidth: 110 }}>Total (LC)</TableCell>
                                <TableCell sx={{ minWidth: 160 }}>Account Code</TableCell>
                                <TableCell sx={{ minWidth: 130 }}>Project</TableCell>
                                <TableCell sx={{ minWidth: 150 }}>Remarks</TableCell>
                                <TableCell width={48}>Action</TableCell>
                              </TableRow>
                            </TableHead>
                            <TableBody>
                              {fields.map((field, index) => {
                                const qty = Number(watch(`items.${index}.quantity`)) || 0;
                                const price = Number(watch(`items.${index}.unitPrice`)) || 0;
                                return (
                                  <TableRow key={field.id} sx={{ '& > td': { verticalAlign: 'middle' } }}>
                                    <TableCell>{index + 1}</TableCell>
                                    <TableCell>
                                      <ProductCell index={index} methods={methods} options={productCodeOptions} products={products} placeholder="Select item" sx={{ minWidth: 180 }} />
                                    </TableCell>
                                    <TableCell>
                                      <ProductCell index={index} methods={methods} options={productNameOptions} products={products} placeholder="Select item" sx={{ minWidth: 200 }} />
                                    </TableCell>
                                    <TableCell>
                                      <FormSelect
                                        name={`items.${index}.fromWarehouse`}
                                        label=""
                                        placeholder={branch ? 'Select' : 'Select branch first'}
                                        options={branchWarehouseOptions}
                                        disabled={!branch}
                                        sx={{ minWidth: 150 }}
                                      />
                                    </TableCell>
                                    <TableCell>
                                      <FormSelect
                                        name={`items.${index}.toWarehouse`}
                                        label=""
                                        placeholder={branch ? 'Select' : 'Select branch first'}
                                        options={branchWarehouseOptions}
                                        disabled={!branch}
                                        sx={{ minWidth: 150 }}
                                      />
                                    </TableCell>
                                    <TableCell>
                                      <TotalStockCell index={index} methods={methods} />
                                    </TableCell>
                                    <TableCell>
                                      <FormTextField name={`items.${index}.quantity`} label="" type="number" />
                                    </TableCell>
                                    <TableCell>
                                      <FormTextField name={`items.${index}.uom`} label="" placeholder="UoM" />
                                    </TableCell>
                                    <TableCell>
                                      <FormTextField name={`items.${index}.unitPrice`} label="" type="number" />
                                    </TableCell>
                                    <TableCell>
                                      <FormTextField name={`items.${index}.itemCost`} label="" type="number" />
                                    </TableCell>
                                    <TableCell sx={{ whiteSpace: 'nowrap' }}>{round2(qty * price).toFixed(2)}</TableCell>
                                    <TableCell>
                                      <FormSelect name={`items.${index}.accountCode`} label="" placeholder="Select account" options={accountOptions} />
                                    </TableCell>
                                    <TableCell>
                                      <FormTextField name={`items.${index}.project`} label="" placeholder="Project" />
                                    </TableCell>
                                    <TableCell>
                                      <FormTextField name={`items.${index}.remarks`} label="" placeholder="Remarks" />
                                    </TableCell>
                                    <TableCell>
                                      <IconButton
                                        type="button"
                                        size="small"
                                        color="error"
                                        onClick={() => removeItem(index)}
                                        disabled={fields.length <= 1}
                                        aria-label="remove item"
                                      >
                                        <DeleteIcon fontSize="small" />
                                      </IconButton>
                                    </TableCell>
                                  </TableRow>
                                );
                              })}
                            </TableBody>
                          </Table>
                        </TableContainer>
                        )}
                      </>
                    )}

                    {tab === 1 && (
                      <Box>
                        <Typography variant="body2" sx={{ mb: 0.5 }}>Attach Document</Typography>
                        <Button component="label" variant="outlined" size="small">
                          Choose File
                          <input type="file" hidden onChange={(e) => handleFile(e.target.files?.[0])} />
                        </Button>
                        {watch('attachmentName') && (
                          <Chip
                            sx={{ ml: 1.5 }}
                            size="small"
                            label={watch('attachmentName')}
                            onDelete={() => setValue('attachmentName', '')}
                          />
                        )}
                      </Box>
                    )}
                  </CardContent>
                </Card>
              </fieldset>

              <Card variant="outlined">
                <CardContent sx={{ p: { xs: 2, sm: 3 } }}>
                  <fieldset disabled={readOnly} style={{ border: 0, padding: 0, margin: 0, minWidth: 0, width: '100%', display: 'block' }}>
                    <Grid container spacing={3}>
                      <Grid item xs={12} md={4}>
                        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1 }}>Prepared By *</Typography>
                        <FormSelect name="preparedBy" label="" placeholder="Select user" options={preparedByOptions} />
                      </Grid>
                      <Grid item xs={12} md={4}>
                        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1 }}>Journal Remarks</Typography>
                        <FormTextField name="journalRemarks" label="" placeholder="Enter journal remarks (optional)" multiline rows={3} />
                      </Grid>
                      <Grid item xs={12} md={4}>
                        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1 }}>Remarks</Typography>
                        <FormTextField name="remarks" label="" placeholder="Enter any remarks (optional)" multiline rows={3} />
                      </Grid>
                    </Grid>

                    <Grid container spacing={3} sx={{ mt: 0.5 }}>
                      <Grid item xs={12} md={5}>
                        <Box sx={{ border: '1px solid', borderColor: 'divider', borderRadius: 1.5, p: 2.5 }}>
                          <Typography variant="body2" color="text.secondary">Total Transfer Value (₹)</Typography>
                          <Typography variant="h5" fontWeight={700}>₹{totals.amount.toFixed(2)}</Typography>
                        </Box>
                      </Grid>
                    </Grid>
                  </fieldset>

                  <Stack
                    direction={{ xs: 'column', sm: 'row' }}
                    spacing={1.5}
                    justifyContent={{ xs: 'stretch', sm: 'flex-end' }}
                    sx={{ mt: 3 }}
                  >
                    <Button fullWidth={isMobile} type="button" variant="outlined" color="inherit" startIcon={<CloseIcon />} onClick={backToList} disabled={creating || updating}>
                      Cancel
                    </Button>
                    {!readOnly && (
                      <>
                        <FormSubmitButton
                          fullWidth={isMobile}
                          variant="outlined"
                          onClick={() => { pendingStatusRef.current = 'Draft'; }}
                          disabled={creating || updating}
                        >
                          Save as Draft
                        </FormSubmitButton>
                        <FormSubmitButton
                          fullWidth={isMobile}
                          onClick={() => { pendingStatusRef.current = 'Posted'; }}
                          disabled={creating || updating}
                        >
                          {editingRow ? 'Update Transfer' : 'Save & Post Transfer'}
                        </FormSubmitButton>
                      </>
                    )}
                  </Stack>
                </CardContent>
              </Card>
              </>
            );
          }}
        </AppForm>
      ) : (
        <Card variant="outlined">
          <CardContent sx={{ p: 0 }}>
            <Stack
              direction={{ xs: 'column', sm: 'row' }}
              alignItems={{ xs: 'stretch', sm: 'center' }}
              justifyContent="space-between"
              flexWrap="wrap"
              gap={1.5}
              sx={{ px: { xs: 2, sm: 3 }, pt: 2.5, pb: 1.5 }}
            >
              <Typography variant="subtitle1" fontWeight={700}>Stock Transfer List</Typography>
              <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.5} flexWrap="wrap" useFlexGap sx={{ width: { xs: '100%', sm: 'auto' } }}>
                <TableSearchFilter table={table} placeholder="Search by transfer no..." showFilter={false} />
                <Stack direction="row" spacing={1.5}>
                  <Button size="small" variant="outlined" color="inherit" startIcon={<FilterListIcon />} onClick={() => setShowFilters((v) => !v)} sx={{ whiteSpace: 'nowrap', flexShrink: 0 }}>
                    Filter
                  </Button>
                  <CanAdd>
                    <Button size="small" variant="contained" startIcon={<AddIcon />} onClick={openCreate} sx={{ whiteSpace: 'nowrap', flexShrink: 0 }}>
                      Create Transfer
                    </Button>
                  </CanAdd>
                </Stack>
              </Stack>
            </Stack>

            <Collapse in={showFilters} unmountOnExit>
            <Box sx={{ px: { xs: 2, sm: 3 }, pb: 2 }}>
              <FormGrid columns={4}>
                <Autocomplete
                  size="small"
                  options={TYPE_FILTERS}
                  value={typeFilter}
                  onChange={(_e, v) => { setTypeFilter(v || 'All Types'); setPage(0); }}
                  disableClearable
                  renderInput={(params) => <TextField {...params} label="Type" InputLabelProps={{ shrink: true }} />}
                />
                <Autocomplete
                  size="small"
                  options={STATUS_FILTERS}
                  value={statusFilter}
                  onChange={(_e, v) => { setStatusFilter(v || 'All Status'); setPage(0); }}
                  disableClearable
                  renderInput={(params) => <TextField {...params} label="Status" InputLabelProps={{ shrink: true }} />}
                />
                <TextField
                  size="small"
                  fullWidth
                  label="Date Range"
                  value={dateRangeLabel}
                  onClick={(e) => setDateAnchor(e.currentTarget)}
                  InputProps={{
                    readOnly: true,
                    startAdornment: <InputAdornment position="start"><EventIcon fontSize="small" /></InputAdornment>,
                    endAdornment: (dateFrom || dateTo) ? (
                      <InputAdornment position="end">
                        <IconButton size="small" onClick={(e) => { e.stopPropagation(); setDateFrom(null); setDateTo(null); setPage(0); }}>
                          <CloseIcon fontSize="small" />
                        </IconButton>
                      </InputAdornment>
                    ) : null,
                  }}
                  InputLabelProps={{ shrink: true }}
                  sx={{ cursor: 'pointer' }}
                />
                <FilterAutocomplete
                  label="Warehouse"
                  allLabel="All Warehouses"
                  options={allWarehouseOptions}
                  value={warehouseFilter}
                  onChange={(v) => { setWarehouseFilter(v); setPage(0); }}
                />
              </FormGrid>

              <Popover
                open={!!dateAnchor}
                anchorEl={dateAnchor}
                onClose={() => setDateAnchor(null)}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
              >
                <Stack direction="row" spacing={2} sx={{ p: 2 }}>
                  <DatePicker label="From" value={dateFrom} onChange={(v) => { setDateFrom(v); setPage(0); }} slotProps={{ textField: { size: 'small' } }} />
                  <DatePicker label="To" value={dateTo} onChange={(v) => { setDateTo(v); setPage(0); }} slotProps={{ textField: { size: 'small' } }} />
                </Stack>
              </Popover>
              <TableFilterPanel table={table} embedded open />
            </Box>
            </Collapse>

            {checkedIds.length > 0 && (
              <Box sx={{ px: { xs: 2, sm: 3 }, pb: 1.5 }}>
                <Button variant="outlined" color="error" size="small" startIcon={<DeleteIcon />} onClick={removeSelected}>
                  Delete Selected ({checkedIds.length})
                </Button>
              </Box>
            )}

            {isMobile ? (
              <Box sx={{ px: 2, pb: 1 }}>
                {!isLoading && pagedRows.map((row) => (
                  <MobileRecordCard
                    key={row.id}
                    title={row.transferNo}
                    statusChip={<Chip size="small" label={row.status} color={STATUS_COLORS[row.status] || 'default'} variant="outlined" />}
                    fields={[
                      { label: 'Type', value: row.transferType || '—' },
                      { label: 'Request Date', value: row.requestDate ? dayjs(row.requestDate).format('DD/MM/YYYY') : '—' },
                      { label: 'From Warehouse', value: warehouseLabel(row.fromWarehouse) || '—' },
                      { label: 'To Warehouse', value: warehouseLabel(row.toWarehouse) || '—' },
                      { label: 'Amount', value: `₹${Number(row.amount).toFixed(2)}` },
                    ]}
                    onEdit={() => handleEdit(row)}
                    onDelete={() => handleDelete(row)}
                  />
                ))}
                {!isLoading && filteredRows.length === 0 && (
                  <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>No stock transfers found</Typography>
                )}
              </Box>
            ) : (
              <ScrollableTableContainer>
                <Table size="small" stickyHeader>
                  <TableHead>
                    <TableRow>
                      <SortableHeaderCell field="id" sort={table.sort} onSort={table.toggleSort} padding="checkbox">
                        <Checkbox
                          size="small"
                          checked={pagedRows.length > 0 && pagedRows.every((r) => checkedIds.includes(r.id))}
                          indeterminate={pagedRows.some((r) => checkedIds.includes(r.id)) && !pagedRows.every((r) => checkedIds.includes(r.id))}
                          onChange={(e) => {
                            const ids = pagedRows.map((r) => r.id);
                            setCheckedIds((prev) => e.target.checked
                              ? Array.from(new Set([...prev, ...ids]))
                              : prev.filter((c) => !ids.includes(c)));
                          }}
                        />
                      </SortableHeaderCell>
                      <TableCell width={40}>#</TableCell>
                      <SortableHeaderCell field="transferNo" sort={table.sort} onSort={table.toggleSort}>Material Transfer No.</SortableHeaderCell>
                      <SortableHeaderCell field="transferType" sort={table.sort} onSort={table.toggleSort}>Type</SortableHeaderCell>
                      <SortableHeaderCell field="requestDate" sort={table.sort} onSort={table.toggleSort}>Request Date</SortableHeaderCell>
                      <SortableHeaderCell field="fromWarehouse" sort={table.sort} onSort={table.toggleSort}>From Warehouse</SortableHeaderCell>
                      <SortableHeaderCell field="toWarehouse" sort={table.sort} onSort={table.toggleSort}>To Warehouse</SortableHeaderCell>
                      <SortableHeaderCell field="amount" sort={table.sort} onSort={table.toggleSort}>Amount (₹)</SortableHeaderCell>
                      <SortableHeaderCell field="status" sort={table.sort} onSort={table.toggleSort}>Status</SortableHeaderCell>
                      <TableCell align="right">Action</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {!isLoading && pagedRows.map((row, i) => (
                      <TableRow key={row.id} hover>
                        <TableCell padding="checkbox">
                          <Checkbox
                            size="small"
                            checked={checkedIds.includes(row.id)}
                            onChange={() => setCheckedIds((prev) => prev.includes(row.id) ? prev.filter((c) => c !== row.id) : [...prev, row.id])}
                          />
                        </TableCell>
                        <TableCell>{page * pageSize + i + 1}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.transferNo}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.transferType || '—'}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.requestDate ? dayjs(row.requestDate).format('DD/MM/YYYY') : '—'}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{warehouseLabel(row.fromWarehouse) || '—'}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{warehouseLabel(row.toWarehouse) || '—'}</TableCell>
                        <TableCell sx={{ whiteSpace: 'nowrap' }}>{Number(row.amount).toFixed(2)}</TableCell>
                        <TableCell>
                          <Chip size="small" label={row.status} color={STATUS_COLORS[row.status] || 'default'} variant="outlined" />
                        </TableCell>
                        <TableCell align="right">
                          <Stack direction="row" spacing={0.5} justifyContent="flex-end">
                            <Tooltip title="View">
                              <IconButton size="small" onClick={() => handleView(row)} aria-label="view">
                                <VisibilityOutlinedIcon fontSize="small" />
                              </IconButton>
                            </Tooltip>
                            <Tooltip title="Print">
                              <IconButton size="small" onClick={() => handlePrint(row)} aria-label="print">
                                <PrintOutlinedIcon fontSize="small" />
                              </IconButton>
                            </Tooltip>
                            <IconButton
                              size="small"
                              onClick={(e) => { setRowMenuAnchor(e.currentTarget); setRowMenuTarget(row); }}
                              aria-label="more actions"
                            >
                              <MoreVertIcon fontSize="small" />
                            </IconButton>
                          </Stack>
                        </TableCell>
                      </TableRow>
                    ))}
                    {!isLoading && filteredRows.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={10}>
                          <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>No stock transfers found</Typography>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </ScrollableTableContainer>
            )}

            <Menu anchorEl={rowMenuAnchor} open={!!rowMenuAnchor} onClose={() => setRowMenuAnchor(null)}>
              <CanEdit>
                <MenuItem onClick={() => handleEdit(rowMenuTarget)}>
                  <ListItemIcon><EditIcon fontSize="small" /></ListItemIcon>
                  <ListItemText>Edit</ListItemText>
                </MenuItem>
              </CanEdit>
              <CanDelete>
                <MenuItem onClick={() => handleDelete(rowMenuTarget)}>
                  <ListItemIcon><DeleteIcon fontSize="small" color="error" /></ListItemIcon>
                  <ListItemText>Delete</ListItemText>
                </MenuItem>
              </CanDelete>
            </Menu>

            <EntityListPagination total={filteredRows.length} page={page} onChange={setPage} pageSize={pageSize} onPageSizeChange={(v) => { setPageSize(v); setPage(0); }} />
          </CardContent>
        </Card>
      )}
    </Box>
  );
}

// Isolated so the per-row product-select auto-fill effect only re-runs for
// the row whose product actually changed, not every row on every keystroke.
// Total Stock is pre-filled from the product's current opening stock (the
// same company-wide, not warehouse-scoped, approximation Stock Adjustment
// uses) — the authoritative figure used for the negative-stock guard is
// recomputed server-side from the live ledger at save time regardless of
// what is shown here. Unit Price/Item Cost are filled from the product's
// cost price so the transfer can be costed; both stay editable.
function ProductCell({ index, methods, options, products, label = '', placeholder = 'Select item', sx }) {
  const { watch, setValue } = methods;
  const productCodeValue = watch(`items.${index}.productCode`);
  const prevValue = useRef(productCodeValue);

  useEffect(() => {
    if (productCodeValue !== prevValue.current) {
      const found = (products || []).find((p) => p.productCode === productCodeValue);
      if (found) {
        setValue(`items.${index}.productName`, found.productName, { shouldValidate: true });
        setValue(`items.${index}.uom`, found.uom || '', { shouldValidate: true });
        // Total Stock is no longer set from here — it's warehouse-scoped now
        // (see TotalStockCell below), and a product change alone doesn't
        // determine it without also knowing the row's From Warehouse.
        const cost = found.costPrice != null ? Number(found.costPrice) : 0;
        setValue(`items.${index}.unitPrice`, cost, { shouldValidate: true });
        setValue(`items.${index}.itemCost`, cost, { shouldValidate: true });
      }
      prevValue.current = productCodeValue;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [productCodeValue]);

  return <FormSelect name={`items.${index}.productCode`} label={label} placeholder={placeholder} options={options} sx={sx} />;
}

// Total Stock is the row's own From Warehouse position for the row's own
// product — genuinely warehouse-scoped, not the company-wide approximation
// Stock Adjustment uses, because a transfer's whole point is moving stock out
// of ONE specific warehouse, and a company-wide figure could show plenty of
// stock while the actual From Warehouse has none. Reuses Product Master's
// Inventory tab endpoint (utils/productInventory.js), which already derives
// on-hand per warehouse from the same movement ledger the rest of the app
// reads — no new backend endpoint needed.
function TotalStockCell({ index, methods, label = '' }) {
  const { watch, setValue } = methods;
  const productCode = watch(`items.${index}.productCode`);
  const fromWarehouse = watch(`items.${index}.fromWarehouse`);
  const { data: inventory } = useGetProductInventoryQuery(productCode, { skip: !productCode });

  useEffect(() => {
    if (!productCode || !fromWarehouse) return;
    if (!inventory) return;
    const row = (inventory.rows || []).find((r) => r.warehouseCode === fromWarehouse);
    setValue(`items.${index}.totalStock`, row ? Number(row.onHand) || 0 : 0, { shouldValidate: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [productCode, fromWarehouse, inventory]);

  return <FormTextField name={`items.${index}.totalStock`} label={label} type="number" disabled />;
}
