import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Box, Typography, Button, Card, CardContent, Stack, Table, TableBody, TableCell, TableHead,
  TableRow, Chip, IconButton, Menu, MenuItem, ListItemIcon, ListItemText, Tabs, Tab, Grid,
  Divider, Collapse,
} from '@mui/material';
import Inventory2OutlinedIcon from '@mui/icons-material/Inventory2Outlined';
import AddIcon from '@mui/icons-material/Add';
import CloseIcon from '@mui/icons-material/Close';
import SearchIcon from '@mui/icons-material/Search';
import FilterListIcon from '@mui/icons-material/FilterList';
import EditIcon from '@mui/icons-material/EditOutlined';
import DeleteIcon from '@mui/icons-material/DeleteOutline';
import CheckIcon from '@mui/icons-material/Check';
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import { z } from 'zod';
import AppForm, { FormGrid, FormSubmitButton } from '../../components/form/AppForm';
import FormTextField from '../../components/form/FormTextField';
import FormSelect from '../../components/form/FormSelect';
import { FormCheckbox } from '../../components/form/FormCheckbox';
import EntityHeaderCard from '../../components/common/EntityHeaderCard';
import CompanyBadge from '../../components/common/CompanyBadge';
import EntityListPagination from '../../components/data-display/EntityListPagination';
import MobileRecordCard from '../../components/data-display/MobileRecordCard';
import { useIsMobileListView } from '../../components/data-display/useIsMobileListView';
import useDragScroll from '../../components/data-display/useDragScroll';
import { useNotify } from '../../components/feedback/NotificationProvider';
import { applyServerErrors } from '../../lib/formErrors';
import { useConfirm } from '../../components/feedback/ConfirmationDialog';
import { productSchema } from '../../lib/validation/productSchemas';
import {
  productApi, productGroupApi, productSubGroupApi, brandApi, uomApi, taxCodeApi, supplierApi,
  useGetProductCurrentStockQuery,
} from '../../features/resources';
import useTableFeatures from '../../components/data-display/useTableFeatures';
import TableSearchFilter from '../../components/data-display/TableSearchFilter';
import SortableHeaderCell from '../../components/data-display/SortableHeaderCell';
import ScrollableTableContainer from '../../components/data-display/ScrollableTableContainer';
import DocumentNoField from '../../components/form/DocumentNoField';
import ProductInventoryTab from './ProductInventoryTab';
import { useWarehouseOptions } from '../../lib/useWarehouseOptions';

import { CanAdd, CanEdit, CanDelete } from '../../components/common/PermissionGate';
import TableFilterPanel from '../../components/data-display/TableFilterPanel';
// Local schema — the list's "Active" state is exposed as a checkbox rather
// than the shared Active/Inactive select, so swap the shared `status` enum
// for a boolean `active` field here and translate it back on submit.
const productDetailsSchema = productSchema
  .omit({ status: true })
  .extend({ active: z.boolean().optional() });

const emptyValues = {
  productCode: '', productName: '', barcode: '', productGroup: '', productSubGroup: '', brand: '',
  productType: '', uom: '', salesUom: '', hsnCode: '', taxCode: '', taxRateType: '', taxRate: 0,
  calculationMethod: 'None',
  costPrice: 0, salesPrice: 0, minSalesPrice: 0, openingStock: 0, reorderLevel: 0,
  expiryApplicable: false, defaultSupplier: '', defaultLocation: '', rackNo: '',
  description: '', remarks: '', active: true,
};

const PRODUCT_TYPE_OPTIONS = [
  { label: 'Raw Material', value: 'Raw Material' },
  { label: 'Semi-Finished Goods', value: 'Semi-Finished Goods' },
  { label: 'Finished Goods', value: 'Finished Goods' },
  { label: 'Trading Goods', value: 'Trading Goods' },
  { label: 'Service', value: 'Service' },
  { label: 'Consumable', value: 'Consumable' },
  { label: 'Other', value: 'Other' },
];

const TAX_RATE_TYPE_OPTIONS = [
  { label: 'Regular', value: 'Regular' },
  { label: 'Composition', value: 'Composition' },
  { label: 'Exempt', value: 'Exempt' },
  { label: 'Nil-rated', value: 'Nil-rated' },
  { label: 'Zero-rated', value: 'Zero-rated' },
];

const EXPIRY_OPTIONS = [
  { label: 'Yes', value: true },
  { label: 'No', value: false },
];

// Inventory costing method. Picking FIFO or Moving Average makes each of this
// product's stock movements store its unit cost under that method in the
// stock journal's FIFO / MAV columns — a background record only, not shown
// anywhere in the app. 'None' stores neither. No other calculation in the
// application is affected by this choice.
const CALCULATION_METHOD_OPTIONS = [
  { label: 'None', value: 'None' },
  { label: 'FIFO', value: 'FIFO' },
  { label: 'Moving Average', value: 'Moving Average' },
];

const PAGE_SIZE = 10;
const STATUS_FILTERS = ['All', 'Active', 'Inactive'];

export default function ProductMaster() {
  const notify = useNotify();
  const confirmDialog = useConfirm();
  const isMobile = useIsMobileListView();
  const { data: products, isLoading } = productApi.useList();
  const { data: currentStockByCode } = useGetProductCurrentStockQuery();
  const [create, { isLoading: creating }] = productApi.useCreate();
  const [update, { isLoading: updating }] = productApi.useUpdate();
  const [remove] = productApi.useDelete();

  const { data: productGroups } = productGroupApi.useList();
  const { data: productSubGroups } = productSubGroupApi.useList();
  const { data: brands } = brandApi.useList();
  const { data: uoms } = uomApi.useList();
  const { data: taxCodes } = taxCodeApi.useList();
  const { data: suppliers } = supplierApi.useList();

  const productGroupOptions = (productGroups || []).map((g) => ({ label: g.groupName, value: g.groupName }));
  const brandOptions = (brands || []).map((b) => ({ label: b.brandName, value: b.brandName }));
  const uomOptions = (uoms || []).map((u) => ({ label: u.uomName, value: u.uomName }));
  const supplierOptions = (suppliers || []).map((s) => ({ label: s.supplierName, value: s.supplierName }));
  const taxCodeOptions = (taxCodes || []).map((t) => ({
    label: t.taxRate != null ? `${t.taxName} (${Number(t.taxRate)}%)` : t.taxName,
    value: t.taxCode,
    rate: t.taxRate != null ? Number(t.taxRate) : 0,
  }));

  // Form is hidden by default -- it expands in a Collapse ABOVE the list
  // (which stays visible) when "Add Product" or an edit action is
  // triggered, per the inline form template (Payment Entry/Deposit Entry),
  // instead of swapping the whole page out for a separate form view.
  const [showForm, setShowForm] = useState(false);
  const [editingRow, setEditingRow] = useState(null);
  const [readOnly, setReadOnly] = useState(false);
  const { options: warehouseOptions } = useWarehouseOptions({
    currentValue: editingRow?.defaultLocation,
  });
  const [formKey, setFormKey] = useState(0);
  const [tab, setTab] = useState(0);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [filterAnchor, setFilterAnchor] = useState(null);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(PAGE_SIZE);

  // "Stock" in the list shows live current stock (opening stock plus every
  // posted Stock Receipt/Issue/Adjustment), not just the static opening-stock
  // field entered on the product record. Falls back to openingStock while
  // the current-stock lookup is still loading.
  const rows = (products || []).map((p) => ({
    ...p,
    currentStock: currentStockByCode?.[p.productCode] ?? p.openingStock,
  }));

  const baseTableRows = useMemo(() => {
    const q = '';
    return rows.filter((r) => {
      const matchesSearch = !q || [r.productCode, r.productName, r.productGroup, r.brand]
        .some((v) => String(v || '').toLowerCase().includes(q));
      const matchesStatus = statusFilter === 'All' || r.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [rows, statusFilter]);

  // Column definitions drive the global search, the sort icons and the filter
  // popover — see components/data-display/useTableFeatures.js.
  const tableColumns = useMemo(() => ([
    { field: 'productCode', headerName: 'Product Code', filter: 'text' },
    { field: 'productName', headerName: 'Product Name', filter: 'text' },
    { field: 'productGroup', headerName: 'Group', filter: 'text' },
    { field: 'brand', headerName: 'Brand', filter: 'text' },
    { field: 'salesPrice', headerName: 'Sales Price', filter: 'numberRange', sortValue: (row) => (row.salesPrice == null || row.salesPrice === '' ? null : Number(row.salesPrice)) },
    { field: 'currentStock', headerName: 'Stock', filter: 'numberRange', sortValue: (row) => (row.currentStock == null || row.currentStock === '' ? null : Number(row.currentStock)) },
    { field: 'status', headerName: 'Status', filter: 'select' },
  ]), []);
  const table = useTableFeatures(baseTableRows, tableColumns, { onChange: setPage });
  const filteredRows = table.rows;

  const pagedRows = useMemo(
    () => filteredRows.slice(page * pageSize, page * pageSize + pageSize),
    [filteredRows, page, pageSize]
  );

  const openCreate = () => {
    setEditingRow(null);
    setReadOnly(false);
    setFormKey((k) => k + 1);
    setTab(0);
    setShowForm(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const closeForm = () => {
    setShowForm(false);
    setEditingRow(null);
  };

  // Read-only look at a record — same form, every field disabled
  // and the save button removed (see AppForm's readOnly prop).
  const handleView = (row) => {
    setEditingRow(row);
    setReadOnly(true);
    setFormKey((k) => k + 1);
    setTab(0);
    setShowForm(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleEdit = (row) => {
    setEditingRow(row);
    setReadOnly(false);
    setFormKey((k) => k + 1);
    setTab(0);
    setShowForm(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = async (row) => {
    const ok = await confirmDialog({
      title: 'Delete product',
      message: `Are you sure you want to delete "${row.productName}"? This cannot be undone.`,
      confirmLabel: 'Delete',
      severity: 'error',
    });
    if (!ok) return;
    try {
      await remove(row.id).unwrap();
      notify.success('Product deleted');
    } catch (err) {
      notify.error(err?.data?.message || 'Delete failed');
    }
  };

  const handleSubmit = async (values, formMethods) => {
    const { active, ...rest } = values;
    const payload = { ...rest, status: active ? 'Active' : 'Inactive' };
    try {
      if (editingRow) {
        await update({ id: editingRow.id, ...payload }).unwrap();
        notify.success('Product updated');
      } else {
        await create(payload).unwrap();
        notify.success('Product added');
      }
      closeForm();
    } catch (err) {
      notify.error(applyServerErrors(err, formMethods.setError));
    }
  };

  return (
    <Box>
      <EntityHeaderCard
        icon={<Inventory2OutlinedIcon />}
        title="Product Master"
        subtitle="Create and manage products."
        rightContent={<CompanyBadge />}
      />

      <Collapse in={showForm} unmountOnExit>
        <Box sx={{ mb: 2 }}>
          <Card variant="outlined">
            <CardContent sx={{ p: 3 }}>
              <Stack direction="row" alignItems="center" justifyContent="space-between" flexWrap="wrap" gap={1.5} sx={{ mb: 1 }}>
                <Typography variant="subtitle1" fontWeight={700}>
                  {readOnly ? 'View Product' : editingRow ? 'Edit Product' : 'Create Product'}
                </Typography>
                <Button variant="outlined" color="inherit" startIcon={<CloseIcon />} onClick={closeForm}>
                  Close
                </Button>
              </Stack>

              <Tabs value={tab} onChange={(_e, v) => setTab(v)} sx={{ mb: 2, borderBottom: 1, borderColor: 'divider' }}>
                <Tab label="Basic Information" />
                <Tab label="Additional Information" />
                {/* Where this product's stock sits, per warehouse. Only
                    meaningful once the product exists — its movements are
                    tracked against a product code that is issued on save — so
                    on create the tab is present but explains itself rather
                    than showing an empty grid. */}
                <Tab label="Inventory" />
              </Tabs>

              <AppForm readOnly={readOnly}
                key={formKey}
                schema={productDetailsSchema}
                defaultValues={editingRow ? {
                  ...emptyValues,
                  ...editingRow,
                  taxRate: editingRow.taxRate != null ? Number(editingRow.taxRate) : 0,
                  costPrice: editingRow.costPrice != null ? Number(editingRow.costPrice) : 0,
                  salesPrice: editingRow.salesPrice != null ? Number(editingRow.salesPrice) : 0,
                  minSalesPrice: editingRow.minSalesPrice != null ? Number(editingRow.minSalesPrice) : 0,
                  openingStock: editingRow.openingStock != null ? Number(editingRow.openingStock) : 0,
                  reorderLevel: editingRow.reorderLevel != null ? Number(editingRow.reorderLevel) : 0,
                  // Products saved before this field existed come back null;
                  // show them as 'None' so the select isn't blank.
                  calculationMethod: editingRow.calculationMethod || 'None',
                  active: editingRow.status === 'Active',
                } : emptyValues}
                onSubmit={handleSubmit}
              >
                {(methods) => {
                  const groupValue = methods.watch('productGroup');
                  const subGroupOptions = (productSubGroups || [])
                    .filter((s) => !groupValue || !s.groupName || s.groupName === groupValue)
                    .map((s) => ({ label: s.subGroupName, value: s.subGroupName }));

                  // Auto-fill the Tax Rate from the selected Tax Applicable
                  // code (still editable), without stomping on a value the
                  // user already entered when the tax code hasn't changed.
                  const taxCodeValue = methods.watch('taxCode');
                  const prevTaxCode = useRef(editingRow ? editingRow.taxCode : null);
                  useEffect(() => {
                    if (taxCodeValue !== prevTaxCode.current) {
                      const found = taxCodeOptions.find((o) => o.value === taxCodeValue);
                      if (found) methods.setValue('taxRate', found.rate, { shouldValidate: true });
                      prevTaxCode.current = taxCodeValue;
                    }
                    // eslint-disable-next-line react-hooks/exhaustive-deps
                  }, [taxCodeValue]);

                  return (
                    <>
                      {tab === 0 && (
                        <>
                          <FormGrid columns={4}>
                            {/* Auto-generated from the perpetual PRD numbering series (hidden
                                from the Document Numbering page — see hiddenFromNumberingUI
                                in documentNumberService.js). The field is filled and locked
                                on create, and left untouched on edit so an existing record's
                                code is never rewritten. */}
                            <DocumentNoField documentCode="PRD" name="productCode" label="Product Code *" isCreate={!editingRow} />
                            <FormTextField name="productName" label="Product Name *" placeholder="Enter product name" />
                            <FormTextField name="barcode" label="Barcode" placeholder="Enter barcode" />
                            <FormSelect name="productGroup" label="Product Group *" placeholder="Select group" options={productGroupOptions} />

                            <FormSelect name="productSubGroup" label="Product Sub-Group" placeholder="Select sub-group" options={subGroupOptions} />
                            <FormSelect name="brand" label="Brand" placeholder="Select brand" options={brandOptions} />
                            <FormSelect name="uom" label="Unit of Measure *" placeholder="Select unit" options={uomOptions} />
                            <FormSelect name="productType" label="Product Type *" placeholder="Select type" options={PRODUCT_TYPE_OPTIONS} />

                            <FormTextField name="hsnCode" label="HSN / SAC Code" placeholder="Enter HSN / SAC code" digitsOnly maxLength={8} />
                            <FormSelect
                              name="taxCode"
                              label="Tax Applicable *"
                              placeholder="Select tax"
                              options={taxCodeOptions}
                            />
                            {/* Read-only: driven entirely by the Tax Applicable selection above
                                (see the taxCodeValue effect below), so this always reflects the
                                Tax Code master's rate rather than a number typed by hand that could
                                drift from whichever tax code is actually selected. */}
                            <FormTextField name="taxRate" label="Tax Rate (%) *" type="number" placeholder="0.00" disabled />
                            <FormTextField name="openingStock" label="Opening Stock" type="number" placeholder="0.00" />

                            <FormTextField name="costPrice" label="Cost Price (Purchase Price) *" type="number" placeholder="0.00" />
                            <FormTextField name="salesPrice" label="Sales Price (MRP) *" type="number" placeholder="0.00" />
                            <FormTextField name="minSalesPrice" label="Min. Sales Price" type="number" placeholder="0.00" />
                            <FormTextField name="reorderLevel" label="Reorder Level" type="number" placeholder="0.00" />

                            <FormSelect name="defaultSupplier" label="Default Supplier" placeholder="Select supplier" options={supplierOptions} />
                            {/* Picked from the Warehouse Master, like every
                                other warehouse field in the app — see
                                lib/useWarehouseOptions.js. It was free text,
                                so each product carried whatever string someone
                                happened to type, and five inventory reports
                                built their whole warehouse filter out of the
                                distinct values of this one column.
                                The product's stored value is passed in so an
                                existing product's typed location survives as a
                                selectable option instead of being blanked. */}
                            <FormSelect
                              name="defaultLocation"
                              label="Default Location / Warehouse *"
                              placeholder="Select warehouse"
                              options={warehouseOptions}
                            />
                            <FormTextField name="rackNo" label="Shelf / Rack No." placeholder="Enter shelf or rack no." />
                            <FormSelect name="expiryApplicable" label="Expiry Applicable" placeholder="Select option" options={EXPIRY_OPTIONS} />
                            <FormSelect name="calculationMethod" label="Valuation Method" placeholder="Select method" options={CALCULATION_METHOD_OPTIONS} />
                          </FormGrid>

                          <Grid container spacing={2} sx={{ mt: 0.5 }}>
                            <Grid item xs={12} md={6}>
                              <FormTextField name="description" label="Product Description" placeholder="Enter product description" multiline rows={3} />
                            </Grid>
                            <Grid item xs={12} md={6}>
                              <FormTextField name="remarks" label="Remarks" placeholder="Enter remarks" multiline rows={3} />
                            </Grid>
                          </Grid>
                        </>
                      )}

                      {tab === 1 && (
                        <FormGrid columns={3}>
                          <FormSelect name="salesUom" label="Sales UOM" placeholder="Select sales unit" options={uomOptions} />
                          <FormSelect name="taxRateType" label="Tax Rate Type" placeholder="Select tax rate type" options={TAX_RATE_TYPE_OPTIONS} />
                        </FormGrid>
                      )}

                      {tab === 2 && (
                        <ProductInventoryTab
                          productCode={editingRow?.productCode}
                          disabled={!editingRow}
                        />
                      )}

                      <Divider sx={{ my: 3 }} />

                      <Stack direction="row" alignItems="center" justifyContent="space-between" flexWrap="wrap" gap={1.5}>
                        <FormCheckbox name="active" label="Active" />
                        <Stack direction="row" spacing={1.5}>
                          <Button variant="outlined" color="inherit" onClick={() => methods.reset(emptyValues)} disabled={creating || updating}>
                            Reset
                          </Button>
                          <FormSubmitButton disabled={creating || updating}>
                            {readOnly ? 'View' : editingRow ? 'Update Product' : 'Save Product'}
                          </FormSubmitButton>
                        </Stack>
                      </Stack>
                    </>
                  );
                }}
              </AppForm>
            </CardContent>
          </Card>
        </Box>
      </Collapse>

      <Card variant="outlined">
        <CardContent sx={{ p: 0 }}>
          <Stack direction="row" alignItems="center" justifyContent="space-between" flexWrap="wrap" gap={1.5} sx={{ px: 3, pt: 2.5, pb: 1.5 }}>
            <Typography variant="subtitle1" fontWeight={700}>Product List</Typography>
            <Stack direction="row" spacing={1.5} flexWrap="wrap" useFlexGap>
              <TableSearchFilter table={table} placeholder="Search products..." width={220} />
              <Button
                variant="outlined"
                color="inherit"
                startIcon={<FilterListIcon />}
                onClick={(e) => setFilterAnchor(e.currentTarget)}
              >
                Filter{statusFilter !== 'All' ? `: ${statusFilter}` : ''}
              </Button>
              <Menu anchorEl={filterAnchor} open={!!filterAnchor} onClose={() => setFilterAnchor(null)}>
                {STATUS_FILTERS.map((s) => (
                  <MenuItem key={s} selected={statusFilter === s} onClick={() => { setStatusFilter(s); setPage(0); setFilterAnchor(null); }}>
                    {statusFilter === s && <ListItemIcon><CheckIcon fontSize="small" /></ListItemIcon>}
                    <ListItemText inset={statusFilter !== s}>{s}</ListItemText>
                  </MenuItem>
                ))}
              </Menu>
              <CanAdd>
                <Button variant="contained" startIcon={<AddIcon />} onClick={openCreate}>
                  Add Product
                </Button>
              </CanAdd>
            </Stack>

            <TableFilterPanel table={table} />
          </Stack>

          {isMobile ? (
            <Box sx={{ px: 2, pb: 1 }}>
              {!isLoading && pagedRows.map((row) => (
                <MobileRecordCard
                  key={row.id}
                  title={row.productName}
                  statusChip={<Chip size="small" label={row.status} color={row.status === 'Active' ? 'success' : 'default'} variant="outlined" />}
                  fields={[
                    { label: 'Product Code', value: row.productCode },
                    { label: 'Group', value: row.productGroup || '—' },
                    { label: 'Brand', value: row.brand || '—' },
                    { label: 'Sales Price', value: row.salesPrice != null ? `₹${Number(row.salesPrice).toFixed(2)}` : '—' },
                    { label: 'Stock', value: row.currentStock != null ? Number(row.currentStock) : '—' },
                  ]}
                  onView={() => handleView(row)}
                  onEdit={() => handleEdit(row)}
                  onDelete={() => handleDelete(row)}
                />
              ))}
              {!isLoading && filteredRows.length === 0 && (
                <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>No products found</Typography>
              )}
            </Box>
          ) : (
            <ScrollableTableContainer>
              <Table size="small" stickyHeader>
                <TableHead>
                  <TableRow>
                    <TableCell width={48}>#</TableCell>
                    <SortableHeaderCell field="productCode" sort={table.sort} onSort={table.toggleSort}>Product Code</SortableHeaderCell>
                    <SortableHeaderCell field="productName" sort={table.sort} onSort={table.toggleSort}>Product Name</SortableHeaderCell>
                    <SortableHeaderCell field="productGroup" sort={table.sort} onSort={table.toggleSort}>Group</SortableHeaderCell>
                    <SortableHeaderCell field="brand" sort={table.sort} onSort={table.toggleSort}>Brand</SortableHeaderCell>
                    <SortableHeaderCell field="salesPrice" sort={table.sort} onSort={table.toggleSort}>Sales Price</SortableHeaderCell>
                    <SortableHeaderCell field="currentStock" sort={table.sort} onSort={table.toggleSort}>Stock</SortableHeaderCell>
                    <SortableHeaderCell field="status" sort={table.sort} onSort={table.toggleSort}>Status</SortableHeaderCell>
                    <TableCell align="right">Action</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {!isLoading && pagedRows.map((row, i) => (
                    <TableRow key={row.id} hover>
                      <TableCell>{page * pageSize + i + 1}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.productCode}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.productName}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.productGroup || '—'}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.brand || '—'}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.salesPrice != null ? `₹${Number(row.salesPrice).toFixed(2)}` : '—'}</TableCell>
                      <TableCell sx={{ whiteSpace: 'nowrap' }}>{row.currentStock != null ? Number(row.currentStock) : '—'}</TableCell>
                      <TableCell>
                        <Chip size="small" label={row.status} color={row.status === 'Active' ? 'success' : 'default'} variant="outlined" />
                      </TableCell>
                      <TableCell align="right">
                        <Stack direction="row" spacing={0.5} justifyContent="flex-end">
                          <IconButton size="small" onClick={() => handleView(row)} aria-label="view">
                            <VisibilityOutlinedIcon fontSize="small" />
                          </IconButton>
                          <CanEdit>
                            <IconButton size="small" color="primary" onClick={() => handleEdit(row)} aria-label="edit">
                              <EditIcon fontSize="small" />
                            </IconButton>
                          </CanEdit>
                          <CanDelete>
                            <IconButton size="small" color="error" onClick={() => handleDelete(row)} aria-label="delete">
                              <DeleteIcon fontSize="small" />
                            </IconButton>
                          </CanDelete>
                        </Stack>
                      </TableCell>
                    </TableRow>
                  ))}
                  {!isLoading && filteredRows.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={9}>
                        <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>No products found</Typography>
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </ScrollableTableContainer>
          )}

          <EntityListPagination total={filteredRows.length} page={page} onChange={setPage} pageSize={pageSize} onPageSizeChange={(v) => { setPageSize(v); setPage(0); }} />
        </CardContent>
      </Card>
    </Box>
  );
}
