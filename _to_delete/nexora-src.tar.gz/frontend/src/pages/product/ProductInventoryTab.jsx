import React, { useEffect, useMemo, useState } from 'react';
import {
  Box, Typography, Table, TableBody, TableCell, TableHead, TableRow, TextField,
  Button, Stack, Alert, CircularProgress,
} from '@mui/material';
import SaveOutlinedIcon from '@mui/icons-material/SaveOutlined';
import ScrollableTableContainer from '../../components/data-display/ScrollableTableContainer';
import { useNotify } from '../../components/feedback/NotificationProvider';
import {
  useGetProductInventoryQuery, useSaveProductInventoryMutation,
} from '../../features/resources';

// Product Master > Inventory — one row per active warehouse, showing where this
// product's stock sits and what it is worth there.
//
// Everything except the two level columns is READ-ONLY and derived server-side
// from the stock movements and the open orders (see backend
// utils/productInventory.js). Nothing here is a stored quantity, which is what
// keeps it from ever disagreeing with the ledger it came from.
//
// Min and Max inventory level are the exception: they are policy, not
// observation, so they are editable and saved per product+warehouse.

const num = (v) => (v == null ? '' : Number(v).toLocaleString('en-IN', {
  minimumFractionDigits: 2, maximumFractionDigits: 2,
}));
const qty = (v) => {
  if (v == null) return '';
  const n = Number(v);
  return Number.isInteger(n) ? String(n) : n.toFixed(2);
};
// A derived figure that has no value is shown as an em dash rather than 0.00.
// Zero is a fact ("this warehouse holds none"); blank is the absence of one
// ("this product has never moved here, so it has no cost"). Printing 0.00 for
// the second would state a cost that was never paid.
const orDash = (formatted) => (formatted === '' ? '—' : formatted);

export default function ProductInventoryTab({ productCode, disabled }) {
  const notify = useNotify();
  // skip on create: there is no product yet to have stock, and the request
  // would 404 on a code that has not been issued.
  const { data, isLoading, isFetching } = useGetProductInventoryQuery(productCode, {
    skip: !productCode || disabled,
  });
  const [save, { isLoading: saving }] = useSaveProductInventoryMutation();

  // Levels are held locally while being typed and pushed on Save, rather than
  // written through on every keystroke — a per-character PUT would fight the
  // refetch and make the field jump under the cursor.
  const [levels, setLevels] = useState({});
  useEffect(() => {
    if (!data?.rows) return;
    const next = {};
    data.rows.forEach((r) => {
      next[r.warehouseCode] = {
        minInventoryLevel: r.minInventoryLevel ?? '',
        maxInventoryLevel: r.maxInventoryLevel ?? '',
      };
    });
    setLevels(next);
  }, [data]);

  const dirty = useMemo(() => {
    if (!data?.rows) return false;
    return data.rows.some((r) => {
      const local = levels[r.warehouseCode];
      if (!local) return false;
      const asValue = (v) => (v === '' || v == null ? null : Number(v));
      return asValue(local.minInventoryLevel) !== (r.minInventoryLevel ?? null)
        || asValue(local.maxInventoryLevel) !== (r.maxInventoryLevel ?? null);
    });
  }, [data, levels]);

  const setLevel = (warehouseCode, field, value) => setLevels((prev) => ({
    ...prev,
    [warehouseCode]: { ...prev[warehouseCode], [field]: value },
  }));

  const handleSave = async () => {
    try {
      await save({
        productCode,
        rows: Object.entries(levels).map(([warehouseCode, v]) => ({ warehouseCode, ...v })),
      }).unwrap();
      notify.success('Inventory levels saved');
    } catch (err) {
      notify.error(err?.data?.message || 'Could not save inventory levels');
    }
  };

  if (disabled) {
    return (
      <Alert severity="info">
        Inventory is available once the product has been saved — its stock is tracked
        against the product code, which is issued on save.
      </Alert>
    );
  }

  if (isLoading) {
    return (
      <Stack alignItems="center" sx={{ py: 4 }}><CircularProgress size={28} /></Stack>
    );
  }

  const rows = data?.rows || [];
  const totals = data?.totals;

  return (
    <Box>
      {/* Ordered and Committed are stated once, for the product as a whole.
          Purchase and sales orders record a branch but no warehouse, so there
          is nothing to split them by — showing a per-warehouse figure would
          mean inventing an attribution. Said plainly here rather than left for
          someone to discover from empty columns. */}
      <Alert severity="info" sx={{ mb: 2 }}>
        <Typography variant="caption">
          <b>Ordered</b> and <b>Committed</b> are product-wide totals: purchase and sales
          orders record a branch, not a warehouse, so they cannot be attributed to one.
          {totals?.unassignedOnHand ? (
            <>
              {' '}<b>{qty(totals.unassignedOnHand)}</b> of the on-hand quantity is
              unassigned — opening stock and movements from documents that carry no
              warehouse — so the warehouse rows total less than the figure below.
            </>
          ) : null}
        </Typography>
      </Alert>

      <ScrollableTableContainer>
        <Table size="small" stickyHeader>
          <TableHead>
            <TableRow>
              <TableCell>Warehouse</TableCell>
              <TableCell align="right">On Hand</TableCell>
              <TableCell align="right">Ordered</TableCell>
              <TableCell align="right">Committed</TableCell>
              <TableCell align="right">Available</TableCell>
              <TableCell>Branch</TableCell>
              <TableCell align="right">Item Cost</TableCell>
              <TableCell align="right">Moving Average Price</TableCell>
              <TableCell align="right">Average Price</TableCell>
              <TableCell align="right">FIFO Price</TableCell>
              <TableCell align="right">Min. Inventory Level</TableCell>
              <TableCell align="right">Max. Inventory Level</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.map((r) => (
              <TableRow key={r.warehouseCode} hover>
                <TableCell sx={{ whiteSpace: 'nowrap' }}>
                  {r.warehouseName}
                  <Typography variant="caption" color="text.secondary" sx={{ ml: 0.75 }}>
                    {r.warehouseCode}
                  </Typography>
                </TableCell>
                <TableCell align="right">{qty(r.onHand)}</TableCell>
                <TableCell align="right">—</TableCell>
                <TableCell align="right">—</TableCell>
                <TableCell align="right">{qty(r.available)}</TableCell>
                <TableCell sx={{ whiteSpace: 'nowrap' }}>{r.branch || '—'}</TableCell>
                <TableCell align="right">{orDash(num(r.itemCost))}</TableCell>
                <TableCell align="right">{orDash(num(r.movingAveragePrice))}</TableCell>
                <TableCell align="right">{orDash(num(r.averagePrice))}</TableCell>
                <TableCell align="right">{orDash(num(r.fifoPrice))}</TableCell>
                <TableCell align="right">
                  <TextField
                    size="small" type="number" placeholder="—"
                    value={levels[r.warehouseCode]?.minInventoryLevel ?? ''}
                    onChange={(e) => setLevel(r.warehouseCode, 'minInventoryLevel', e.target.value)}
                    inputProps={{ style: { textAlign: 'right' } }}
                    sx={{ width: 96 }}
                  />
                </TableCell>
                <TableCell align="right">
                  <TextField
                    size="small" type="number" placeholder="—"
                    value={levels[r.warehouseCode]?.maxInventoryLevel ?? ''}
                    onChange={(e) => setLevel(r.warehouseCode, 'maxInventoryLevel', e.target.value)}
                    inputProps={{ style: { textAlign: 'right' } }}
                    sx={{ width: 96 }}
                  />
                </TableCell>
              </TableRow>
            ))}

            {rows.length === 0 && (
              <TableRow>
                <TableCell colSpan={12}>
                  <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 3 }}>
                    No active warehouses — add one under Company Setup &gt; Warehouse Master.
                  </Typography>
                </TableCell>
              </TableRow>
            )}

            {/* The only row where Ordered, Committed and a true available-to-
                promise figure can honestly appear. Available here is SAP's
                definition: on hand, less what is already sold, plus what is
                already on its way in. */}
            {totals && (
              <TableRow sx={{ '& td': { fontWeight: 700, borderTop: 2, borderColor: 'divider' } }}>
                <TableCell>Total (all warehouses)</TableCell>
                <TableCell align="right">{qty(totals.onHand)}</TableCell>
                <TableCell align="right">{qty(totals.ordered)}</TableCell>
                <TableCell align="right">{qty(totals.committed)}</TableCell>
                <TableCell align="right">{qty(totals.available)}</TableCell>
                <TableCell colSpan={7} />
              </TableRow>
            )}
          </TableBody>
        </Table>
      </ScrollableTableContainer>

      <Stack direction="row" justifyContent="flex-end" alignItems="center" spacing={1.5} sx={{ mt: 2 }}>
        {isFetching && <CircularProgress size={16} />}
        {/* Its own Save, not the form's. The levels live in a different table
            reached by a different endpoint, so rolling them into Save Product
            would make one button write two records and half-succeed. */}
        <Button
          variant="outlined"
          startIcon={<SaveOutlinedIcon />}
          onClick={handleSave}
          disabled={!dirty || saving}
        >
          {saving ? 'Saving…' : 'Save Inventory Levels'}
        </Button>
      </Stack>
    </Box>
  );
}
