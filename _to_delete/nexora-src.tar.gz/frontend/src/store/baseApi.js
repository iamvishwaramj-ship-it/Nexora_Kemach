import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import { Mutex } from 'async-mutex';
import { accessTokenRefreshed, loggedOut } from './authSlice';

const BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5001';

const rawBaseQuery = fetchBaseQuery({
  baseUrl: `${BASE_URL}/api`,
  prepareHeaders: (headers, { getState }) => {
    const token = getState().auth.accessToken;
    if (token) headers.set('Authorization', `Bearer ${token}`);
    return headers;
  },
});

const mutex = new Mutex();

// Single source of truth for every network call in the app — RTK Query.
// Never hand-roll fetch/axios calls inside components; inject endpoints
// onto this baseApi per domain (see features/<domain>/<domain>Api.js).
const baseQueryWithReauth = async (args, api, extraOptions) => {
  await mutex.waitForUnlock();
  let result = await rawBaseQuery(args, api, extraOptions);

  if (result.error && result.error.status === 401) {
    if (!mutex.isLocked()) {
      const release = await mutex.acquire();
      try {
        const refreshToken = api.getState().auth.refreshToken;
        if (refreshToken) {
          const refreshResult = await rawBaseQuery(
            { url: '/auth/refresh', method: 'POST', body: { refreshToken } },
            api,
            extraOptions
          );
          if (refreshResult.data?.accessToken) {
            api.dispatch(accessTokenRefreshed({ accessToken: refreshResult.data.accessToken }));
            result = await rawBaseQuery(args, api, extraOptions);
          } else {
            api.dispatch(loggedOut());
          }
        } else {
          api.dispatch(loggedOut());
        }
      } finally {
        release();
      }
    } else {
      await mutex.waitForUnlock();
      result = await rawBaseQuery(args, api, extraOptions);
    }
  }

  return result;
};

export const baseApi = createApi({
  reducerPath: 'api',
  baseQuery: baseQueryWithReauth,
  // Every tag a resource uses must be declared here. RTK Query silently
  // ignores an undeclared tag — no warning in production — so a resource
  // whose type is missing from this list still *provides* and *invalidates*
  // as far as the calling code is concerned, but nothing ever refetches.
  // SalesPrice, CustomerDiscount, Transport, AppUser, Enquiry and FollowUp
  // were all in that state: creating, editing or deleting one left its list
  // showing the pre-change data until a hard reload.
  tagTypes: [
    'Health', 'Me',
    'Company', 'Branch', 'FinancialYear', 'TaxCode', 'DocumentNumbering',
    'BankName', 'HouseBank', 'SalesEmployee', 'ApprovalFlow',
    'AccountGroup', 'AccountType', 'ChartOfAccount',
    'ProductGroup', 'ProductSubGroup', 'Brand', 'Uom', 'Product', 'ProductCatalog',
    'PurchasePrice', 'SalesPrice', 'CustomerDiscount',
    'Customer', 'Supplier', 'Transport', 'Warehouse', 'Location', 'AppUser',
    'WarehouseMaster', 'LocationMaster', 'OpeningBalance',
    'PurchaseQuotation', 'PurchaseOrder', 'GoodsReceivedNote', 'PurchaseInvoice',
    'SalesQuotation', 'SalesOrder', 'DeliveryChallan', 'SalesInvoice',
    'Enquiry', 'FollowUp',
    'StockReceipt', 'StockIssue', 'StockAdjustment', 'StockTransfer',
    'CustomerOutstanding', 'Collection', 'SupplierOutstanding', 'SupplierPayment',
    'BankDeposit', 'BankReconciliation', 'Cheque', 'PaymentReceipt', 'PaymentVoucher',
    'Dashboard',
  ],
  endpoints: () => ({}),
});
