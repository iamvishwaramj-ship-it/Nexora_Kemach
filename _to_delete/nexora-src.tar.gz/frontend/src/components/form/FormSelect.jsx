import React from 'react';
import { Controller, useFormContext } from 'react-hook-form';
import { Autocomplete, TextField } from '@mui/material';
import { useFormReadOnly } from './AppForm';

// Any select with more than a handful of options must be type-to-filter —
// this wraps MUI's Autocomplete, never a plain static <select>.
// options: [{ label, value }]
//
// `emptyValue` opts a select into "there is no unselected state" behaviour,
// for report filters that carry an explicit All Customers / All Status /
// All Sources option. Pass the value that option holds (normally '').
//
// Without it, a filter looks unset in two situations even though it isn't:
// clearing the field with the Autocomplete's × writes null, which matches no
// option and leaves the box blank, and a field the form never initialised
// reads undefined and does the same. In both cases the report is still
// unfiltered on that column — "blank" and "All" mean exactly the same thing
// to the query — so showing a blank box states something the report is not
// doing. With `emptyValue` set, both cases resolve to the All option and the
// × snaps back to it instead of emptying the field.
export default function FormSelect({
  name, label, options = [], fullWidth = true, multiple = false, size = 'small', emptyValue, ...rest
}) {
  const readOnly = useFormReadOnly();
  const { control } = useFormContext();
  const hasEmptyValue = emptyValue !== undefined;
  return (
    <Controller
      name={name}
      control={control}
      render={({ field, fieldState: { error } }) => {
        // null/undefined collapse onto the All option when one is declared.
        const current = !multiple && hasEmptyValue && field.value == null ? emptyValue : field.value;
        const selected = multiple
          ? options.filter((o) => (field.value || []).includes(o.value))
          : options.find((o) => o.value === current) || null;

        return (
          <Autocomplete
            options={options}
            multiple={multiple}
            value={selected}
            size={size}
            isOptionEqualToValue={(o, v) => o.value === v.value}
            getOptionLabel={(o) => o.label || ''}
            onChange={(_e, newValue) => {
              if (multiple) {
                field.onChange(newValue.map((v) => v.value));
                return;
              }
              // Clearing a filter means "All", not "nothing".
              field.onChange(newValue?.value ?? (hasEmptyValue ? emptyValue : null));
            }}
            // Autocomplete doesn't forward a bare onBlur the way a plain input
            // does — without wiring it through explicitly, RHF never learns
            // this field was visited, so in 'onTouched' mode (see AppForm) a
            // required select could be focused and left empty and never show
            // its error: the field simply never entered the `touched` set.
            onBlur={field.onBlur}
            renderInput={(params) => (
              <TextField
                {...params}
                label={label}
                error={!!error}
                helperText={error?.message || ' '}
                FormHelperTextProps={{ sx: { mx: 0, mt: 0.25, minHeight: '1.1em', lineHeight: 1.3 } }}
              />
            )}
            fullWidth={fullWidth}
            {...rest}
            // A read-only form disables its fields; an explicit
            // disabled still applies while editing.
            disabled={readOnly || rest.disabled}
          />
        );
      }}
    />
  );
}
