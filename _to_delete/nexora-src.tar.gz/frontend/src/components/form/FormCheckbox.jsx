import React from 'react';
import { Controller, useFormContext } from 'react-hook-form';
import { FormControlLabel, Checkbox, Switch } from '@mui/material';
import { useFormReadOnly } from './AppForm';

export function FormCheckbox({ name, label }) {
  const readOnly = useFormReadOnly();
  const { control } = useFormContext();
  return (
    <Controller
      name={name}
      control={control}
      render={({ field }) => (
        <FormControlLabel control={<Checkbox {...field} checked={!!field.value} disabled={readOnly} />} label={label} />
      )}
    />
  );
}

export function FormSwitch({ name, label }) {
  const readOnly = useFormReadOnly();
  const { control } = useFormContext();
  return (
    <Controller
      name={name}
      control={control}
      render={({ field }) => (
        <FormControlLabel control={<Switch {...field} checked={!!field.value} disabled={readOnly} />} label={label} />
      )}
    />
  );
}
