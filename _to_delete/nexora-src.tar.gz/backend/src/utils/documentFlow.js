/**
 * Document flow — how far an order has been fulfilled, and what that makes its
 * status.
 *
 * Nothing tracked this before. A purchase order stayed 'Open' no matter how
 * many goods receipts were posted against it; a sales order stayed 'Draft' or
 * whatever it was last saved as, however much had been delivered and invoiced.
 * Partial fulfilment could not be represented at all, so:
 *
 *   - the pending-order reports re-derived delivery status by string-matching
 *     document numbers and could not distinguish a part-delivered order from
 *     an untouched one;
 *   - nothing stopped a second full delivery being raised against an order
 *     that had already been delivered in full;
 *   - buyers had no way to see what was still on order.
 *
 * SAP models this with a quantity ledger per order line: ordered, delivered,
 * invoiced, and the open quantity that is the difference. This module does the
 * same thing with the linkage this schema actually has — a plain document
 * number on the follow-on document, since no foreign key exists between them.
 *
 * ## The rule for status
 *
 *   nothing fulfilled            -> 'Open'
 *   some but not all fulfilled   -> 'Partially Delivered' / 'Partially Received'
 *   every line fully fulfilled   -> 'Closed'
 *
 * A cancelled order is left alone: cancellation is a human decision and
 * recomputing over it would silently reopen something somebody closed.
 */

const { round2 } = require('./documentTotals');

/** Statuses whose documents are not real movements. */
const NON_MOVING_STATUSES = ['Draft', 'Cancelled', 'Pending'];

/** Order statuses this module will never overwrite. */
const TERMINAL_ORDER_STATUSES = ['Cancelled', 'Closed - Short', 'Rejected'];

/**
 * Sum a quantity field per product code across a set of documents' lines.
 *
 * Follow-on documents are matched to the order by document number. Lines with
 * no product code cannot be matched to an order line and are ignored rather
 * than being attributed to an arbitrary one.
 */
function sumByProduct(documents, { itemsKey = 'items', quantityField = 'quantity' } = {}) {
  const totals = new Map();
  for (const doc of documents) {
    for (const line of doc[itemsKey] || []) {
      const code = line.productCode;
      if (!code) continue;
      const qty = Number(line[quantityField]) || 0;
      if (qty === 0) continue;
      totals.set(code, round2((totals.get(code) || 0) + qty));
    }
  }
  return totals;
}

/**
 * Work out each order line's fulfilled quantity and the resulting header
 * status.
 *
 * @param {object[]} orderItems  the order's own lines (productCode, quantity)
 * @param {Map}      fulfilled   quantity fulfilled per product code
 * @param {string}   partialLabel status to use when some but not all is done
 */
function reconcileOrder(orderItems, fulfilled, partialLabel) {
  const lines = [];
  let anyFulfilled = false;
  let allFulfilled = true;

  // A product can appear on more than one line of the same order. Fulfilled
  // quantity is tracked per product, so it is consumed line by line in order
  // rather than being credited in full against every line that mentions it.
  const remaining = new Map(fulfilled);

  for (const item of orderItems) {
    const ordered = Number(item.quantity) || 0;
    const code = item.productCode;
    const available = code ? (remaining.get(code) || 0) : 0;
    const applied = round2(Math.min(ordered, available));

    if (code) remaining.set(code, round2(available - applied));

    if (applied > 0.005) anyFulfilled = true;
    if (applied + 0.005 < ordered) allFulfilled = false;

    lines.push({ id: item.id, productCode: code, ordered, fulfilled: applied });
  }

  // An order with no lines is not "fully delivered" — it is untouched.
  if (!orderItems.length) allFulfilled = false;

  let status = 'Open';
  if (allFulfilled) status = 'Closed';
  else if (anyFulfilled) status = partialLabel;

  return { lines, status, anyFulfilled, allFulfilled };
}

/**
 * Recompute one sales order's delivered/invoiced quantities and status.
 *
 * Delivery drives the status: an order is closed when everything ordered has
 * been despatched, which is what the warehouse and the customer care about.
 * Invoiced quantity is tracked alongside for the billing view, but a fully
 * delivered order that has not been invoiced yet is still 'Closed' on the
 * delivery side — matching how the challan is the fulfilling document.
 *
 * When no delivery challan exists at all, the invoice is treated as the
 * fulfilling document, exactly as the stock ledger does — otherwise a one-step
 * sale (invoice, no challan) would leave its order open forever.
 */
async function recomputeSalesOrder(tx, orderNo) {
  if (!orderNo) return null;

  const order = await tx.salesOrder.findFirst({
    where: { orderNo },
    include: { items: { orderBy: { id: 'asc' } } },
  });
  if (!order) return null;
  if (TERMINAL_ORDER_STATUSES.includes(order.status)) return order;

  const [challans, invoices] = await Promise.all([
    tx.deliveryChallan.findMany({
      where: { orderNo, status: { notIn: NON_MOVING_STATUSES } },
      include: { items: true },
    }),
    tx.salesInvoice.findMany({
      where: { orderNo, status: { notIn: ['Draft', 'Cancelled'] } },
      include: { items: true },
    }),
  ]);

  const delivered = sumByProduct(challans);
  const invoiced = sumByProduct(invoices);

  // One-step flow: no challan was ever raised, so the invoice is what
  // fulfilled the order.
  const fulfilment = challans.length ? delivered : invoiced;

  const { lines, status } = reconcileOrder(order.items, fulfilment, 'Partially Delivered');
  const invoicedLines = reconcileOrder(order.items, invoiced, 'Partially Invoiced').lines;
  const invoicedById = new Map(invoicedLines.map((l) => [l.id, l.fulfilled]));

  await Promise.all(
    lines.map((line) =>
      tx.salesOrderItem.update({
        where: { id: line.id },
        data: {
          deliveredQuantity: challans.length ? line.fulfilled : 0,
          invoicedQuantity: invoicedById.get(line.id) || 0,
        },
      })
    )
  );

  await tx.salesOrder.update({ where: { id: order.id }, data: { status } });
  return { ...order, status };
}

/**
 * Recompute one purchase order's received/invoiced quantities and status.
 *
 * Mirrors the sales side: the goods receipt is the fulfilling document, and
 * the purchase invoice stands in for it when no GRN exists.
 */
async function recomputePurchaseOrder(tx, poNo) {
  if (!poNo) return null;

  const order = await tx.purchaseOrder.findFirst({
    where: { poNo },
    include: { items: { orderBy: { id: 'asc' } } },
  });
  if (!order) return null;
  if (TERMINAL_ORDER_STATUSES.includes(order.status)) return order;

  const [grns, invoices] = await Promise.all([
    tx.goodsReceivedNote.findMany({
      where: { poNo, status: { notIn: NON_MOVING_STATUSES } },
      include: { items: true },
    }),
    tx.purchaseInvoice.findMany({
      where: { poNo, status: { notIn: ['Draft', 'Cancelled'] } },
      include: { items: true },
    }),
  ]);

  const received = sumByProduct(grns, { quantityField: 'receivedQuantity' });
  const invoiced = sumByProduct(invoices);
  const fulfilment = grns.length ? received : invoiced;

  const { lines, status } = reconcileOrder(order.items, fulfilment, 'Partially Received');
  const invoicedLines = reconcileOrder(order.items, invoiced, 'Partially Invoiced').lines;
  const invoicedById = new Map(invoicedLines.map((l) => [l.id, l.fulfilled]));

  await Promise.all(
    lines.map((line) =>
      tx.purchaseOrderItem.update({
        where: { id: line.id },
        data: {
          receivedQuantity: grns.length ? line.fulfilled : 0,
          invoicedQuantity: invoicedById.get(line.id) || 0,
        },
      })
    )
  );

  await tx.purchaseOrder.update({ where: { id: order.id }, data: { status } });
  return { ...order, status };
}

/**
 * Reject a delivery that would despatch more than the order calls for.
 *
 * The purchase side has had this check since round 1 (assertNoOverReceipt);
 * the sales side had nothing, so an order for 10 could be delivered three
 * times over without complaint. `excludeChallanNo` lets an edit exclude its
 * own previous lines, so re-saving a challan does not measure itself as extra.
 */
async function assertNoOverDelivery(tx, { orderNo, items, excludeChallanNo = null }) {
  if (!orderNo) return;

  const order = await tx.salesOrder.findFirst({
    where: { orderNo },
    include: { items: true },
  });
  if (!order) return; // A challan raised without an order is unconstrained.

  const priorChallans = await tx.deliveryChallan.findMany({
    where: {
      orderNo,
      status: { notIn: NON_MOVING_STATUSES },
      ...(excludeChallanNo ? { challanNo: { not: excludeChallanNo } } : {}),
    },
    include: { items: true },
  });

  const ordered = sumByProduct([order]);
  const alreadyDelivered = sumByProduct(priorChallans);
  const nowDelivering = sumByProduct([{ items }]);

  const offending = [];
  for (const [code, qty] of nowDelivering) {
    const orderedQty = ordered.get(code) || 0;
    if (orderedQty <= 0) continue; // Not on the order — treat as a free line.
    const cumulative = round2((alreadyDelivered.get(code) || 0) + qty);
    if (cumulative > orderedQty + 0.005) {
      offending.push(`${code}: delivering ${cumulative} against an ordered quantity of ${orderedQty}`);
    }
  }

  if (offending.length) {
    const err = new Error(
      `Delivered quantity exceeds the order — ${offending.join('; ')}`
    );
    err.status = 400;
    throw err;
  }
}

module.exports = {
  sumByProduct,
  reconcileOrder,
  recomputeSalesOrder,
  recomputePurchaseOrder,
  assertNoOverDelivery,
  NON_MOVING_STATUSES,
  TERMINAL_ORDER_STATUSES,
};
