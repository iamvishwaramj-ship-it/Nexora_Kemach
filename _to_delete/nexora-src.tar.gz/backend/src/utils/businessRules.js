/**
 * Business rules that guard postings: credit control and master-data
 * integrity.
 *
 * Both address the same class of problem — the application captured a control
 * and then never applied it.
 */

const { round2 } = require('./documentTotals');

/** Statuses whose documents do not represent real exposure. */
const UNREALISED = ['Draft', 'Cancelled'];

/**
 * Enforce a customer's credit limit.
 *
 * `Customer.creditLimit` was captured on the master, displayed in the
 * outstanding report, and never once checked. An order or invoice could be
 * raised for any amount for any customer, however far past their limit they
 * already were — which is the entire point of having a credit limit.
 *
 * Exposure is measured the way a credit controller would: what the customer
 * already owes on open invoices, plus what this document is about to add. A
 * limit of zero or null means "no limit set", not "no credit allowed" —
 * treating an unconfigured master as a hard block would stop every sale on day
 * one.
 *
 * `excludeDocumentNo` lets an edit exclude its own prior contribution, so
 * re-saving an invoice does not count it twice.
 */
async function assertWithinCreditLimit(tx, {
  customerName,
  documentAmount,
  excludeInvoiceNo = null,
  documentLabel = 'document',
}) {
  if (!customerName) return null;

  const customer = await tx.customer.findFirst({
    where: { customerName },
    select: { creditLimit: true, customerName: true, status: true },
  });
  if (!customer) return null;

  const limit = Number(customer.creditLimit) || 0;
  if (limit <= 0) return null; // No limit configured.

  const openItems = await tx.customerOutstanding.findMany({
    where: {
      customerName,
      status: { not: 'Paid' },
      ...(excludeInvoiceNo ? { invoiceNo: { not: excludeInvoiceNo } } : {}),
    },
    select: { balanceAmount: true },
  });

  const currentExposure = round2(
    openItems.reduce((sum, i) => sum + (Number(i.balanceAmount) || 0), 0)
  );
  const newExposure = round2(currentExposure + (Number(documentAmount) || 0));

  if (newExposure > limit + 0.005) {
    const err = new Error(
      `${customerName} would exceed their credit limit. `
      + `Limit ${limit.toFixed(2)}, already outstanding ${currentExposure.toFixed(2)}, `
      + `this ${documentLabel} ${(Number(documentAmount) || 0).toFixed(2)} `
      + `— ${(newExposure - limit).toFixed(2)} over.`
    );
    err.status = 409;
    err.code = 'CREDIT_LIMIT_EXCEEDED';
    throw err;
  }

  return { limit, currentExposure, newExposure, available: round2(limit - newExposure) };
}

/**
 * Where each master record's identity appears across the transaction tables.
 *
 * Customers, suppliers and products are linked to every transaction by a plain
 * string with no foreign key, so the database cannot refuse a delete that
 * orphans history the way it would for a real relation. Deleting a customer
 * left their invoices pointing at a name that no longer existed: the
 * outstanding report still showed the debt, nothing could be collected against
 * it, and no screen explained where the customer had gone.
 *
 * These maps drive both the delete guard and the rename cascade.
 */
const REFERENCE_MAP = {
  customer: {
    label: 'customer',
    masterDelegate: (c) => c.customer,
    nameField: 'customerName',
    references: [
      { delegate: (c) => c.salesQuotation, field: 'customer', label: 'sales quotation' },
      { delegate: (c) => c.salesOrder, field: 'customer', label: 'sales order' },
      { delegate: (c) => c.deliveryChallan, field: 'customer', label: 'delivery challan' },
      { delegate: (c) => c.salesInvoice, field: 'customer', label: 'sales invoice' },
      { delegate: (c) => c.customerOutstanding, field: 'customerName', label: 'outstanding invoice' },
      { delegate: (c) => c.collection, field: 'customerName', label: 'collection' },
      // PaymentReceipt shares one partyName column across Customer/Vendor/
      // Account (see schema.prisma) — extraWhere scopes the count/rename to
      // rows actually posted as a Customer, so a same-named Vendor or
      // Account row is never counted or renamed by mistake.
      { delegate: (c) => c.paymentReceipt, field: 'partyName', extraWhere: { partyType: 'Customer' }, label: 'payment receipt' },
      { delegate: (c) => c.salesPrice, field: 'customer', label: 'sales price' },
      { delegate: (c) => c.customerDiscount, field: 'customer', label: 'customer discount' },
    ],
  },
  supplier: {
    label: 'supplier',
    masterDelegate: (c) => c.supplier,
    nameField: 'supplierName',
    references: [
      { delegate: (c) => c.purchaseQuotation, field: 'supplier', label: 'purchase quotation' },
      { delegate: (c) => c.purchaseOrder, field: 'supplier', label: 'purchase order' },
      { delegate: (c) => c.goodsReceivedNote, field: 'supplier', label: 'goods received note' },
      { delegate: (c) => c.purchaseInvoice, field: 'supplier', label: 'purchase invoice' },
      { delegate: (c) => c.supplierOutstanding, field: 'supplierName', label: 'outstanding invoice' },
      { delegate: (c) => c.supplierPayment, field: 'supplierName', label: 'payment' },
      // Same partyType scoping as the customer side above, so a same-named
      // Customer or Account row is never counted or renamed by mistake.
      { delegate: (c) => c.paymentReceipt, field: 'partyName', extraWhere: { partyType: 'Vendor' }, label: 'payment receipt' },
      // Same partyName-sharing story as PaymentReceipt, scoped to Vendor —
      // PaymentVoucher's Account rows are never counted or renamed here.
      { delegate: (c) => c.paymentVoucher, field: 'partyName', extraWhere: { partyType: 'Vendor' }, label: 'payment voucher' },
      { delegate: (c) => c.purchasePrice, field: 'supplier', label: 'purchase price' },
    ],
  },
  product: {
    label: 'product',
    masterDelegate: (c) => c.product,
    nameField: 'productCode',
    references: [
      { delegate: (c) => c.salesInvoiceItem, field: 'productCode', label: 'sales invoice' },
      { delegate: (c) => c.salesOrderItem, field: 'productCode', label: 'sales order' },
      { delegate: (c) => c.deliveryChallanItem, field: 'productCode', label: 'delivery challan' },
      { delegate: (c) => c.purchaseInvoiceItem, field: 'productCode', label: 'purchase invoice' },
      { delegate: (c) => c.purchaseOrderItem, field: 'productCode', label: 'purchase order' },
      { delegate: (c) => c.goodsReceivedNoteItem, field: 'productCode', label: 'goods received note' },
      { delegate: (c) => c.stockReceiptItem, field: 'productCode', label: 'stock receipt' },
      { delegate: (c) => c.stockIssueItem, field: 'productCode', label: 'stock issue' },
      { delegate: (c) => c.stockAdjustmentItem, field: 'productCode', label: 'stock adjustment' },
    ],
  },
};

/**
 * Refuse to delete a master record that transactions still refer to.
 *
 * Reports the first few document types that reference it, with counts, so the
 * user knows what to deal with rather than just being told "no".
 */
async function assertNotReferenced(tx, kind, identity) {
  const spec = REFERENCE_MAP[kind];
  if (!spec || !identity) return;

  const counts = await Promise.all(
    spec.references.map(async (ref) => ({
      label: ref.label,
      count: await ref.delegate(tx).count({ where: { [ref.field]: identity, ...(ref.extraWhere || {}) } }),
    }))
  );

  const used = counts.filter((c) => c.count > 0);
  if (!used.length) return;

  const detail = used
    .slice(0, 4)
    .map((u) => `${u.count} ${u.label}${u.count === 1 ? '' : 's'}`)
    .join(', ');
  const more = used.length > 4 ? `, and ${used.length - 4} more` : '';

  const err = new Error(
    `"${identity}" cannot be deleted — it is referenced by ${detail}${more}. `
    + `Set its status to Inactive instead, so the history stays readable.`
  );
  err.status = 409;
  err.code = 'MASTER_IN_USE';
  throw err;
}

/**
 * Carry a master rename across every transaction that names it.
 *
 * Without this, renaming a customer detached them from their entire history in
 * one save: the invoices kept the old string, the customer master had the new
 * one, and nothing joined them again.
 */
async function cascadeRename(tx, kind, previousIdentity, nextIdentity) {
  const spec = REFERENCE_MAP[kind];
  if (!spec || !previousIdentity || !nextIdentity) return 0;
  if (previousIdentity === nextIdentity) return 0;

  let updated = 0;
  for (const ref of spec.references) {
    const result = await ref.delegate(tx).updateMany({
      where: { [ref.field]: previousIdentity, ...(ref.extraWhere || {}) },
      data: { [ref.field]: nextIdentity },
    });
    updated += result.count || 0;
  }
  return updated;
}

/**
 * Reject a transaction naming a party or product that does not exist.
 *
 * A typo in the customer field used to create a phantom customer that appeared
 * in every report grouped by customer name, with real money attached to it and
 * no master record behind it.
 */
async function assertMasterExists(tx, kind, identity, { allowBlank = true } = {}) {
  if (!identity) {
    if (allowBlank) return;
    const err = new Error(`A ${REFERENCE_MAP[kind]?.label || kind} is required`);
    err.status = 400;
    throw err;
  }

  const spec = REFERENCE_MAP[kind];
  if (!spec) return;

  const found = await spec.masterDelegate(tx).findFirst({
    where: { [spec.nameField]: identity },
    select: { id: true },
  });
  if (found) return;

  const err = new Error(
    `No ${spec.label} named "${identity}" exists. Create the ${spec.label} first, `
    + `or pick an existing one.`
  );
  err.status = 400;
  err.code = 'MASTER_NOT_FOUND';
  throw err;
}

module.exports = {
  assertWithinCreditLimit,
  assertNotReferenced,
  cascadeRename,
  assertMasterExists,
  REFERENCE_MAP,
};
